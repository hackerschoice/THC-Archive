/*
 * (c) 2004 by van Hauser / THC <vh@thc.org>
 * Code inspiration by Stealth
 *
 */

#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <fcntl.h>
#include <time.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <sys/poll.h>
#include <sys/resource.h>
#include <signal.h>
#include <errno.h>
#ifdef PCRE
 #include <pcre.h>
#endif
#include "is.h"

extern int errno;
char *prg;
char *trigger = TRIGGER;
int triggerlen;
int timeout_connect = TIMEOUT_CONNECT;
int timeout_recv = TIMEOUT_RECV;
int max_sock = SUPER_MAX_FD;
int cur_sock = 0;
struct sockaddr_in sain;
is_sockets *issptr;
int massconnect = 0;
int usecs = 0;
int done = 0;
int is_connect_done = 0;
int is_send_done = 0;
int is_recv_done = 0;
unsigned long int count_ips = 1;
unsigned long int count_all = 0;
unsigned long int count_connects = 0;
unsigned long int count_responses = 0;

/********/

void
help()
{
  printf("%s %s (c) 2004 by %s\n\n", PROGRAM, VERSION, AUTHOR);
  printf("Syntax: %s [OPTIONS] 127.0.0.0-127.0.255.255\n", prg);
  printf(
    " Connection Optimization Options:\n"
    "  -M          massconnect (connect as many connections each time as possible)\n"
    "  -s sockets  maximum sockets to use (default: %d, max: %d)\n"
    "  -u usecs    wait usecs prior makeing the next connection (default: %d)\n"
    "  -P usecs    wait usecs during polling (default: %d)\n"
    "  -t seconds  timeout in seconds for connects and responses (default: %d)\n"
    " Data Collection Options:\n"
    "  -p port     port to check (default: %d)\n"
    "  -f file     file with the trigger data to send. (default: \"HEAD / HTTP/1.0\")\n"
    "  -G expr     grep and save only lines matching this regex [REQUIRES PCRE]\n"
    "  -g          save only the Server: lines (like -G \"^Server:\")\n"
    "\n", MAX_FD, SUPER_MAX_FD, usecs, POLLWAIT, TIMEOUT_CONNECT, PORT);
    printf("%s scans large ranges for a port, sends a trigger and dumps the\nresponses. Speeds up to 1000 connections per second. Use allowed only for legal\npurposes. Check for updates at %s. Code inspiration by Stealth.\n", PROGRAM, WEB);
    printf("Config hints:\n"
           "  Internet Server: -s 2048 -M (set -s between 1024-5120, depends on dst nets)\n"
           "  DSL Connection:  -s 768 -u 10 -P 150 (you have to play with all options)\n"
           );
    printf("WARNING: THIS IS NOT A PUBLIC RELEASE! IF YOU ARE NOT THC, YOU MAY NOT USE IT!\n");
  exit(-1);
}

/********/

void
sig_alarm(int signal)
{
  return;
}

/********/

char *
is_inet_ntoa(struct in_addr *in) {
#ifdef CYGWIN
  return (char *) inet_ntoa(*in);
#else
  static char out[16];
  return (char *) inet_ntop(AF_INET, in, (char *) &out, sizeof(out));
#endif
}

/********/

void
is_wipe_iss(is_sockets * iss)
{
  int error = 0;
  int len = sizeof(error);

  getsockopt(iss->socket, SOL_SOCKET, SO_ERROR, &error, &len);
  shutdown(iss->socket, SHUT_RDWR);
  iss->active = 0;
  --cur_sock;
  close(iss->socket);
  iss->socket = -1;
}

/********/

is_scanblock *
is_init(char *range, int port)
{
  struct in_addr ia;
  char *ptr = range, *idx;
  is_scanblock *sb = (is_scanblock *) malloc(sizeof(is_scanblock));

  if ((idx = index(ptr, '-')) == NULL)
    return NULL;
  *idx++ = 0;
#ifdef CYGWIN
  if (inet_aton(ptr, &ia) <= 0)
    return NULL;
#else
  if (inet_pton(AF_INET, ptr, &ia) <= 0)
    return NULL;
#endif
  sb->sip = sb->cip = ia.s_addr;
#ifdef CYGWIN
  if (inet_aton(idx, &ia) <= 0)
    return NULL;
#else
  if (inet_pton(AF_INET, idx, &ia) <= 0)
    return NULL;
#endif
  sb->eip = ia.s_addr;
  sb->eip = ntohl(sb->eip);     /* yes we save it NOT in network format */
  sb->cip = ntohl(sb->cip);     /* this is converted back some lines later */

  while (((sb->cip & 0x0000ff) == 0x000000ff) || ((sb->cip | 0xffffff00) == 0xffffff00)) {
    sb->cip++;
    ++count_ips;
  }
  if (sb->cip > sb->eip)
    return NULL;
  sb->cip = htonl(sb->cip);

  memset(&sain, 0, sizeof(sain));
  sain.sin_port = htons(port);
  sain.sin_family = AF_INET;

  return (sb);
}

/********/

void
is_next_ip(is_scanblock * sb)
{
  sb->cip = ntohl(sb->cip) + 1;
  while ((sb->cip <= sb->eip && sb->cip != 0x00000000) && ((sb->cip & 0x000000ff) == 0x000000ff) || ((sb->cip | 0xffffff00) == 0xffffff00)) {
    sb->cip++;
    ++count_ips;
  }
  if (sb->cip > sb->eip || sb->cip == 0x00000000) {
    is_connect_done = 1;
    if (sb->cip - sb->eip > 1)
      count_ips -= ((sb->cip - sb->eip) - 1);
  } else {
    sb->cip = htonl(sb->cip);
    ++count_ips;
  }
}

/********/

int
is_connect(is_scanblock * sb)
{
  int i = 0;
  int s;
  int res;

  if (is_connect_done || cur_sock >= max_sock)
    return -1;

  if ((s = socket(PF_INET, SOCK_STREAM, 0)) >= 0) {
    res = 1;
    setsockopt(s, SOL_SOCKET, SO_REUSEADDR, &res, sizeof(res));
    if (fcntl(s, F_SETFL, O_NONBLOCK) >= 0) {
      sain.sin_addr.s_addr = sb->cip;
      if (usecs > 0)
        usleep(usecs);
      if (connect(s, (struct sockaddr *) &sain, sizeof(sain)) < 0 && errno != EINPROGRESS) {
        if (errno == ENETUNREACH || errno == EACCES || errno == EPERM) {

          fprintf(stderr, "Error: IP %s produced errors, skipping: %s",
            (char *) is_inet_ntoa((struct in_addr*)&sb->cip),
            strerror(errno));
          shutdown(s, SHUT_RDWR);
          close(s);
          is_next_ip(sb);
          return 0;
        }
      } else {
        while (issptr[i].active != 0)
          i++;
        issptr[i].ip = sb->cip;
        issptr[i].socket = s;
        issptr[i].active = POLLOUT;
        issptr[i].time = time(NULL);
        ++cur_sock;
        ++count_all;
        is_next_ip(sb);
        return s;
      }
    } else {
      shutdown(s, SHUT_RDWR);
      close(s);
      s = -1;
      return 0;
    }
  } else
    return -1;
  return s;
}

/********/

int
is_connect_start(is_scanblock * sb)
{
  int s = 0;

  while (cur_sock < max_sock && s >= 0 && is_connect_done == 0) {
    s = is_connect(sb);
  };
  
  return 0;
}

/********/

int
main(int argc, char *argv[])
{
  is_scanblock *sb;
  int port = PORT;
  struct rlimit rlim = { SUPER_MAX_FD, SUPER_MAX_FD };
  int i = setrlimit(RLIMIT_NOFILE, &rlim);      /* this is evil :-) int i is only there to call a function illegally here :-) */
  is_sockets iss[max_sock];
  struct sigaction sa;
  time_t time_start;
  struct pollfd pfd[max_sock];
  unsigned int nfds = 0;
  unsigned int iptr[max_sock];
  unsigned char rbuf[4096];
  int rlen, wlen, count, grepserver = 0, pollwait = POLLWAIT;
  unsigned long int readerrors = 0, writeerrors = 0;
  char datetime[24];
  struct tm *the_time;
  time_t cur_time, poll_time;
  char *ptr, *ptr2, *file = NULL, *expr = NULL, *range;
  FILE *f;
  struct stat st;
  int (*is_connect_ptr) (is_scanblock*);
#ifdef PCRE
  pcre *pattern;
  pcre_extra *hints;
  const char *error;
  int errptr;
  int offsets[16];
#endif

#ifdef _SC_OPEN_MAX
  max_sock = sysconf(_SC_OPEN_MAX) - 4;
  if (max_sock > MAX_FD)
    max_sock = MAX_FD;
#else
  max_sock = MAX_FD - 4;
#endif

  prg = argv[0];
  memset(iss, 0, sizeof(iss));
  issptr = iss;

  if (argc < 2 || strncmp(argv[1], "-h", 2) == 0 || strncmp(argv[1], "--h", 3) == 0)
    help();

  while ((i = getopt(argc, argv, "Mu:t:s:p:P:f:G:g")) >= 0) {
    switch(i) {
      case 'M': massconnect = 1;
        break;
      case 'u': usecs = atoi(optarg);
        break;
      case 't': timeout_connect =  atoi(optarg);
        break;
      case 's': max_sock = atoi(optarg);
                if (max_sock > SUPER_MAX_FD) {
                  max_sock = SUPER_MAX_FD - 4;
                  fprintf(stderr, "Warning: Maximum for sockets is %d, setting to that value\n", SUPER_MAX_FD);
                }
                if (max_sock + 4 > SUPER_MAX_FD)
                  max_sock -= 4;
        break;
      case 'p': port = atoi(optarg);
        break;
      case 'P': pollwait = atoi(optarg);
        break;
      case 'f': file = optarg;
        break;
      case 'G': expr = optarg;
#ifndef PCRE
                fprintf(stderr, "Error: not compiled with PCRE support, type \"make pcre\"\n");
                exit(-1);
#endif
        break;
      case 'g': grepserver = 1;
        break;
      default:
        help();
    }
  }
  
  if (optind + 1 != argc)
    help();

  if (file != NULL)
    if ((f = fopen(file, "r")) != NULL) {
      fstat(fileno(f), &st);
      triggerlen = st.st_size;
      trigger = malloc(triggerlen);
      fread(trigger, 1, triggerlen, f);
    } else {
      fprintf(stderr, "Error: file %s could not be loaded: %s\n", file, strerror(errno));
      exit(-1);
    }
  else
    triggerlen = strlen(TRIGGER);

#ifdef PCRE
  if (expr != NULL) {
    pattern = pcre_compile(expr, PCRE_MULTILINE | PCRE_CASELESS | PCRE_DOTALL, &error, &errptr, NULL);
    if (pattern != NULL)
      hints = pcre_study(pattern, 0, &error);
    if (error != NULL) {
      fprintf(stderr, "Error: Invalid regex string\n");
      exit(-1);
    }
  }
#endif

  range = strdup(argv[argc-1]);
  if ((sb = is_init(argv[argc - 1], port)) == NULL) {
    fprintf(stderr, "Error: Invalid scanblock definition\n");
    exit(-1);
  }

  if (massconnect == 1)
    is_connect_ptr = &is_connect_start;
  else
    is_connect_ptr = &is_connect;

  memset(&sa, 0, sizeof(sa));
  sa.sa_handler = sig_alarm;
  sigaction(SIGALRM, &sa, NULL);

  time_start = time(NULL);
  the_time = localtime(&time_start);
  strftime(datetime, sizeof(datetime), "%Y-%m-%d %H:%M:%S", the_time);
  printf("Scanning range %s for port %d at %s\n\n", range, port, datetime);

  (void) is_connect_ptr(sb);
  do {
    if (!massconnect)
      (void) is_connect_ptr(sb);
    poll_time = time(NULL);
    nfds = 0;
    memset(pfd, 0, sizeof(pfd));
    for (i = 0; i < max_sock; i++) {
      pfd[nfds].fd = issptr[i].socket;
      pfd[nfds].events = issptr[i].active;
      iptr[nfds] = i;
      ++nfds;
    }
    if (poll(pfd, nfds, pollwait) > 0)
      for (i = 0; i < nfds; i++) {
        if ((pfd[i].revents & POLLOUT) == POLLOUT) {
          setsockopt(issptr[iptr[i]].socket, IPPROTO_TCP, TCP_NODELAY, &count, sizeof(count));
          ptr = trigger;
          wlen = triggerlen;
          count = 0;
          ++count_connects;
          while (wlen > 0 && count >= 0)
            if ((count = write(issptr[iptr[i]].socket, ptr, wlen)) > 0) {
              ptr += count;
              wlen -= count;
            }
          if (count < 0) {
            writeerrors++;
            fprintf(stderr, "Error: write to %s failed: %s\n", (char *) is_inet_ntoa((struct in_addr*)&issptr[iptr[i]].ip), strerror(errno));
            is_wipe_iss(&issptr[iptr[i]]);
            (void)is_connect_ptr(sb);
          } else {
            issptr[iptr[i]].time = time(NULL);
            issptr[iptr[i]].active = POLLIN;
          }
        } else if ((pfd[i].revents & POLLIN) == POLLIN) {
          memset(rbuf, 0, sizeof(rbuf));
          if ((rlen = read(issptr[iptr[i]].socket, rbuf, sizeof(rbuf))) > 0) {
            if (grepserver || expr != NULL) {
             if (grepserver) {
              if ((ptr = strstr(rbuf, "Server:")) == NULL || (ptr2 = index(ptr, '\n')) == NULL)
                printf("%s = <server string not in response>\n",
                  (char *) is_inet_ntoa((struct in_addr*)&issptr[iptr[i]].ip)
                  );
              else {
                *ptr2 = 0;
                if (*(--ptr2) == '\r');
                  *ptr2 = 0;
                printf("%s = %s\n", 
                  (char *) is_inet_ntoa((struct in_addr*)&issptr[iptr[i]].ip),
                  ptr);
              }
             } else {
#ifdef PCRE
              if (pcre_exec(pattern, hints, rbuf, rlen, 0, 0, offsets, 15) >= 0) {
                ptr = rbuf + offsets[0];
                while ((char *)ptr > (char *)rbuf && *(ptr - 1) != '\n')
                  --ptr;
                if ((ptr2 = index(ptr, '\n')) != NULL) {
                  if (*(ptr2 - 1) == '\r')
                    --ptr2;
                  *ptr2 = 0;
                }
                printf("%s = %s\n", 
                  (char *) is_inet_ntoa((struct in_addr*)&issptr[iptr[i]].ip),
                  ptr);
              } else
                printf("%s = <search string not found>\n",
                  (char *) is_inet_ntoa((struct in_addr*)&issptr[iptr[i]].ip)
                );
#endif
             }
            } else
              printf("%s\n%s\n",
                (char *) is_inet_ntoa((struct in_addr*)&issptr[iptr[i]].ip),
                rbuf);
            ++count_responses;
          } else if (rlen < 0) {
            readerrors++;
            fprintf(stderr, "Error: read from %s failed: %s\n", (char *) is_inet_ntoa((struct in_addr*)&issptr[iptr[i]].ip), strerror(errno));
            if (grepserver)
              printf("%s = <no response>\n",
                (char *) is_inet_ntoa((struct in_addr*)&issptr[iptr[i]].ip)
                );
            else
              printf("%s\n\n",
                (char *) is_inet_ntoa((struct in_addr*)&issptr[iptr[i]].ip)
                );
          }
          if (rlen != 0) {
            is_wipe_iss(&issptr[iptr[i]]);
            (void) is_connect_ptr(sb);
          }
        } else if (pfd[i].revents > 0) {
          if (issptr[iptr[i]].active == POLLIN) {
            if (grepserver)
              printf("%s = <no response>\n",
                (char *) is_inet_ntoa((struct in_addr*)&issptr[iptr[i]].ip)
                );
            else
              printf("%s\n\n",
                (char *) is_inet_ntoa((struct in_addr*)&issptr[iptr[i]].ip)
                );
          }
          is_wipe_iss(&issptr[iptr[i]]);
          (void) is_connect_ptr(sb);
        }
      }

    cur_time = time(NULL) - (TIMEOUT_CONNECT + (time(NULL) - poll_time));
    for (i = 0; i < max_sock; i++)
      if (issptr[i].active > 0 && cur_time > issptr[i].time) {
        if (issptr[i].active == POLLIN) {
          if (grepserver)
            printf("%s = <response timeout>\n",
              (char *) is_inet_ntoa((struct in_addr*)&issptr[iptr[i]].ip));
          else
            printf("%s\n\n",
              (char *) is_inet_ntoa((struct in_addr*)&issptr[iptr[i]].ip));
        }
        is_wipe_iss(&issptr[i]);
        (void) is_connect_ptr(sb);
      }

  } while (is_connect_done == 0 || cur_sock > 0);

  if (time(NULL) == time_start)
    --time_start;
  printf("\nStatistics: %ld IPs, %ld connects, %ld sessions, %ld responses; %ld read errors, %ld write errors; %ld seconds (%ld IPs/s)\n",
         count_ips, count_all, count_connects, count_responses, readerrors, writeerrors,
         time(NULL) - time_start, 1 + count_ips / (time(NULL) - time_start));

  return 0;
}
