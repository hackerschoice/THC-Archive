/*
 * Header file for is.c
 * Just change the <CONFIGURE HERE> part
 *
 */

#ifndef _IS_H_

#define _IS_H_

/* <CONFIGURE HERE> */

#define MAX_FD          65535
#define POLLWAIT        1
#define TIMEOUT_CONNECT 5
#define TIMEOUT_RECV    5  // not used currently
#define PORT            80
#define TRIGGER         "HEAD / HTTP/1.0\r\n\r\n"
#define ALARM_FOR_AIO	3  // not used currently
#define SUPER_MAX_FD    60000

/* </ END OF CONFIGURE /> */


#define	PROGRAM		"Internet Scanner"
#define AUTHOR		"van Hauser / THC <vh@thc.org>"
#define VERSION		"v1.0"
#define WEB		"http://www.thc.org"


typedef struct {
  unsigned long int sip; /* not used yet, for future stuff */
  unsigned long int eip;
  unsigned long int cip;
} is_scanblock;

typedef struct {
  int socket;
  int active; /* 0 = not used, 1 = connect in progress, 2 = data sent */
  time_t time;
  unsigned long int ip;
#ifdef _IS_AIO
  struct aiocb cbr;
  struct aiocb cbw;
  unsigned char rbuf[4096];
  unsigned char wbuf[4096];
  size_t rlen;
  size_t wlen;
#endif
} is_sockets;

#endif
