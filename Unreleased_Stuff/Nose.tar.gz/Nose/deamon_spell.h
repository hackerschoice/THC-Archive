#ifndef __DEAMON_SPELL_HDR
#define __DEAMON_SPELL_HDR

#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>

extern int deamon_spell(void);

#endif
