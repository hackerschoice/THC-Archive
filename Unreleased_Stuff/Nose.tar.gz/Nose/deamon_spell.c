#include "deamon_spell.h"

extern int deamon_spell(void)
{
  pid_t pid;
  
  if( (pid = fork()) < 0)
    return(-1);
  else if(pid != 0)
    exit(0);
  
  setsid();     /* become the controling process */
  chdir("/");   /* change working direc. */
  umask(0);     /* delete filecreatingmask */

  return(0);
}
