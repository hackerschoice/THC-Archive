#ifndef __DNS_LIB_HDR
#define __DNS_LIB_HDR

#include <sys/types.h>

u_long  nameResolve(char *hostname);
char    *hostLookup(u_long in);

#endif



