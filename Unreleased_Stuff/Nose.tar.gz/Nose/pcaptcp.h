#ifndef __PCAPTCP_HD
#define __PCAPTCP_HD

/*#include <netinet/in.h>*/
#include <netinet/ip.h>
#include <netinet/tcp.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <arpa/inet.h>
/*#include <linux/socket.h>*/
/*#include <linux/ip.h>*/
/*#include <linux/tcp.h>*/
#include <errno.h>
#include "pcap.h"
#include "error.h"

#define ETHHDR    14
#define IPHDR     20
#define TCPHDR    20
#define TCPIPHDR  IPHDR + TCPHDR

#define MAXLOAD   2049

/*
** libpcap stuff
*/
pcap_t              *__pdesc;
struct bpf_program   __filter;
bpf_u_int32          __localnet;
bpf_u_int32          __netmask;
char                 __errbuf[PCAP_ERRBUF_SIZE];

struct ti_pack
{
  struct iphdr  ip;
  struct tcphdr tcp;
  char          load[MAXLOAD];
};
      
extern int init_pcap(char *device, char *proto, int snaplen, int to_ms, int promisc);
extern int readtcp(char *ip, char *tcp, char *load);

#endif
