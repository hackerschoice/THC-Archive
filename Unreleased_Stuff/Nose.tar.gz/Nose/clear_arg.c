void clear_arg(char *str)
{
  char *tmpstr = str;
  
  while(*str != '\0')
    *str++ = ' ';
  *tmpstr = '\0';
}

