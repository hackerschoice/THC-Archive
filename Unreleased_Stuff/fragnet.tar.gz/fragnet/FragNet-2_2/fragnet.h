#ifndef __FRAGNET_HDR
#define __FRAGNET_HDR


#define FRAG_LEN        16
#define MAXLOAD         2049


#define NONBLOCK          1

#define FNE_NOERROR       0
#define FNE_NOTCLOSED     1
#define FNE_NOTINITED     2
#define FNE_TIMEDOUT_1    3
#define FNE_TIMEDOUT_2    4
#define FNE_NOHNDSHK      5
#define FNE_SEND          6
#define FNE_RECV          7
#define FNE_WNDW2SMALL    8
#define FNE_BUFF2SMALL    9
#define FNE_NOSHTDWN     10
#define FNE_BLOCK        11

#define MAX_ERRMSGS      12
 

#define DEBUG(str)  \
{ \
  if(fn_debug)  \
    fprintf(debug_out, "%s", str); \
}


/* the following 2 func.s were part of route's and halflife's lnw.h */
u_int   nameResolve(char *hostname);
char *  hostLookup(unsigned long in);

/*
** Checksum routine for Internet Protocol family headers (C Version).
**
** Refer to "Computing the Internet Checksum" by R. Braden, D. Borman and
** C. Partridge, Computer Communication Review, Vol. 19, No. 2, April 1989,
** pp. 86-101, for additional details on computing this checksum.
*/
u_short in_chksum(register u_short *ptr, register int nbytes);

int     set_signal(int sig, void (*fkt_ptr) (int));

int     fragnet_init(u_long src_ip, u_long dst_ip, u_short src_prt, u_short dst_prt);
int     fragnet_hndshk(void);
int     fragnet_send(char *data, u_int datalen);
int     fragnet_recv(char *buffer, int mode);
int     fragnet_finshtdwn(void);
int     fragnet_rstshtdwn(void);
int     fragnet_close(void);
int     fragnet_error(int fn_error);

int     chop_up(char *packet, u_long packetlen, u_long fraglen);
int     free_fc(void);

#endif
