/*****************************************************************************
**
**  >>>----|F|---|R|--|A|--------|G|-|N|------|E|------|T|------>
**
** Purpose:     The FragNet Lib.functions are designed to establish a
**              TCP Connection by using IP Fragmnets.
**
** Last Update: 2000/08/27
**
** Author: TICK / THC <tick@thehackerschoice.com>
**
** Copyright: GNU Public License
**
*****************************************************************************/

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <linux/socket.h>
#include <linux/ip.h>
#include <linux/tcp.h>
#include <linux/if_ether.h>
#include <pcap.h>
#include <errno.h>
extern int errno;

#include "libfragnet.h"
#include "error.h"
#include "rtt.h"

#define u_char  unsigned char


/********************** LIB FUNCTIONS *************************************/

/*
** Init. all the Stuff we need and open send/recv sockets
*/
int fragnet_init(u_long src_ip, u_long dst_ip, u_short src_prt, u_short dst_prt)
{
  int     on = 1;

  if(!closed)
    back(FNE_NOTCLOSED)
    
  /*
  ** Open send/recv Sockets
  */
  if( (ip_sock = socket(AF_INET, SOCK_RAW, IPPROTO_RAW)) < 0 )
    err_mesg(FATAL_SYS, "Can't create raw IP socket.\nSYSERR");
  if( setsockopt(ip_sock, IPPROTO_IP, IP_HDRINCL, (char *) &on, sizeof(on)) < 0 )
    err_mesg(FATAL_SYS, "Can't set socket option IP_HDRINCL.\nSYSERR");
      
  ip_sin.sin_family        = AF_INET;
  ip_sin.sin_port          = dst_prt;
  ip_sin.sin_addr.s_addr   = dst_ip;
  ip_sinlen                = sizeof(ip_sin);


  /*
  ** Set global Variables
  */
  TCP_isn     = (u_long) rand();
  TCP_seq     = 0;
  TCP_snd_nxt = 0;
  TCP_ack     = 0;
  TCP_window  = 0;
  TCP_source  = src_prt;
  TCP_dest    = dst_prt;
  
  IP_saddr    = src_ip;
  IP_daddr    = dst_ip;
  
  /*
  ** Set up Pseudo Header
  */
  ps_hdr               = (struct PseudoHdr *) ChkSumBuf;
  ps_hdr->saddr        = IP_saddr;
  ps_hdr->daddr        = IP_daddr;
  ps_hdr->pad          = 0;
  ps_hdr->proto        = IPPROTO_TCP;
  ps_hdr->tcplen       = htons(TCPHDR);
                  
  /*
  ** Set Signal Handler for RTT
  */
  if(set_signal(SIGALRM, rtt_alarm) < 0)
    err_mesg(FATAL_SYS, "ERROR: set_signal()\nSYSERR");
    
  
  /*
  ** Set up pcap Stuff
  */
  if((device = pcap_lookupdev(errbuf)) == NULL)
    err_mesg(FATAL_SYS, "ERROR: pcap_lookupdev()\nSYSERR");

  if((pd = pcap_open_live(device, SNAPLEN, 1, TO_MS, errbuf)) == NULL)
    err_mesg(FATAL, "%s\n", errbuf);

  if(pcap_lookupnet(device, &localnet, &netmask, errbuf) < 0)
    err_mesg(FATAL, "%s\n", errbuf);

  if(pcap_compile(pd, &filter, "tcp", 1, netmask) < 0)
    err_mesg(FATAL, "ERROR: pcap_compile()\n");

  if(pcap_setfilter(pd, &filter)<0)
    err_mesg(FATAL, "ERROR: pcap_set()\n");


  inited    = 1;
  closed    = 0;
  handshake = 0;

  return(0);
}


/*
** Close sockets, set all used variables to zero and free memory used for
** linked list.
*/
int fragnet_close(void)
{
  if(closed)
    return(0);
  if(!inited)
    back(FNE_NOTINITED)
    
  close(ip_sock);
  pcap_close(pd);
  
  bzero(&ip_sin, sizeof(ip_sin));
  ip_sinlen = 0;
        
  TCP_isn     = 0;
  TCP_seq     = 0;
  TCP_snd_nxt = 0;
  TCP_ack     = 0;
  TCP_window  = 0;
  TCP_source  = 0;
  TCP_dest    = 0;
                      
  IP_saddr    = 0;
  IP_daddr    = 0;
                            
  if(fc_begin != NULL)
    free_fc();
                            
  inited    = 0;
  closed    = 1;

  return(0);
}


/*
** chop_up() chops up a Packet (of any kind) in Fragments, which will be
** 'fraglen' Bytes long.
** The IP Headers plus the Packetdata will be placed in a linked list.
*/ 
int chop_up(char *packet, u_long packetlen, u_long fraglen)
{
  fragchain     *fc_current;
  u_long        frag_ctr;
  u_long        frags;
  struct IPPack i_pack = { 0 };
  char          *finger;
  u_int         lastone = 0;
  u_short       offset;
    

  /* First set static IP Hdr infos */
  i_pack.ip.version   = 4;
  i_pack.ip.ihl       = 5;  /* DWORDS */
  i_pack.ip.id        = (u_short) rand();
  i_pack.ip.ttl       = 0x64;
  i_pack.ip.protocol  = IPPROTO_TCP;
  i_pack.ip.saddr     = IP_saddr;
  i_pack.ip.daddr     = IP_daddr;


  /* Set up linked list and other stuff */
  if(fc_begin != NULL)
    free_fc();
  if( (fc_begin = (fragchain *) malloc(sizeof(fragchain))) == NULL)
    err_mesg(FATAL, "ERROR: Can't allocate memory for first fragchain object!\n");
    
  frags = (packetlen % fraglen) ? ((packetlen / fraglen) + 1) : (packetlen / fraglen);
    

  for(fc_current = fc_begin, frag_ctr = 0; frag_ctr < frags; frag_ctr++)
  {
    /* set up the things we know about our fragchain object */
    fc_current->frag_nr   = frag_ctr + 1;
    fc_current->frag_off  = (frag_ctr * fraglen);
    
    /* The Fragment Offset is measured in Units of 8 Octets (s. RFC 791) */
    offset = fc_current->frag_off / 8;
                
    /* set pointer to current offset in our TCP packet */
    finger = packet + fc_current->frag_off;

    if( (frags - frag_ctr) > 1)
    {
      i_pack.ip.frag_off    = htons( IP_MF | offset );
      fc_current->frag_size = fraglen;      
    }
    else /* last fragment */
    {
      lastone = 1;
      i_pack.ip.frag_off    = htons( offset );
      fc_current->frag_size = packetlen - (frag_ctr * fraglen);
    }

    i_pack.ip.tot_len       = htons( IPHDR + fc_current->frag_size );
    i_pack.ip.check         = in_chksum((u_short *) &i_pack, IPHDR);
      
  
    /* copy IP Hdr and Packetdata into Fragment List */
    bzero(i_pack.load, FRAG_LEN);
    bcopy(finger, i_pack.load, fc_current->frag_size);
    bcopy(&i_pack, fc_current->frag, ntohs(i_pack.ip.tot_len));
    
    /* create a new element for our linked list or set next_frag to NULL */
    if(!lastone)
    {
      if( (fc_current->next_frag = (fragchain *) malloc(sizeof(fragchain))) == NULL)
        err_mesg(FATAL, "ERROR: Can't allocate memory for fragchain object!\n");
        
      fc_current  = fc_current->next_frag;
    }
    else
      fc_current->next_frag = NULL;
      
  }
  
  return(frag_ctr);
}


/*
** Free the memory allocated for your Fragment List
*/
int free_fc(void)
{
  fragchain *fc_current;
  fragchain *fc_backup;
  

  if(fc_begin == NULL)
    return(-1);
    
  for(fc_current = fc_begin; fc_current != NULL; fc_current = fc_backup)
  {
    fc_backup = fc_current->next_frag;

    free(fc_current);
  }
  fc_begin = NULL;

  return(0);
}


/*
** This Function process the TCP 3-Way Handshake
*/
int fragnet_hndshk(void)
{
  struct tcphdr       *t_ptr;
  char                t_pack[TCPHDR] = { 0 };
  struct TCPIPPack    *ti_ptr;
  char                ti_pack[TCPIPHDR] = { 0 };
  struct iphdr        *ip;
  fragchain           *fc_current;
  int                 ctr;
    

  if(!shtdwn)
    back(FNE_NOSHTDWN)

  if( rttfirst )
  {
    rtt_init(&rttinfo);   /* init. first time we are called */
    rttfirst = 0;
  }
  
  /*
  ** Send our ISN to the Server to get his ISN and to let him know our
  */

  /* Set up TCP packet */
  t_ptr = (struct tcphdr *) t_pack;
  t_ptr->source   = TCP_source;
  t_ptr->dest     = TCP_dest;
  t_ptr->seq      = htonl(TCP_isn);
  t_ptr->doff     = 5;
  t_ptr->syn      = 1;
  t_ptr->window   = htons(MAXLOAD);

  /* Calculate CheckSum */
  bzero(ChkSumBuf+PHDR, TCPHDR+MAXLOAD);  
  bcopy(t_pack, ChkSumBuf+PHDR, TCPHDR);
  t_ptr->check    = in_chksum((u_short *) ChkSumBuf, PTCPHDR);
  
  ctr = chop_up(t_pack, (u_long) TCPHDR, (u_long) FRAG_LEN);
  FRAGDEBUG("fragnet_hndshk()", TCPHDR, ctr)
  
  TCP_snd_nxt = TCP_isn + 1L;
  
  rtt_newpack(&rttinfo);  /* init. for new packet */
      
rexmit:
  if(fn_debug)
  {
    fprintf(debug_out, "FCT: fragnet_hndshk()\n"
                       "ACT: send SYN\n"
                       "SEQ: %lu\n\n", TCP_isn);
    fflush(debug_out);
  }
  
  for(fc_current = fc_begin; fc_current != NULL; fc_current = fc_current->next_frag)
  {
    SENDDEBUG("fragnet_hndshk()")

    ip = (struct iphdr *) fc_current->frag;
/*
    printf("\nIP Version: %i\n", ip->version);
    printf("IP HdrLen: %i\n", ip->ihl);
    printf("IP ID: %hu\n", ip->id);
    printf("IP Src: %s\n", hostLookup(ip->saddr));
    printf("IP Dst: %s\n", hostLookup(ip->daddr));
    printf("IP FragOffset: 0x%04X\n", ntohs(ip->frag_off));
    printf("IP TotLen: %hu\n", htons(ip->tot_len));
*/    


    if(sendto(ip_sock, fc_current->frag, IPHDR + fc_current->frag_size, 0, (struct sockaddr *) &ip_sin, ip_sinlen) < 0)
      back(FNE_SEND)
  }
  
  /*
  ** Set RTT Stuff.
  */
  errno = rtt_to = 0;             /* for signal handler */
  alarm( rtt_start(&rttinfo) );   /* calc. timeout value & start timer */
              
  while(1)
  {
    bzero(ti_pack, sizeof(ti_pack));
    
    if(llreadtcp(pd, ti_pack, ti_pack+IPHDR, NULL) < 0 )
    {
      if(rtt_to)
      {
        /*
        ** The llreadtcp() timed out.
        ** If we have tried enough, then let's quit.
        */
        if( rtt_timeout(&rttinfo) < 0 )
        {
          rttfirst = 1;
          back(FNE_TIMEDOUT_1)
        }
        
        /*
        ** We have to send the packet again.
        */
        if(fn_debug)
          err_mesg(WARN, "fragnet_hndshk(): REXMIT\n");
        goto rexmit;
      }
      
      if(fn_debug)
        err_mesg(WARN_SYS, "ERROR: llreadtcp()\nSYSERR");
      continue;
    }

    /* We cought a TCP pack, so let's check if it belongs to us */
    ti_ptr = (struct TCPIPPack *) ti_pack;
    if(
        ti_ptr->ip.saddr    == IP_daddr               &&
        ti_ptr->ip.daddr    == IP_saddr               &&
        ti_ptr->tcp.source  == TCP_dest               &&
        ti_ptr->tcp.dest    == TCP_source             &&
        ti_ptr->tcp.ack_seq == htonl(TCP_snd_nxt)     &&
        ti_ptr->tcp.syn     == 1                      &&
        ti_ptr->tcp.ack     == 1        
      )
      break;
    
    RCVRST("fragnet_hndshk()")

    if(fn_debug)
      err_mesg(WARN, "fragnet_hndshk(): packet doesn't belong to us!\n");

  }
      
  alarm(0);           /* stop signal timer */
  rtt_stop(&rttinfo); /* stop RTT timer, calc & store new values */
  
  /* set SEQ/ACK stuff */
  TCP_seq     = TCP_snd_nxt;
  TCP_ack     = (u_long) (ntohl(ti_ptr->tcp.seq) + 1L);

  TCP_window  = ntohs(ti_ptr->tcp.window);
  
  if(fn_debug)
  {
    fprintf(debug_out, "FCT: fragnet_hndshk()\n"
                       "ACT: received SYN\n"
                       "SEQ: %lu\n"
                       "WDW: %hu\n\n", (u_long) ntohl(ti_ptr->tcp.seq), TCP_window);
    fflush(debug_out);
  }


  /*
  ** Send an ACKnowledgment for the Server's ISN
  */
      
  bzero(t_pack, sizeof(t_pack));
    
  /* Set up TCP packet */
  t_ptr->source   = TCP_source;
  t_ptr->dest     = TCP_dest;
  t_ptr->seq      = htonl(TCP_seq);
  t_ptr->ack_seq  = htonl(TCP_ack);
  t_ptr->doff     = 5;
  t_ptr->ack      = 1;
  t_ptr->window   = htons(MAXLOAD);

  /* Calculate Checksum */
  bzero(ChkSumBuf+PHDR, TCPHDR+MAXLOAD);
  bcopy(t_pack, ChkSumBuf+PHDR, TCPHDR);
  t_ptr->check    = in_chksum((u_short *) ChkSumBuf, PTCPHDR);
    
  ctr = chop_up(t_pack, (u_long) TCPHDR, (u_long) FRAG_LEN);
  FRAGDEBUG("fragnet_hndshk()", TCPHDR, ctr)

  if(fn_debug)
  {
    fprintf(debug_out, "FCT: fragnet_hndshk()\n"
                       "ACT: send ACK\n"
                       "SEQ: %lu\n"
                       "ACK: %lu\n\n", TCP_seq, TCP_ack);
    fflush(debug_out);
  }

  for(fc_current = fc_begin; fc_current != NULL; fc_current = fc_current->next_frag)
  {
    SENDDEBUG("fragnet_hndshk()")
    if(sendto(ip_sock, fc_current->frag, IPHDR + fc_current->frag_size, 0, (struct sockaddr *) &ip_sin, ip_sinlen) < 0)
      back(FNE_SEND)
  }
  
  free_fc();
  
  handshake = 1;
  shtdwn    = 0;

  return(0);
}


/*
** fragnet_send() sends the Data stored at '*data' to the Server
*/
int fragnet_send(char *data, u_int datalen)
{
  struct TCPPack      *t_ptr;
  char                t_pack[TCPHDR+MAXLOAD]  = { 0 };
  struct TCPIPPack    *ti_ptr;
  char                ti_pack[TCPIPHDR+MAXLOAD] = { 0 };  /* for ACKnowledment */
  fragchain           *fc_current;
  int                 ctr;
  
  
  if(!inited || closed)
    back(FNE_NOTINITED)
  if(!handshake)
    back(FNE_NOHNDSHK)

  if(datalen > TCP_window || datalen > MAXLOAD)
    back(FNE_WNDW2SMALL)
      
  if( rttfirst )
  {
    rtt_init(&rttinfo);   /* init. first time we are called */
    rttfirst = 0;
  }

  fprintf(debug_out, "DAT: %s\n\n", data);
  fflush(debug_out);


  /* Set up TCP packet */
  t_ptr = (struct TCPPack *) t_pack;
  t_ptr->tcp.source   = TCP_source;
  t_ptr->tcp.dest     = TCP_dest;
  t_ptr->tcp.seq      = htonl(TCP_seq);
  t_ptr->tcp.ack_seq  = htonl(TCP_ack);
  t_ptr->tcp.doff     = 5;
  t_ptr->tcp.psh      = 1;
  t_ptr->tcp.ack      = 1;
  t_ptr->tcp.window   = htons(MAXLOAD);
  
  /* now we copy user data into TCP payload */
  bcopy(data, t_ptr->load, datalen);
  
  /* Calculate Checksum */
  ps_hdr->tcplen       = htons(TCPHDR + datalen);
  bzero(ChkSumBuf+PHDR, TCPHDR+MAXLOAD);              
  bcopy(t_pack, ChkSumBuf+PHDR, TCPHDR+datalen);
  t_ptr->tcp.check    = in_chksum((u_short *) ChkSumBuf, PTCPHDR + datalen);
  ps_hdr->tcplen       = htons(TCPHDR);                  

  ctr = chop_up(t_pack, TCPHDR + datalen, FRAG_LEN);
  FRAGDEBUG("fragnet_send()", TCPHDR + datalen, ctr) 
  
  TCP_snd_nxt = TCP_seq + datalen;

  rtt_newpack(&rttinfo);  /* init. for new packet */

rexmit:
  if(fn_debug)
  {
    fprintf(debug_out, "FCT: fragnet_send()\n"
                       "ACT: send Data (%u Bytes)\n"
                       "SEQ: %lu:%lu\n"
                       "ACK: %lu\n\n", datalen, TCP_seq, TCP_snd_nxt, TCP_ack);
    fflush(debug_out);
  }
  
  for(fc_current = fc_begin; fc_current != NULL; fc_current = fc_current->next_frag)
  {
    if(fn_debug && fc_current->frag_off > (u_short) 20)
    {
      fprintf(debug_out, "DAT: %s\n\n", fc_current->frag);
      fflush(debug_out);
    }

    SENDDEBUG("fragnet_send()")
    
    if(sendto(ip_sock, fc_current->frag, IPHDR + fc_current->frag_size, 0, (struct sockaddr *) &ip_sin, ip_sinlen) < 0)
      back(FNE_SEND)
  }
      
  /*
  ** Set RTT Stuff.
  */
  errno = rtt_to = 0;             /* for signal handler */
  alarm( rtt_start(&rttinfo) );   /* calc. timeout value & start timer */
            
  while(1)
  {
    bzero(ti_pack, TCPIPHDR+MAXLOAD);
  
    if(llreadtcp(pd, ti_pack, ti_pack+IPHDR, ti_pack+TCPIPHDR) < 0 )
    {
      if(rtt_to)
      {
        /*
        ** The llreadtcp() timed out.
        ** If we have tried enough, then let's quit.
        */
        if( rtt_timeout(&rttinfo) < 0 )
        {
          rttfirst = 1;
          back(FNE_TIMEDOUT_1)
        }
         
        /*
        ** We have to send the packet again.
        */
        goto rexmit;
      }
  
      if(fn_debug)    
        err_mesg(WARN_SYS, "ERROR: llreadtcp()\nSYSERR");
      continue;
    }

    /* We cought a TCP pack, so let's check if it belongs to us */
    ti_ptr = (struct TCPIPPack *) ti_pack;
    if(
        ti_ptr->ip.saddr    == IP_daddr           &&
        ti_ptr->ip.daddr    == IP_saddr           &&
        ti_ptr->tcp.source  == TCP_dest           &&
        ti_ptr->tcp.dest    == TCP_source         &&
        ti_ptr->tcp.seq     == htonl(TCP_ack)     &&
        ti_ptr->tcp.ack_seq == htonl(TCP_snd_nxt) &&
        ti_ptr->tcp.ack     == 1
      )
      break;
  }
  alarm(0);           /* stop signal timer */
  rtt_stop(&rttinfo); /* stop RTT timer, calc & store new values */
      
  free_fc();
  
  TCP_seq   = TCP_snd_nxt;
  /* We didn't have to calculate a new ACK, because TCP isn't ACKing ACKs */
  
  TCP_window  = ntohs(ti_ptr->tcp.window);

  ACKDEBUG("fragnet_send()")

  /*
  ** We have to send an ACK if we get an Echo (PSH Flag set) from the Server,
  ** which includes the Server's ACK.
  ** The Telnet and the Rlogin Server uses this Method.
  ** (s. TCP/IP Illustrated Vol. 1, Section <Somewhere>)
  ** But we let fragnet_recv() do this work...
  */

  return(0);
}


/*
** Yep, you gussed it. This Function process the TCP FIN Shutdown.
** We don't use RST because it's dirty and Data could be lost.
*/
int fragnet_finshtdwn(void)
{
  struct TCPPack      t_pack = { 0 };
  struct TCPIPPack    ti_pack;
  struct TCPIPPack    *ti_ptr = &ti_pack;
  fragchain           *fc_current;
  int                 ctr;
  
  
  if(!handshake)
    back(FNE_NOHNDSHK)

  if( rttfirst )
  {
    rtt_init(&rttinfo);   /* init. first time we are called */
    rttfirst = 0;
  }
              
  /*
  ** Send TCP FIN Packet to the Server
  */

  /* Set up TCP packet */
  t_pack.tcp.source   = TCP_source;
  t_pack.tcp.dest     = TCP_dest;
  t_pack.tcp.seq      = htonl(TCP_seq);
  t_pack.tcp.ack_seq  = htonl(TCP_ack);
  t_pack.tcp.doff     = 5;
  t_pack.tcp.fin      = 1;
  t_pack.tcp.ack      = 1;
  t_pack.tcp.window   = htons(MAXLOAD);

  /* Calculate CheckSum */
  bzero(ChkSumBuf+PHDR, TCPHDR+MAXLOAD);
  bcopy(&t_pack, ChkSumBuf+PHDR, TCPHDR);
  t_pack.tcp.check    = in_chksum((u_short *) ChkSumBuf, PTCPHDR);

  ctr = chop_up((char *) &t_pack, TCPHDR, FRAG_LEN);
  FRAGDEBUG("fragnet_finshtdwn()", TCPHDR, ctr)

  TCP_snd_nxt = TCP_seq + 1;

  rtt_newpack(&rttinfo);  /* init. for new packet */

rexmit_fin:
  if(fn_debug)
  {
    fprintf(debug_out, "FCT: fragnet_finshtdwn()\n"
                       "ACT: send FIN\n"
                       "SEQ: %lu:%lu\n"
                       "ACK: %lu\n\n", TCP_seq, TCP_snd_nxt, TCP_ack);
    fflush(debug_out);
  }

  for(fc_current = fc_begin; fc_current != NULL; fc_current = fc_current->next_frag)
  {
    SENDDEBUG("fragnet_finshtdwn()")

    if(sendto(ip_sock, fc_current->frag, IPHDR + fc_current->frag_size, 0, (struct sockaddr *) &ip_sin, ip_sinlen) < 0)
      back(FNE_SEND)
  }

  /*
  ** Set RTT Stuff.
  */
  errno = rtt_to = 0;             /* for signal handler */
  alarm( rtt_start(&rttinfo) );   /* calc. timeout value & start timer */
              
  while(1)
  {
    bzero(&ti_pack, TCPIPHDR + MAXLOAD);

    if(llreadtcp(pd, (char *) &ti_pack.ip, (char *) &ti_pack.tcp, NULL) < 0 )
    {
      if(rtt_to)
      {
        /*
        ** The llreadtcp() timed out.
        ** If we have tried enough, then let's quit.
        */
        if( rtt_timeout(&rttinfo) < 0 )
        {
          rttfirst = 1;
          back(FNE_TIMEDOUT_1)
        }
        
        /*
        ** We have to send the packet again.
        */
        goto rexmit_fin;
      }
      
      if(fn_debug)
        err_mesg(WARN_SYS, "ERROR: llreadtcp()\nSYSERR");
      continue;
    }

    /* We cought a TCP pack, so let's check if it belongs to us */
    if(
        ti_pack.ip.saddr    == IP_daddr           &&
        ti_pack.tcp.source  == TCP_dest           &&
        ti_pack.tcp.dest    == TCP_source         &&
        ti_pack.tcp.seq     == htonl(TCP_ack)     &&
        ti_pack.tcp.ack_seq == htonl(TCP_snd_nxt) &&
        ti_pack.tcp.ack     == 1
      )
      break;
  }
  alarm(0);           /* stop signal timer */
  rtt_stop(&rttinfo); /* stop RTT timer, calc & store new values */  

  /* set SEQ/ACK stuff */
  TCP_seq     = TCP_snd_nxt;

  ACKDEBUG("fragnet_finshtdwn()")

  /*
  ** Wait for Server's FIN Packet and ACKnowledge it
  */

  alarm(RECV_TIMEOUT);
  while(1)
  {
    bzero(&ti_pack, TCPIPHDR + MAXLOAD);
    errno = 0;

    if(llreadtcp(pd, (char *) &ti_pack.ip, (char *) &ti_pack.tcp, NULL) < 0 )
    {
      if(errno == EINTR)
      {
        errno = 0;
        back(FNE_TIMEDOUT_2)
      }
      else
        continue;
    }

    /* We cought a TCP pack, so let's check if it belongs to us */
    if(
        ti_pack.ip.saddr    == IP_daddr           &&
        ti_pack.tcp.source  == TCP_dest           &&
        ti_pack.tcp.dest    == TCP_source         &&
        ti_pack.tcp.seq     == htonl(TCP_ack)     &&
        ti_pack.tcp.ack_seq == htonl(TCP_snd_nxt) &&
        ti_pack.tcp.fin     == 1                  &&
        ti_pack.tcp.ack     == 1
      )
      break;
  }
  alarm(0);
  
  /* set SEQ/ACK stuff */
  TCP_ack     = ntohl(ti_pack.tcp.seq) + 1;

  if(fn_debug)
  {
    fprintf(debug_out, "FCT: fragnet_finshtdwn()\n"
                       "ACT: recv ACK\n"
                       "SEQ: %lu\n"
                       "ACK: %lu\n", ntohl(ti_pack.tcp.seq)
                                   , ntohl(ti_pack.tcp.ack_seq));
    fflush(debug_out);
  }

  /*
  ** Set up TCP ACK packet for Server
  */
  bzero(&t_pack, TCPHDR + MAXLOAD);
    
  t_pack.tcp.source   = TCP_source;
  t_pack.tcp.dest     = TCP_dest;
  t_pack.tcp.seq      = htonl(TCP_seq);
  t_pack.tcp.ack_seq  = htonl(TCP_ack);
  t_pack.tcp.doff     = 5;
  t_pack.tcp.ack      = 1;
  t_pack.tcp.window   = htons(MAXLOAD);

  /* Calculate Checksum, Pseudo Hdr stays the same */
  bzero(ChkSumBuf+PHDR, TCPHDR+MAXLOAD);
  bcopy(&t_pack, ChkSumBuf+PHDR, TCPHDR);
  t_pack.tcp.check    = in_chksum((u_short *) ChkSumBuf, PTCPHDR);


  ctr = chop_up((char *) &t_pack, TCPHDR, FRAG_LEN);
  FRAGDEBUG("fragnet_finshtdwn()", TCPHDR, ctr)

rexmit_ack:
  if(fn_debug)
  {
    fprintf(debug_out, "FCT: fragnet_finshtdwn()\n"
                       "ACT: send ACK\n"
                       "SEQ: %lu\n"
                       "ACK: %lu\n\n", TCP_seq, TCP_ack);
    fflush(debug_out);
  }

  for(fc_current = fc_begin; fc_current != NULL; fc_current = fc_current->next_frag)
  {
    if(sendto(ip_sock, fc_current->frag, IPHDR + fc_current->frag_size, 0, (struct sockaddr *) &ip_sin, ip_sinlen) < 0)
      back(FNE_SEND)
  }
  
  /*
  ** Now we are in the TIME_WAIT State.
  ** We have to wait 2 * MSL Seconds to verify if our ACK reaches the Server.
  ** If we aren't receive a Packet in MSL2 sec. we could be sure (?) that the
  ** Server gets our ACK and exits clearly.
  */
  if(fn_debug)
  {
    fprintf(debug_out, "FCT: fragnet_finshtdwn()\n"
                       "ACT: wait 2 * MSL seconds\n\n");
    fflush(debug_out);
  }
  
  alarm(MSL2);
  while(1)
  {
    bzero(&ti_pack, TCPIPHDR + MAXLOAD);
    errno = 0;
    
    if(llreadtcp(pd, (char *) &ti_pack.ip, (char *) &ti_pack.tcp, NULL) < 0 )
    {
      if(errno == EINTR)
        break;
      
      if(fn_debug)
        err_mesg(WARN_SYS, "ERROR: llreadtcp()\nSYSERR");
      continue;
    }

    /* We cought a TCP pack, so let's check if it belongs to us */
    if(
        ti_pack.ip.saddr    == IP_daddr    &&
        ti_pack.tcp.source  == TCP_dest    &&
        ti_pack.tcp.dest    == TCP_source
      )
      goto rexmit_ack;
  }
  alarm(0);
    
  free_fc();

  
  handshake = 0;
  shtdwn    = 1;

  return(0);
}


/*
** sometimes we will need the RST shutdown
*/
int fragnet_rstshtdwn(void)
{
  struct TCPPack      t_pack = { 0 };
  fragchain           *fc_current;
  int                 ctr;
  
  
  if(!handshake)
    back(FNE_NOHNDSHK)

  /*
  ** send TCP RST packet to the server
  */

  /* Set up TCP packet */
  t_pack.tcp.source   = TCP_source;
  t_pack.tcp.dest     = TCP_dest;
  t_pack.tcp.seq      = htonl(TCP_seq);
  t_pack.tcp.ack_seq  = htonl(TCP_ack);
  t_pack.tcp.doff     = 5;
  t_pack.tcp.rst      = 1;
  t_pack.tcp.ack      = 1;
  t_pack.tcp.window   = htons(MAXLOAD);

  /* Calculate CheckSum */
  bzero(ChkSumBuf+PHDR, TCPHDR+MAXLOAD);
  bcopy(&t_pack, ChkSumBuf+PHDR, TCPHDR);
  t_pack.tcp.check    = in_chksum((u_short *) ChkSumBuf, PTCPHDR);

  ctr = chop_up((char *) &t_pack, TCPHDR, FRAG_LEN);
  FRAGDEBUG("fragnet_rstshtdwn()", TCPHDR, ctr)

  if(fn_debug)
  {
    fprintf(debug_out, "FCT: fragnet_rstshtdwn()\n"
                       "ACT: send RST\n"
                       "SEQ: %lu:%lu\n"
                       "ACK: %lu\n\n", TCP_seq, TCP_snd_nxt, TCP_ack);
    fflush(debug_out);
  }

  for(fc_current = fc_begin; fc_current != NULL; fc_current = fc_current->next_frag)
  {
    SENDDEBUG("fragnet_rstshtdwn()")

    if(sendto(ip_sock, fc_current->frag, IPHDR + fc_current->frag_size, 0, (struct sockaddr *) &ip_sin, ip_sinlen) < 0)
      back(FNE_SEND)
  }
  
  free_fc();


  handshake = 0;
  shtdwn    = 1;

  return(0);
}


/*
** fragnet_recv() receives Data from the Server.
** It returns if it has received Data or after RECV_TIMEOUT Seconds;
** by setting RECV_TIMEOUT to 0 you get a blocking Function.
*/
int fragnet_recv(char *buffer, int mode)
{
  int                 sockflags;
  struct TCPIPPack    *ti_ptr;
  char                ti_pack[TCPIPHDR+MAXLOAD] = { 0 };
  struct tcphdr       *t_ptr;
  char                t_pack[TCPHDR+MAXLOAD] = { 0 };
  fragchain           *fc_current;
  int                 ctr;
  u_long              packlen;
  

  if(fn_debug)
  {
    fprintf(debug_out, "FCT: fragnet_recv()\n"
                       "ACT: wait for Data\n\n");
    fflush(debug_out);
  }

  /*  
  if(mode == NONBLOCK)
  {
    if((sockflags = fcntl(recv_sock, F_GETFL, 0)) < 0)
      back(FNE_BLOCK)
    sockflags |= FNDELAY;
    if((sockflags = fcntl(recv_sock, F_SETFL, sockflags)) < 0)
      back(FNE_BLOCK) 
  }
  else
    alarm(RECV_TIMEOUT);
  */
  
  /*
  **
  ** Signals blocken !!!
  **
  */

  alarm(RECV_TIMEOUT);
  while(1)
  {
    bzero(&ti_pack, TCPIPHDR + MAXLOAD);
    errno = 0;

    if((packlen = llreadtcp(pd, ti_pack, ti_pack+IPHDR, ti_pack+TCPIPHDR)) < 0 )
    {
      if(errno == EINTR)
      {
        errno = 0;
        back(FNE_TIMEDOUT_2)
      }
      else
        continue;
    }

/*
    if(fn_debug)
    {
      fprintf(debug_out, "FCT: fragnet_recv()\n"
                         "ACT: cought packet\n\n");
      fflush(debug_out);
    }
*/
     
    /* We cought a TCP pack, so let's check if it belongs to us */
    ti_ptr = (struct TCPIPPack *) ti_pack;
    if(
        ti_ptr->ip.saddr    == IP_daddr           &&
        ti_ptr->tcp.source  == TCP_dest           &&
        ti_ptr->tcp.dest    == TCP_source         &&
        ti_ptr->tcp.ack_seq == htonl(TCP_snd_nxt) &&
        ti_ptr->tcp.seq     == htonl(TCP_ack)     &&
        ti_ptr->tcp.ack     == 1                  &&
        ti_ptr->tcp.psh     == 1
      )
      break;
  }
  alarm(0);
  
  /* Calculate the new ACK value 

  if(fn_debug)
  {
    fprintf(debug_out, "FCT: fragnet_recv()\n"
                       "ACT: calc ACK\n"
                       "IHL: %hu\n"
                       "THL: %hu\n"
                       "PKL: %lu\n\n", (ti_ptr->ip.ihl << 2)
                                     , (ti_ptr->tcp.doff << 2)
                                     ,  packlen);
    fflush(debug_out);
  }
  */

  packlen -= ( (ti_ptr->ip.ihl << 2) + (ti_ptr->tcp.doff << 2) + ETHHDR );
  TCP_ack += packlen;

  /* ... copy Payload into User's Buffer */
  strncpy(buffer, ti_ptr->load, MAXLOAD);
    
  if(fn_debug)
  {
    fprintf(debug_out, "FCT: fragnet_recv()\n"
                       "ACT: recv Data (%lu Bytes)\n"
                       "IHL: %hu\n"
                       "THL: %hu\n"
                       "SEQ: %lu\n"
                       "ACK: %lu\n\n", packlen
                                     , (ti_ptr->ip.ihl << 2)
                                     , (ti_ptr->tcp.doff << 2) 
                                     , ntohl(ti_ptr->tcp.seq)
                                     , ntohl(ti_ptr->tcp.ack_seq));
    fflush(debug_out);
  }
  
  /* ... and ACKnowledge the Data */
  t_ptr = (struct tcphdr *) t_pack;
  t_ptr->source   = TCP_source;
  t_ptr->dest     = TCP_dest;
  t_ptr->seq      = htonl(TCP_seq);
  t_ptr->ack_seq  = htonl(TCP_ack);
  t_ptr->doff     = 5;
  t_ptr->ack      = 1;
  t_ptr->window   = htons(MAXLOAD);

  /* Calculate CheckSum */
  bzero(ChkSumBuf+PHDR, TCPHDR+MAXLOAD);              
  bcopy(t_pack, ChkSumBuf+PHDR, TCPHDR);
  t_ptr->check    = in_chksum((u_short *) ChkSumBuf, PTCPHDR);


  ctr = chop_up(t_pack, TCPHDR, FRAG_LEN);
  FRAGDEBUG("fragnet_recv()", TCPHDR, ctr) 

  if(fn_debug)
  {
    fprintf(debug_out, "FCT: fragnet_recv()\n"
                       "ACT: send ACK\n"
                       "SEQ: %lu\n"
                       "ACK: %lu\n\n", TCP_seq, TCP_ack);
    fflush(debug_out);
  }

  for(fc_current = fc_begin; fc_current != NULL; fc_current = fc_current->next_frag)
  {
    SENDDEBUG("fragnet_recv()")

    if(sendto(ip_sock, fc_current->frag, IPHDR + fc_current->frag_size, 0, (struct sockaddr *) &ip_sin, ip_sinlen) < 0)
      back(FNE_SEND)
  }
  
  free_fc();

  /*   
  if(mode == NONBLOCK)
  {
    if((sockflags = fcntl(recv_sock, F_GETFL, 0)) < 0)
      back(FNE_BLOCK)
    sockflags &= ~FNDELAY;
    if((sockflags = fcntl(recv_sock, F_SETFL, sockflags)) < 0)
      back(FNE_BLOCK)
  }
  */

  return(0);
}


/*
** Could be called after a fragnet_xxx() returns '-1' - indicates an Error.
** This Function prints an Error Message to stderr;
** Return Value:
**  -1: fn_errno is out of Range
**   1: fatal Error
**   0: non-fatal Error
*/
int fragnet_error(int fn_error)
{
  char  err_matrix[MAX_ERRMSGS][1024] =
        {
          "No Error occurs.",
          "fragnet_init() was called but the Connection isn't closed.",
          "Please call fragnet_init() before doing anything else.",
          "RTT Timeout.",
          "Normal Timeout.",
          "Please call fragnet_hndshk() before doing anything else.",
          "sendto() gives back an Error.",
          "recv() gives back an Error.",
          "The Data tried to send via fragnet_send() was too big.\n"
          "Either you have to set MAXLOAD to a higher Value or the Server's TCP Window is too small.",
          "The Buffer for fragnet_recv() is too small.\n"
          "It must be MAXLOAD Bytes big.",
          "You call fragnet_hndshk() while a Connection is already open.",
          "Can't enable/disable blocking Mode on Socket."
        };

  if(fn_error < 0 || fn_error > MAX_ERRMSGS)
  {
    err_mesg(WARN, "\'fn_errno\' is out of Range!\n");
    return(-1);
  }
  
  /*
  ** Print Error Message
  */
  err_mesg(WARN, "%s\n", err_matrix[fn_error]);

  /*
  ** Check if it was an fatal Error (Return Value = 1) or
  ** not (Return Value = 0)
  */
  if(fn_error == 3 || fn_error == 4 || fn_error == 6 || fn_error == 7)
    return(1);
  else
    return(0);
}
    

/*
** libpcap based routine for just reading a TCP packet
** return: packet length
*/
static int llreadtcp(pcap_t  *pdesc, char *ip, char *tcp, char *load)
{
  u_char              *pcdata;
  struct pcap_pkthdr  pchdr;
  

reread:
  errno = 0;
  if( (pcdata = (u_char *) pcap_next(pd, &pchdr)) == NULL)
  {
    if(errno == EINTR)
      return(-1);
    if(!errno)
      goto reread;
    pcap_perror(pd, "PCAP");
    err_mesg(FATAL_SYS, "ERROR: pcap_next()\nSYSERR");
  }

/*
  if(fn_debug)
  {
    fprintf(debug_out, "FCT: llreadtcp()\nINF: Packetlength: %lu\n\n", pchdr.len);
    fflush(debug_out);
  }
*/  
  if(ip)
    memcpy(ip, pcdata + ETHHDR, IPHDR);
  if(tcp)
    memcpy(tcp, pcdata + ETHHDR + IPHDR, TCPHDR);
  if(load && pchdr.len >= (TCPIPHDR + ETHHDR))
    memcpy(load, pcdata + ETHHDR + IPHDR + TCPHDR, pchdr.len - (TCPHDR+IPHDR+ETHHDR));

  return(pchdr.len);
}


/*
** return the checksum in low-order 16 bits
*/
u_short in_chksum(register u_short *ptr, register int nbytes)
{
  register long     sum;      /* assumes long == 32 bist */
  u_short           oddbyte;
  register u_short  answer;   /* assumes u_short == 16 bits */

  /*
  ** Our algorithm is simple, using a 32-bit accumulator (sum),
  ** we add sequential 16-bit words to it, and at the end, fold back
  ** all the carry bits from the top 16 bits into the lower 16 bits.
  */

  sum = 0;
  while(nbytes > 1)
  {
    sum += *ptr++;
    nbytes -= 2;
  }

  /* mop up an odd byte, if necessary */
  if(nbytes == 1)
  {
    oddbyte = 0;    /* make sure top half is zero */
    *((u_char *) &oddbyte) = *(u_char *) ptr;   /* one byte only */
    sum += oddbyte;
  }

  /*
  ** Add back carry outs from top 16 bits to low 16 bits.
  */
  sum = (sum >> 16) + (sum & 0xFFFF);   /* add high-16 to low-16 */
  sum += (sum >> 16);                   /* add carry */
  answer = ~sum;                        /* ones-complement, then truncate to
                                           16 bits */

  return(answer);
}


/*
** IP address into network byte order
*/
u_int nameResolve(char *hostname)
{
  struct in_addr addr;
  struct hostent *hostEnt;

  if((addr.s_addr=inet_addr(hostname)) == -1)
  {
    if(!(hostEnt=gethostbyname(hostname)))
      err_mesg(FATAL, "Name lookup failure: `%s`\n", hostname);
    bcopy(hostEnt->h_addr, (char *) &addr.s_addr, hostEnt->h_length);
	}

  return(addr.s_addr);
}


/*
** Network byte order into IP address
*/
char *hostLookup(u_long in)
{
  char            hostname[1024];
  struct in_addr  addr;
  struct hostent  *hostEnt;

  bzero(&hostname, sizeof(hostname));
  addr.s_addr = in;

  if((hostEnt = gethostbyaddr((char *)&addr, sizeof(struct in_addr), AF_INET)) == NULL)
    strcpy(hostname, inet_ntoa(addr));
  else
    strcpy(hostname, hostEnt->h_name);

  return(strdup(hostname));
}


