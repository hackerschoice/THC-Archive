#ifndef __LIBFRAGNET_HDR
#define __LIBFRAGNET_HDR

#include <sys/types.h>
#include "fragnet.h"

#define TCPHDR          20
#define IPHDR           20
#define TCPIPHDR        IPHDR + TCPHDR
#define PHDR            12
#define PTCPHDR         PHDR + TCPHDR
#define ETHHDR          14
#define IP_MF           0x2000

#define RECV_TIMEOUT    10    /* Timeout (Seconds) for fragnet_recv()    */
                              /* and fragnet_shtdwn() in TIME_WAIT State */
                              /* if 0 -> blocking Mode                   */
#define MSL2            60    /* Time to wait (Seconds) after sending    */
                              /* our last ACK.                           */
                              /* It is used to verify if our ACK reaches */
                              /* the Server.                              */


#define SNAPLEN         512   /* pcap_open_live() capture length */
#define TO_MS           2000  /*   -   "    -     read timeout */  

#define back(err) \
{ \
  fn_errno = err; \
  return(-1);     \
}
  

#define RCVRST(fct)\
if(\
   ti_ptr->ip.saddr    == IP_daddr               &&\
   ti_ptr->ip.daddr    == IP_saddr               &&\
   ti_ptr->tcp.source  == TCP_dest               &&\
   ti_ptr->tcp.dest    == TCP_source             &&\
   ti_ptr->tcp.rst     == 1\
  )\
{\
  if(fn_debug)\
    err_mesg(WARN, "%s: received RST!\n", fct);\
  return(-1);\
}


#define SENDDEBUG(fct) \
if(fn_debug)  \
{ \
  fprintf(debug_out, "FCT: %s\n"  \
                     "ACT: send IP Fragment\n"  \
                     "NUM: %u\n"  \
                     "SIZ: %u\n"  \
                     "OFS: %hu\n\n", fct, fc_current->frag_nr \
                                   , fc_current->frag_size  \
                                   , fc_current->frag_off);  \
  fflush(debug_out); \
}


#define ACKDEBUG(fct) \
if(fn_debug)  \
{ \
  fprintf(debug_out, "FCT: %s\n"  \
                     "ACT: received ACK\n"  \
                     "SEQ: %lu\n" \
                     "ACK: %lu\n" \
                     "WDW: %hu\n\n", fct, ntohl(ti_ptr->tcp.seq) \
                                 , ntohl(ti_ptr->tcp.ack_seq), TCP_window);  \
  fflush(debug_out);  \
}

#define FRAGDEBUG(fct, size, ctr) \
if(fn_debug)  \
{ \
  fprintf(debug_out, "FCT: %s\n"  \
                     "ACT: chop_up(): %u Bytes to %u Frags\n\n"  \
                   , fct, size, ctr); \
  fflush(debug_out);  \
}
                                                                                                                         

/******************** GLOBALS ************************************************/

u_long              TCP_seq;        /* our actual Seq# */
u_long              TCP_snd_nxt;    /* the next Seq# to use, ACK of Sender */
u_long              TCP_isn;        /* our Initial Sequence Number */
u_long              TCP_ack;        /* our next ACK */
u_short             TCP_window;     /* Window of Sender */
u_short             TCP_source;     /* source Port, Network Byte Order */
u_short             TCP_dest;       /* dest Port, Network Byte Order */

u_long              IP_saddr;       /* our IP Addr, Network Byte Order */
u_long              IP_daddr;       /* the dest IP Addr, Network Byte Order */


char                eth_dst[ETH_ALEN];  /* dest. etheraddr */
char                eth_src[ETH_ALEN];  /* src. etheraddr */

int                 ip_sock;         /* raw ip socket for sending */

struct sockaddr_in  ip_sin;
u_int               ip_sinlen;

pcap_t              *pd;            /* libpcap */
struct bpf_program  filter;         /* filter program */
bpf_u_int32         localnet;
bpf_u_int32         netmask;
char                *device;
char                errbuf[PCAP_ERRBUF_SIZE];


u_int               closed    = 1;
u_int               inited    = 0;
u_int               handshake = 0;
u_int               shtdwn    = 1;

char                ChkSumBuf[PTCPHDR+MAXLOAD] = { 0 };

struct rtt_struct  rttinfo;         /* RTT structure */
int                rttfirst   = 1;

struct TCPIPPack
{
  struct iphdr  ip;
  struct tcphdr tcp;
  char          load[MAXLOAD];
};

struct TCPPack
{
  struct tcphdr tcp;
  char          load[MAXLOAD];
};

struct IPPack
{
  struct iphdr  ip;
  char          load[FRAG_LEN];
};

struct EthPack
{
  struct ethhdr       eth;
  char                load[IPHDR + FRAG_LEN];
};

struct PseudoHdr    /* for TCP checksum calculation */
{
  u_long  saddr;
  u_long  daddr;
  u_char  pad;
  u_char  proto;
  u_short tcplen;
} *ps_hdr;

typedef struct frag
{
  u_int   frag_nr;
  u_short frag_off;
  size_t  frag_size;  /* w/o the size of the IP Header */
  char    frag[IPHDR + FRAG_LEN];
  struct  frag *next_frag;
} fragchain;

fragchain *fc_begin;

extern u_int  fn_errno;
extern u_int  fn_debug;
extern FILE   *debug_out;

/* internal routines */
static int ether_a2e(char addr[ETH_ALEN], char *estring);
/*static int llsendto(int sock, char *packet, int packsize, struct sockaddr in_sin, int in_sinlen, char *edst, u_short etype);*/
static int llreadtcp(pcap_t  *pdesc, char *ip, char *tcp, char *load);

#endif
