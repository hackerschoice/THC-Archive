/*
 * hydra v3.1 (c) 2001-2004 by van Hauser / THC <vh@thc.org>
 * http://www.thc.org
 *
 * Parallel host scanning by m0j0.j0j0 [m0j0@foofus.net]
 *
 * Parallized network login hacker. Do only use for legal purposes.
 */

#ifdef NESSUS_PLUGIN
#include <includes.h>
#endif

#include "hydra.h"

extern void service_telnet(unsigned long int ip, int sp, unsigned char options, char *miscptr, FILE * fp, int port);
extern void service_ftp(unsigned long int ip, int sp, unsigned char options, char *miscptr, FILE * fp, int port);
extern void service_pop3(unsigned long int ip, int sp, unsigned char options, char *miscptr, FILE * fp, int port);
extern void service_imap(unsigned long int ip, int sp, unsigned char options, char *miscptr, FILE * fp, int port);
extern void service_ldap(unsigned long int ip, int sp, unsigned char options, char *miscptr, FILE * fp, int port);
extern void service_cisco(unsigned long int ip, int sp, unsigned char options, char *miscptr, FILE * fp, int port);
extern void service_cisco_enable(unsigned long int ip, int sp, unsigned char options, char *miscptr, FILE * fp, int port);
extern void service_vnc(unsigned long int ip, int sp, unsigned char options, char *miscptr, FILE * fp, int port);
extern void service_socks5(unsigned long int ip, int sp, unsigned char options, char *miscptr, FILE * fp, int port);
extern void service_rexec(unsigned long int ip, int sp, unsigned char options, char *miscptr, FILE * fp, int port);
extern void service_nntp(unsigned long int ip, int sp, unsigned char options, char *miscptr, FILE * fp, int port);
extern void service_http(unsigned long int ip, int sp, unsigned char options, char *miscptr, FILE * fp, int port);
extern void service_http_proxy(unsigned long int ip, int sp, unsigned char options, char *miscptr, FILE * fp, int port);
extern void service_icq(unsigned long int ip, int sp, unsigned char options, char *miscptr, FILE * fp, int port);
extern void service_pcnfs(unsigned long int ip, int sp, unsigned char options, char *miscptr, FILE * fp, int port);
extern void service_smb(unsigned long int ip, int sp, unsigned char options, char *miscptr, FILE * fp, int port);
#ifdef LIBDES
extern void service_smbnt(unsigned long int ip, int sp, unsigned char options, char *miscptr, FILE * fp, int port);
#endif
extern void service_mysql(unsigned long int ip, int sp, unsigned char options, char *miscptr, FILE * fp, int port);

/* ADD NEW SERVICES HERE */

#define SERVICES  "telnet ftp pop3 imap smb smbnt http https http-proxy cisco cisco-enable ldap mysql nntp vnc rexec socks5 icq pcnfs"
/* ADD NEW SERVICES HERE */

#define MAXBUF      264
#define MAXTASKS    255
#define MAXSERVERS  16

#define PROGRAM   "Hydra"
#define VERSION   "v3.1"
#define AUTHOR    "van Hauser / THC"
#define EMAIL     "<vh@thc.org>"
#define RESSOURCE "http://www.thc.org"

#define DEBUG	  0
#define WAITTIME  30
#define TASKS     4
#define SERVERS   1
#define RESTOREFILE "./hydra.restore"

extern void hydra_tobase64(unsigned char *buf);

extern int errno;
extern char HYDRA_EXIT[5];
extern int debug;
extern int verbose;
extern int waittime;
extern int port;
extern int found;
extern int use_proxy;
extern int proxy_string_port;
extern unsigned long int proxy_string_ip;
extern char *proxy_authentication;
extern char *cmdlinetarget;
char *prg, *tmp;
size_t extra;
int killed = 0, alive = 0;
int process_restore = 0;
int start_login_no = 0, start_pass_no = 0;

static pid_t pids[MAXTASKS];
static pid_t addr_pids[MAXSERVERS];

/* moved for restore feature */
int scans = 0, tasks = 1, servers = SERVERS, exit_found = 0;
unsigned char options = 0;
int try_password_same_as_login = 0, try_null_password = 0, restore = 0;
char *colonfile = NULL, *outfile_ptr = NULL, *infile_ptr = NULL;
char *miscptr = NULL, *server, *service;
char *login_ptr = NULL, *pass_ptr = "", *csv_ptr = NULL, *ipaddr_ptr_save = NULL, *ipaddr_ptr = NULL;
size_t countlogin = 1, sizelogin = 0, countpass = 0, sizepass = 0, countservers = 1, sizeipaddr = 0;
unsigned long int todo = 0;
unsigned long int ip = 0;
int showAttempt = 0, a = 0, b = 0;
unsigned long int sent = 0;
char *t_login_ptr = NULL;
char *t_pass_ptr = NULL;
int dont_unlink = 0;

void
help()
{
  printf("%s %s [%s] (c) 2004 by %s %s\n\n"
         "Syntax: %s [[[-l LOGIN|-L FILE] [-p PASS|-P FILE]] | "
         "[-C FILE]] [-o FILE] [-t TASKS] [-g TASKS] [-T SERVERS] [-M FILE] "
         "[-w TIME] [-f] [-e ns] [-s PORT] [-S] [-vV] server service [OPT]\n", PROGRAM, VERSION, RESSOURCE, AUTHOR, EMAIL, prg);
  printf("\nOptions:\n"
         "  -R        restore a previous aborted/crashed session\n");
#ifdef OPENSSL
  printf("  -S        connect via SSL\n");
#endif
  printf("  -s PORT   if the service is on a different default port, "
         "define it here\n"
         "  -l LOGIN or -L FILE login with LOGIN name, or load "
         "several logins from FILE\n"
         "  -p PASS  or -P FILE try password PASS, or load several "
         "passwords from FILE\n"
         "  -e ns     additional checks, \"n\" for null password, \"s\" "
         "try login as pass\n"
         "  -C FILE   colon seperated \"login:pass\" format, instead of "
         "-L/-P option\n"
         "  -M FILE   file containing server list (parallizes attacks, see -T)\n"
         "  -o FILE   write found login/password pairs to FILE instead "
         "of stdout\n"
         "  -f        exit after the first found login/password pair\n"
         "  -t TASKS  run TASKS number of connects in parallel "
         "(default: %d)\n"
         "  -g TASKS  start TASKS number per second until -t TASKS are"
         " reached\n"
         "  -T SERVERS attack servers in parallel (-T * -t = no. of tasks spawned!)\n"
         "  -w TIME   in seconds, defines the max wait reply time "
         "(default: %d)\n"
         "  -v / -V   verbose mode / show login+pass combination for each attempt\n"
         "  server    the target server (use either this OR the -M option)\n"
         "  service   the service to crack. Supported protocols: [%s]\n"
         "  OPT       some service modules need special input (see README!)\n\n"
         "Use HYDRA_PROXY_HTTP/HYDRA_PROXY_CONNECT and HYDRA_PROXY_AUTH env for a proxy.\n"
         "%s is a tool to guess valid login/password pairs on a "
         "target server.\nYou can always find the newest version at %s\n" "Use this tool only for legal purposes!\n", TASKS, WAITTIME, SERVICES, PROGRAM, RESSOURCE);
  exit(-1);
}

void
bail(char *text)
{
  fprintf(stderr, "Error: %s\n", text);
  exit(-1);
}

void
hydra_restore_write(int exit_msg)
{
  FILE *f;
  int i = 0;

  if (process_restore != 1)
    return;

  if ((f = fopen(RESTOREFILE, "w")) == NULL) {
    fprintf(stderr, "Error: Can not create restore file (%s) - \n", RESTOREFILE);
    perror("");
    process_restore = 0;
  } else if (verbose)
    printf("Writing restore file... ");

  if (options & OPTION_SSL)
    i = i | 1;
  if (verbose)
    i = i | 2;
  if (showAttempt)
    i = i | 4;
  if (exit_found)
    i = i | 8;
  if (debug)
    i = i | 16;
  if (try_null_password)
    i = i | 32;
  if (try_password_same_as_login)
    i = i | 64;
  fprintf(f, "%d\n%d\n%d\n%d\n%d\n%lu\n%lu\n%lu\n%lu\n%s\n%s\n%s\n%s\n%d\n%lu\n",
    colonfile == NULL ? 1 : 2, i, a, b, tasks, sent, todo, (unsigned long int) countlogin, (unsigned long int) countpass,
    outfile_ptr == NULL ? "" : outfile_ptr, server, service, miscptr == NULL ? "" : miscptr, port, ip);
  fprintf(f, "%lu\n%d\n", (unsigned long int) sizelogin, t_login_ptr - login_ptr);
  fwrite(login_ptr, sizelogin, 1, f);
  if (colonfile == NULL) {
    fprintf(f, "%lu\n%d\n", (unsigned long int) sizepass, t_pass_ptr - pass_ptr);
    fwrite(pass_ptr, sizepass, 1, f);
  }
  fprintf(f, "%lu\n%d\n", (unsigned long int) sizeipaddr, ipaddr_ptr - ipaddr_ptr_save);
  fwrite(ipaddr_ptr_save, sizeipaddr, 1, f);
  fclose(f);
  if (verbose)
    printf ("done\n");
  if (exit_msg)
    printf("The session file %s was written. Type \"%s -R\" to resume session. This is still experimental!\n", RESTOREFILE, prg);
/*
printf("XXX->%d\n%d\n%d\n%d\n%d\n%lu\n%lu\n%lu\n%lu\n%s\n%s\n%s\n%s\n%d\n%lu\n",
    colonfile == NULL ? 1 : 2, i, a, b, tasks, sent, todo, (unsigned long int) countlogin, (unsigned long int) countpass,
    outfile_ptr == NULL ? "" : outfile_ptr, server, service, miscptr == NULL ? "" : miscptr, port, ip);
printf("YYY->%lu\n%d\n", (unsigned long int) sizelogin, t_login_ptr - login_ptr);
*/
}

int
hydra_restore_read()
{
  FILE *f;
  int i, ssl = 0;
  char out[1024], *ptr;

  ptr = out;
  if ((f = fopen(RESTOREFILE, "r")) == NULL) {
    fprintf(stderr, "Error: restore file (%s) not found - ", RESTOREFILE);
    perror("");
    exit(-1);
  }

  fgets(out, sizeof(out), f);
  if (( out[0] != '1' && out[0] != '2') || ( out[1] != 0 && out[1] != '\n')) {
    fprintf(stderr, "Error: invalid restore file\n");
    exit(-1);
  }
  if (out[0] == '1')
    colonfile = NULL;
  else
    colonfile = prg;
  i = atoi(fgets(out, sizeof(out), f));
  if ((i & 1) == 1) {
    ssl = 1;
    options = options & OPTION_SSL;
  }
  if ((i & 2) == 2)
    verbose = 1;
  if ((i & 4) == 4)
    showAttempt = 1;
  if ((i & 8) == 8)
    exit_found = 1;
  if ((i & 16) == 16)
    debug = 1;
  if ((i & 32) == 32)
    try_null_password = 1;
  if ((i & 64) == 64)
    try_password_same_as_login = 1;

  start_login_no = atoi(fgets(out, sizeof(out), f));
  start_pass_no = atoi(fgets(out, sizeof(out), f));
  tasks = strtoul(fgets(out, sizeof(out), f), (char **)NULL, 10);
  sent = strtoul(fgets(out, sizeof(out), f), (char **)NULL, 10);
  todo = strtoul(fgets(out, sizeof(out), f), (char **)NULL, 10);
  countlogin = strtoul(fgets(out, sizeof(out), f), (char **)NULL, 10);
  countpass = strtoul(fgets(out, sizeof(out), f), (char **)NULL, 10);
  outfile_ptr = strdup(fgets(out, sizeof(out), f));
  if (outfile_ptr[strlen(outfile_ptr) - 1] == '\n')
    outfile_ptr[strlen(outfile_ptr) - 1] = 0;
  if (strlen(outfile_ptr) == 0)
    outfile_ptr = NULL;
  server = strdup(fgets(out, sizeof(out), f));
  if (server[strlen(server) - 1] == '\n')
    server[strlen(server) - 1] = 0;
  service = strdup(fgets(out, sizeof(out), f));
  if (service[strlen(service) - 1] == '\n')
    service[strlen(service) - 1] = 0;
  miscptr = strdup(fgets(out, sizeof(out), f));
  if (miscptr[strlen(miscptr) - 1] == '\n')
    miscptr[strlen(miscptr) - 1] = 0;
  if (strlen(miscptr) == 0)
    miscptr = NULL;
  port = atoi(fgets(out, sizeof(out), f));
  ip = strtoul(fgets(out, sizeof(out), f), (char **)NULL, 10);
  sizelogin = strtoul(fgets(out, sizeof(out), f), (char **)NULL, 10);
  login_ptr = malloc(sizelogin);
  t_login_ptr = login_ptr + strtoul(fgets(out, sizeof(out), f), (char **)NULL, 10);
  fread(login_ptr, sizelogin, 1, f);
  if (colonfile == NULL) {
    sizepass = strtoul(fgets(out, sizeof(out), f), (char **)NULL, 10);
    pass_ptr = malloc(sizepass);
    t_pass_ptr = pass_ptr + strtoul(fgets(out, sizeof(out), f), (char **)NULL, 10);
    fread(pass_ptr, sizepass, 1, f);
  } else {
    pass_ptr = csv_ptr = login_ptr;
  }

  sizeipaddr = strtoul(fgets(out, sizeof(out), f), (char **)NULL, 10);
  ipaddr_ptr_save = malloc(sizeipaddr);
  ipaddr_ptr = ipaddr_ptr_save + strtoul(fgets(out, sizeof(out), f), (char **)NULL, 10);
  fread(ipaddr_ptr_save, sizeipaddr, 1, f);

/*
printf("XXX->%d\n%d\n%d\n%d\n%d\n%lu\n%lu\n%lu\n%lu\n%s\n%s\n%s\n%s\n%d\n%lu\n",
    colonfile == NULL ? 1 : 2, i, a, b, tasks, sent, todo, (unsigned long int) countlogin, (unsigned long int) countpass,
    outfile_ptr == NULL ? "" : outfile_ptr, server, service, miscptr == NULL ? "" : miscptr, port, ip);
printf("YYY->%lu\n%d\n", (unsigned long int) sizelogin, t_login_ptr - login_ptr);
*/
  fclose(f);
  return ssl;
}


void
killed_childs(int signo)
{
  killed++;
  alive--;
  (void) wait3(NULL, WNOHANG, NULL);
}

void
kill_children(int signo)
{
  int i;

  if (process_restore == 1)
    hydra_restore_write(1);

  for (i = 0; i < MAXTASKS; i++)
    if (pids[i] > 0)
      kill(pids[i], SIGTERM);
  for (i = 0; i < MAXSERVERS; i++)
    if (addr_pids[i] > 0)
      kill(addr_pids[i], SIGTERM);
  sleep(1);
  for (i = 0; i < MAXSERVERS; i++)
    if (addr_pids[i] > 0)
      kill(addr_pids[i], SIGKILL);
  for (i = 0; i < MAXTASKS; i++)
    if (pids[i] > 0)
      kill(pids[i], SIGKILL);

  exit(0);
}

unsigned long int
countlines(FILE * fp)
{
  size_t lines = 0, size = 0;
  char *buf = malloc(MAXBUF);

  while (!feof(fp)) {
    if (fgets(buf, MAXBUF, fp) != NULL) {
      if (buf[0] != 0) {
        size += strlen(buf);
        lines++;
      }
    }
  }
  free(buf);
  rewind(fp);
  size++;
  extra = size;
  return lines;
}

void
fill_mem(char *ptr, FILE * fp)
{
  char tmp[MAXBUF + 4] = "";

  while (!feof(fp)) {
    if (fgets(tmp, MAXBUF, fp) != NULL) {
      if (tmp[0] != 0) {
        if (tmp[strlen(tmp) - 1] == '\n')
          tmp[strlen(tmp) - 1] = '\0';
        if (tmp[strlen(tmp) - 1] == '\r')
          tmp[strlen(tmp) - 1] = '\0';
        memcpy(ptr, tmp, strlen(tmp));
        ptr += strlen(tmp);
        *ptr = '\0';
        ptr++;
      }
    }
  }
  fclose(fp);
}

char *
hydra_build_time()
{
  static char datetime[24];
  struct tm *the_time;
  time_t epoch;

  time(&epoch);
  the_time = localtime(&epoch);
  strftime(datetime, sizeof(datetime), "%Y-%m-%d %H:%M:%S", the_time);
  return (char *) &datetime;
}

#ifdef NESSUS_PLUGIN
int
hydra_main(int soc, struct arglist *nessus, int argc, char *argv[])
{
#else
int
hydra_main(int soc, void *nessus, int argc, char *argv[])
{
#endif

  unsigned int group = MAXTASKS + 1;
  char *login = NULL, *loginfile = NULL, *pass = NULL, *passfile = NULL;
  char  *proxy_string = NULL;
  FILE *lfp, *pfp, *cfp, *ifp, *ofp = stdout;
  int addr_socketpairs[MAXSERVERS][2];
  size_t countinfile = 1, sizeinfile = 0;
  unsigned long int math2;
  struct hostent *target;
  struct in_addr in;
  int i, j, sID;
  time_t starttime, elapsed, elapsed2;
  char *tmpptr;
  unsigned int ssl = 0;

#ifdef NESSUS_PLUGIN
  char *svc_kb_name;
  char *asc_port;
#endif
  char empty_login[2] = "";

/* new for parallel host attacks */
  int a = 0, done = 0;
  char rc;

  prg = argv[0];
  debug = 0;
  verbose = 0;
  found = 0;
  use_proxy = 0;
  proxy_string_ip = proxy_string_port = 0;
  proxy_authentication = cmdlinetarget = NULL;
  waittime = WAITTIME;
  port = 0;
  tasks = TASKS;
  if (argc < 4 && (argc < 2 || strcmp(argv[1], "-R") != 0))
    help();
  tmp = malloc(MAXBUF);
  (void) setvbuf(stdout, NULL, _IONBF, 0);

  while ((i = getopt(argc, argv, "Rde:vVl:fg:L:p:P:o:M:C:t:T:m:w:s:S")) >= 0) {
    switch (i) {
    case 'R':
      restore = 1;
      if (argc != 2) {
        fprintf(stderr, "Error: no option may be supplied together with -R\n");
        exit(-1);
      }
      break;
    case 'd':
      debug = 1;
      verbose++;
      break;
    case 'e':
      i = 0;
      while (i < strlen(optarg)) {
        switch (optarg[i]) {
        case 'n':
          try_null_password = 1;
          break;
        case 's':
          try_password_same_as_login = 1;
          break;
        default:
          fprintf(stderr, "Error: unknown mode %c for option -e, only supporting \"n\" and \"s\"\n", optarg[i]);
          exit(-1);
        }
        i++;
      }
      break;
    case 'v':
      verbose = 1;
      break;
    case 'V':
      showAttempt = 1;
      break;
    case 'l':
      login = optarg;
      break;
    case 'L':
      loginfile = optarg;
      break;
    case 'p':
      pass = optarg;
      break;
    case 'P':
      passfile = optarg;
      break;
    case 'f':
      exit_found = 1;
      break;
    case 'g':
      group = atoi(optarg);
      break;
    case 'o':
      outfile_ptr = optarg;
      break;
    case 'M':
      infile_ptr = optarg;
      break;
    case 'C':
      colonfile = optarg;
      break;
    case 't':
      tasks = atoi(optarg);
      break;
    case 'T':
      servers = atoi(optarg);
      break;
    case 'm':
      miscptr = optarg;
      break;
    case 'w':
      waittime = atoi(optarg);
      break;
    case 's':
      port = atoi(optarg);
      break;
    case 'S':
#ifndef OPENSSL
      fprintf(stderr, "Sorry, hydra was compiled without SSL support. Install openssl and recompile!\n");
      ssl = 0;
      break;
#else
      ssl = 1;
      break;
#endif
    default:
      fprintf(stderr, "Error: unknown option -%c\n", i);
      help();
    }
  }

  if (restore) {
    ssl = hydra_restore_read();
  } else {
    if (servers > MAXSERVERS) {
      fprintf(stderr, "Option -T needs to be a number between 1 (default) and %d\n", MAXSERVERS);
      exit(-1);
    }
    if (infile_ptr != NULL) {
      if (optind + 2 < argc)
        bail("The -M FILE option can not be used together with a host on the commandline");
      if (optind + 2 == argc)
        fprintf(stderr, "Warning: With the -M FILE option you can not specify a server on the commandline. Lets hope you did everything right!\n");
      server = NULL;
      service = argv[optind];
      if (optind + 2 == argc)
        miscptr = argv[optind + 1];
    } else if (optind + 2 != argc && optind + 3 != argc) {
      server = NULL;
      service = NULL;
      help();
    } else {
      server = argv[optind];
      cmdlinetarget = argv[optind];
      service = argv[optind + 1];
      if (optind + 3 == argc)
        miscptr = argv[optind + 2];
    }

    i = 0;
    if (strcmp(service, "telnet") == 0)
      i = 1;
    if (strcmp(service, "ftp") == 0)
      i = 1;
    if (strcmp(service, "pop3") == 0)
      i = 1;
    if (strcmp(service, "imap") == 0)
      i = 1;
    if (strcmp(service, "rexec") == 0)
      i = 1;
    if (strcmp(service, "nntp") == 0)
      i = 1;
    if (strcmp(service, "socks5") == 0)
      i = 1;
    if (strcmp(service, "icq") == 0)
      i = 1;
    if (strcmp(service, "mysql") == 0)
      i = 1;
    if (strcmp(service, "http-proxy") == 0)
      i = 1;
/* ADD NEW SERVICES HERE */
    if (strcmp(service, "smb") == 0) {
      if (tasks > 1) {
        fprintf(stderr, "Reduced number of tasks to 1 (smb does not like parallel connections)\n");
        tasks = 1;
      }
      i = 1;
    }
#ifdef LIBDES
    if (strcmp(service, "smbnt") == 0) {
      if (tasks > 1) {
        fprintf(stderr, "Reduced number of tasks to 1 (smb does not like parallel connections)\n");
        tasks = 1;
      }
      i = 1;
      if (miscptr == NULL) {
        bail("You must supply a testing method via the -m option.\n\tValid methods are: L, LH, D, DH, B, BH.\n\tSee README for more information.\n");
      }
    }
#endif
    if (strcmp(service, "pcnfs") == 0) {
      i = 1;
      if (port == 0) {
        fprintf(stderr, "Error: You must set the port for pcnfs with -s (run \"rpcinfo -p %s\" and look for the pcnfs v2 UDP port)\n", server);
        exit(-1);
      }
    }
    if (strcmp(service, "cisco") == 0) {
      i = 2;
      login = empty_login;
      if (tasks > 4)
        printf("Warning: you should set the number of parallel task to 4 for cisco services.\n");
    }
    if (strcmp(service, "ldap") == 0) {
      i = 1;
      if ((miscptr != NULL && login != NULL)
          || (miscptr != NULL && loginfile != NULL) || (login != NULL && loginfile != NULL))
        bail("Error: you may only use one of -l, -L or -m (or none)\n");
      if (login == NULL && loginfile == NULL && miscptr == NULL)
        fprintf(stderr, "Warning: no DN to authenticate to defined, using DN of null (use -m, -l or -L to define DNs)\n");
      if (login == NULL && loginfile == NULL) {
        i = 2;
        login = empty_login;
      }
    }
    if (strcmp(service, "cisco-enable") == 0) {
      i = 3;
      if (login == NULL)
        login = empty_login;
      if (miscptr == NULL) {
        bail("Error: You must supply the initial password to logon via the -m option\n");
      }
      if (tasks > 4)
        printf("Warning: you should set the number of parallel task to 4 for cisco enable services.\n");
    }
    if (strcmp(service, "vnc") == 0) {
      i = 2;
      login = empty_login;
      if (tasks > 4)
        printf("Warning: you should set the number of parallel task to 4 for vnc services.\n");
    }
    if (strcmp(service, "www") == 0 || strcmp(service, "http") == 0) {
      i = 1;
      if (miscptr == NULL)
        bail("You must supply the web page as an additional option or via -m");
      if (*miscptr != '/')
        bail("The web page you supplied must start with a \"/\", e.g. \"/protected/login\"");
      strcpy(service, "www");
      if (getenv("HYDRA_PROXY_HTTP") && getenv("HYDRA_PROXY_CONNECT"))
        bail("Found HYDRA_PROXY_HTTP *and* HYDRA_PROXY_CONNECT environment variables - you can use only ONE for the service www!");
      if (getenv("HYDRA_PROXY_HTTP")) {
        printf("Using HTTP Proxy: %s\n", getenv("HYDRA_PROXY_HTTP"));
        use_proxy = 1;
      }
    }
#ifdef OPENSSL
    if (strcmp(service, "ssl") == 0 || strcmp(service, "https") == 0) {
      i = 1;
      if (miscptr == NULL)
        bail("You must supply the web page as an additional option or via -m");
      if (*miscptr != '/')
        bail("The web page you supplied must start with a \"/\", e.g. \"/protected/login\"");
      ssl = 1;
      strcpy(service, "www");
    }
#endif
/* ADD NEW SERVICES HERE - if not done above */

    if (i == 0)
      bail("Unknown service");

    if (strcmp(service, "www") != 0 && getenv("HYDRA_PROXY_HTTP"))
      fprintf(stderr, "Warning: the HYDRA_PROXY_HTTP environment variable works only with the www module, ignored...\n");

    if (i == 2 && ((login != NULL && strlen(login) > 0) || loginfile != NULL || colonfile != NULL))
      bail
        ("The cisco and vnc crack modes are only using the -p or -P option, not login (-l, -L) or colon file (-C).\nUse the normal telnet crack mode for cisco using \"Username:\" authentication.\n");
    if (i == 1 && login == NULL && loginfile == NULL && colonfile == NULL)
      bail("I need at least either the -l, -L or -C option to know the login");
    if (colonfile != NULL && ((login != NULL || loginfile != NULL)
                              || (pass != NULL && passfile != NULL)))
      bail("The -C option is standalone, dont use it with -l/L and -p/P !");
    if (try_password_same_as_login == 0 && try_null_password == 0 && pass == NULL && passfile == NULL && colonfile == NULL)
      bail("I need at least the -e, -p or -P option to have some passwords!");
    if (tasks < 1 || tasks > MAXTASKS) {
      fprintf(stderr, "Option -t needs to be a number between 1 and %d\n", MAXTASKS);
      exit(-1);
    }

    if (loginfile != NULL) {
      if ((lfp = fopen(loginfile, "r")) == NULL)
        bail("File for logins not found!");
      countlogin = countlines(lfp);
      sizelogin = extra;
      if (countlogin == 0)
        bail("File for logins is empty!");
      login_ptr = malloc(sizelogin);
      fill_mem(login_ptr, lfp);
    } else
      login_ptr = login;
    if (passfile != NULL) {
      if ((pfp = fopen(passfile, "r")) == NULL)
        bail("File for passwords not found!");
      countpass = countlines(pfp);
      sizepass = extra;
      if (countpass == 0)
        bail("File for passwords is empty!");
      pass_ptr = malloc(sizepass);
      fill_mem(pass_ptr, pfp);
    } else {
      if (pass != NULL) {
        pass_ptr = pass;
        countpass = 1;
      }
    }
    if (colonfile != NULL) {
      if (try_password_same_as_login + try_null_password > 0)
        bail("Error: the -C option may not be used together with the -e option\n");
      if ((cfp = fopen(colonfile, "r")) == NULL)
        bail("File with login:password information not found!");
      countlogin = countlines(cfp);
      sizelogin = extra;
      if (countlogin == 0)
        bail("File for login:password information is empty!");
      csv_ptr = malloc(sizelogin);
      fill_mem(csv_ptr, cfp);
      countpass = 1;
      pass_ptr = login_ptr = csv_ptr;
      while (*pass_ptr != '\0' && *pass_ptr != ':')
        pass_ptr++;
      if (*pass_ptr == ':') {
        *pass_ptr = '\0';
        pass_ptr++;
      } else {
        fprintf(stderr, "Invalid line in colonfile: %s\n", login_ptr);
        pass_ptr = HYDRA_EXIT;
      }
    }

    countpass += try_password_same_as_login + try_null_password;

    if (fopen(RESTOREFILE, "r") != NULL) {
      fprintf(stderr, "WARNING: Restorefile (%s) from a previous session found, to prevent overwriting, you have 10 seconds to abort...\n", RESTOREFILE);
      sleep(10);
    }

    if (infile_ptr != NULL) {
      if ((ifp = fopen(infile_ptr, "r")) == NULL)
        bail("File for IP addresses not found!");
      countinfile = countlines(ifp);
      sizeinfile = extra;
      if (countinfile == 0)
        bail("File for IP addresses is empty!");
      if (servers > countinfile)
        servers = countinfile;
      countservers = countinfile;
      ipaddr_ptr = malloc(sizeinfile);
      fill_mem(ipaddr_ptr, ifp);
      sizeipaddr = sizeinfile;
    } else {
      ipaddr_ptr = server;
      countservers = servers = 1;
      sizeipaddr = strlen(server) + 1;
    }
    ipaddr_ptr_save = ipaddr_ptr;

  }

  if (getenv("HYDRA_PROXY_CONNECT") && use_proxy == 0) {
    printf("Using Connect Proxy: %s\n", getenv("HYDRA_PROXY_CONNECT"));
    use_proxy = 2;
  }
  if (use_proxy == 1)
    proxy_string = getenv("HYDRA_PROXY_HTTP");
  if (use_proxy == 2)
    proxy_string = getenv("HYDRA_PROXY_CONNECT");
  if (proxy_string != NULL) {
    if (strstr(proxy_string, "//") != NULL) {
      proxy_string = strstr(proxy_string, "//");
      proxy_string += 2;
    }
    if (proxy_string[strlen(proxy_string) - 1] == '/')
      proxy_string[strlen(proxy_string) - 1] = 0;
    if ((tmpptr = index(proxy_string, ':')) == NULL)
      use_proxy = 0;
    else {
      *tmpptr = 0;
      tmpptr++;
#ifdef CYGWIN
      if (inet_aton(proxy_string, &in) <= 0) {
#else
      if (inet_pton(AF_INET, proxy_string, &in) <= 0) {
#endif
        if ((target = gethostbyname(proxy_string)) != NULL)
          memcpy(&proxy_string_ip, target->h_addr, 4);
        else
          use_proxy = 0;
      } else {
        memcpy(&proxy_string_ip, &in.s_addr, 4);
      }
      proxy_string_port = atoi(tmpptr);
    }
    if (use_proxy == 0)
      fprintf(stderr, "Warning: invalid proxy definition. Syntax: \"http://1.2.3.4:80/\".\n");
  } else
    use_proxy = 0;
  if (use_proxy > 0 && (tmpptr = getenv("HYDRA_PROXY_AUTH")) != NULL) {
    if (index(tmpptr, ':') == NULL) {
      fprintf(stderr, "Warning: invalid proxy authentication. Syntax: \"login:password\". Ignoring ...\n");
    } else {
      proxy_authentication = malloc(strlen(tmpptr) * 2);
      strcpy(proxy_authentication, tmpptr);
      hydra_tobase64((unsigned char*)proxy_authentication);
      free(proxy_authentication);
    }
  }

  math2 = countlogin * countpass;
  todo = math2;
  if (math2 < tasks) {
    tasks = math2;
    fprintf(stderr, "Warning: More tasks defined than login/pass pairs exist. Tasks reduced to %d.\n", tasks);
  }
  math2 = math2 / tasks;

  /* set options (bits!) */
  options = 0;
  if (ssl)
    options = options | OPTION_SSL;

  printf("%s %s (c) 2004 by %s - use allowed only for legal purposes.\n", PROGRAM, VERSION, AUTHOR);
  printf("%s (%s) starting at %s\n", PROGRAM, RESSOURCE, hydra_build_time());
  printf("[DATA] %d parallel tasks, %lu login tries (l:%d/p:%d), ~%lu tries per task\n", tasks, todo, countlogin, countpass, math2);

/*
printf("XXX->%d\n%d\n%d\n%d\n%d\n%lu\n%lu\n%lu\n%lu\n%s\n%s\n%s\n%s\n%d\n%lu\n",
    colonfile == NULL ? 1 : 2, i, a, b, tasks, sent, todo, (unsigned long int) countlogin, (unsigned long int) countpass,
    outfile_ptr == NULL ? "" : outfile_ptr, server, service, miscptr == NULL ? "" : miscptr, port, ip);
printf("YYY->%lu\n%d\n", (unsigned long int) sizelogin, t_login_ptr - login_ptr);
*/

  if (outfile_ptr != NULL) {
    if ((ofp = fopen(outfile_ptr, "a+")) == NULL) {
      bail("Error creating outputfile");
    }
    fprintf(ofp, "# %s %s run at %s on %s %s ( ", PROGRAM, VERSION, hydra_build_time(), server, service);
    if (login != NULL)
      fprintf(ofp, "-l %s ", login);
    if (pass != NULL)
      fprintf(ofp, "-p %s ", pass);
    if (colonfile != NULL)
      fprintf(ofp, "-C %s ", colonfile);
    if (loginfile != NULL)
      fprintf(ofp, "-L %s ", loginfile);
    if (passfile != NULL)
      fprintf(ofp, "-P %s ", passfile);
    if (try_password_same_as_login)
      fprintf(ofp, "-e s ");
    if (try_null_password)
      fprintf(ofp, "-e n ");
    if (ssl)
      fprintf(ofp, "-S ");
    if (infile_ptr != NULL)
      fprintf(ofp, "-M %s ", infile_ptr);
    fprintf(ofp, ")\n");
  }

  /* we have to flush all writeable buffered file pointers before forking */
  fflush(stdout);
  fflush(stderr);
  fflush(ofp);

#ifdef NESSUS_PLUGIN
  svc_kb_name = malloc(40 + strlen(service));
  if (strcmp(service, "http") == 0)
    strcpy(svc_kb_name, "Services/www");
  else
    sprintf(svc_kb_name, "Services/%s", service);
  asc_port = plug_get_key(nessus, svc_kb_name);
  if (asc_port)
    port = atoi(asc_port);
  free(svc_kb_name);
  if (port && host_get_port_state(nessus, port) == 0)
    return 0;
  if (port && IS_ENCAPS_SSL(plug_get_port_transport(nessus, port)))
    options |= OPTION_SSL;
  if (soc >= 0)
    ofp = fdopen(soc, "r+");
#endif

  /* fork attack processes */
  signal(SIGCHLD, killed_childs);
  signal(SIGTERM, kill_children);
  signal(SIGSEGV, kill_children);
  signal(SIGHUP, kill_children);
  signal(SIGINT, kill_children);
  signal(SIGPIPE, SIG_IGN);
  starttime = time(NULL);

/* XXXXX */
  for (sID = 0; sID < servers; sID++) { /* PARALLEL HOSTS THREADS */
    if (socketpair(PF_UNIX, SOCK_STREAM, 0, addr_socketpairs[sID]) != 0) {
      perror("socketpair failed");
      addr_socketpairs[sID][1] = -1;
    }
    if ((addr_pids[sID] = fork()) == 0) {
      char rc;
      int socketpairs[MAXTASKS][2];
      unsigned long int t_ip;
      char t_ipaddr_str[INET_ADDRSTRLEN];
      char *t_pass_ptr_save;
#ifdef CYGWIN
      struct in_addr *ipptr = (struct in_addr *) &t_ip;
#endif

      for (i = 0; i < MAXSERVERS; i++)
        addr_pids[i] = 0;
      if (countservers > 1)
        free(ipaddr_ptr);

      close(addr_socketpairs[sID][1]);

      signal(SIGCHLD, killed_childs);
      signal(SIGTERM, kill_children);
      signal(SIGSEGV, kill_children);
      signal(SIGHUP, kill_children);
      signal(SIGINT, kill_children);
      signal(SIGPIPE, SIG_IGN);

      while (1) {               /* Wait for address */
       wait_addr:
        if (read(addr_socketpairs[sID][0], &rc, 1) > 0) {
          if (rc == 'N') {
            write(addr_socketpairs[sID][0], "N", 1);
          } else if (rc == 'Q') {
            process_restore = 0;
            if (dont_unlink == 0)
              unlink(RESTOREFILE);
            (void) wait3(NULL, WNOHANG, NULL);
            exit(0);
          } else if (rc == 'Y') {
            dont_unlink = 0;
            read(addr_socketpairs[sID][0], &t_ip, sizeof(t_ip));
#ifdef CYGWIN
            strcpy(t_ipaddr_str, inet_ntoa((struct in_addr) *ipptr));
#else
            inet_ntop(AF_INET, &t_ip, t_ipaddr_str, sizeof(t_ipaddr_str));
#endif
            if (restore == 0) {
              t_login_ptr = login_ptr;
              t_pass_ptr = pass_ptr;
              sent = 0;
            } else
              restore = 0;
/*
printf("XXX->%d\n%d\n%d\n%d\n%d\n%lu\n%lu\n%lu\n%lu\n%s\n%s\n%s\n%s\n%d\n%lu\n",
    colonfile == NULL ? 1 : 2, i, a, b, tasks, sent, todo, (unsigned long int) countlogin, (unsigned long int) countpass,
    outfile_ptr == NULL ? "" : outfile_ptr, server, service, miscptr == NULL ? "" : miscptr, port, ip);
printf("YYY->%lu\n%d\n", (unsigned long int) sizelogin, t_login_ptr - login_ptr);
*/
            killed = 0;
            for (i = 0; i < tasks; i++) {       /* PARALLEL LOGIN THREADS */
              if (socketpair(PF_UNIX, SOCK_STREAM, 0, socketpairs[i]) != 0) {
                perror("socketpair failed");
                socketpairs[i][0] = -1;
              } else {
                if ((pids[i] = fork()) == 0) {
                  signal(SIGTERM, exit);
                  signal(SIGHUP, exit);
                  signal(SIGPIPE, exit);
                  if (colonfile == NULL) {
                    if (countlogin > 1)
                      free(login_ptr);
                    if (countpass > 3)
                      free(pass_ptr);
                  } else
                    free(csv_ptr);
                  if (strcmp(service, "telnet") == 0)
                    service_telnet(t_ip, socketpairs[i][1], options, miscptr, ofp, port);
                  if (strcmp(service, "ftp") == 0)
                    service_ftp(t_ip, socketpairs[i][1], options, miscptr, ofp, port);
                  if (strcmp(service, "pop3") == 0)
                    service_pop3(t_ip, socketpairs[i][1], options, miscptr, ofp, port);
                  if (strcmp(service, "imap") == 0)
                    service_imap(t_ip, socketpairs[i][1], options, miscptr, ofp, port);
                  if (strcmp(service, "ldap") == 0)
                    service_ldap(t_ip, socketpairs[i][1], options, miscptr, ofp, port);
                  if (strcmp(service, "www") == 0)
                    service_http(t_ip, socketpairs[i][1], options, miscptr, ofp, port);
                  if (strcmp(service, "http-proxy") == 0)
                    service_http_proxy(t_ip, socketpairs[i][1], options, miscptr, ofp, port);
                  if (strcmp(service, "cisco") == 0)
                    service_cisco(t_ip, socketpairs[i][1], options, miscptr, ofp, port);
                  if (strcmp(service, "cisco-enable") == 0)
                    service_cisco_enable(t_ip, socketpairs[i][1], options, miscptr, ofp, port);
                  if (strcmp(service, "socks5") == 0)
                    service_socks5(t_ip, socketpairs[i][1], options, miscptr, ofp, port);
                  if (strcmp(service, "vnc") == 0)
                    service_vnc(t_ip, socketpairs[i][1], options, miscptr, ofp, port);
                  if (strcmp(service, "rexec") == 0)
                    service_rexec(t_ip, socketpairs[i][1], options, miscptr, ofp, port);
                  if (strcmp(service, "nntp") == 0)
                    service_nntp(t_ip, socketpairs[i][1], options, miscptr, ofp, port);
                  if (strcmp(service, "icq") == 0)
                    service_icq(t_ip, socketpairs[i][1], options, miscptr, ofp, port);
                  if (strcmp(service, "pcnfs") == 0)
                    service_pcnfs(t_ip, socketpairs[i][1], options, miscptr, ofp, port);
                  if (strcmp(service, "smb") == 0)
                    service_smb(t_ip, socketpairs[i][1], options, miscptr, ofp, port);
#ifdef LIBDES
                  if (strcmp(service, "smbnt") == 0)
                    service_smbnt(t_ip, socketpairs[i][1], options, miscptr, ofp, port);
#endif
                  if (strcmp(service, "mysql") == 0)
                    service_mysql(t_ip, socketpairs[i][1], options, miscptr, ofp, port);
/* ADD NEW SERVICES HERE */

                  return 0;
                }
                if (pids[i] > 0) {
                  write(socketpairs[i][1], "N", 1);
                  fcntl(socketpairs[i][0], F_SETFL, O_NONBLOCK);
                } else {
                  perror("Fork for children failed");
                  socketpairs[i][0] = -1;
                }
              }
              if ((((i + 1) % group) == 0) && ((i + 1) != tasks))
                sleep(1);
            }

            /* feed the (grand)children with login/pass data - be a good mom */
            if (infile_ptr == NULL)
              process_restore = 1;
            starttime = elapsed = elapsed2 = time(NULL);
            {
              int c, done, length;
              char sb[MAXBUF], rc;

              t_pass_ptr_save = t_pass_ptr;

              for (a = start_login_no; a < countlogin; a++) {
                start_login_no = 0;
                for (b = start_pass_no; b < countpass; b++) {
                  start_pass_no = 0;
                  done = 0;
                  if ((char *) t_pass_ptr != (char *) &HYDRA_EXIT) {
                    while (!done) {
                      i = 0;
                      for (c = 0; c < tasks; c++) {
                        if (!done && socketpairs[c][0] >= 0) {
                          if (read(socketpairs[c][0], &rc, 1) > 0) {
                            if (rc == 'F') {
                              char *cracked_login = malloc(MAXBUF);

                              found++;

                              if (exit_found) {
                                int as;
                                sleep(1);
                                for (as = 0; as < tasks; as++)
                                  if (pids[as] > 0)
                                    (void) kill(pids[as], SIGTERM);
                                (void) wait3(NULL, WNOHANG, NULL);
                                printf("%s Finished scan for %s\n", PROGRAM, t_ipaddr_str);
                                for (as = 0; as < tasks; as++) {
                                  close(socketpairs[as][0]);
                                  close(socketpairs[as][1]);
                                  socketpairs[as][1] = -1;
                                  socketpairs[as][0] = -1;
                                }
                                for (as = 0; as < tasks; as++)
                                  if (pids[as] > 0) {
                                    (void) kill(pids[as], SIGKILL);
                                    pids[as] = 0;
                                  }
                                (void) wait3(NULL, WNOHANG, NULL);
                                write(addr_socketpairs[sID][0], "Q", 1);
                                elapsed2 = elapsed = time(NULL);
                                printf("[DATA] %d passwords found on %s, %lu attempts made in %02lu:%02luh\n", found, t_ipaddr_str, sent, (elapsed - starttime) / 3600,
                                       ((elapsed - starttime) % 3600) / 60 + 1);
                                goto wait_addr;
                              }
                              memset(cracked_login, 0, MAXBUF);
                              read(socketpairs[c][0], cracked_login, MAXBUF);
                              if (colonfile == NULL) {
                                if (strcmp(cracked_login, t_login_ptr) == 0) {
                                  a++;
                                  if (a < countlogin) {
                                    while (*t_login_ptr != '\0')
                                      t_login_ptr++;
                                    t_login_ptr++;
                                    t_pass_ptr = t_pass_ptr_save;
                                    sent += countpass - b;
                                    b = 0;
                                  } else {
/*
 *                                   rc = 'X';
 *                                   b = countpass;
 *                                   sent = todo;
 *                                   done = 1;
 */
                                  }
                                  if (verbose)
                                    printf("The password for \"%s\" was found, skipping to next login (pairs already sent to childrens will still be tried)\n", cracked_login);
                                }
                              }

                              free(cracked_login);
                            }
                            if (rc == 'N' || rc == 'F') {
                              done = 1;
                              sent++;
/*
  printf("DEBUG: login_ptr %p %s  pass_ptr %p %s\n", login_ptr, login_ptr, pass_ptr, pass_ptr);
  printf("sent: %lu, todo: %lu\n", sent, todo);
  printf("DEBUG: t_login_ptr %p %s  t_pass_ptr %p %s\n", t_login_ptr, t_login_ptr, t_pass_ptr, t_pass_ptr);
*/
                              if ((verbose) || (showAttempt)) {
                                if (b < try_null_password + try_password_same_as_login) {
                                  if (try_null_password && b == 0)
                                    printf("[new pair] host: %s - login \"%s\" - pass \"\" (%lu of %lu)\n", t_ipaddr_str, t_login_ptr, sent, todo);
                                  if (try_password_same_as_login && ((b == 0 && try_null_password == 0)
                                                                     || (b == 1 && try_null_password)))
                                    printf("[new pair] host: %s - login \"%s\" - pass \"%s\" (%lu of %lu)\n", t_ipaddr_str, t_login_ptr, t_login_ptr, sent, todo);
                                } else
                                  printf("[new pair] host: %s - login \"%s\" - pass \"%s\" (%lu of %lu)\n", t_ipaddr_str, t_login_ptr, t_pass_ptr, sent, todo);
                              }

                              if (process_restore == 1 && time(NULL) - elapsed2 > 299) {
                                hydra_restore_write(0);
                                elapsed2 = time(NULL);
                              }
                              if (time(NULL) - elapsed > 59) {

/*
			          int delint;
			          for (delint = 0; delint < 256; delint++)
			            printf("%c", 8);
*/
                                elapsed = time(NULL);
                                printf("[STATUS] Speed: %.2f tries/min, %lu tries in %02lu:%02luh, %lu todo in %02lu:%02luh\n",
                                       (1.0 * sent) / (((elapsed - starttime) * 1.0) / 60), sent, (elapsed - starttime) / 3600, ((elapsed - starttime) % 3600) / 60, todo - sent,
                                       ((todo - sent) / (sent / (elapsed - starttime))) / 3600, ((((todo - sent) / (sent / (elapsed - starttime))) % 3600) / 60) + 1);
                              }

                              memset(&sb, 0, sizeof(sb));
                              length = strlen(t_login_ptr) + 1;
                              strcpy(sb, t_login_ptr);
                              if (b < try_password_same_as_login + try_null_password) {
                                if (try_null_password && b == 0) {
                                  length += 1;
                                }
                                if (try_password_same_as_login && ((b == 0 && try_null_password == 0)
                                                                   || (b == 1 && try_null_password))) {
                                  strcpy(sb + length, t_login_ptr);
                                  length += strlen(t_login_ptr) + 1;
                                }
                              } else {
                                while (((try_password_same_as_login && strcmp(t_pass_ptr, t_login_ptr) == 0)
                                        || (try_null_password && strlen(t_pass_ptr) == 0))
                                       && b < countpass) {
                                  if (verbose)
                                    printf("Detected double with -e n|s option, skipping double password try. %s <-> %s\n", t_login_ptr, t_pass_ptr);
                                  t_pass_ptr += strlen(t_pass_ptr) + 1;
                                  b++;
                                  sent++;
                                }
                                if (b == countpass) {
                                  strcpy(sb + length, "THChydra");
                                  length += 9;
                                  b = countpass - 1;
                                  if (sent > todo)
                                    sent = todo;
                                } else {
                                  strcpy(sb + length, t_pass_ptr);
                                  length += strlen(t_pass_ptr) + 1;
                                }
                              }
/*
 *                              if (verbose)
 *                                printf("[new pair] login \"%s\" - pass \"%s\" (%lu of %lu)\n", sb, sb + strlen(sb) + 1, sent, todo);
 */
                              write(socketpairs[c][0], sb, length);
                              if (debug)
                                printf("Pair sent to process %d\n", pids[c]);
                            } else {
                              if (debug)
                                printf("Process %d reported it quit\n", pids[c]);
                              socketpairs[c][0] = -1;
                              pids[c] = 0;
                              i++;
                              (void) wait3(NULL, WNOHANG, NULL);
                            }
                          } else if (errno == EBADF) {
                            socketpairs[c][0] = -1;
                            pids[c] = 0;
                            i++;
                            (void) wait3(NULL, WNOHANG, NULL);
                          }
                        } else
                          i++;
                      }
                      if (i >= tasks) {
                        printf("All childrens are dead.\n");
                        if (process_restore == 1) {
                          dont_unlink = 1;
                          hydra_restore_write(1);
                          process_restore = 0;
                        }
                        fprintf(stderr, "Server (%s) scan complete\n", t_ipaddr_str);
                        write(addr_socketpairs[sID][0], "Q", 1);
                        elapsed = time(NULL);
                        printf("[DATA] %d passwords found on %s, %lu attempts made in %02lu:%02luh\n", found, t_ipaddr_str, sent, (elapsed - starttime) / 3600,
                               ((elapsed - starttime) % 3600) / 60 + 1);
                        for (i = 0; i < tasks; i++)
                          if (pids[i] > 0)
                            (void) kill(pids[i], SIGTERM);
                        for (i = 0; i < tasks; i++) {
                          close(socketpairs[i][0]);
                          close(socketpairs[i][1]);
                          socketpairs[i][1] = -1;
                          socketpairs[i][0] = -1;
                        }
                        for (i = 0; i < tasks; i++)
                          if (pids[i] > 0) {
                            (void) kill(pids[i], SIGKILL);
                            pids[i] = 0;
                          }
                        (void) wait3(NULL, WNOHANG, NULL);
                        goto wait_addr;
                      }
                    }
                  }
                  if (b < countpass && b >= try_password_same_as_login + try_null_password) {
                    while (*t_pass_ptr != '\0')
                      t_pass_ptr++;
                    t_pass_ptr++;
                  }
                }
                if (a < countlogin) {
                  while (*t_login_ptr != '\0')
                    t_login_ptr++;
                  t_login_ptr++;
                }
                if (colonfile == NULL) {
                  t_pass_ptr = t_pass_ptr_save;
                } else {
                  if ((char *) t_pass_ptr != (char *) &HYDRA_EXIT) {
                    while (*t_login_ptr != '\0')
                      t_login_ptr++;
                    t_login_ptr++;
                  }
                  t_pass_ptr = t_login_ptr;
                  while (*t_pass_ptr != '\0' && *t_pass_ptr != ':')
                    t_pass_ptr++;
                  if (*t_pass_ptr == ':' || *t_pass_ptr == '\0') {
                    *t_pass_ptr = '\0';
                    t_pass_ptr++;
                  } else {
                    if (strlen(t_login_ptr) > 0)
                      fprintf(stderr, "Invalid line in colonfile: %s\n", t_login_ptr);
                    t_pass_ptr = HYDRA_EXIT;
                  }
                }
              }

              i = 0;
              j = 0;
              (void) wait3(NULL, WNOHANG, NULL);
              if (verbose)
                printf("Waiting for children to finnish their jobs ...\n");
              while (i < tasks && j < 5) {
                i = 0;
                for (c = 0; c < tasks; c++) {
                  if (socketpairs[c][0] >= 0) {
                    if (read(socketpairs[c][0], &rc, 1) > 0 || j == 4) {
                      if (rc == 'F')
                        found++;
                      i++;
                      (void) write(socketpairs[c][0], HYDRA_EXIT, sizeof(HYDRA_EXIT));
                      socketpairs[c][0] = -1;
                    }
                  } else
                    i++;
                }
                if (i < tasks) {
                  j++;
                  sleep(1);
                }
              }

              i = 0;
              j = 1;
              while (j > 0 && killed < tasks && i <= (WAITTIME + tasks + 6)) {
                j = 0;
                (void) wait3(NULL, WNOHANG, NULL);
                for (c = 0; c < tasks; c++) {
                  if (pids[c] > 0)
                    if (kill(pids[c], 0) >= 0)
                      j++;
                }
                sleep(1);
                i++;
                if (debug)
                  printf("tasks: %d   still alive: %d   killed: %d   time: %d of %d\n", tasks, j, killed, i, WAITTIME + tasks + 6);
              }
            }

            for (i = 0; i < tasks; i++)
              if (pids[i] > 0)
                kill(pids[i], SIGTERM);

            fprintf(stderr, "Server (%s) scan complete\n", t_ipaddr_str);
            write(addr_socketpairs[sID][0], "Q", 1);
            elapsed = time(NULL);
            printf("[DATA] %d passwords found on %s, %lu attempts made in %02lu:%02luh\n", found, t_ipaddr_str, sent, (elapsed - starttime) / 3600, ((elapsed - starttime) % 3600) / 60 + 1);
            for (i = 0; i < tasks; i++) {
              close(socketpairs[i][0]);
              close(socketpairs[i][1]);
              socketpairs[i][1] = -1;
              socketpairs[i][0] = -1;
            }
            for (i = 0; i < tasks; i++)
              if (pids[i] > 0) {
              (void) kill(pids[i], SIGKILL);
              pids[i] = 0;
            }
            (void) wait3(NULL, WNOHANG, NULL);
            goto wait_addr;
          }
        }
      }                         /* loop while waiting for an address */
    }                           /* IP scanners fork */

    close(addr_socketpairs[sID][0]);
    if (addr_pids[sID] > 0) {
      write(addr_socketpairs[sID][1], "N", 1);
      fcntl(addr_socketpairs[sID][0], F_SETFL, O_NONBLOCK);
      fcntl(addr_socketpairs[sID][1], F_SETFL, O_NONBLOCK);
    } else {
      perror("Fork for children failed");
      addr_socketpairs[sID][0] = -1;
    }
  }

  /* feed the children with ip address data - be a good mom */

 scans = 0, done = 0;
 while (done < countinfile) {
    for (a = 0; a < servers; a++) {
      if (read(addr_socketpairs[a][1], &rc, 1) > 0) {
        read(addr_socketpairs[a][1], &rc, 1);
        if ((rc == 'N') && (scans < countinfile)) { 
          scans++;
                                                                                                                                                                                              
            /* resolve target */
#ifdef CYGWIN
            if (inet_aton(ipaddr_ptr, &in) <= 0) {
#else
            if (inet_pton(AF_INET, ipaddr_ptr, &in) <= 0) {
#endif
              if ((target = gethostbyname(ipaddr_ptr)) != NULL)
                memcpy(&ip, target->h_addr, 4);
            } else {
              memcpy(&ip, &in.s_addr, 4);
            }

            if ((target = gethostbyname(ipaddr_ptr)) == NULL) {
              done++;
              fprintf(stderr, "Error: invalid server address: %s\n", ipaddr_ptr);
              write(addr_socketpairs[a][1], "N", 1);
            } else {
              write(addr_socketpairs[a][1], "Y", 1);
              write(addr_socketpairs[a][1], &ip, sizeof(ip));
            }
                                                                                                                                                                                              
          if (scans < countinfile) {
            while (*ipaddr_ptr != '\0') ipaddr_ptr++;
            ipaddr_ptr++;
          }
        } else if (rc == 'N') { 
          write(addr_socketpairs[a][1], "Q", 1);
        } else if (rc == 'Q') {
          done++;
          if (scans < countinfile)
            write(addr_socketpairs[a][1], "N", 1);
          else {
          write(addr_socketpairs[a][1], "Q", 1);
          addr_pids[a] = 0;
        }
    }
    }
  }
  }
  
  /* yeah we did it */
  printf("%s finished at %s\n", PROGRAM, hydra_build_time());

  fclose(ofp);

  return 0;
}


#ifndef NESSUS_PLUGIN
int
main(int argc, char *argv[])
{
  return hydra_main(-1, NULL, argc, argv);
}
#endif
