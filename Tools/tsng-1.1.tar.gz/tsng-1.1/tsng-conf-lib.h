/* tsng config file reader */

#ifndef _TSNGCONF_H
#define _TSNGCONF_H

#define SEPARATOR "="

#define DIALMODE_SEQ  1
#define DIALMODE_RAND 2

typedef struct {
    int fd;
    FILE *stream;
    char *password;
    int port;
    int dialmode;
    char *modem;
    char *logfile;
    int baud;
    int databits;
    int stopbits;
    char parity;
    char *initstring1;
    char *initstring2;
    char *initstring3;
    char *dialstring_front;
    char *dialstring_end;
    int dial_wait;
    int dial_wait_errors;
    int hangup;
    int ringout;
    int busyout;
    int timeout;
    int errorout;
    char *nudgestring;
    int debug;
    int socket;
    FILE *streamsocket;
} tsng_modem_config;

extern tsng_modem_config *tsng_modem_config_new(char *);
int tsng_modem_config_parse(const char *, char **, char **);
int tsng_modem_config_set(tsng_modem_config *, char *, char *);
char *tsng_modem_config_readline(char **, int);
int tsng_modem_config_mmap(char *, char **);
extern int tsng_modem_config_destroy(tsng_modem_config **);

#endif
