/*
 * ths@dev.io && vh@thc.org
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <err.h>
#include <unistd.h>
#include <string.h>
#include <sys/uio.h>
#include <sys/types.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <signal.h>
#include <fcntl.h>
#include <netdb.h>
#include <errno.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include "tsng.h"
#include "tsng-client.h"
#include "COMMANDS"
#include "tsng-general-lib.h"

#define _DEFINE_TSNG_CLIENT

int debug = 0;

int tsng_mode = TSNG_CLIENT;
int sock = -1;
FILE *LOG = NULL;
FILE *FD = NULL;

int help(char *p) {
   printf("THC-SCAN Next Generation - CLIENT - %s\n\n", VERSION);
   printf("Syntax: %s [-s server] [-p port] [-v] [-f scriptfile] [-l logfile]\n", p);
   exit(0);
}

void tsng_client_terminate() {
  tsng_fprintf(FD, "QUIT\n");
  fclose(LOG);
  exit(0);
}

int tsng_client_disconnect(int fd) {
   FD = tsng_stream_disconnect(FD);
   return -1;
}

int tsng_connect(tsng_config *cfg) {  
   if ((FD = tsng_stream_connect_host_tcp(cfg->host, cfg->port)) == NULL)
     return -1;
   return(fileno(FD));
}

size_t tsng_client_send(char *line) {
   size_t ret;
   if (debug)
     printf("[D] Sending %u bytes: %s\n", (unsigned int) strlen(line), line);
   ret = tsng_fprintf(FD, "%s", line);
   return ret;
}

void tsng_client_output(char *buf) {
  if (LOG != NULL)
    fprintf(LOG, " << %s\n", buf);
  if (*buf == 'E')
    printf("[-] %s\n", buf);
  else
    printf("[+] %s\n", buf);
}

char *tsng_read_master(char *buf, int buflen, int print) {
  char *ret = NULL;
  if (FD != NULL && (ret = tsng_stream_fgets(buf, buflen, FD)) != NULL && print)
    tsng_client_output(buf);
  return ret;
}

void tsng_client_command(tsng_config *cfg, char *lptr) {
  char request[TSNG_MAX_LINE], line[TSNG_MAX_LINE], response[TSNG_MAX_LINE];
  char *args[TSNG_MAX_ARGC];
  int  argcs;
  FILE *f;
  unsigned int i = 0;
  int cs = 0;
  char *ptr, *ptr2;

  if (sock < 0 && (strncasecmp(lptr, "EXIT", strlen("EXIT")) == 0 ||
    strncasecmp(lptr, "QUIT", strlen("QUIT")) == 0)) {
    printf("[+] Exiting ...\n");
    exit(0);
  } else if (strncasecmp(lptr, "LOG ", strlen("LOG ")) == 0) {
    if (LOG != NULL) {
      fclose(LOG);
      LOG = NULL;
    }
    tsng_split_line(TSNG_MAX_ARGC, &argcs, args, lptr, strlen(lptr));
    ptr = args[1];
    if (argcs > 1 && ptr != NULL) {
      if ((LOG = fopen(ptr, "a+")) != NULL) {
        printf("[+] Writing log to file %s\n", ptr);
      } else
        printf("[-] Can not write to log file %s\n", ptr);
      free(ptr);
    } else
      printf("[-] LOG command is missing the filename\n");
  } else if (strncasecmp(lptr, "CONNECT", strlen("CONNECT")) == 0) {
    if (sock >= 0) {
      cs = tsng_client_send("QUIT\n");
      usleep(400000);
      tsng_client_disconnect(sock);
      sock = -1;
      printf("[+] Disconnected from master\n");
    }
    tsng_split_line(TSNG_MAX_ARGC, &argcs, args, lptr, strlen(lptr));
    if (argcs < 2) {
      fprintf(stderr, "[err] no/invalid host\n");
      cfg->host = NULL;
    } else {
      cfg->host = args[1];
      if (argcs < 3)
        cfg->port = TSNG_PORT_MASTER;
      else {
        cfg->port = atoi(args[2]);
        if (argcs >= 4)
          cfg->password = strdup(args[3]);
      }
      printf("[~] Connecting to %s port %d\n", cfg->host, cfg->port);
      if ((sock = tsng_connect(cfg)) < 0)
        printf("[-] Failed.\n");
      else {
        printf("[+] Successfully connected.\n");
//              FD = tsng_stream_fdopen(sock, "a+");
      }
    }
  } else if (strncasecmp(lptr, "HELP", strlen("HELP")) == 0) {
    printf("%s\n", COMMAND_HELP);
  } else { /* cmd != CONNECT && != LOG && != HELP */
    if (sock < 0) {
      fprintf(stderr, "[-] You are not connected to a master, use CONNECT first.\n");
    } else {
      if (strncasecmp(lptr, "SAVE", strlen("SAVE")) == 0 ||
          strncasecmp(lptr, "DUMP", strlen("DUMP")) == 0 ||
          strncasecmp(lptr, "EXPORT", strlen("EXPORT")) == 0) {
        tsng_split_line(TSNG_MAX_ARGC, &argcs, args, lptr, strlen(lptr));
        ptr = args[1];
        if (strncasecmp(args[0], "EXPORT", strlen("EXPORT")) == 0)
          strcpy(request, "EXPORT");
        else
          strcpy(request, "DUMP");
        if (argcs == 2) 
          i = 1;
        else
          i = 2;
        while(i < argcs) {
          strcat(request, " ");
          strcat(request, args[i]);
          i++;
        }
        strcat(request, "\n");
        if (argcs > 1 && (f = fopen(ptr, "w")) != NULL) {
          while (tsng_read_master(response, sizeof(response), 1) != NULL) {}
          response[0] = 0;
          cs = tsng_client_send(request);
          do { usleep(300); } while(tsng_read_master(response, sizeof(response), 1) == NULL && response[0] != 'E' && response[0] != 'O');
          if (response[0] == 'O') {
            do {
              if (tsng_stream_fgets(response, sizeof(response), FD) != NULL) {
                if (strncasecmp(response, "EXPORT END", strlen("EXPORT END")) != 0) {
                  if (strncasecmp(response, "EXPORT", strlen("EXPORT")) == 0) {
                    fprintf(f, "%s\n", response + (strlen("EXPORT") + 1));
                  } else
                    tsng_client_output(response);
                }
              }
            } while (strncasecmp(response, "EXPORT END", strlen("EXPORT END")) != 0);
            printf("[+] data successfully saved to file %s\n", ptr);
          } else
            unlink(ptr);
          fclose(f);
        } else
          fprintf(stderr, "[-] Can not create data save file %s\n", ptr);
          // TODO
      } else if (strncasecmp(lptr, "SCANFILE", strlen("SCANFILE")) == 0) {
        tsng_split_line(TSNG_MAX_ARGC, &argcs, args, lptr, strlen(lptr));
        ptr = args[1];
        if (ptr != NULL && argcs > 1 && (f = fopen(ptr, "r")) != NULL) {
          if (argcs == 2) {
            if ((ptr2 = rindex(ptr, '/')) == NULL)
              ptr2 = ptr;
            else
              ptr2++;
          } else
            ptr2 = args[2];
          snprintf(response, sizeof(response), "SCANARRAY %s\n", ptr2);
          strcat(response, "\n");
          tsng_client_send(response);
          do { usleep(300); } while(tsng_read_master(response, sizeof(response), 1) == NULL);
          if (response[0] != 'E') {
            printf("[+] Uploading numbers from %s, scan ID is %s\n", ptr, ptr2);
            while (tsng_fgets(line, sizeof(line), f) != NULL) {
              strcat(line, "\n");
              tsng_client_send(line);
            }
            cs = tsng_client_send("END\n");
            fclose(f);
            do {
              if (tsng_read_master(response, sizeof(response), 1) == NULL)
                 usleep(200);
/*
                    else
                      if (response[0] == 'E')
                        printf("[-] %s\n", response);
                      else if (response[0] != 'O')
                        printf("[+] %s\n", response);
*/
            } while(response[0] != 'O');
            printf("[+] Upload done for ID %s\n", ptr2);
          } else
            printf("[-] filename %s is invalid as ID\n", ptr2);
          if (LOG != NULL)
             fprintf(LOG, " << %s\n", response); // XXX required here?
        } else
          printf("[-] error with scanfile %s\n", ptr);
      } else {
        strcat(lptr, "\n");
        cs = tsng_client_send(lptr);
/*
              if ((cs = tsng_client_send(lptr)) <= 0)
                printf("[-] send failed.\n");
*/
        if (strncasecmp(lptr, "QUIT", strlen("QUIT")) == 0
            || strncasecmp(lptr, "EXIT", strlen("EXIT")) == 0) {
          printf("[+] Exiting ...\n");
          usleep(400000);
          exit(0);
        }
        usleep(40000);
        while (tsng_read_master(response, sizeof(response), 1) != NULL) {}
        if (strncasecmp(lptr, "LOGOFF", strlen("LOGOFF")) == 0 ||
            strncasecmp(lptr, "LOGOUT", strlen("LOGOUT")) == 0 ||
/*            strncasecmp(lptr, "KILL", strlen("KILL")) == 0 ||*/
            strncasecmp(lptr, "DISCONNECT", strlen("DISCONNECT")) == 0) {
          printf("[+] Exiting from master ...\n");
          usleep(400000);
          tsng_client_disconnect(sock);
          sock = -1;
        }
      }
    }
  }
}

/* interactive client */
void tsng_client_interactive(tsng_config *cfg) {
   char line[TSNG_MAX_LINE], *lptr;
   char response[TSNG_MAX_LINE];
   int go = 1;
   unsigned int i;

   memset(line, 0, sizeof(line));
   fcntl(0, F_SETFL, O_NONBLOCK);

   printf("[+] %s %s - INTERACTIVE - type HELP for help...\n",
         TSNG_PROGRAM, VERSION);

   while(go) {
      line[0] = 0;
      while (tsng_read_master(response, sizeof(response), 1) != NULL) {}
      if (tsng_fgets(line, sizeof(line), stdin) != NULL) {
        i = strlen(line);
        if (debug)
          printf("[D] read %d bytes: %s\n", i, line);
        lptr = line;
        if (i > 0) {
          while (*lptr == ' ' || *lptr == '\t')
            lptr++;
          if (LOG != NULL)
            fprintf(LOG, " >> %s\n", lptr);
        }
        tsng_client_command(cfg, lptr);
      } else {
        if (FD != NULL) {
          while (tsng_read_master(response, sizeof(response), 1) != NULL) {}
          usleep(20000);
        } else
          usleep(30000);
      }
/*
      if (cs < 0) {
        printf("[-] Connection to master lost\n");
if (debug) { printf("Code: %d, errorno: %d\n", cs, errno); perror(""); }
        tsng_client_disconnect(sock);
        sock = -1;
        cs = 0;
      }
*/
   }
   printf("[-] ERROR IN PROGRAM, THIS SHOULD NEVER BE REACHED!\n");
}

void tsng_client_scriptfile(tsng_config *cfg) {
  FILE *f;
  char line[TSNG_MAX_LINE], response[TSNG_MAX_LINE], *lptr;
  
   printf("[+] %s %s - SCRIPT %s\n",
         TSNG_PROGRAM, VERSION, cfg->scriptfile);

  if (strcmp(cfg->scriptfile, "-") == 0)
    f = stdin;
  else {
    if ((f = fopen(cfg->scriptfile, "r")) == NULL) {
      fprintf(stderr, "Error: Can not open script file %s\n", cfg->scriptfile);
      exit(-1);
    }
  }
  while (fgets(line, sizeof(line), f) != NULL) {
    lptr = line;
    while (*lptr == ' ' || *lptr == '\t')
      lptr++;
    if (*lptr != 0 && *lptr != '\r' && *lptr != '\n' && *lptr != '#') {
      if (line[strlen(line)-1] == '\n')
        line[strlen(line)-1] = 0;
      if (line[strlen(line)-1] == '\r')
        line[strlen(line)-1] = 0;
      printf("%s\n", lptr);
      tsng_client_command(cfg,lptr);
    }
    if (FD != NULL) {
      sleep(1);
      while (tsng_read_master(response, sizeof(response), 1) != NULL) {}
    }
  }
}

int tsng_doauth(int fd, tsng_config *cfg) {
   return(0);

   /* ... implement auth first... */
   return(-1); /* failed */
}

int main(int ac, char **av) {
   int c;
   int fd;
   char *prog;
   int interactive = 1;
   tsng_config *tsng_cfg;
   
   prog = av[0];
   
   if ((tsng_cfg = (tsng_config *)malloc(sizeof(tsng_config))) == NULL)
      err(0, NULL);

   memset(tsng_cfg, 0, sizeof(tsng_config));
   tsng_cfg->host = NULL;
   tsng_cfg->port     = TSNG_PORT_MASTER;
   tsng_cfg->verbose  = 0;

   while( (c = getopt(ac, av, "ihp:Dvf:s:l:P:")) >= 0 )
         switch(c) {

            case 's':   /* server to connect */
               tsng_cfg->host = optarg;
               break;
            case 'p':   /* server port */
               tsng_cfg->port = atoi(optarg);
               break;
            case 'D':   /* debug level */
//               tsng_cfg->loglevel = atoi(optarg);
               debug = 1;
               break;
#ifdef _NOT_NEEDED
            case 't':   /* timeout */
               tsng_cfg->timeout = atoi(optarg);
               break;

            case 'r':   /* ring timeout */
               tsng_cfg->ringout = atoi(optarg);
               break;

            case 'b':   /* busy timeout */
               tsng_cfg->busyout = atoi(optarg);
               break;
#endif
            case 'v':   /* verbose mode */
               tsng_cfg->verbose = 1;
               break;
            case 'f':   /* script file */
               tsng_cfg->scriptfile = optarg;
               break;
            case 'l':   /* log file */
               tsng_cfg->logfile = optarg;
               if ((LOG = fopen(optarg, "a+")) != NULL) {
                 printf("[+] Writing log to file %s\n", optarg);
               } else {
                 printf("[-] Can not write to log file %s\n", optarg);
                 exit(-1);
               }
               break;
            case 'P':   /* realm */
               tsng_cfg->password = optarg;
               break;
            case 'h':   /* help */
               help(prog);
            case 'i':   /* start in interactive mode */
               interactive += 1;
               break;
            default:    /* default */
               help(prog);
         }

   ac-=optind;
   av+=optind;

   /* 
    * non interactive functionality starts here (when cmd line params are
    * given) 
    * 
    * */
   if(tsng_cfg->host != NULL) {
     sock = tsng_connect(tsng_cfg);
     if (  tsng_doauth(fd, tsng_cfg) < 0 ) { /* auth failed */
       printf("[!] authentification failed!\n"); 
       tsng_client_disconnect(fd);
       free(tsng_cfg);
       exit(-1);
     }
//     FD = tsng_stream_fdopen(sock, "a+");
   }

   signal(SIGPIPE, SIG_IGN);
   signal(SIGTERM, tsng_client_terminate);
   signal(SIGSEGV, tsng_client_terminate);
   signal(SIGINT, tsng_client_terminate);
   signal(SIGABRT, tsng_client_terminate);

   if (tsng_cfg->scriptfile == NULL) {
      tsng_client_interactive(tsng_cfg);
   } else {
      tsng_client_scriptfile(tsng_cfg);
      if (interactive > 1)
        tsng_client_interactive(tsng_cfg);
   }

   /* quit */
   printf("Exiting tsng-client\n");
   if (LOG != NULL)
     fclose(LOG);
   if (sock >= 0) {
     tsng_client_send("QUIT\n");
     usleep(400000);
     tsng_client_disconnect(sock);
   }
   free(tsng_cfg);
   exit(0);
}
