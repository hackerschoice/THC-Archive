#ifndef _TSNG_ZOMBIE_H
#define _TSNG_ZOMBIE_H

#define TSNG_MAX_ARGC 8

#endif
