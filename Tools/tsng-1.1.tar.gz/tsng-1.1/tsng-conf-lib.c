/* tsng config file reader */

#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <ctype.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <fcntl.h>
#include <termios.h>

#include "tsng.h"
#include "tsng-conf-lib.h"

extern int tsng_mode;

/* splits line in token and value, seperated by SEPARATOR
 * does some clean up
 */
int tsng_modem_config_parse(const char *line, char **token, char **value) {
    char *pos, *pos_val, *pos_tok;
    int length;

    *token = NULL;

    while ((*line == ' ') || (*line == '\t'))
        line++;

    if ((pos = strstr(line, SEPARATOR)) == NULL)
        return -1;

    /* remove whitespaces, tabs after SEPARATOR */
    pos_val = pos + 1;

    while ((*pos_val == ' ') || (*pos_val == '\t'))
        pos_val++;
    
    *value = strdup(pos_val);
    pos_val = *value;
    while (*pos_val != 0 && *pos_val != ' ' && *pos_val != '\t')
      pos_val++;
    *pos_val = 0;

    /* remove whitespaces, tabs before SEPARATOR */
    pos_tok = pos - 1;

    while ((*pos_tok == ' ') || (*pos_tok == '\t'))
        pos_tok--;
    
    length = pos_tok - line + 1;
    if ((*token = malloc(length + 1)) == NULL) {
        perror("malloc failed");
        return -2;
    }
    strncpy(*token, line, length);
    *(*token + length) = 0;

    return 0;
}

/* sets element in struct */
int tsng_modem_config_set(tsng_modem_config *conf, char *token, char *value) {
    /* ignore empty tokens */
    if (token == NULL || *token == 0)
      return 0;
    
    /* set password */
    if (!(strncmp(token, "pass", 4))) {
        conf->password = value;
        return 0;
    }

    /* set modem */
    if (!(strcmp(token, "modem"))) {
        conf->modem = value;
        return 0;
    }

    /* set nudge */
    if (!(strcmp(token, "nudgestring"))) {
        conf->nudgestring = value;
        return 0;
    }

    /* set baud */
    if (!(strcmp(token, "baud"))) {
        switch(atoi(value)) {
          case 1200:
            conf->baud = B1200;
            break;
          case 2400:
            conf->baud = B2400;
            break;
          case 9600:
            conf->baud = B9600;
            break;
          case 19200:
            conf->baud = B19200;
            break;
          case 57600:
            conf->baud = B57600;
            break;
          case 115200:
            conf->baud = B115200;
            break;
          default:
            conf->baud = B19200;
        }
        free(value);
        return 0;
    }

    /* set databits */
    if (!(strcmp(token, "databits"))) {
        conf->databits = atoi(value);
        if (atoi(value) > 8 || atoi(value) < 7) {
          fprintf(stderr, "ERROR: databits must be 7 or 8, normal is 8\n");
          exit(-1);
        }
        free(value);
        return 0;
    }

    /* set stopbits */
    if (!(strcmp(token, "stopbits"))) {
        conf->stopbits = atoi(value);
        if (atoi(value) > 2) {
          fprintf(stderr, "ERROR: stopbits must be 1 or 2, normal is 1\n");
          exit(-1);
        }
        free(value);
        return 0;
    }

    /* set port */
    if (!(strcmp(token, "port"))) {
        conf->port = atoi(value);
        if (atoi(value) < 1 || atoi(value) > 65535) {
          fprintf(stderr, "ERROR: TCP port value must be between 1 and 65535\n");
          exit(-1);
        }
        free(value);
        return 0;
    }

    /* set parity */
    if (!(strcmp(token, "parity"))) {
        conf->parity = toupper(*value);
        switch(conf->parity) {
          case 'O':
          case 'N':
          case 'E':
            break;
          default:
            fprintf(stderr, "ERROR: Parity must be 'N', 'E' or 'O'\n");
            exit(-1);
        }
        free(value);
        return 0;
    }

    if (!(strcmp(token, "hangup"))) {
        conf->hangup = -1;
        if (strcasecmp(value, "default") == 0)
          conf->hangup = TSNG_HANGUP_DEFAULT;
        if (strcasecmp(value, "secure") == 0)
          conf->hangup = TSNG_HANGUP_SECURE;
        if (strcasecmp(value, "all") == 0)
          conf->hangup = TSNG_HANGUP_ALL;
        if (conf->hangup == -1) {
          fprintf(stderr, "ERROR: Invalid value for hangup (default, secure, all): %s\n", value);
          exit(-1);
        }
        free(value);
        return 0;
    }

    /* set initstring1 */
    if (!(strcmp(token, "initstring1"))) {
        conf->initstring1 = value;
        return 0;
    }

    /* set initstring2 */
    if (!(strcmp(token, "initstring2"))) {
        conf->initstring2 = value;
        return 0;
    }

    /* set initstring3 */
    if (!(strcmp(token, "initstring3"))) {
        conf->initstring3 = value;
        return 0;
    }

    /* set dialstring_front */
    if (!(strcmp(token, "dialstring_front"))) {
        if (strncasecmp(value, "AT", 2) == 0) {
          conf->dialstring_front = value + 2;
        } else {
          conf->dialstring_front = value;
        }
        return 0;
    }

    /* set dialstring_end */
    if (!(strcmp(token, "dialstring_end"))) {
        conf->dialstring_end = malloc(strlen(value + 2));
        strcpy(conf->dialstring_end, value);
        free(value);
        return 0;
    }

    /* set dial_wait */
    if (!(strcmp(token, "dial_wait"))) {
        conf->dial_wait = atoi(value);
        free(value);
        return 0;
    }

    /* set dial_wait_errors */
    if (!(strcmp(token, "dial_wait_errors"))) {
        conf->dial_wait_errors = atoi(value);
        free(value);
        return 0;
    }

    /* set ringout */
    if (!(strcmp(token, "ringout"))) {
        conf->ringout = atoi(value);
        free(value);
        return 0;
    }

    /* set errorout */
    if (!(strcmp(token, "errorout"))) {
        conf->errorout = atoi(value);
        free(value);
        return 0;
    }

    /* set debug */
    if (!(strcmp(token, "debug"))) {
        if (*value == '1' || *value == 'Y' || *value == 'y')
          conf->debug = 1;
        free(value);
        return 0;
    }

    /* set busyout */
    if (!(strcmp(token, "busyout"))) {
        conf->busyout = atoi(value);
        free(value);
        return 0;
    }

    /* set timeout */
    if (!(strcmp(token, "timeout"))) {
        conf->timeout = atoi(value);
        free(value);
        return 0;
    }

    /* set logfile */
    if (!(strcmp(token, "logfile"))) {
        conf->logfile = value;
        return 0;
    }

    /* unknown token */
    return -1;
}

/* returns one config file line */
char *tsng_modem_config_readline(char **mmap, int max) {
    char *line, *tmp = *mmap;
    int length = 0;

    while ((*tmp != '\n') && (length < max)) {
        length++;
        tmp++;
    }

    if ((line = malloc(length + 1)) == NULL) {
        perror("malloc failed");
        return NULL;
    }

    strncpy(line, *mmap, length);
    line[length] = 0;

    *mmap += length + 1;

    return line;
}

/* mmap the config file */
int tsng_modem_config_mmap(char *filename, char **map) {
    int fd, size;
    struct stat st;
    char *tmp;

    if ((fd = open(filename, O_RDONLY, 0)) == -1) {
        perror("open config file");
        return -1;
    }
    
    if (fstat(fd, &st) == -1) {
        perror("fstat");
        return -1;
    }

    size = st.st_size;

    // we are not using mmap anymore to be portable
    /*
    if ((tmp = mmap(NULL, size, PROT_READ, MAP_PRIVATE, fd, 0)) == (caddr_t)-1) {
        perror("mmap");
        return -1;
    }
    */
    if ((tmp = malloc(size)) == NULL) {
      fprintf(stderr, "Error: malloc() failed\n");
      return -1;
    }
    if (read(fd, tmp, size) != size) {
      fprintf(stderr, "Error: reading from %s\n", filename);
      return -1;
    }

    close(fd);

    *map = tmp;
        
    return size;
}

/* free struct and elements */
int tsng_modem_config_destroy(tsng_modem_config **conf) {
    free((*conf)->modem);
    free((*conf)->password);
    free((*conf)->initstring1);
    free((*conf)->initstring2);
    free((*conf)->initstring3);
    free((*conf)->dialstring_front);
    free((*conf)->dialstring_end);
    free((*conf)->nudgestring);
    free((*conf)->logfile);

    free(*conf);
    *conf = NULL;

    return 0;
}

/* returns config struct; main function */
tsng_modem_config *tsng_modem_config_new(char *filename) {
    char *line, *token, *value, *mmap, *mmap_bak;
    int mmap_size, max;
    tsng_modem_config *conf;
    
    if ((conf = malloc(sizeof(tsng_modem_config))) == NULL) {
        perror("malloc failed");
        return NULL;
    }
    memset(conf, 0, sizeof(tsng_modem_config));

    if ((mmap_size = tsng_modem_config_mmap(filename, &mmap)) < 0)
        return NULL;

    mmap_bak = mmap;

    /* set defaults */
    if (tsng_mode == TSNG_ZOMBIE)
      conf->port = TSNG_PORT_ZOMBIE;
    if (tsng_mode == TSNG_MASTER)
      conf->port = TSNG_PORT_MASTER;
    conf->baud = B57600;
    conf->databits = 8;
    conf->stopbits = 1;
    conf->parity = 'N';
    conf->hangup = TSNG_HANGUP_DEFAULT;
    conf->ringout = 3;
    conf->busyout = 3;
    conf->errorout = 5;
    conf->timeout = 45;
    conf->dialmode = DIALMODE_RAND;
    conf->dialstring_front = "DT";
    conf->nudgestring = strdup("~~~^M~^M~~?^M~~HELP^M~~~.^M~~~~~");
    conf->dialstring_end = "";
    // critical not set: password, modem
    // uncritical not set: initstring*, dialstring_end

    /* proceed config file lines */
    while ((mmap - mmap_bak) < mmap_size) {
        max = mmap_size - (mmap - mmap_bak);
        if ((line = tsng_modem_config_readline(&mmap, max)) == NULL)
            return NULL;

        /* comment line? */
        if (line[0] == '#' || line[0] == '\n' || line[0] == 0)
            continue;
        
        if (tsng_modem_config_parse(line, &token, &value) < -1)
            return NULL;
        
        if (tsng_modem_config_set(conf, token, value) < 0)
          fprintf(stderr, "Warning: token %s unknown\n", token);

        free(line);
        free(token);
    }

//    munmap(mmap_bak, mmap_size);
    free(mmap_bak);

    return conf;
}


/* test function */
#ifdef _MAIN
int main(int argc, char **argv) {
    tsng_modem_config *conf;
    
    if ((conf = tsng_modem_config_new(argv[1])) == NULL)
        return -1;

    printf("password: %s\n"
           "modem: %s\n"
           "baud: %i\n"
           "databits: %d\n"
           "stopbits: %i\n"
           "parity: %c\n"
           "initstring1: %s\n"
           "initstring2: %s\n"
           "initstring3: %s\n"
           "dialstring_front: %s\n"
           "dialstring_end: %s\n"
           "ringout: %i\n"
           "busyout: %i\n"
           "timeout: %i\n"
           "debug: %i\n",
           conf->password, conf->modem, conf->baud, conf->databits, conf->stopbits, conf->parity,
           conf->initstring1, conf->initstring2, conf->initstring3,
           conf->dialstring_front, conf->dialstring_end, conf->ringout,
           conf->busyout, conf->timeout, conf->debug);

    tsng_modem_config_destroy(&conf);

    return 0;
}
#endif
