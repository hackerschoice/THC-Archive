/*
 * (c) 2005 by van Hauser / THC <vh@thc.org www.thc.org
 *
 * Basic Modem Function Library for THC-SCAN New Generation
 *
 */

#include <stdio.h>
#include <string.h>
#include <stdarg.h>
#include <stdlib.h>
#include <termios.h>
#include <unistd.h>
#include <ctype.h>
/* network */
#include <signal.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
/* files */
#include <fcntl.h>
/* misc */
#include <time.h>
#include <errno.h>

#include "tsng.h"
#include "tsng-conf-lib.h"
#include "tsng-general-lib.h"

#define DEBUG_FILE stderr

#ifdef _MAIN
int debug = 0;
#else
extern int debug;
extern int go;
extern int stop;
extern int to_dial;
extern int rings;
extern int dialing;
extern int cancel;
extern time_t dial_elapsed;
extern void check_master_com();
#endif
int tsng_modem_lib_debug = 0;
char lineend[] = "\r";

/*
 * INPUT: char *modem_at_command - Full modem command, beginning with "AT"
 *                                 in front, but no \r ending.
 * OUTPUT: char *modem_at_response - pointer to buffer for the response of
 *                                   the modem. WARNING: maximum size of
 *                                   4096 bytes must be allocated!
 * OUTPUT: int return code	 0 = success
 *				-1 = error
 */

void tsng_modem_debug(char *str1, char *str2) {
  int i;
  char str[strlen(str2) + 1];
#ifdef DEBUG
  debug = 1;
#endif
  if (debug || tsng_modem_lib_debug) {
    strcpy(str, str2);
    for (i = 0; i < strlen(str); i++)
      if (! isprint(str[i]) || str[i] == '\n' || str[i] == '\r')
        str[i] = '.';
    fprintf(DEBUG_FILE, "%s \"%s\"\n", str1, str);
  }
}

void tsng_modem_debug_in(char *modem_at_command) {
  if (debug) {printf("Hex of AT command:\n");tsng_dump_asciihex(modem_at_command, strlen(modem_at_command));}
  tsng_modem_debug("DEBUG >> MODEM >>", modem_at_command);
}

void tsng_modem_debug_out(char *modem_at_response) {
  tsng_modem_debug("DEBUG << MODEM <<", modem_at_response);
}

char *tsng_client_stream_fgets(char *b, int s, FILE *f) {
  char *ptr = NULL;
  if ((ptr = tsng_stream_fgets(b, s, f)) != NULL) {
    tsng_modem_debug_out(b);
  }
  return ptr;
}

int tsng_modem_write(tsng_modem_config *config, char *data, int datalen) {
  char *ptr = data;
  int len = datalen, n = 0;

  if (config->fd < 0) {
    fprintf(DEBUG_FILE, "ERROR-MODEM Modem not initialized\n");
    return -1;
  }

  tsng_modem_debug_in(data);
  
  while (len > 0) {
    if ((n = fwrite(ptr, len, 1, config->stream)) > 0) {
      len -= n;
      ptr += n;
    } else {
      fprintf(DEBUG_FILE, "ERROR-MODEM Writing data to modem failed\n");
      return -1;
    }
  }
  fflush(config->stream);
  usleep(100000);

  return 0;
}

/*
 * return codes:   -2 timeout
 *                 -3 master told us to stop
 */

int tsng_modem_read_line(tsng_modem_config *config, char *response, int timeout) {
  time_t counter = time(NULL);
    
  response[0] = 0;
  do {
    check_master_com();
    tsng_client_stream_fgets(response, 4096, config->stream);
    if (response[0] == '\n')
      response[0] = 0;
    if (response[0] == '\r')
      response[0] = 0;
    if (strncmp(response, "AT", 2) == 0 || strlen(response) < 2)
      response[0] = 0;
    if (debug && response[0] != 0)
      tsng_dump_asciihex(response, strlen(response));
    usleep(15000);
  } while (response[0] == 0 && stop == 0 && cancel == 0 && (timeout == -1 || time(NULL) < counter + timeout));
//printf("got response: %s\n", response);

  if (cancel == 1 || stop == 1)
    return -3;
  if (response[0] == 0)
    return -2;
  
  return 0;  
}

int tsng_modem_read(tsng_modem_config *config, char *response, int timeout, int linefeeds, int mindata, int block) {
  int total = 0, i = 0, countlinefeeds = 0, n = 0, wait = 1;
  time_t counter;
  char *ptr = response;

  cancel = 0;
  memset(response, 0, 4096);
  counter = time(NULL);
  while (wait && cancel == 0 && counter + timeout >= time(NULL) && total < 4094) {
    if ((n = fread(ptr, 4095 - total, 1, config->stream)) > 0) {
      for(i = 0; i < n; i++)
        if (ptr[i] == '\n')
          countlinefeeds++;
      ptr += n;
      total += n;
    }
    if ((countlinefeeds >= linefeeds || linefeeds == 0) && (mindata <= total || mindata == 0))
        wait = 0;
    check_master_com();
    if ((go == 1 && stop == 0 && cancel == 0) || block == 1)
      usleep(15000);
    else
      return -3;
  }

  tsng_modem_debug_out(response);
  cancel = 0;

  if (wait)
    return -2;

  if (strlen(response) == 0 || mindata > total) {
    fprintf(DEBUG_FILE, "ERROR-MODEM Reading from modem failed\n");
    return -1;
  }

  return 0;
}

int tsng_modem_at(tsng_modem_config *config, char *modem_at_command, char *modem_at_response, int timeout) {
  char cmd[strlen(modem_at_command) + 6], *ptr = cmd;
  int ret;

  cancel = 0;
  if (config->fd < 0) {
    fprintf(DEBUG_FILE, "ERROR-MODEM Modem not initialized\n");
    return -1;
  }
  
  if (strncasecmp("AT", modem_at_command, 2) != 0) {
    strcpy(cmd, "AT");
    strncat(cmd, modem_at_command, sizeof(cmd) - 6);
  } else
    strcpy(cmd, modem_at_command);
  if (cmd[strlen(cmd) - 1] == '\n')
    cmd[strlen(cmd) - 1] = 0;
  if (cmd[strlen(cmd) - 1] == '\r')
    cmd[strlen(cmd) - 1] = 0;
  strcat(cmd, lineend);
  
  tsng_client_stream_fgets(modem_at_response, 255, config->stream);
  tsng_stream_resetbuffer(config->stream);
  if (tsng_modem_write(config, ptr, strlen(ptr)) < 0)
    return -1;

  ret = tsng_modem_read_line(config, modem_at_response, timeout);
  cancel = 0;
  return ret;
}

/*
 * INPUT: tsng_modem_config *config - modem configureation structure (see .h)
 * OUTPUT: int return code        0 = success
 *                               -1 = error
 */

int tsng_modem_hangup(tsng_modem_config *config) {
  char response[4096];
  char enter[2] = "\r";
  struct termios old, new;
  int type = config->hangup;
  
  if (type == 0)
    type = TSNG_HANGUP_SOFT + TSNG_HANGUP_DTR + TSNG_HANGUP_HARD;
  
  if ((type & TSNG_HANGUP_SOFT) == TSNG_HANGUP_SOFT)
    fwrite(enter, 1, 1, config->stream);
  
  if ((type & TSNG_HANGUP_DTR) == TSNG_HANGUP_DTR) {
    tcgetattr(config->fd, &new);
    tcgetattr(config->fd, &old);
    cfsetospeed(&new, B0);
    cfsetispeed(&new, B0);
    tcsetattr(config->fd, TCSANOW, &new);
    sleep(1);
    tcsetattr(config->fd, TCSANOW, &old);
  }
  
  if ((type & TSNG_HANGUP_HARD) == TSNG_HANGUP_HARD) {
    sleep(1);
    tsng_client_stream_fgets(response, 255, config->stream);
    tsng_stream_resetbuffer(config->stream);
    tsng_modem_write(config, "+++", 3);
    sleep(4);
    tsng_modem_read(config, response, 0, 1, 0, 1);
    if (strstr(response, "OK") == NULL)
      tsng_modem_read(config, response, 4, 2, 2, 1);
    tsng_modem_at(config, "H0", response, 2);
  }
  // XXX TODO FIXME : modem response check??
  dialing = 0;
  return 0;
}

int tsng_modem_init(tsng_modem_config *config, char *modem_at_response) {
  struct termios options/*, old_options, new_options*/;
  char empty[1] = "", cmd1[]="ATE0";
  int ret = 0, count = 0;
  
  config->fd = -1;
  if ((config->fd = open(config->modem, O_RDWR | O_NOCTTY | O_NDELAY)) < 0) {
      fprintf(DEBUG_FILE, "ERROR-MODEM Opening device %s failed\n", config->modem);
    return -1;
  }
//  tcgetattr(config->fd, &options);

//  tcgetattr(config->fd, &old_options);
  tcgetattr(config->fd, &options);

  options.c_cflag = options.c_cflag & ~CSIZE;
  options.c_cflag = config->baud | CRTSCTS | CLOCAL | CREAD;
  options.c_iflag = IGNBRK | IGNPAR; /*| ICRNL;*/
  options.c_oflag = 0;
  options.c_lflag = 0; // ICANON | ~ECHO;
  options.c_cc[VTIME]    = 5;     /* inter-character timer unused */
  options.c_cc[VMIN]     = 1;     /* blocking read until 1 character arrives */
  if (config->stopbits == 2)
    options.c_cflag = options.c_cflag | CSTOPB;
  if (config->parity == 'E')
    options.c_cflag = options.c_cflag | PARENB;
  else if (config->parity == 'O')
    options.c_cflag = options.c_cflag | PARODD;
  if (config->databits == 7)
    options.c_cflag = options.c_cflag | CS7;
  else
    options.c_cflag = options.c_cflag | CS8;
/*
  options.c_cc[VINTR]    = 0;
  options.c_cc[VQUIT]    = 0;
  options.c_cc[VERASE]   = 0;
  options.c_cc[VKILL]    = 0;
  options.c_cc[VEOF]     = 4;
  options.c_cc[VSWTC]    = 0;
  options.c_cc[VSTART]   = 0;
  options.c_cc[VSTOP]    = 0;
  options.c_cc[VSUSP]    = 0;
  options.c_cc[VEOL]     = 0;
  options.c_cc[VREPRINT] = 0;
  options.c_cc[VDISCARD] = 0;
  options.c_cc[VWERASE]  = 0;
  options.c_cc[VLNEXT]   = 0;
  options.c_cc[VEOL2]    = 0;
*/
  tcflush(config->fd, TCIFLUSH);
  tcsetattr(config->fd, TCSANOW, &options);
//  tcsetattr(config->fd, TCSANOW, &options);
/*
  tcgetattr(config->fd, &new_options);
  if (new_options.c_cflag != old_options.c_cflag)
    printf("cflag: %d\n", new_options.c_cflag - old_options.c_cflag);
  if (new_options.c_iflag != old_options.c_iflag)
    printf("iflag: %d\n", new_options.c_iflag - old_options.c_iflag);
  if (new_options.c_oflag != old_options.c_oflag)
    printf("oflag: %d\n", new_options.c_oflag - old_options.c_oflag);
  if (new_options.c_lflag != old_options.c_lflag)
    printf("lflag: %d\n", new_options.c_lflag - old_options.c_lflag);
exit(0);
*/
  if ((config->stream = tsng_stream_fdopen(config->fd, "a+")) == NULL) {
    fprintf(stderr, "ERROR: Your OS does not support streaming fd's to a modem! Please report to programmer!\n");
    return -1;
  }
//  setvbuf(config->stream, NULL, _IONBF, 0);
  fcntl(config->fd, F_SETFL, O_NONBLOCK);
// init
  while (tsng_fgets(modem_at_response, 4096, config->stream) != NULL);
  do {
    ret = tsng_modem_at(config, cmd1, modem_at_response, 5);
    count++;
  } while (ret < 0 && count < 5);
  if (ret < 0) {
    fprintf(DEBUG_FILE, "ERROR-MODEM Config Echo Off\n"); 
    return -1;
  }
  
  if (config->initstring1 != NULL && strlen(config->initstring1) > 0)
    if (tsng_modem_at(config, config->initstring1, modem_at_response, 5) < 0)
      fprintf(DEBUG_FILE, "ERROR-MODEM Initstring 1 failed\n"); 
  if (config->initstring2 != NULL && strlen(config->initstring2) > 0)
    if (tsng_modem_at(config, config->initstring2, modem_at_response, 5) < 0)
      fprintf(DEBUG_FILE, "ERROR-MODEM Initstring 2 failed\n"); 
  if (config->initstring3 != NULL && strlen(config->initstring3) > 0)
    if (tsng_modem_at(config, config->initstring3, modem_at_response, 5) < 0)
      fprintf(DEBUG_FILE, "ERROR-MODEM Initstring 3 failed\n"); 
  return tsng_modem_at(config, empty, modem_at_response, 5);
}

/*
 * return codes:     -1 error reading/writing
 *                   -2 ERROR (modem reports error in command)
 *                   -3 no dial tone
 *                   -4 unknown modem response
 *                    0 CONNECT/CARRIER
 *                    1 NO ANSWER / NO CARRIER
 *                    2 BUSY
 *                    3 OK
 *                    5 RINGOUT
 *                    6 TIMEOUT
 *                    7 VOICE
 *                   10 aborted
 */
 
int tsng_modem_dial(tsng_modem_config *config, char *number, char *response) {
  char cmd[256];
  int ret;
  time_t dial_start;
  int timeout_left = config->timeout;
  
  rings = 0;
  dialing = 1;

  snprintf(cmd, sizeof(cmd), "AT%s%s%s%s", config->dialstring_front, number, config->dialstring_end == NULL ? "" : config->dialstring_end, lineend);
//tsng_dump_asciihex(cmd, strlen(cmd)); 
  if (debug || tsng_modem_lib_debug)
    printf("DEBUG Dialing %s\n", number);
  while(tsng_fgets(response, 4096, config->stream) != NULL);
  tsng_client_stream_fgets(response, 255, config->stream);
  tsng_stream_resetbuffer(config->stream);
  if (tsng_modem_write(config, cmd, strlen(cmd)) < 0)
//  if (tsng_modem_at(config, cmd, response, timeout) < 0);
    return -1;
  dial_start = time(NULL);
  usleep(400000);
ring:
  timeout_left = config->timeout - (time(NULL) - dial_start);
  ret = tsng_modem_read_line(config, response, timeout_left);
//printf("ret: %d [stop %d, cancel %d]\n",ret, stop, cancel);
  dial_elapsed = time(NULL) - dial_start;
  if (ret < 0) {
    tsng_modem_hangup(config);
    if (ret == -3)
      return 10;
    else
      return 6;
  } else {
    if (strncasecmp(response, "OK", strlen("OK")) == 0) {
      /* note: needs hangup !!! */
      return 3;
    } else if (strncasecmp(response, "CONNECT", strlen("CONNECT")) == 0) {
      /* note: needs hangup !!! */
      return 0;
    } else if (strncasecmp(response, "RINGING", strlen("RINGING")) == 0) {
      rings++;
      fprintf(config->streamsocket, "DATA RINGING %s %lu %d %s\n", number, dial_elapsed, rings, response);
      if (rings > config->ringout) {
        tsng_modem_hangup(config);
        return 5;
      } else {
        goto ring;
      }
    } else if (strncasecmp(response, "BUSY", strlen("BUSY")) == 0) {
      dialing = 0;
      return 2;
    } else if (strncasecmp(response, "NO ANSWER", strlen("NO ANSWER")) == 0 ||
               strncasecmp(response, "NO CARRIER", strlen("NO CARRIER")) == 0) {
      dialing = 0;
      return 1;
    } else if (strncasecmp(response, "VOICE", strlen("VOICE")) == 0) {
      dialing = 0;
      return 7;
    } else if (strncasecmp(response, "ERROR", strlen("ERROR")) == 0) {
      dialing = 0;
      return -2;
    } else if (strncasecmp(response, "NO DIAL", strlen("NO DIAL")) == 0) {
      dialing = 0;
      return -3;
    }
  }
  return -4; // unknown modem response
}

#ifdef _MAIN
int main(int argc, char *argv[]) {
  char req[256], reply[5000];
  tsng_modem_config config;
  char cmd[] = "AT";

  config.fd = -1;
  debug = 1;
  config.modem = malloc(50);
  strcpy(config.modem, "/dev/ttySL0");
  config.baud = B576000;
  config.parity &= ~PARENB;
  config.parity &= ~CSTOPB;
  config.parity &= ~CSIZE;
  config.parity |= CS8;
  config.initstring1 = cmd;
  config.initstring2 = cmd;
  config.initstring3 = cmd;
  config.dialstring_front = "DT";
  config.dialstring_end = "";
  config.timeout = 15;

  if (tsng_modem_init(&config, reply) == 0)
printf("ret of dial: %d\n", tsng_modem_dial(&config, "12345", reply));
    while (1) {
      if (fgets(req, sizeof(req), stdin) == NULL)
        return -1;
      if (strlen(req) > 0) {
        tsng_modem_at(&config, req, reply, 65);
        if (strlen(reply) > 0)
          printf("%s\n", reply);
      }
    }
  return 0;
}
#endif
