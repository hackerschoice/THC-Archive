#ifndef _TSNG_H
#define TSNG_H

#define VERSION "v1.1"			/* version of tsng */

#define TSNG_PORT_MASTER 60000		/* default port of master */
#define TSNG_PORT_ZOMBIE 60001		/* default port of zombie */

#define MAX_X 6				/* maximum number of X's for scanning */

#define MAX_ARRAY_ZOMBIE 10		/* maximum numbers to dial for zombie */
#define MAX_ARRAY_MASTER 1000000	/* maximum numbers for dialist for master */

#define MAX_LINE 5000			/* maximum line length to support */

#define DAT_UNDIALED   0
#define DAT_DROPPED    1
#define DAT_INPROGRESS 2
#define DAT_CARRIER    3
#define DAT_OK         4
#define DAT_NOANSWER   5
#define DAT_VOICE      6
#define DAT_BUSY       7
#define DAT_RINGOUT    8
#define DAT_TIMEOUT    9
#define DAT_ERROROUT  10
#define DAT_BUSYOUT   11
#define DAT_UNKNOWNERROR 12
/* 0 2 4 8 = 4 bit, 4 bit for busy or ringout */

/* internal stuff */

#define TSNG_ANY    0
#define TSNG_CLIENT 1
#define TSNG_MASTER 2
#define TSNG_ZOMBIE 3

#define TSNG_DAT_VERSION 1

#define TSNG_HANGUP_SOFT 1
#define TSNG_HANGUP_DTR  2
#define TSNG_HANGUP_HARD 4
#define TSNG_HANGUP_DEFAULT ( TSNG_HANGUP_SOFT + TSNG_HANGUP_DTR )
#define TSNG_HANGUP_SECURE  ( TSNG_HANGUP_SOFT + TSNG_HANGUP_HARD )
#define TSNG_HANGUP_ALL     ( TSNG_HANGUP_SOFT + TSNG_HANGUP_DTR + TSNG_HANGUP_HARD )

#endif

