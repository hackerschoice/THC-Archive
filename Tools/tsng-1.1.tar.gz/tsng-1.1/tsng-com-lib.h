
#ifndef _TSNG_COM_LIB_H

#define _TSNG_COM_LIB_H

#define MAX_NUMBER_LENGTH 128

/* help functions */
extern int      tsng_com_cmd(int *argc, char *argv[], char *result);
extern int      tsng_com_ok(char *buf, char *msg);
extern int      tsng_com_error(char *buf, char *msg);

/* for zombie and master */
extern int      tsng_com_ext_start(char *id);
extern void     tsng_com_ext_stop();
extern int      tsng_com_ext_kill(char *host, char *port);
extern int      tsng_com_ext_cancel(char *id);
extern void     tsng_com_ext_scanarray(char *id); // is NULL if mode=zombie
extern int      tsng_com_scanarray(char *in, char *out, int current, int max);

/* only for master */
extern int     tsng_com_ext_timeout(int count, char *id);
extern int     tsng_com_ext_busyout(int count, char *id);
extern int     tsng_com_ext_ringout(int count, char *id);
extern int     tsng_com_ext_errorout(int count, char *id);
extern int     tsng_com_ext_nudge(char *nudge, char *id);
extern int     tsng_com_ext_scan(char *string, char *id);
extern int     tsng_com_ext_drop(char *string, char *id);
extern int     tsng_com_ext_add(char *host, char *port);
extern int     tsng_com_ext_del(char *host, char *port, int kill);
extern int     tsng_com_ext_watch(char *onoffstatus); // can be NULL!!
extern int     tsng_com_ext_list(char *id);	// can be NULL !!
extern int     tsng_com_ext_continue(char *id);
extern int     tsng_com_ext_priority(char *prio, char *id);
extern int     tsng_com_ext_dump(char *id);
extern int     tsng_com_ext_export(char *id);
extern int     tsng_com_ext_dialmode(int type, char *id);
extern int     tsng_com_ext_restore(char *id);
extern int     tsng_com_ext_release(char *id);

#endif
