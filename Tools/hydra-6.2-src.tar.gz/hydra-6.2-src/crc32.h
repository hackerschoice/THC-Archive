#ifndef CRC32_H
#define CRC32_H

#include <sys/types.h>

unsigned int crc32(const void *buf, unsigned int size);

#endif
