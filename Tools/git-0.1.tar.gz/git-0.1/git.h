#ifndef GIT_H

#include "git-lib.h"

#define VERSION			"v0.1"
#define AUTHOR			"van Hauser / THC"
#define EMAIL			"vh@reptile.rug.ac.be"
#define WEB			"http://www.thehackerschoice.com"

char *prg;
char *nul = "";

#define GIT_LOOKUP_KEYLENGTH              16

#define GIT_VERSION                       1

#define GIT_LOOKUP_MAX_TABLE_ITEMS        65536
#define MAX_MSEC_VALUE			  1000000

#define GIT_FILE_TYPE_SORTED              1 << 0
#define GIT_FILE_TYPE_WITH_PACKET_DATA    1 << 1
#define GIT_FILE_TYPE_WITH_PACKET_HEADER  1 << 2
#define GIT_FILE_TYPE_UNUSED              1 << 3

struct GIT_FILE_HEADER {
    unsigned char       git_string[3],   // 3 bytes = "GIT"
                        version:4,       // 4 bits
                        type:4;          // 4 bits
             long  int  epoch_seconds;   // 4 bytes
             long  int  milliseconds;    // 4 bytes
    unsigned long  int  host_ns;         // 4 bytes
    unsigned char       unused[4];       // 4 bytes
    unsigned char       email[32];       // 32 bytes
};  // 52 bytes

struct GIT_FILE_ENTRY {
    unsigned char       anonymous[16];   // 16 bytes
             long  int  epoch_seconds;   // 4 bytes
             long  int  milliseconds;    // 4 bytes
             long  int  diff_epoch_seconds;      // 4 bytes
             long  int  diff_milliseconds; // 4 bytes
    unsigned short int  data_length;     // 2 bytes
    unsigned char       unused[2];       // 2 bytes
};  // 36 bytes

struct GIT_FILE_FOOTER {
    unsigned char       git_string[3],   // 3 bytes
                        version:4,       // 4 bits
                        type:4;          // 4 bits
             long int   epoch_seconds;   // 4 bytes
             long int   milliseconds;    // 4 bytes
};  // 12 bytes

struct GIT_FILE_LOOKUP {
    unsigned char       anonymous[16];   // 16 bytes
    unsigned long int   host_ns_src;     // 4 bytes
    unsigned long int   host_ns_dst;     // 4 bytes
    unsigned short int  port_ns_src;     // 2 bytes
    unsigned short int  port_ns_dst;     // 2 bytes
    unsigned char       proto, random[3];// 4 bytes
};  // 32 bytes

#define GIT_H_
#endif
