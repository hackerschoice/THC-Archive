#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <string.h>
#include <strings.h>
#include <time.h>
#include <ctype.h>
#include "git.h"

#define PROGRAM			"git_search"

struct packet_characteristic {
    long int sec;
    long int msec;
    long int length;
};

void help() {
    printf("%s %s (c) 2002 by %s <%s>\n\n", PROGRAM, VERSION, AUTHOR, EMAIL);
    printf("Syntax: %s [-f TIME] [-i] [-v] FILE LENGTH TIME LENGTH [TIME LENGTH ...]\n\n", prg);
    printf("Options:
  -f      fuzziness level (time in milliseconds which is allowed to differ
          from the specified TIME between each packet)
  -i      ignore packets which were recorded with zero length
  -v      dump each connection if characteristic is matched
  FILE    the sniff_...git file to search in
  LENGTH  length of the packet(s)
  TIME    time in milliseconds between the packets (see -f for fuzziness!)
          you may use the \"1.1\" format to specify 1 second + 100 milliseconds 
\"X\" is a wildcard for LENGTH and TIME\n\n");
    printf("Searches git_sniffer anonymized output for connection characteristics.\n\n");
    printf("You can find updates of GIT at %s\n", WEB);
    printf("READ THE LICENCE - THIS IT NOT GPL!\n");
    exit(0);
}

int main(int argc, char *argv[]) {
    FILE *fsniff;
    struct GIT_FILE_HEADER gfh;
    struct GIT_FILE_ENTRY gfe;
    struct GIT_FILE_FOOTER gff;
    char *file;
    long int fuzzy = 0;
    int ignore = 0;
    int verbose = 0;
    struct packet_characteristic **pc;
    int pc_count, count = 0, found = 0;
    struct in_addr src;
    struct tm *tp;
    char out[16];
    int i, j;
    char old_anon[sizeof(gfe.anonymous)];

    prg = argv[0];
    memset(old_anon, 0, sizeof(old_anon));
    
    if (argc < 5 || strncmp("-h", argv[1], 2) == 0 || strncmp("--h", argv[1], 3) == 0)
        help();

    while ((i = getopt(argc, argv, "f:iv")) != EOF) {
        switch(i) {
            case 'f': fuzzy = atoi(optarg); break;
            case 'i': ignore = 1; break;
            case 'v': verbose = 1; break;
            default: help();
        }
    }

    if (argc - optind < 3) {
        fprintf(stderr, "Error: not enough command line options\n");
        exit(-1);
    }
    if ((argc - optind) % 2 != 0) {
        fprintf(stderr, "Error: after the filename, the first value is the LENGTH, followed by pairs of  TIME and LENGTH. Your command line options seem to be missing a final LENGTH.\n");
        exit(-1);
    }

    pc_count = (argc - optind) / 2;
    count = 0;
    file = argv[optind];
    optind++;
    pc = malloc(pc_count * sizeof(pc[0]));
    pc[count] = malloc(sizeof(struct packet_characteristic));
    pc[count]->sec = -1;
    pc[count]->msec = -1;
    if (toupper(argv[optind][0]) == 'X')
        pc[count]->length = -1;
    else
        pc[count]->length = atoi(argv[optind]);
    optind++;
    count++;

    if ((fsniff = fopen(file,"r")) == NULL) {
        fprintf(stderr, "Error: file not found - %s\n", file);
        exit(-1);
    }
    while (optind < argc) {
        pc[count] = malloc(sizeof(struct packet_characteristic));
        if (index(argv[optind], '.') == NULL) {
            if (toupper(argv[optind][0]) == 'X') {
                pc[count]->sec = -1;
                pc[count]->msec = -1;
            } else {
               pc[count]->sec = atoi(argv[optind]) / 1000;
               pc[count]->msec = atoi(argv[optind]) % 1000;
            }
        } else {
            char *ptr, tmp[strlen(argv[optind] + 1)];
            strcpy(tmp, argv[optind]);
            ptr = index(tmp, '.');
            *ptr = 0;
            ptr++;
            while (*ptr == '0')
               ptr++;
            pc[count]->sec = atoi(tmp);
            if (strlen(ptr) > 3)
                *(ptr + 3) = 0;
            j = strlen(ptr);
            switch (j) {
                case 0: pc[count]->msec = 0;
                case 1: pc[count]->msec = atoi(ptr) * 100;
                case 2: pc[count]->msec = atoi(ptr) * 10;
                case 3: pc[count]->msec = atoi(ptr)    ;
            }
        }
        optind++;
        if (toupper(argv[optind][0]) == 'X')
            pc[count]->length = -1;
        else
            pc[count]->length = atoi(argv[optind]);
        optind++;
        count++;
    }

    fread(&gfh, sizeof(gfh), 1, fsniff);
    if (memcmp(&gfh.git_string, "GIT", 3) != 0) {
        fprintf(stderr, "Error: not a GIT sniff file - %s\n", file);
        exit(-1);
    } 
    printf("FILENAME   : %s\nGIT VERSION: %d\n",file,gfh.version);
    if ((gfh.type & GIT_FILE_TYPE_SORTED) == 0) {
        fprintf(stderr, "Error: GIT file %s not sorted - use git_sort first\n", file);
        exit(-1);
    }
    if (gfh.type & GIT_FILE_TYPE_WITH_PACKET_DATA ||
        gfh.type & GIT_FILE_TYPE_WITH_PACKET_HEADER ||
        gfh.type & GIT_FILE_TYPE_UNUSED ||
        gfh.version != GIT_VERSION) {
        fprintf(stderr, "Error: GIT type/version is not supported\n");
        exit(-1);
    }
    memcpy(&src.s_addr, &gfh.host_ns, 4);
    printf("IP ADDRESS : %s\nCONTACT    : %s\n",inet_ntop(AF_INET,&src,(char*)&out,sizeof(out)),gfh.email);
    tp = localtime((time_t*)&gfh.epoch_seconds);
    printf("SNIFF START: %02d.%02d.%04d %02d:%02d:%02d\n\n",tp->tm_mday,tp->tm_mon,tp->tm_year,tp->tm_hour,tp->tm_min,tp->tm_sec);

   {
    unsigned char status[pc_count];
    long long int diff1, diff2;
    long int saved_milliseconds = 0, saved_epoch_seconds = 0, saved_pos = 0;
    int skip = 0;
    status[0] = 1;
    for (i = 1; i < pc_count; i++)
        status[i] = 0;
    while (! feof(fsniff)) {
#ifdef DEBUG
printf("DEBUG status before: %d %d %d %d\n",status[0],status[1],status[2],status[3]);
#endif
        if (fread(&gfe, sizeof(gfe), 1, fsniff) == 1) {
            if (memcmp(old_anon, gfe.anonymous, sizeof(old_anon)) != 0) {
                memcpy(old_anon, gfe.anonymous, sizeof(old_anon));
                if (skip) {
                    tp = localtime((time_t*)&saved_epoch_seconds);
                    printf("%02d.%02d.%04d %02d:%02d:%02d.%06ld\n",tp->tm_mday,tp->tm_mon,tp->tm_year,tp->tm_hour,tp->tm_min,tp->tm_sec,saved_milliseconds);
                    skip = 0;
                    if (verbose) {
                        struct GIT_FILE_ENTRY gfe2;
                        long no = 0, current_pos = ftell(fsniff);
                        fseek(fsniff, saved_pos, SEEK_SET);
                        do {
                            if (fread(&gfe2, sizeof(gfe2), 1, fsniff) == 1) {
                                no++;
                                tp = localtime((time_t*)&gfe2.epoch_seconds);
                                printf("PACKET %ld: LENGTH - %u  TIME - %02d.%02d.%04d %02d:%02d:%02d.%06ld\n", no,gfe2.data_length,
                                tp->tm_mday,tp->tm_mon,tp->tm_year,tp->tm_hour,tp->tm_min,tp->tm_sec,gfe2.milliseconds);
                            }
                        } while (ftell(fsniff) != current_pos);
                    }
                    printf("\n");
                }
                saved_epoch_seconds = gfe.epoch_seconds;
                saved_milliseconds = gfe.milliseconds;
                saved_pos = ftell(fsniff) - sizeof(gfe);
                for (i = 1; i < pc_count; i++)
                    status[i] = 0;
                if (pc[0]->length < 0 || gfe.data_length == pc[0]->length)
                    status[1] = 1;
            } else {
                if (skip == 0) {
                  for (j = pc_count - 1; j >= 0; j--)
                    if (status[j] > 0) {
                        diff1 = (pc[j]->sec * 1000) + pc[j]->msec;
                        diff2 = (gfe.diff_epoch_seconds * 1000) + ((gfe.diff_milliseconds *  1000)/ MAX_MSEC_VALUE);
                        if ((pc[j]->length < 0 || pc[j]->length == gfe.data_length) &&
                            (pc[j]->sec < 0 || 
                             (diff1 > diff2 ? diff1 <= diff2 + fuzzy : diff2 <= diff1 + fuzzy)
                           )) {
                            if (j > 0)
                                status[j] = 0;
                            if (j + 1 == pc_count) {
                                tp = localtime((time_t*)&saved_epoch_seconds);
                                printf("HASH: ");
                                for (i = 0; i < 16; i++)
                                    printf("%02x", gfe.anonymous[i]);
                                printf("\nTIME: %02d.%02d.%04d %02d:%02d:%02d.%06ld to ",
                                tp->tm_mday,tp->tm_mon,tp->tm_year,tp->tm_hour,tp->tm_min,tp->tm_sec,saved_milliseconds);
                                found++;
                                skip = 1;
                            } else
                                status[j+1] = 1;
                        } else {
                            if ((gfe.data_length > 0 || ignore == 0) && j > 0)
                                status[j] = 0;
                        }
                    }
                } else {
                    saved_epoch_seconds = gfe.epoch_seconds;
                    saved_milliseconds = gfe.milliseconds;
                }
            }
        }
#ifdef DEBUG
        printf("DEBUG status after:  %d %d %d %d\n",status[0],status[1],status[2],status[3]);
#endif
    }
    if (skip) {
        tp = localtime((time_t*)&saved_epoch_seconds);
        printf("%02d.%02d.%04d %02d:%02d:%02d.%06ld\n",tp->tm_mday,tp->tm_mon,tp->tm_year,tp->tm_hour,tp->tm_min,tp->tm_sec,saved_milliseconds);
        if (verbose) {
            struct GIT_FILE_ENTRY gfe2;
            long no = 0, current_pos = ftell(fsniff);
            fseek(fsniff, saved_pos, SEEK_SET);
            do {
                if (fread(&gfe2, sizeof(gfe2), 1, fsniff) == 1) {
                    no++;
                    tp = localtime((time_t*)&gfe2.epoch_seconds);
                    printf("PACKET %ld: LENGTH - %u  TIME - %02d.%02d.%04d %02d:%02d:%02d.%06ld\n",no,gfe2.data_length,
                      tp->tm_mday,tp->tm_mon,tp->tm_year,tp->tm_hour,tp->tm_min,tp->tm_sec,gfe2.milliseconds);
                }
            } while (ftell(fsniff) != current_pos);
        }
        printf("\n");
    }
   }

    fseek(fsniff, -(sizeof(gff)), SEEK_END);
    fread(&gff, sizeof(gff), 1, fsniff);
    if (memcmp(&gff.git_string, "GIT", 3) != 0 || gff.version != 0x0f || gff.type != 0x0f) {
        fprintf(stderr, "Warning: GIT file ending not found - git_sniffer still running or git_sniffer process was killed\n");
    } else {
        tp = localtime((time_t*)&gff.epoch_seconds);
        printf("SNIFF STOP : %02d.%02d.%04d %02d:%02d:%02d\n",tp->tm_mday,tp->tm_mon,tp->tm_year,tp->tm_hour,tp->tm_min,tp->tm_sec);
    }
    fclose(fsniff);

    printf("%d occurances found.\n", found);
    return(0);
}
