#include <stdio.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include "git.h"

int main(int argc, char *argv[]) {
    FILE *flookup;
    struct in_addr src, dst;
    struct GIT_FILE_LOOKUP gfl;
    int i;

    if (argc != 3) {
        fprintf(stderr, "Syntax: %s FILE KEY\n", argv[0]);
        exit(-1);
    }

    git_set_key(argv[2]);
    git_kill_string(argv[2]);

    if ((flookup = fopen(argv[1],"r")) == NULL) {
        fprintf(stderr, "Error: file not found - %s\n", argv[1]);
        exit(-1);
    }
    
    while (! feof(flookup)) {
        if (fread(&gfl, sizeof(gfl), 1, flookup) == 1) {
            git_decrypt((char*)&gfl, sizeof(gfl));
            memcpy(&src.s_addr, &gfl.host_ns_src, 4);
            memcpy(&dst.s_addr, &gfl.host_ns_dst, 4);
            printf("HASH: ");
            for (i = 0; i < 16; i++)
                printf("%02x", gfl.anonymous[i]);
            printf("\nS IP: %s\nD IP: %s\nS PORT: %d\nD PORT: %d\nPROTO: %d\n\n",inet_ntoa(src),inet_ntoa(dst),ntohs(gfl.port_ns_src),ntohs(gfl.port_ns_dst),gfl.proto);
        }
    }
    return(0);
}
