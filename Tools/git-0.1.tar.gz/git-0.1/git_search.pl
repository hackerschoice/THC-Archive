#!/usr/bin/perl

#
# Config this
#
$CGI_PATH= "/cgi-bin/git_search.pl";
$GIT_PATH= "/projects/git";
$GIT_SNIFF_FILE= "/projects/git/sniff_xxx.git";

#
#---------------------------
#
# dont change anything below
#
$query = $ENV{'QUERY_STRING'};
$cmd = $GIT_PATH . "/git_search -vi";
$fuzzy = "0";

#$query = $ARGV[0];

if ($query eq '') {
    print <<EOF;
 <html>
  <head><title>GIT search CGI tool</title></head>
  <body><center><h1>GIT search CGI tool<p></h1></center><hr>
  <form action="$CGI_PATH" method="get">
   Fuzzy Level (milliseconds): <input type=text   name=fuzzy value="100">
   <p><br><tr>
    Length of packet 1: <input type=text   name=length1 value=""><p>
    Time delta between packet 1 and 2: <input type=text   name=delta12 value=""><p>
    Length of packet 2: <input type=text   name=length2 value=""><p>
    Time delta between packet 2 and 3: <input type=text   name=delta23 value=""><p>
    Length of packet 3: <input type=text   name=length3 value=""><p>
    Time delta between packet 3 and 4: <input type=text   name=delta34 value=""><p>
    Length of packet 4: <input type=text   name=length4 value=""><p>
    Time delta between packet 4 and 5: <input type=text   name=delta45 value=""><p>
    Length of packet 5: <input type=text   name=length5 value=""><p>
    Time delta between packet 5 and 6: <input type=text   name=delta56 value=""><p>
    Length of packet 6: <input type=text   name=length5 value=""><p>
   </tr><p><br>
   <input type=submit name=search   value="Search">

  </form>
  <hr><center><h2>
  Find out more about the Global Intrusion Tracer and THC - The Hackers Choice at <a href="http://www.thehackerschoice.com">http://www.thehackerschoice.com</a>
  </h2></center></body>
 </html>
EOF
} else {
    print "<html><head><title>GIT search results</title></head><body><center><h1>GIT search results<p></h1></center><hr><pre>\n";
    $done="0";
    foreach(split(/\&/, $query)) {
        ($name, $value) = split(/=/, $_, 2);
        undef $done;
        $value =~ s/[^0-9xX]//g;
        $name =~ tr/A-Z/a-z/;
        $name =~ s/[^a-z0-9]//g;
        if ($name eq "fuzzy") {
	    $fuzzy="$value";
            $done="1";
        }
        if ($name eq "length1") {
	    $length1="$value";
            $done="1";
        }
        if ($name eq "length2") {
	    $length2="$value";
            $done="1";
        }
        if ($name eq "length3") {
	    $length3="$value";
            $done="1";
        }
        if ($name eq "length4") {
	    $length4="$value";
            $done="1";
        }
        if ($name eq "length5") {
	    $length5="$value";
            $done="1";
        }
        if ($name eq "length6") {
	    $length6="$value";
            $done="1";
        }
        if ($name eq "delta12") {
	    $delta12="$value";
            $done="1";
        }
        if ($name eq "delta23") {
	    $delta12="$value";
            $done="1";
        }
        if ($name eq "delta34") {
	    $delta12="$value";
            $done="1";
        }
        if ($name eq "delta45") {
	    $delta12="$value";
            $done="1";
        }
        if ($name eq "delta56") {
	    $delta12="$value";
            $done="1";
        }
        if (!defined $done) {
           print "Variable $name is unknown - do not try to play tricks!";
           print "\n</pre><hr><center><h2>Find out more about the Global Intrusion Tracer and THC - The Hackers Choice at <a href=\"http://www.thehackerschoice.com\">http://www.thehackerschoice.com</a></h2></center></body></html>\n";
 	   exit(0);
        }
    }
    open (FD, "$cmd -f $fuzzy $GIT_SNIFF_FILE $length1 $delta12 $length2 $delta23 $length3 $delta34 $length4 $delta45 $length5 $delta56 $length6 2>&1 |") || print "ERROR: unable to execute git_search";
    while (<FD>) {
        print "$_";
    }
    print "\n</pre><hr><center><h2>Find out more about the Global Intrusion Tracer and THC - The Hackers Choice at <a href=\"http://www.thehackerschoice.com\">http://www.thehackerschoice.com</a></h2></center></body></html>\n";
}
exit(0);
