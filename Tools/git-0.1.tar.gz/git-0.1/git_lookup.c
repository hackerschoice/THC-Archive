#include <stdio.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <ctype.h>
#include "git.h"

#define PROGRAM			"git_lookup"

struct GIT_FILE_LOOKUP gfl;
unsigned char key[GIT_LOOKUP_KEYLENGTH + 1];

void help() {
    printf("%s %s (c) 2002 by %s <%s>\n\n", PROGRAM, VERSION, AUTHOR, EMAIL);
    printf("Syntax: %s FILE HASH\n\n", prg);
    printf("Options:
  FILE    the lookup_...git file to search in
  HASH    the hash value to lookup\n\n");
    printf("Search git_sniffer encrypted lookup output for a given hash.\n\n");
    printf("You can find updates of GIT at %s\n", WEB);
    printf("READ THE LICENCE - THIS IT NOT GPL!\n");
    exit(0);
}

void cleanup(int signo) {
    git_kill_string(key);
    memset(&gfl, 0, sizeof(gfl));
    system("stty echo");
    if (signo > 0) {
        printf("Received signal %d, going down ...\n", signo);
        exit(-1);
    }
    exit(0);
}

int main(int argc, char *argv[]) {
    FILE *flookup;
    struct in_addr src, dst;
    unsigned char hash[16];
    int i;
    unsigned char j, k;

    git_secure_process();
    memset(key, 0, sizeof(key));
    prg = argv[0];
    memset(&hash, 0, sizeof(hash));
    
    if (argc != 3)
        help();

    if (strlen(argv[2]) != 32) {
        fprintf(stderr, "Error: invalid hash - %s (a real hash looks like: 60b725f10c9c85c70d97880dfe8191b3)\n", argv[2]);
        exit(-1);
    }
    
    for (i = 0; i < 16; i++) {
        if (isalpha((j = tolower(argv[2][i*2]))))
            j = (j - 'a' + 10) * 16;
        else
            if (isdigit(j))
                j = (j - '0') * 16;
            else {
                fprintf(stderr, "Error: invalid characters in hash - %c\n", argv[2][i]);
                exit(-1);
            }
        if (isalpha((k = tolower(argv[2][(i*2)+1]))))
            j += (k - 'a' + 10);
        else
            if (isdigit(k))
                j += (k - '0');
            else {
                fprintf(stderr, "Error: invalid characters in hash - %c\n", argv[2][i+1]);
                exit(-1);
            }
        hash[i] = j;
    }

    if ((flookup = fopen(argv[1], "r")) == NULL) {
        fprintf(stderr, "Error: file not found - %s\n", argv[1]);
        exit(-1);
    }
    
    sleep(1);

    for (i = 1; i < 32; i++)
        if (i < 17 || i > 27)
            signal(i, cleanup);

// XXX wipe stdin!
    printf("Lookup password: ");
    system("stty -echo");
    (void) fgets(key, GIT_LOOKUP_KEYLENGTH + 1, stdin);
    system("stty echo");
    printf("thank you. (key validity will not be checked!)\n");
    if (key[strlen(key) - 1] == '\n')
        key[strlen(key) - 1] = 0;
    if (key[strlen(key) - 1] == '\r')
        key[strlen(key) - 1] = 0;
    git_set_key(key);
    git_kill_string(key);
    sleep(1);
    printf("\n");
    sleep(1);

    while (! feof(flookup)) {
        if (fread(&gfl, sizeof(gfl), 1, flookup) == 1) {
            git_decrypt((char*)&gfl, sizeof(gfl));
            if (memcmp(hash, gfl.anonymous, sizeof(gfl.anonymous)) == 0) {
                char out[16], out2[16];
                git_wipe_key();
                memcpy(&src.s_addr, &gfl.host_ns_src, 4);
                memcpy(&dst.s_addr, &gfl.host_ns_dst, 4);
                printf("HASH: ");
                for (i = 0; i < 16; i++)
                    printf("%02x", gfl.anonymous[i]);
                printf("\nSRC IP: %s\nDST IP: %s\nSRC PORT: %d\nDST PORT: %d\nPROTOCOL: %d\n\n",
                  inet_ntop(AF_INET,&src,(char*)&out,sizeof(out)),inet_ntop(AF_INET,&dst,(char*)&out2,sizeof(out2)),
                  ntohs(gfl.port_ns_src),ntohs(gfl.port_ns_dst),gfl.proto);
                memset(&gfl, 0, sizeof(gfl));
                fclose(flookup);
                sleep(1);
                exit(0);
            }
        }
    }
    fclose(flookup);
    sleep(1);
    printf("Warning: hash not found\n");

    return(0);
}
