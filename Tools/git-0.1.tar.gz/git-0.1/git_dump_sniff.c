#include <stdio.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <time.h>
#include "git.h"

int main(int argc, char *argv[]) {
    FILE *fsniff;
    struct in_addr src;
    struct GIT_FILE_ENTRY gfe;
    struct GIT_FILE_HEADER gfh;
    struct GIT_FILE_FOOTER gff;
    struct tm *tp;
    int i;

    if ((fsniff = fopen(argv[1],"r")) == NULL) {
        fprintf(stderr, "Error: file not found - %s\n", argv[1]);
        exit(-1);
    }

    fread(&gfh, sizeof(gfh), 1, fsniff);
    if (memcmp(&gfh.git_string, "GIT", 3) != 0) {
        fprintf(stderr, "Error: not a GIT sniff file - %s\n", argv[1]);
        exit(-1);
    } 
    printf("FILE: %s\nVERSION: %d\nTYPE: ",argv[1],gfh.version);
    if (gfh.type & GIT_FILE_TYPE_SORTED)
        printf("SORTED ");
    else
        printf("UNSORTED ");
    if (gfh.type & GIT_FILE_TYPE_WITH_PACKET_DATA)
        printf("WITH_PACKET_DATA ");
    else
        printf("WITHOUT_PACKET_DATA ");
    if (gfh.type & GIT_FILE_TYPE_WITH_PACKET_HEADER)
        printf("WITH_PACKET_HEADER");
    else
        printf("WITHOUT_PACKET_HEADER");
    memcpy(&src.s_addr, &gfh.host_ns, 4);
    printf("\nHOST IP: %s\nEMAIL: %s\n",inet_ntoa(src),gfh.email);
    tp = localtime((time_t*)&gfh.epoch_seconds);
    printf("START TIME: %d.%d.%d %d:%d:%d\n\n",tp->tm_mday,tp->tm_mon,tp->tm_year,tp->tm_hour,tp->tm_min,tp->tm_sec);
    
    while (! feof(fsniff)) {
        if (fread(&gfe, sizeof(gfe), 1, fsniff) == 1) {
              printf("HASH: ");
              for (i = 0; i < 16; i++)
                  printf ("%02x", gfe.anonymous[i]);
              printf("\nEPOCH: %ldsec %ldms\nDIFF: %ldsec %ldms\nLENGTH: %d\n---\n",
                gfe.epoch_seconds, gfe.milliseconds, gfe.diff_epoch_seconds, gfe.diff_milliseconds, gfe.data_length);
        }
    }
    printf("\n");

    fseek(fsniff, -(sizeof(gff)), SEEK_END);
    fread(&gff, sizeof(gff), 1, fsniff);
    if (memcmp(&gff.git_string, "GIT", 3) != 0 || gff.version != 0x0f || gff.type != 0x0f) {
        fprintf(stderr, "Warning: git_sniffer still running or git_sniffer process was killed\n");
        exit(1);
    }
    tp = localtime((time_t*)&gff.epoch_seconds);
    printf("STOP TIME: %02d.%02d.%04d %02d:%02d:%02d\n",tp->tm_mday,tp->tm_mon,tp->tm_year,tp->tm_hour,tp->tm_min,tp->tm_sec);
    return(0);
}
