#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <signal.h>
#include <ctype.h>
#include <time.h>
#include <sys/types.h>
#include <sys/time.h>
#include <pcap.h>
#include <libnet.h>
#include "git.h"

#define PROGRAM				"git_sniff"
#define GIT_CAPTURE_STRING		"(tcp or udp)"

int  foreground = 0;
static pcap_t *pcap_link = NULL;
struct libnet_ip_hdr *ip_hdr = NULL;
struct libnet_tcp_hdr *tcp_hdr = NULL;
struct libnet_udp_hdr *udp_hdr = NULL;
FILE *fsniff = NULL;
FILE *flookup = NULL;
struct timeval tp;
struct timezone tz;
char key[GIT_LOOKUP_KEYLENGTH + 1];
unsigned long int count = 0;
unsigned long int random_int;
struct GIT_FILE_LOOKUP gfl;
struct GIT_FILE_HEADER gfh;
struct GIT_FILE_ENTRY  gfe;
struct GIT_FILE_FOOTER gff;
struct GIT_FILE_LOOKUP **table = NULL;
struct GIT_FILE_LOOKUP *table_found = NULL;
unsigned long int table_count = 0;
int i, j;
int verbose = 0;
struct tm *timeptr;

void help() {
    printf("%s %s (c) 2002 by %s <%s>\n\n", PROGRAM, VERSION, AUTHOR, EMAIL);
    printf("Syntax: %s [-I IP] [-m] [-p file] [-P pass] [-v] interface your-email\n\n", prg);
    printf("Options:
  -I IP        IP address to write into sniff file
  -m           do also log data with your own IP address
  -p file      the file to read the password to encrypt the lookup file with
  -P pass      the password to encrypt the lookup file with
  -v           verbose mode (dump hash, packet length and time of packets)
  interface    the network interface to sniff on
  your-email   your email address, so people can contact you for lookups
If neither -p or -P is used, the program asks for a password.

The output is written into two data files:
  sniff_YEAR-MONTH-DAY-HOUR-MINUTE-SECOND.git
  lookup_YEAR-MONTH-DAY-HOUR-MINUTE-SECOND.git
The sniff_... file contains the anonymized information, the lookup_.. file is
encrypted and contains the anonymized hash and the real IP data.\n\n");
    printf("You can find updates of GIT at %s\n", WEB);
    printf("READ THE LICENCE - THIS IS NOT GPL!\n");
    exit(0);
}

void cleanup(int signo) {
    git_kill_string(key);
    git_wipe_key();
    gettimeofday(&tp, &tz);
    if (pcap_link != NULL)
        (void) pcap_close(pcap_link);
    if (fsniff != NULL) {
        gff.git_string[0] = 'G';
        gff.git_string[1] = 'I';
        gff.git_string[2] = 'T';
        gff.version = 0x0f;
        gff.type    = 0x0f;
        gff.epoch_seconds = tp.tv_sec;
        gff.milliseconds  = tp.tv_usec;
        fwrite(&gff, sizeof(gff), 1, fsniff);
        fclose(fsniff);
    }
    if (flookup != NULL)
        fclose(flookup);
    printf("\n%s(%d): end requested.\n", PROGRAM, getpid());
    exit(0);
}

void sniff(u_char *foo, const struct pcap_pkthdr *header, const u_char *data) {
    ip_hdr = (struct libnet_ip_hdr *)(data + sizeof(struct libnet_ethernet_hdr));

    // we currently support only IPv4
    if (ip_hdr->ip_v != 4)
        return;

    gfe.epoch_seconds = header->ts.tv_sec;
    gfe.milliseconds  = header->ts.tv_usec;

    memcpy(&gfl.host_ns_src, &ip_hdr->ip_src.s_addr, 4);
    memcpy(&gfl.host_ns_dst, &ip_hdr->ip_dst.s_addr, 4);

    if ((gfl.proto = ip_hdr->ip_p) == 6) { // TCP Packet
        tcp_hdr = (struct libnet_tcp_hdr *) ((char*)ip_hdr + (ip_hdr->ip_hl * 4));
        memcpy(&gfl.port_ns_src, &tcp_hdr->th_sport, 2);
        memcpy(&gfl.port_ns_dst, &tcp_hdr->th_dport, 2);
        gfe.data_length = ntohs(ip_hdr->ip_len) - (ip_hdr->ip_hl * 4) - (tcp_hdr->th_off * 4);
    } else { // UDP Packet
        udp_hdr = (struct libnet_udp_hdr *) ((char*)ip_hdr + (ip_hdr->ip_hl * 4));
        memcpy(&gfl.port_ns_src, &udp_hdr->uh_sport, 2);
        memcpy(&gfl.port_ns_dst, &udp_hdr->uh_dport, 2);
        gfe.data_length = ntohs(udp_hdr->uh_ulen) - sizeof(struct libnet_udp_hdr);
    }

/*
 * For the future: this needs a tree for faster searching
 */

    // look into the table if we have already a hash
    table_found = NULL;
    i = 0;
    if (table_count > 0)
        do {
            if (memcmp(&table[i]->host_ns_src, &gfl.host_ns_src, sizeof(struct GIT_FILE_LOOKUP) - sizeof(gfl.anonymous) - sizeof(gfl.random)) == 0)
                table_found = table[i];
            i++;
        } while (table_found == NULL && i < table_count);

/*
 * For the future: remove items from the table after 60 minutes without packets
 */

    // not found in table, create new table entry
    if (table_found == NULL) { // nicht in table:
        // oops our table is full, dump the oldest 2/3 and rebuild
        if (table_count + 1 == GIT_LOOKUP_MAX_TABLE_ITEMS) {
            struct GIT_FILE_LOOKUP **new_table;
            int k = GIT_LOOKUP_MAX_TABLE_ITEMS / 3;
            i = table_count - k;
            new_table = malloc(GIT_LOOKUP_MAX_TABLE_ITEMS * sizeof(table[0]));
            for (j = i; j < table_count; j++) {
                new_table[j-i] = malloc(sizeof(struct GIT_FILE_LOOKUP));
                memcpy(new_table[j-i], table[j], sizeof(struct GIT_FILE_LOOKUP));
                free(table[j]);
            }
            free(table);
            table = new_table;
            table_count = k;
        }
        table[table_count] = malloc(sizeof(struct GIT_FILE_LOOKUP));
        random_int = libnet_get_prand(PRu32);
        memcpy(&gfl.random, &random_int + 1, 3);
        git_md5hash((char*)&gfl.anonymous, (char*)&gfl.host_ns_src, sizeof(gfl) - sizeof(gfl.anonymous));
        memcpy(table[table_count], &gfl, sizeof(struct GIT_FILE_LOOKUP));
        table_found = table[table_count];
        git_encrypt((char *)&gfl, sizeof(gfl));
        fwrite(&gfl, sizeof(gfl), 1, flookup);
        table_count++;
        table[table_count] = NULL;
    }

    memcpy(&gfe.anonymous, table_found->anonymous, sizeof(gfl.anonymous));

    if (verbose) {
        timeptr = localtime((time_t*)&gfe.epoch_seconds);
        printf("\nHASH: ");
        for (i = 0; i < 16; i++)
            printf("%02x", gfe.anonymous[i]);
        printf("\nLEN : %d\nTIME: %02d.%02d.%04d %02d:%02d:%02d.%06ld\n", gfe.data_length,
        timeptr->tm_mday,timeptr->tm_mon,timeptr->tm_year,timeptr->tm_hour,timeptr->tm_min,timeptr->tm_sec,gfe.milliseconds);
    }

    fwrite(&gfe, sizeof(gfe), 1, fsniff);
    memset(&gfe, 0, sizeof(gfe));
    memset(&gfl, 0, sizeof(gfl));
    count++;
    if (verbose == 0 && foreground && count % 100 == 1)
        printf(".");
}

int main(int argc, char *argv[]) {
    char *keyfile = NULL;
    char *interface;
    char *email;
    int  save_own_ip = 0;
    unsigned long int my_ip = 0;
    struct in_addr ip;
    char capture[256] = GIT_CAPTURE_STRING;
    char errbuf[PCAP_ERRBUF_SIZE];
    struct bpf_program fcode;
    char filename[32], out[16];
    int found = 0;
    int len;

    git_secure_process();

    prg = argv[0];
    memset(key, 0, sizeof(key) + 1);
    memset(&gfh, 0, sizeof(gfh));
    memset(&gfe, 0, sizeof(gfe));
    memset(&gff, 0, sizeof(gff));
    memset(&gfl, 0, sizeof(gfl));
    setvbuf(stdout, NULL, _IONBF, 0);
    
    if (argc < 3 || strncmp(argv[1], "-h", 2) == 0 || strncmp(argv[1], "--h", 3) == 0)
        help();
    
    while ((i = getopt(argc, argv, "fI:mp:P:v")) != EOF) {
        switch(i) {
            case 'f': foreground = 1; break;
            case 'I': if (inet_pton(AF_INET,optarg, &ip) <= 0) {
                          fprintf(stderr, "Error: not a valid IP address - %s\n", optarg);
                          exit(-1);
                      }
                      memcpy(&my_ip, &ip.s_addr, 4);
                      break;
            case 'm': save_own_ip = 1; break;
            case 'p': keyfile = optarg;
                      argv[optind - 2] = nul;
                      argv[optind - 1] = nul;
                      break;
            case 'P': strncpy(key, optarg, GIT_LOOKUP_KEYLENGTH);
                      git_kill_string(argv[optind - 2]);
                      argv[optind - 2] = nul;
                      git_kill_string(argv[optind - 1]);
                      argv[optind - 1] = nul;
                      break;
            case 'v': verbose = 1; break;
            default : help();
        }
    }

    if (keyfile != NULL && key[0] != 0) {
        fprintf(stderr, "Error: You may not use the options -p and -P together\n");
        exit(-1);
    }

    if (optind + 2 != argc) {
        fprintf(stderr, "Error: missing or too much commandline options\n");
        exit(-1);
    }
    
    interface = argv[argc-2];
    email = argv[argc-1];
    
    if (strlen(email) > 31) {
        fprintf(stderr, "Error: email too long, maximum length is 32\n");
        exit(-1);
    }
    
    // get key
    if (keyfile == NULL) {
        if (key[0] == 0) {
            printf("Please enter a strong password: ");
            // set echo off
            system("stty -echo");
            (void) fgets(key, GIT_LOOKUP_KEYLENGTH + 1, stdin);
            // set echo on
            system("stty echo");
            printf("thank you.\n");
            if (key[strlen(key) - 1] == '\n')
                key[strlen(key) - 1] = 0;
            if (key[strlen(key) - 1] == '\r')
                key[strlen(key) - 1] = 0;
        }
        found = strlen(key);
    } else {
        FILE *f;
        if ((f = fopen(keyfile, "r")) == NULL) {
            fprintf(stderr, "Error: keyfile not found - %s\n", keyfile);
            exit(-1);
        }
        git_kill_string(keyfile);
        keyfile = nul;
        len = fread(key, GIT_LOOKUP_KEYLENGTH, 1, f);
        fclose(f);
        for (len = 1; len <= GIT_LOOKUP_KEYLENGTH; len++) {
            if (found)
                key[len] = 0;
            else
                if (key[len] == '\n' || key[len] == '\r') {
                    key[len] = 0;
                    found = len;
                }
        }
        if (found == 0)
            found = GIT_LOOKUP_KEYLENGTH;
    }

    // calculate key strength
    i = 0;
    for (j = 0; j < found; j++)
        if (isalnum(key[j]) == 0)
            i++;
    if (i > 0)
        i = 1;
    if (strpbrk(key, "ABCDEFGHIJKLMNOPQRSTUVWXYZ") != NULL)
        i++;
    if (strpbrk(key, "abcdefghijklmnopqrstuvwxyz") != NULL)
        i++;
    if (strpbrk(key, "0123456789") != NULL)
        i++;
    if (found < 8 || i < 3) {
        fprintf(stderr, "Error: key is too weak, the minimum length is 8 with 3 different charsets.\n");
        exit(-1);
    }

    if (my_ip == 0)
        if ((my_ip = htonl(libnet_get_ipaddr(NULL, interface, errbuf))) == 0) {
            fprintf(stderr, "Error: could not determine IP address on interface %s - define an existing interface, set it an IP address or use the -I option\n", interface);
            exit(-1);
        }

    if (save_own_ip == 0) {
        memcpy(&ip.s_addr, &my_ip, 4);
        snprintf(capture, sizeof(capture), "%s and not host %s",
          GIT_CAPTURE_STRING, inet_ntop(AF_INET,&ip,(char*)&out,sizeof(out)));
    }

    umask(077);

    for (i = 1; i < 32; i++)
        signal(i, cleanup);

    gettimeofday(&tp, &tz);
    timeptr = localtime((time_t*)&tp.tv_sec);
    snprintf(filename, sizeof(filename), "sniff_%04d-%02d-%02d-%02d-%02d-%02d.git",
      timeptr->tm_year, timeptr->tm_mon, timeptr->tm_mday, timeptr->tm_hour, timeptr->tm_min, timeptr->tm_sec);
    printf("Writing anonymized sniffing data to %s ...\n", filename);
    if ((fsniff = fopen(filename, "w")) == NULL) {
        fprintf(stderr, "Error: could not create sniff output file %s\n", filename);
        exit(-1);
    }
    gfh.git_string[0] = 'G';
    gfh.git_string[1] = 'I';
    gfh.git_string[2] = 'T';
    gfh.version = GIT_VERSION;
    gfh.type    = 0; // not sorted, no packet header, no packet data
    gfh.epoch_seconds = tp.tv_sec;
    gfh.milliseconds  = tp.tv_usec;
    memcpy(&gfh.host_ns, &my_ip, 4);
    memcpy(&gfh.email, email, strlen(email));
    fwrite(&gfh, sizeof(gfh), 1, fsniff);
    snprintf(filename, sizeof(filename), "lookup_%04d-%02d-%02d-%02d-%02d-%02d.git",
      timeptr->tm_year, timeptr->tm_mon, timeptr->tm_mday, timeptr->tm_hour, timeptr->tm_min, timeptr->tm_sec);
    printf("Writing encrypted lookup data to %s ...\n", filename);
    if ((flookup = fopen(filename, "w")) == NULL) {
        fprintf(stderr, "Error: could not create sniff output file %s\n", filename);
        exit(-1);
    }

    table = malloc(GIT_LOOKUP_MAX_TABLE_ITEMS * sizeof(table[0]));
    printf("Capturing [%s] on interface %s ...\n", capture, interface);

    if (foreground)
        printf("Press Control-C to exit.\n");
    else {
        if (fork() > 0) {
            sleep(1);
            exit(0);
        }
        printf("Type \"kill %d\" to terminate %s.\n", getpid(), PROGRAM);
    }
    
    (void)libnet_seed_prand();
    git_set_key(key);
    git_kill_string(key);

    if ((pcap_link = pcap_open_live(interface, 112, 1, 10, errbuf)) == NULL) {
        fprintf(stderr,"Error: %s - %s\n", errbuf, interface);
        exit(-1);
    }
    if (pcap_compile(pcap_link, &fcode, capture, 1, 0) < 0) {
        fprintf(stderr,"Error: %s\n", errbuf);
        exit(-1);
    }
    if (pcap_loop(pcap_link, -1, sniff, 0) < 0) {
        fprintf(stderr,"Error: %s\n", errbuf);
        exit(-1);
    }
    fprintf(stderr, "Error: libpcap exited.\n");
    return(-1);
}
