#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <string.h>
#include <time.h>
#include "git.h"

#define PROGRAM				"git_sort"
#define BUFSIZE				65536

void help() {
    printf("%s %s (c) 2002 by %s <%s>\n\n", PROGRAM, VERSION, AUTHOR, EMAIL);
    printf("Syntax: %s FILE\n\n", prg);
    printf("Options:
  FILE    the sniff_...git file to sort (will be replaced)\n\n");
    printf("Sorts git_sniffer anonymized sniffer output for use with git_search.\n\n");
    printf("You can find updates of GIT at %s\n", WEB);
    printf("READ THE LICENCE - THIS IT NOT GPL!\n");
    exit(0);
}

int main(int argc, char *argv[]) {
    FILE *fin, *fout;
    struct GIT_FILE_ENTRY gfe;
    struct GIT_FILE_HEADER gfh;
    struct GIT_FILE_FOOTER gff;
    int fd;
    int items;
    char fn[64] = "/tmp/.git_sort.XXXXXX";
    char *ptr;
    int counter = 0;
    unsigned long position;
    char **table;
    int table_count = 0;
    int found = 1;
    int i, j;
    long int old_epoch, old_msec;

    prg = argv[0];
    
    if (argc != 2 || strncmp("-h", argv[1], 2) == 0 || strncmp("--h", argv[1], 3) == 0)
        help();

    if ((fin = fopen(argv[1],"r")) == NULL) {
        fprintf(stderr, "Error: file not found - %s (use \"-h\" for help)\n", argv[1]);
        exit(-1);
    }
    
    umask(077);

    fread(&gfh, sizeof(gfh), 1, fin);
    if (memcmp(&gfh.git_string, "GIT", 3) != 0) {
        fprintf(stderr, "Error: not a GIT sniff file - %s\n", argv[1]);
        exit(-1);
    } 
    printf("FILE: %s\nVERSION: %d\n",argv[1],gfh.version);
    if (gfh.type & GIT_FILE_TYPE_SORTED) {
        fprintf(stderr, "Error: GIT file %s is already sorted\n", argv[1]);
        exit(-1);
    }
    if (gfh.type & GIT_FILE_TYPE_WITH_PACKET_DATA ||
        gfh.type & GIT_FILE_TYPE_WITH_PACKET_HEADER ||
        gfh.type & GIT_FILE_TYPE_UNUSED ||
        gfh.version != GIT_VERSION) {
        fprintf(stderr, "Error: GIT type/version is not supported\n");
        exit(-1);
    }

    gfh.type += GIT_FILE_TYPE_SORTED;
    printf("\n");

    if ((fd = mkstemp(fn)) < 0) {
        fprintf(stderr, "Error: unable to create temporay file %s\n", fn);
        exit(-1);
    }
    if ((fout = fdopen(fd, "w+")) == NULL) {
        fprintf(stderr, "Error: fdopen failed\n");
        exit(-1);
    }

    setvbuf(stdout, NULL, _IONBF, 0);
    fwrite(&gfh, sizeof(gfh), 1, fout);

    printf("Sorting into temporary file %s ", fn);

    table = malloc(GIT_LOOKUP_MAX_TABLE_ITEMS * sizeof(table[0]));
    position = ftell(fin);

    while(found) {
        table[table_count] = malloc(sizeof(gfe.anonymous));
        found = 0;
        while (! feof(fin) && found == 0) {

            if (fread(&gfe, sizeof(gfe), 1, fin) == 1) {
                counter++;
                old_epoch = old_msec = 0;

                // first: find an item not yet in our table (new)
                if (table_count > 0) {
                    i = j = 0;
                    do {
                        if (memcmp(gfe.anonymous, table[i], sizeof(gfe.anonymous)) == 0)
                            j = 1;
                        i++;
                    } while (i < table_count && j == 0);
                    if (j == 0) {
                        found = 1;
                        old_msec  = gfe.milliseconds;
                        old_epoch = gfe.epoch_seconds;
                    }
                } else {
                    found = 1;
                    old_msec  = gfe.milliseconds;
                    old_epoch = gfe.epoch_seconds;
                }

                if (found == 1) {
                    // oops our table is full, dump the oldest 1/2 and rebuild
                    if (table_count + 1 == GIT_LOOKUP_MAX_TABLE_ITEMS) {
                        char **new_table;
                        int k = GIT_LOOKUP_MAX_TABLE_ITEMS / 2;
                        i = table_count - k;
                        new_table = malloc(GIT_LOOKUP_MAX_TABLE_ITEMS * sizeof(table[0]));
                        for (j = i; j < table_count; j++) {
                            new_table[j-i] = malloc(sizeof(gfe.anonymous));
                            memcpy(new_table[j-i], table[j], sizeof(gfe.anonymous));
                            free(table[j]);
                        }
                        free(table);
                        table = new_table;
                        table_count = k;
                    }
                    memcpy(table[table_count], gfe.anonymous, sizeof(gfe.anonymous));
                    fwrite(&gfe, sizeof(gfe), 1, fout);
                    printf(".");
                    while (! feof(fin)) {
                        if (fread(&gfe, sizeof(gfe), 1, fin) == 1) {
                            if (memcmp(gfe.anonymous, table[table_count], sizeof(gfe.anonymous)) == 0) {
                                if ((old_epoch == 0 && old_msec == 0) ||
                                    (gfe.epoch_seconds < old_epoch) ||
                                    (gfe.epoch_seconds == old_epoch && gfe.milliseconds < old_msec))
                                    {
                                    gfe.diff_epoch_seconds = 0;
                                    gfe.diff_milliseconds = 0;
                                } else {
                                    gfe.diff_epoch_seconds = gfe.epoch_seconds - old_epoch;
                                    if (gfe.milliseconds < old_msec) {
                                        gfe.diff_epoch_seconds--;
                                        gfe.diff_milliseconds = (MAX_MSEC_VALUE + gfe.milliseconds) - old_msec;
                                    } else {
                                        gfe.diff_milliseconds = gfe.milliseconds - old_msec;
                                    }
                                }
                                fwrite(&gfe, sizeof(gfe), 1, fout);
                                old_msec  = gfe.milliseconds;
                                old_epoch = gfe.epoch_seconds;
                            }
                        }
                    }
                }
            }
        }
        fseek(fin, position + (counter * sizeof(gfe)), SEEK_SET);
        table_count++;
    }

    printf(" done\n\n");

    fseek(fin, -(sizeof(gff)), SEEK_END);
    fread(&gff, sizeof(gff), 1, fin);
    if (memcmp(&gff.git_string, "GIT", 3) != 0 || gff.version != 0x0f || gff.type != 0x0f) {
        fprintf(stderr, "Warning: GIT file ending not found - git_sniffer still running or git_sniffer process was killed\n");
    } else {
        fwrite(&gff, sizeof(gff), 1, fout);
    }

    fclose(fin);

    if ((fin = fopen(argv[1], "w+")) == NULL) {
        fprintf(stderr, "Error: can not truncate %s\n", argv[0]);
        exit(-1);
    }
    rewind(fout);
    ptr = malloc(BUFSIZE);
    do {
        items = fread(ptr, 1, BUFSIZE, fout);
        fwrite(ptr, 1, items, fin);
    } while (items == BUFSIZE);
    
    fclose(fin);
    fclose(fout);
    unlink(fn);
    
    printf("Temporary file removed, file %s is now sorted\n", argv[1]);

    return(0);
}
