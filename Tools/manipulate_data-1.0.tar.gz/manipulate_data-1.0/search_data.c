/*
 * search_data v1.0   (c) 1998 by van Hauser / THC <vh@reptile.rug.ac.be>
 * http://r3wt.base.org
 *
 * searchs for data on a blockdevice
 */
#include <stdio.h>
#include <sys/stat.h>
#include <unistd.h>
#include <stdlib.h>

#define NEEDLE_SIZE 1024
#define BUFSIZE 65536

char needle[NEEDLE_SIZE];
unsigned long add_count = 0, count = 0;
unsigned int son;
char *prog;

void help() {
    printf("Syntax: %s [-i] blockdevice searchstring\n", prog);
    printf("[-i] ignore case\n");
    exit(1);
}                        

void clean_string (char *buf) {
    unsigned int i = son;
    char *c_ptr = buf + son - 1;
    do {    
        c_ptr++; i++;
        if ( (*c_ptr < 32) || (*c_ptr > 126) || (i > 60) ) {
            *c_ptr = '\0';
        }
    } while (*c_ptr != '\0');
}

void search (char *buf, unsigned long bufsize) {
    char tmpbuf[70];
    unsigned int i = 0;
    char *c_ptr = buf;
    while (bufsize >= (son + i)) {
        if (strncmp(c_ptr, needle, son) == 0) {
	    strncpy(tmpbuf, c_ptr, sizeof(tmpbuf) - 1);
	    clean_string(tmpbuf);
	    printf("found at %lu: %s\n", (unsigned long) (count + add_count + i), tmpbuf);
        }
        c_ptr++; i++;
    }
}

int main (int argc, char *argv[]) {
    char dev[100];
    FILE *f;
    struct stat st;
    unsigned long loop = 0, read_error = 0, reat;
    unsigned int jump_size, ignore = 0, i = 1;
    char buf[BUFSIZE];
    char tmpbuf[(NEEDLE_SIZE - 1)*2];
    
    prog = argv[0];
    if ((argc < 3) || (argc >4)) {
	help(1);
    }
    if (argc == 4) {
	if (strncmp(argv[i++], "-i", 2) != 0) {
	    help();
	}
	ignore++;
    }
    strncpy(dev, argv[i++], sizeof(dev) - 1);
    strncpy(needle, argv[i++], sizeof(needle) - 1);
    if (lstat(dev, &st) != 0) {
        perror("Can't access blockdevice");
        exit(1);
    }
    if ((st.st_mode & S_IFBLK) != S_IFBLK) {
        printf("Warning: %s is not a block device\n", dev);
    }
    if ((f = fopen(dev, "r")) == NULL) {
        perror("Can't open blockdevice for reading");
	exit(1);
    }

    jump_size = strlen(needle) - 1;
    son = strlen(needle);
    if (ignore) {
        for (i=0; i<son; i++) {
             needle[i] = tolower(needle[i]);
        }
    }
    do {
        loop++;
        reat = fread(&buf, 1, BUFSIZE, f);
        if (reat != BUFSIZE) {
            read_error++;
	    if (reat <= strlen (needle) -1) {
                jump_size = (unsigned int) (reat % BUFSIZE);
            }
        }
        if (ignore) {
            for (i=0; i<reat; i++) {
                buf[i] = tolower(buf[i]);
            }
        }
        if (loop > 1) {
            add_count = (unsigned long) (buf + BUFSIZE - son + 1);
            memcpy(tmpbuf + son - 1, buf, jump_size);
	    search(tmpbuf, son - 1 + jump_size);
            count = count + reat;
            add_count = 0;
        }
	search(buf, reat);
	memcpy(tmpbuf, buf + BUFSIZE - son, son - 1);
    } while ((feof(f) == 0) && (read_error == 0));
    fclose(f);
    exit(0);
}
