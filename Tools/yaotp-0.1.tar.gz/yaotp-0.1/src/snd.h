/*
 * Yaotp (Yet Another One-Time Pad) 
 * ---
 * (c) 2004 Plasmoid <plasmoid@thc.org>, The Hacker's Choice
 * $Id: snd.h,v 1.12 2004/08/05 13:29:37 plasmoid Exp $  
 * ---
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of
 * the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU General Public 
 * License along with this program; if not, write to the Free 
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston, 
 * MA 02111-1307, USA.
 */

#ifndef _SND_H
#define _SND_H

#define SND_RATE 		44000	/* Sampling rate 44000 hz */
#define SND_SIZE 		16	/* Sample size: 16 bit */
#define SND_CHAN 	        1	/* Channels: 1 = mono  */
#define SND_BLOCK               4096	/* Size of sound block */

int open_snd_dev(char *dev);
int read_snd(int fd, buf_t * b, size_t len);
void test_snd(char *snd_dev, size_t size);
unsigned long size_to_secs(size_t bytes);

#endif				/* _SND_H */
