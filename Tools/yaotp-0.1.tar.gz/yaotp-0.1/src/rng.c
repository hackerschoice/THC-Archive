/*
 * Yaotp (Yet Another One-Time Pad) 
 * ---
 * (c) 2004 Plasmoid <plasmoid@thc.org>, The Hacker's Choice
 * $Id: rng.c,v 1.13 2004/08/12 09:35:29 plasmoid Exp $  
 * ---
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of
 * the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU General Public 
 * License along with this program; if not, write to the Free 
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston, 
 * MA 02111-1307, USA.
 */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>

#include <openssl/md5.h>
#include <openssl/sha.h>
#include <openssl/ripemd.h>

#include "misc.h"
#include "buf.h"
#include "rng.h"

/*
 * Divide buffer in slices and overlay those by XOR'ing bits. For every
 * second slice the order of the bits is reversed, so that low and high
 * bits swap.
 */
int overlay_buf(buf_t * b, int num)
{
   size_t len, j;
   int i;

   if(num == 0)
      return 1;
   
   info_msg(3, "overlay_buf(%p, %d)", b, num);

   if (num % 2 != 0) {
      err_msg("overlay_bytes: Number needs to be even");
      return 0;
   }

   /* Calculate overlay length */
   len = b->len / num;

   /* Overlay buffer content num times by XOR'ing bits. */
   for (i = 1; i < num; i++) {
      for (j = 0; j < len; j++) {
	 if (i % 2 == 0)
	    b->buf[j] ^= b->buf[i * j];
	 else
	    b->buf[j] ^= reverse(b->buf[i * j]);
      }
   }

   /* Set new buffer length */
   b->len = len;

   return 1;
}

/*
 * "Digest" or better hash buffer. The buffer is devided into slice 
 * according to the provided ratio and each slice is hashed into a 
 * new buffer. A buffer of length n, thus is condensed to n / ratio 
 * bytes.
 */
int hash_buf(buf_t * b, int ratio, hash_t alg)
{
   unsigned char *(*hash_func) ();
   int hash_len;
   size_t i;

   info_msg(3, "hash_buf(%p, %d, %d)", b, ratio, alg);

   /* Set hash function and length */
   switch (alg) {
   case HASH_SHA:
      hash_func = SHA1;
      hash_len = SHA_DIGEST_LENGTH;
      break;
   case HASH_MD5:
      hash_func = MD5;
      hash_len = MD5_DIGEST_LENGTH;
      break;
   case HASH_RIPEMD:
      hash_func = RIPEMD160;
      hash_len = RIPEMD160_DIGEST_LENGTH;
      break;
   default:
      err_msg("hash_buf: Unknown algorithm (%d)", alg);
      return 0;
   }

   /* 
    * Ratio determines how many data bits correspond to one hash bit. 
    */
   for (i = 0; i < b->len / ratio; i += hash_len)
      hash_func(b->buf + (i * ratio), hash_len * ratio, b->buf + i);

   /* Set new buffer length */
   b->len = i;

   return 1;
}

/*
 * Check the randomness of the buffer. In fact measuring randomness is far
 * beyond the scope of this function (consult the DIEHARD tool suite), 
 * instead it calculates the byte mean, deviation and entropy of the buffer
 * content.
 */
int check_randomness(buf_t * b, int warn)
{
   double m, d, e, s[256];
   size_t i;

   /* Calculate byte entropy */
   memset(s, 0, sizeof(double) * 256);
   for (i = 0; i < b->len; i++)
      s[b->buf[i]]++;

   e = 0;
   for (i = 0; i < 256; i++) {
      s[i] = s[i] / b->len;
      e += s[i] * (log10(1 / s[i]) * log2of10);
   }

   /* Calculate byte mean */
   m = 0;
   for (i = 0; i < b->len; i++)
      m += b->buf[i];
   m = m / b->len;

   /* Calculate byte deviation */
   d = 0;
   for (i = 0; i < b->len; i++)
      d += fabs(m - b->buf[i]);
   d = d / b->len;

   info_msg(2, "Buffer mean: %8.4f, deviation: %7.4f, entropy: %7.6f",
	    m, d, e);

   if (fabs(127.5 - m) > MEAN_TOLERANCE) {
      if (warn)
	 warn_msg("Not enough randomness in buffer (mean: %8.4f). "
		  "Skipping", m);
      return 0;
   }
   if (fabs(64 - d) > DEVI_TOLERANCE) {
      if (warn)
	 warn_msg("Not enough randomness in buffer (deviation: %7.4f). "
		  "Skipping", m);
      return 0;
   }
   if (fabs(8 - e) > ENTR_TOLERANCE) {
      if (warn)
	 warn_msg("Not enough randomness in buffer (entropy: %7.6f). "
		  "Skipping", e);
      return 0;
   }

   return 1;
}
