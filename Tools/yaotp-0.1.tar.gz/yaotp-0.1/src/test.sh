#!/bin/sh

# Init secure file names
MSG_N=`mktemp /tmp/msg_n.XXXXXX` || exit 1
MSG_O=`mktemp /tmp/msg_o.XXXXXX` || exit 1
CRYPT=`mktemp /tmp/crypt.XXXXXX` || exit 1
KEY_A=`mktemp /tmp/key_a.XXXXXX` || exit 1
KEY_B=`mktemp /tmp/key_b.XXXXXX` || exit 1

# Prepare two keys
echo "--- Preparing test keys (A,B) and test message"
cp test.key $KEY_A
cp test.key $KEY_B
./yaotp -k $KEY_A -p 

# Generate a random message
dd if=/dev/urandom of=$MSG_O count=10 
MD5_O=`md5sum $MSG_O | awk '{print $1}'`

# Encrypt message
echo "--- Encrypting test message"
cat $MSG_O | ./yaotp -e -vv -k $KEY_A > $CRYPT || exit 1

# Decrypt message
echo "--- Decrypting test message"
cat $CRYPT | ./yaotp -d -vv -k $KEY_B > $MSG_N || exit 1

# Verify new message
echo "--- Verifying test message"
MD5_N=`md5sum $MSG_N | awk '{print $1}'`
echo "Original message:  $MD5_O"
echo "Decrypted message: $MD5_N"
test $MD5_O == $MD5_N || exit 1

# Clean up
echo "--- Cleaning up"
rm -f $MSG_N $MSG_O $KEY_A $KEY_B $CRYPT
