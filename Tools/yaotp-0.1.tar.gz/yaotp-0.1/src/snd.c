/*
 * Yaotp (Yet Another One-Time Pad) 
 * ---
 * (c) 2004 Plasmoid <plasmoid@thc.org>, The Hacker's Choice
 * $Id: snd.c,v 1.22 2004/08/12 09:35:29 plasmoid Exp $  
 * ---
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of
 * the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU General Public 
 * License along with this program; if not, write to the Free 
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston, 
 * MA 02111-1307, USA.
 */

#include <sys/types.h>
#include <sys/ioctl.h>
#include <linux/soundcard.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <assert.h>

#include "misc.h"
#include "buf.h"
#include "otp.h"
#include "rng.h"
#include "snd.h"

extern int verbose;

/*
 * Open and configure the sound device. This function is very Linux 
 * specific; unfortunately. 
 */
int open_snd_dev(char *dev)
{
   int arg, r, fd;

   info_msg(3, "open_snd_dev(%s)", dev);

   /* Open sound device */
   fd = open(dev, O_RDONLY);
   if (fd == -1) {
      err_msg("open_snd_dev: Could not open device %s", dev);
      return -1;
   }

   info_msg(1, "Configuring sound, size %dbit, channel %d, rate %dHz",
	    SND_SIZE, SND_CHAN, SND_RATE);

   /* Set sound parameters */
   arg = SND_SIZE;		/* Sample size */
   r = ioctl(fd, SOUND_PCM_WRITE_BITS, &arg);
   arg = SND_CHAN;		/* Mono or stereo */
   r += ioctl(fd, SOUND_PCM_WRITE_CHANNELS, &arg);
   arg = SND_RATE;		/* Sampling rate */
   r += ioctl(fd, SOUND_PCM_WRITE_RATE, &arg);
   if (r != 0) {
      err_msg("open_snd_dev: Could not initialize device %s", dev);
      return -1;
   }

   return fd;
}

/*
 * Fill buffer with lower 8 bits from audio data
 */
int read_snd(int fd, buf_t * b, size_t len)
{
   unsigned char block[SND_BLOCK * 2];
   size_t i, j;
   ssize_t r;

   info_msg(3, "read_snd(%d, %p, %lu)", fd, b, len);

   if (len > b->maxlen)
      if (!resize_buf(b, len, 1)) {
	 err_msg("read_snd: Could not resize buffer to %lu bytes", len);
	 return 0;
      }

   b->len = 0;

   while (b->len < len) {
      r = read(fd, block, SND_BLOCK * 2);
      if (r == -1) {
	 err_msg("read_snd: Failed to read block");
	 return 0;
      }

      if (b->len + SND_BLOCK < len)
	 j = SND_BLOCK;
      else
	 j = len - b->len;

      for (i = 0; i < j; i++)
	 b->buf[i + b->len] = block[2 * i];

      b->len += j;
   }

   assert(b->len == len);
   return 1;
}

/*
 * Convert the given amount of bytes into the number of seconds
 * sampling requires (according to the current configuration)
 */
unsigned long size_to_secs(size_t bytes)
{
   unsigned long secs;
   secs = bytes / (SND_RATE * SND_CHAN);
   return secs;
}

/*
 * Sample and test audio data. 
 */
void test_snd(char *snd_dev, size_t size)
{
   int snd, ok = 1;
   buf_t *b;
   size_t i, j;

   snd = open_snd_dev(snd_dev);
   if (snd == -1) {
      err_msg("Could not open sound device %s", snd_dev);
      exit(EXIT_FAILURE);
   }

   if (!create_buf(&b, BUF_SIZE)) {
      err_msg("Could not create temporary buffer");
      exit(EXIT_FAILURE);
   }

   info_msg(0, "Adjust volume of sound device to minimize bad buffers.");

   for (i = 0, j = 0; ok && i < size; i += b->len, j++) {
      ok &= read_snd(snd, b, BUF_SIZE);

      if (!check_randomness(b, 1))
	 i -= b->len;

      progress_bar(i, size, size_to_secs(size - i));
   }

   progress_bar(i, size, 0);
   printf("\n");

   free_buf(b, 0);
   close(snd);

   if (!ok) {
      err_msg("Failed to test sound device %s. Aborting", snd_dev);
      exit(EXIT_FAILURE);
   }

   info_msg(0, "Sound test successful. Have fun.\n");
}
