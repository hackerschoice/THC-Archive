/*
 * Yaotp (Yet Another One-Time Pad) 
 * ---
 * (c) 2004 Plasmoid <plasmoid@thc.org>, The Hacker's Choice
 * $Id: yaotp.h,v 1.12 2004/08/10 13:52:05 plasmoid Exp $  
 * ---
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of
 * the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU General Public 
 * License along with this program; if not, write to the Free 
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston, 
 * MA 02111-1307, USA.
 */

#ifndef _YAOTP_H
#define _YAOTP_H

#define NUM_OL                  4
#define HASH_RATIO                2
#define HASH_ALG                  HASH_MD5

#define KEY_FILE                "yaotp.key"
#define KEY_SIZE                16 * 1024 * 1024

#define SND_DEV		        "/dev/dsp"

typedef enum {
   CMD_NONE, CMD_GEN_KEY, CMD_ENCRYPT, CMD_DECRYPT, CMD_TEST_SND,
   CMD_PRINT_KEY
} chash_t;

#endif				/* _YAOTP_H */
