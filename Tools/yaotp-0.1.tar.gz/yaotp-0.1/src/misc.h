/*
 * Yaotp (Yet Another One-Time Pad) 
 * ---
 * (c) 2004 Plasmoid <plasmoid@thc.org>, The Hacker's Choice
 * $Id: misc.h,v 1.13 2004/08/05 13:29:37 plasmoid Exp $  
 * ---
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of
 * the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU General Public 
 * License along with this program; if not, write to the Free 
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston, 
 * MA 02111-1307, USA.
 */

#ifndef _MISC_H
#define _MISC_H

#define BUF_SIZE        (32768)

#define BIT(b,num)      (b & (1<<num)) >> num
#define PB_WIDTH        57
#define PB_FULL         '#'
#define PB_MIDDLE       '='
#define PB_NONE         ' '
#define PB_HEAD         '>'

void err_msg(const char *fmt, ...);
void warn_msg(const char *fmt, ...);
void info_msg(int lvl, const char *fmt, ...);
void progress_bar(float curr, float total, unsigned long eta);
unsigned char reverse(unsigned char a);
void bin_to_str(unsigned char *b, char *h, int n, int l);

#endif				/* _MISC_H */
