/*
 * Yaotp (Yet Another One-Time Pad) 
 * ---
 * (c) 2004 Plasmoid <plasmoid@thc.org>, The Hacker's Choice
 * $Id: misc.c,v 1.14 2004/08/05 13:29:37 plasmoid Exp $  
 * ---
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of
 * the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU General Public 
 * License along with this program; if not, write to the Free 
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston, 
 * MA 02111-1307, USA.
 */

#include <stdlib.h>
#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include <unistd.h>
#include <time.h>
#include <errno.h>

#include "misc.h"

extern int errno;
extern int verbose;

/*
 * Simple error function that equals printf but cares for error numbers.
 */
void err_msg(const char *fmt, ...)
{
   char s[128];
   va_list ap;

   va_start(ap, fmt);
   vsnprintf(s, 128, fmt, ap);
   va_end(ap);

   fprintf(stderr, "Error: %s\n", s);

   if (errno) {
      perror("  >>>");
      errno = 0;
   }
}


/*
 * Simple warning function.
 */
void warn_msg(const char *fmt, ...)
{
   char s[128];
   va_list ap;

   if (verbose < 0)
      return;

   va_start(ap, fmt);
   vsnprintf(s, 128, fmt, ap);
   va_end(ap);

   fprintf(stderr, "\nWarning: %s\n", s);
}


/*
 * Print'n'flush. Could have been a macro, but who cares.
 */
void info_msg(int lvl, const char *fmt, ...)
{
   va_list ap;
   char s[128], timestr[32];
   time_t ts;

   if (lvl > verbose)
      return;

   va_start(ap, fmt);
   vsnprintf(s, 128, fmt, ap);
   va_end(ap);

   ts = time(NULL);
   strftime(timestr, 32, "%H:%M:%S", localtime(&ts));
   fprintf(stderr, "[%s] %s\n", timestr, s);
   fflush(stdout);
}

/*
 * Reverse the bit ordering inside an unsigned char. Note that this function
 * is totally unrelated to endianess.
 */
unsigned char reverse(unsigned char a)
{
   unsigned char b = 0;
   int i, n;

   n = sizeof(a) * 8;
   for (i = 0; i < n; i++)
      b |= BIT(a, (n - i - 1)) << i;

   return b;
}

void progress_bar(float curr, float total, unsigned long eta)
{
   static char bar[PB_WIDTH];
   char etastr[11];
   unsigned int i, size;
   float perc;

   if (verbose < 0)
      return;

   perc = curr * 100 / total;
   size = (int) (perc * (PB_WIDTH - 1)) / 100;

   if (perc == 0) {
      for (i = 0; i < PB_WIDTH; i++)
	 bar[i] = PB_NONE;

      bar[0] = '[';
      bar[1] = PB_HEAD;
      bar[PB_WIDTH - 2] = ']';
      bar[PB_WIDTH - 1] = 0;
      goto print;
   }

   if (perc > 99.9) {
      for (i = 1; i < PB_WIDTH - 2; i++)
	 bar[i] = PB_FULL;
      goto print;
   }

   for (i = 1; i < size; i++) {
      if (i < size - 1)
	 bar[i] = PB_MIDDLE;
      else
	 bar[i] = PB_HEAD;
   }

 print:
   strftime(etastr, 10, "%H:%M:%S", gmtime((time_t *) & eta));
   printf("\r%s %5.1f%%  ETA: %s", bar, perc, etastr);

   if (verbose > 1)
      printf("\n");

   fflush(stdout);
}

void bin_to_str(unsigned char *b, char *h, int n, int l)
{
   char buf[3];
   int i, j;

   *h = 0;
   for (i = 0, j = 0; i < n; i++, j += 2) {
      sprintf(buf, "%.2x", b[i]);

      if (j + 3 <= l) {
	 strcat(h, buf);
	 h += 2;
      }
   }
}
