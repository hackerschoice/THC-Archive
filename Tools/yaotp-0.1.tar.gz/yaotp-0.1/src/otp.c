/*
 * Yaotp (Yet Another One-Time Pad) 
 * ---
 * (c) 2004 Plasmoid <plasmoid@thc.org>, The Hacker's Choice
 * $Id: otp.c,v 1.20 2004/08/12 09:35:28 plasmoid Exp $  
 * ---
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of
 * the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU General Public 
 * License along with this program; if not, write to the Free 
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston, 
 * MA 02111-1307, USA.
 */

#include <sys/types.h>
#include <sys/stat.h>
#include <netinet/in.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <assert.h>

#include "misc.h"
#include "buf.h"
#include "io.h"
#include "uu.h"
#include "bz.h"
#include "wipe.h"
#include "key.h"
#include "otp.h"

/*
 * Append current key offset to buffer
 */
int append_offset(buf_t * b, size_t key_off, int wipe_msg)
{
   size_t msg_off;

   info_msg(3, "append_offset(%p, %lu)", b, key_off);

   if (!resize_buf(b, b->len + sizeof(size_t), wipe_msg)) {
      err_msg("append_offset: Could not resize buffer");
      return 0;
   }

   msg_off = htonl(key_off);
   memcpy(b->buf + b->len, &msg_off, sizeof(size_t));
   b->len += sizeof(size_t) + 1;

   return 1;
}

/*
 * Verify that the offset at the enf of the buffer equals the current
 * key offset
 */
int verify_offset(buf_t * b, size_t key_off)
{
   size_t msg_off;
   
   info_msg(3, "verify_offset(%p, %lu)", b, key_off);

   b->len -= sizeof(size_t) + 1;
   memcpy(&msg_off, b->buf + b->len, sizeof(size_t));
   msg_off = ntohl(msg_off);

   if (msg_off != key_off) {
      err_msg("verify_offset: Key offset mismatch %lu != %lu",
	      msg_off, key_off);
      return 0;
   }

   return 1;
}

/*
 * Encrypt buffer with key
 */
void otp_encrypt_buf(buf_t * b, buf_t * k)
{
   size_t i;

   info_msg(3, "otp_encrypt_buf(%p, %p)", b, k);

   assert(b->len == k->len);
   for (i = 0; i < b->len; i++)
      b->buf[i] ^= k->buf[i];

}


/*
 * Decrypt buffer with key
 */
void otp_decrypt_buf(buf_t * b, buf_t * k)
{
   size_t i;

   info_msg(3, "otp_decrypt_buf(%p, %p)", b, k);

   assert(b->len == k->len);
   for (i = 0; i < b->len; i++)
      b->buf[i] ^= k->buf[i];
}

/*
 * Encrypt a message read from STDIN using the provided key file.
 */ 
void otp_encrypt_msg(char *key_file, int wipe_msg)
{
   buf_t *b, *k;
   FILE *f;
   hdr_t h;

   /* Create buffers */
   if (!create_buf(&b, BUF_SIZE) || !create_buf(&k, BUF_SIZE)) {
      err_msg("Could not allocate buffers");
      exit(EXIT_FAILURE);
   }

   /* Open key file */
   f = fopen(key_file, "r+");
   if (!f) {
      err_msg("Could not open key file %s", key_file);
      exit(EXIT_FAILURE);
   }

   /* Read key header */
   if (!fread_key_hdr(f, &h)) {
      err_msg("Could not read header from key file %s", key_file);
      exit(EXIT_FAILURE);
   }

   if (h.avail == 0) {
      err_msg("Key file %s is empty. Generate a new one", key_file);
      exit(EXIT_FAILURE);
   }

   if (!fread_buf_eof(stdin, b, -1, wipe_msg)) {
      err_msg("Failed to fill message buffer");
      goto skip;
   }

   if (!bzcompress(b) || !append_md5(b, wipe_msg)) {
      err_msg("Could not prepare message buffer");
      goto skip;
   }

   if (b->len > h.avail) {
      err_msg("Key file %s too short or too few bytes available.", key_file);
      goto skip;
   }

   if (!fread_buf(f, k, b->len, sizeof(hdr_t) + h.total - h.avail, 
       wipe_msg)) {
      err_msg("Failed to read in partial key");
      goto skip;
   }
   
   info_msg(1, "Encrypting message with %d bytes", k->len);
   otp_encrypt_buf(b, k);

   if (!append_offset(b, h.total - h.avail, wipe_msg) || !uuencode(b)) {
      err_msg("Could not finalize and uuencode message");
      goto skip;
   }

   fprint_buf(stdout, b);

   /* Update and wipe key file */
   if (!fwipe(f, k->len, sizeof(hdr_t) + h.total - h.avail)) {
      err_msg("Could not wipe bytes from key file %s", key_file);
      goto skip;
   }

   h.avail -= k->len;
   if (!fwrite_key_hdr(f, &h)) {
      err_msg("Could not update key file %s", key_file);
      goto skip;
   }

   free_buf(k, 1);
   free_buf(b, wipe_msg);
   fclose(f);
   return;

 skip:
   free_buf(k, 1);
   free_buf(b, wipe_msg);
   fclose(f);
   exit(EXIT_FAILURE);
}

/*
 * Decrypt a message read from STDIN using the provided key file.
 */ 
void otp_decrypt_msg(char *key_file, int wipe_msg)
{
   buf_t *b, *k;
   FILE *f;
   hdr_t h;

   /* Create buffers */
   if (!create_buf(&b, BUF_SIZE) || !create_buf(&k, BUF_SIZE)) {
      err_msg("Could not allocate buffers");
      exit(EXIT_FAILURE);
   }

   /* Open key file */
   f = fopen(key_file, "r+");
   if (!f) {
      err_msg("Could not open key file %s", key_file);
      exit(EXIT_FAILURE);
   }

   /* Read key header */
   if (!fread_key_hdr(f, &h)) {
      err_msg("Could not read header from key file %s", key_file);
      exit(EXIT_FAILURE);
   }

   if (h.avail == 0) {
      err_msg("Key file %s is empty. Generate a new one", key_file);
      exit(EXIT_FAILURE);
   }

   if (!fscan_buf(stdin, b, wipe_msg)) {
      err_msg("Failed to fill buffer and decode message");
      goto skip;
   }

   if (!uudecode(b) || !verify_offset(b, h.total - h.avail)) {
      err_msg("Failed to decode message");
      goto skip;
   }

   if (b->len > h.avail) {
      err_msg("Key file %s too short or too few bytes available.", key_file);
      goto skip;
   }

   if (!fread_buf(f, k, b->len, sizeof(hdr_t) + h.total - h.avail, 
      wipe_msg)) {
      err_msg("Failed to read in partial key");
      goto skip;
   }

   info_msg(1, "Decrypting message with %d bytes", k->len);
   otp_decrypt_buf(b, k);

   if (!verify_md5(b) || !bzdecompress(b)) {
      err_msg("Could not decompress and verify message");
      goto skip;
   }

   if (!fwrite_buf(stdout, b, -1)) {
      err_msg("Could not print message");
      goto skip;
   }

   /* Update and wipe key file */
   if (!fwipe(f, k->len, sizeof(hdr_t) + h.total - h.avail)) {
      err_msg("Could not wipe bytes from key file %s", key_file);
      goto skip;
   }

   h.avail -= k->len;
   if (!fwrite_key_hdr(f, &h)) {
      err_msg("Could not update key file %s", key_file);
      goto skip;
   }

   free_buf(k, 1);
   free_buf(b, wipe_msg);
   fclose(f);
   return;

 skip:
   free_buf(k, 1);
   free_buf(b, wipe_msg);
   fclose(f);
   exit(EXIT_FAILURE);
}
