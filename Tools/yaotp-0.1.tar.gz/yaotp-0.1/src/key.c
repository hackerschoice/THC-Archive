/*
 * Yaotp (Yet Another One-Time Pad) 
 * ---
 * (c) 2004 Plasmoid <plasmoid@thc.org>, The Hacker's Choice
 * $Id: key.c,v 1.7 2004/08/12 09:35:28 plasmoid Exp $  
 * ---
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of
 * the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU General Public 
 * License along with this program; if not, write to the Free 
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston, 
 * MA 02111-1307, USA.
 */

#include <sys/types.h>
#include <sys/stat.h>
#include <netinet/in.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <time.h>

#include <config.h>

#include "misc.h"
#include "buf.h"
#include "io.h"
#include "rng.h"
#include "snd.h"
#include "wipe.h"
#include "key.h"

extern int verbose;

/*
 * Read key header from stream
 */
int fread_key_hdr(FILE * f, hdr_t * h)
{
   info_msg(3, "fread_key_hdr(%p, %p)", f, h);

   rewind(f);
   fread(h, sizeof(hdr_t), 1, f);
   if (ferror(f)) {
      err_msg("fread_key_hdr: Could not read header from key file");
      return 0;
   }

   h->avail = ntohl(h->avail);
   h->total = ntohl(h->total);
   h->ctime = ntohl(h->ctime);

   if (memcmp(h->magic, HDR_MAGIC, 3)) {
      err_msg("fread_key_hdr: Invalid key file header ");
      return 0;
   }

   return 1;
}

/*
 * Write key header to stream
 */
int fwrite_key_hdr(FILE * f, hdr_t * h)
{
   info_msg(3, "fwrite_key_hdr(%p, %p)", f, h);

   h->total = htonl(h->total);
   h->avail = htonl(h->avail);
   h->ctime = htonl(time(NULL));

   memcpy(h->magic, HDR_MAGIC, 3);
   snprintf(h->version, 8, "%s", VERSION);
   memset(h->reserved, 0, 32);

   /* Terminate the header, so that we can trim it with tail */
   h->cr = '\n';

   rewind(f);
   fwrite(h, sizeof(hdr_t), 1, f);
   if (ferror(f)) {
      err_msg("fwrite_key_hdr: Could not write header to key file");
      return 0;
   }

   return 1;
}

/*
 * Print key header to stream
 */ 
void fprint_key_hdr(FILE * f, hdr_t * h)
{
   char *s;

   fprintf(f, "   Total key size:      %lu\n", (long unsigned) h->total);
   fprintf(f, "   Available key size:  %lu\n", (long unsigned) h->avail);
   s = ctime((time_t *) & h->ctime);
   fprintf(f, "   Creation time:       %s", s);
   fprintf(f, "   Key label:           %s\n", h->label);
}

/*
 * Generate a new Yaotp key
 */
void generate_key(char *key_file, size_t key_size, char *snd_dev,
		  int num_ol, int hash_alg, int hash_ratio, char *label)
{
   int snd, ok = 1, bad = 0;
   FILE *f;
   buf_t *b;
   size_t i;
   time_t eta;
   hdr_t hdr;

   info_msg(1, "Generating new key %s (%lukb)", key_file, key_size >> 10);

   snd = open_snd_dev(snd_dev);
   if (snd == -1) {
      err_msg("Could not open sound device %s", snd_dev);
      exit(EXIT_FAILURE);
   }

   if (!create_buf(&b, BUF_SIZE)) {
      err_msg("Could not create temporary buffer");
      exit(EXIT_FAILURE);
   }

   /* Create key file */
   f = fopen(key_file, "w");
   if (!f) {
      err_msg("Could not create key file %s", key_file);
      exit(EXIT_FAILURE);
   }
   fchmod(fileno(f), 0600);


   for (i = 0; ok && i < key_size; i += b->len) {

      ok &= read_snd(snd, b, BUF_SIZE);

      if (ok && !check_randomness(b, verbose)) {
	 i -= b->len;
	 ok &= (++bad <= BAD_THRES);
	 continue;
      }

      ok &= overlay_buf(b, num_ol);
      ok &= hash_buf(b, hash_ratio, hash_alg);

      /* Truncate buffer if we generated too much data */
      if (i + b->len > key_size)
	 b->len = key_size - i;

      ok &= fwrite_buf(f, b, i + sizeof(hdr_t));
      eta = size_to_secs((key_size - i) * num_ol * hash_ratio);

      progress_bar(i, key_size, eta);
   }

   progress_bar(i, key_size, 0);
   printf("\n");

   free_buf(b, 1);

   /* Write real header */
   if (label)
      snprintf(hdr.label, 33, "%s", label);
   hdr.total = hdr.avail = key_size;
   ok &= fwrite_key_hdr(f, &hdr);

   if (bad > BAD_THRES)
      err_msg("Bad audio source (low volume, skips) or sound muted.");

   if (!ok) {
      err_msg("Could not write consistent key file %s. Aborting", key_file);
      unlink(key_file);
      exit(EXIT_FAILURE);
   }

   close(snd);
   fclose(f);

   info_msg(1, "Key file %s succesfully written.", key_file);
}

/*
 * Print information about the given key file.
 */
void fprint_key_info(FILE * f, char *key_file)
{
   FILE *k;
   hdr_t hdr;

   k = fopen(key_file, "r");
   if (!k) {
      err_msg("Could not create key file %s", key_file);
      exit(EXIT_FAILURE);
   }

   if (!fread_key_hdr(k, &hdr)) {
      err_msg("Could not read header from key file %s", key_file);
      exit(EXIT_FAILURE);
   }

   fclose(k);

   fprintf(f, "Key file: %s\n", key_file);
   fprint_key_hdr(f, &hdr);

}
