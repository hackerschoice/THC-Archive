/*
 * Yaotp (Yet Another One-Time Pad) 
 * ---
 * (c) 2004 Plasmoid <plasmoid@thc.org>, The Hacker's Choice
 * $Id: key.h,v 1.5 2004/08/10 13:52:04 plasmoid Exp $  
 * ---
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of
 * the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU General Public 
 * License along with this program; if not, write to the Free 
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston, 
 * MA 02111-1307, USA.
 */

#ifndef _KEY_H
#define _KEY_H

#define HDR_MAGIC       "::-"
#define BAD_THRES	1024

typedef struct {
   char magic[3];
   size_t avail;
   size_t total;
   time_t ctime;
   char version[8];
   char label[33];
   char reserved[32];
   char cr;
} hdr_t;

int fread_key_hdr(FILE * f, hdr_t * h);
int fwrite_key_hdr(FILE * f, hdr_t * h);
void fprint_key_hdr(FILE * f, hdr_t * h);

void generate_key(char *key_file, size_t key_size, char *snd_dev,
		  int num_ol, int hash_alg, int hash_ratio, char *label);

void fprint_key_info(FILE * f, char *key_file);


#endif				/* _KEY_H */
