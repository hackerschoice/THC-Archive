/*
 * Yaotp (Yet Another One-Time Pad) 
 * ---
 * (c) 2004 Plasmoid <plasmoid@thc.org>, The Hacker's Choice
 * $Id: io.h,v 1.15 2004/08/10 09:54:37 plasmoid Exp $  
 * ---
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of
 * the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU General Public 
 * License along with this program; if not, write to the Free 
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston, 
 * MA 02111-1307, USA.
 */

#ifndef _IO_H
#define _IO_H

#define IO_PAGE         8192                  /* Default i/o buffer size */

#define BUF_WIDTH       60                    /* Width of printed message */
#define BUF_BEGIN_HDR   "BEGIN YAOTP MSG {"   /* Yaotp header "begin" */
#define BUF_END_HDR     "} END YAOTP MSG"     /* Yaotp header "end"  */

/*
 * Modes for message scan
 */
typedef enum {
   BUF_NONE, BUF_BEGIN, BUF_END
} msg_mode_t;

int fwrite_buf(FILE *, buf_t * b, off_t off);
int fread_buf(FILE *, buf_t * b, size_t len, off_t off, int wipe);
int fread_buf_eof(FILE *, buf_t * b, off_t off, int wipe);
int fscan_buf(FILE * f, buf_t * b, int wipe);
int fprint_buf(FILE * f, buf_t * b);

#endif				/* _IO_H */
