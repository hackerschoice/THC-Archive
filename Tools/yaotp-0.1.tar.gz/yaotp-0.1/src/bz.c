/*
 * Yaotp (Yet Another One-Time Pad) 
 * ---
 * (c) 2004 Plasmoid <plasmoid@thc.org>, The Hacker's Choice
 * $Id: bz.c,v 1.13 2004/08/12 12:55:41 plasmoid Exp $  
 * ---
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of
 * the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU General Public 
 * License along with this program; if not, write to the Free 
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston, 
 * MA 02111-1307, USA.
 */

#include <sys/types.h>
#include <netinet/in.h>
#include <stdio.h>
#include <stdlib.h>
#include <bzlib.h>
#include <assert.h>
#include <string.h>


#include "misc.h"
#include "buf.h"
#include "wipe.h"

extern int wipe_msg;

/*
 * Internal malloc() function for the bz2 library. 
 */
void *bzalloc(void *opaque, int n, int m)
{
   info_msg(3, "bzalloc(%d, %d)", n, m);

   return malloc(n * m);
}

/*
 * Internal free() function for the bz2 library. The function extends
 * the free() call by wiping out memory beforehand. 
 */
void bzfree(void *opaque, void *addr)
{
   size_t size;

   info_msg(3, "bzfree(%p)", addr);

   /* 
    * Honestly, this is dirty. If you know how to get the size of 
    * a memory chunk the "right" way, let me know. ;)
    */
   if (wipe_msg) {
      memcpy(&size, (char *) addr - sizeof(size_t), sizeof(size_t));
      size -= 32;
      wipe_mem(addr, size);
   }
      
   free(addr);
}

/*
 * Compress buffer with the bz2 library. For easy decompression the original
 * buffer size is appended to the compressed buffer.
 */
int bzcompress(buf_t * b)
{
   bz_stream strm;
   size_t size;
   int ret;
   unsigned char *buf;

   info_msg(3, "bzcompress(%p)", b);

   /* Prepare out buffer. Sanity overhead 2% and 600 bytes */
   buf = malloc(b->len + b->len / 50 + 600);
   if (!buf) {
      err_msg("bzcompress: Could not allocate memory");
      return 0;
   }

   /* Prepare stream structure */
   strm.bzalloc = bzalloc;
   strm.bzfree = bzfree;
   strm.opaque = NULL;
   strm.next_in = (char *) b->buf;
   strm.avail_in = b->len;
   strm.next_out = (char *) buf;
   /*
    *  According to the bz2 library documentation a buffer may 
    *  grow about 2% and 600 bytes if being _compressed_. 
    */
   strm.avail_out = b->len + b->len / 50 + 600;

   info_msg(1, "Compressing message with bzlib");

   BZ2_bzCompressInit(&strm, 1, 0, 0);

   /* Compress until stream end is reached */
   do {
      ret = BZ2_bzCompress(&strm, BZ_FINISH);
   } while (ret != BZ_STREAM_END && ret == BZ_OK);

   BZ2_bzCompressEnd(&strm);

   /* Wipe and destroy old buffer content */
   wipe_mem(b->buf, b->maxlen);
   free(b->buf);

   if (ret != BZ_STREAM_END && ret != BZ_OK) {
      err_msg("bzcompress: Failure during compression");
      return 0;
   }

   /* Set new buffer content */
   b->buf = buf;
   b->maxlen = b->len + b->len / 50 + 600;
   b->len = strm.total_out_lo32;

   /* We don't support large 64 bit files. */
   assert(strm.total_out_hi32 == 0);

   /* Copy original size in network byte order to end of buffer */
   size = htonl(strm.total_in_lo32);
   memcpy(b->buf + b->len, &size, sizeof(size_t));
   b->len += sizeof(size_t);

   info_msg(1, "Compression ratio %4.1f%%",
	    ((double) strm.total_out_lo32) / strm.total_in_lo32 * 100);

   return 1;
}

/*
 * Decompress buffer with bz2 library. The function works straight-forward.
 * The uncompressed buffer size was appended to the compressed buffer, so
 * that we don't run into any problems regarding compression ratios.
 */
int bzdecompress(buf_t * b)
{
   bz_stream strm;
   size_t size;
   unsigned char *buf;
   int ret;

   info_msg(3, "bzdecompress(%p)", b);

   /* Get original buffer size from end of buffer */
   b->len -= sizeof(size_t);
   memcpy(&size, b->buf + b->len, sizeof(size_t));
   size = ntohl(size);

   info_msg(3, "Original size of message %lu", size);

   /* Prepare out buffer. */
   buf = malloc(size);
   if (!buf) {
      err_msg("bzdecompress: Could not allocate memory");
      return 0;
   }

   /* Prepare stream structure */
   strm.bzalloc = bzalloc;
   strm.bzfree = bzfree;
   strm.opaque = NULL;
   strm.next_in = (char *) b->buf;
   strm.avail_in = b->len;
   strm.next_out = (char *) buf;
   strm.avail_out = size;

   info_msg(1, "Decompressing message with bzlib");

   BZ2_bzDecompressInit(&strm, 0, 1);

   /* Decompress until stream end is reached */
   do {
      ret = BZ2_bzDecompress(&strm);
   } while (ret != BZ_STREAM_END && ret == BZ_OK);

   BZ2_bzDecompressEnd(&strm);

   /* Wipe and destroy old buffer content */
   wipe_mem(b->buf, b->maxlen);
   free(b->buf);

   if (ret != BZ_STREAM_END && ret != BZ_OK) {
      err_msg("bzdecompress: Failure during decompression");
      return 0;
   }

   /* Set new buffer content */
   b->buf = buf;
   b->maxlen = size;
   b->len = strm.total_out_lo32;

   info_msg(1, "Decompression ratio %4.1f%%",
	    ((double) strm.total_out_lo32) / strm.total_in_lo32 * 100);

   return 1;
}
