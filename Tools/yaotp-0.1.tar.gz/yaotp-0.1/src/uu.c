/*
 * Yaotp (Yet Another One-Time Pad) 
 * ---
 * (c) 2004 Plasmoid <plasmoid@thc.org>, The Hacker's Choice
 * $Id: uu.c,v 1.18 2004/08/12 09:35:29 plasmoid Exp $  
 * ---
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of
 * the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU General Public 
 * License along with this program; if not, write to the Free 
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston, 
 * MA 02111-1307, USA.
 */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <assert.h>

#include <config.h>

#include "misc.h"
#include "buf.h"
#include "wipe.h"

static const char base64[] =
    "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
static const char pad64 = '=';

/*
 * Uuencode the given buffer. The function has been derived from 
 * Markus Friedl's OpenSSH code.
 */
int uuencode(buf_t * b)
{
   size_t i, j, k;
   unsigned char *buf;

   info_msg(3, "uuencode(%p)", b);
   info_msg(1, "Uuencoding message");

   /* Prepare output buffer */
   buf = (unsigned char *) malloc(b->len * 4 / 3 + 3);
   if (!buf) {
      err_msg("uuencode: Could not allocate memory");
      return 0;
   }

   /* Convert three source bytes to four 6 bit slices */
   for (i = 0, j = 0; i < b->len; i += 3, j += 4) {
      buf[j + 0] = b->buf[i + 0] >> 2;
      buf[j + 1] = ((b->buf[i + 0] & 0x03) << 4) + (b->buf[i + 1] >> 4);
      buf[j + 2] = ((b->buf[i + 1] & 0x0f) << 2) + (b->buf[i + 2] >> 6);
      buf[j + 3] = b->buf[i + 2] & 0x3f;
   }

   assert(j <= b->len * 4 / 3 + 3);

   if (i > b->len) {
      if (i == b->len + 1) {
	 /* One byte left and two to pad */
	 buf[j - 4] = b->buf[i - 3] >> 2;
	 buf[j - 3] = (b->buf[i - 3] & 0x03) << 4;
      } else {
	 /* Two bytes left and one to pad */
	 buf[j - 4] = b->buf[i - 3] >> 2;
	 buf[j - 3] = ((b->buf[i - 3] & 0x03) << 4) + (b->buf[i - 2] >> 4);
	 buf[j - 2] = (b->buf[i - 2] & 0x0f) << 2;
      }
   }

   /* Replace raw bytes with base64 alphabet */
   for (k = 0; k < j - (i - b->len); k++)
      buf[k] = base64[buf[k]];

   /* Replace padded bytes with padding symbol */
   for (k = 0; k < i - b->len; k++)
      buf[j - k - 1] = pad64;

   info_msg(2, "Message size changed from %d to %d bytes", b->len, j);


   /* Wipe and destroy old buffer content */
   wipe_mem(b->buf, b->maxlen);
   free(b->buf);

   /* Set new buffer content */
   b->buf = buf;
   b->maxlen = b->len * 4 / 3 + 3;
   b->len = j;

   return 1;
}

/*
 * Uudecode the given buffer. The function has been derived from 
 * Markus Friedl's OpenSSH code.
 */
int uudecode(buf_t * u)
{
   unsigned char c = 0, *buf;
   char *pos;
   size_t i, j, k;
   int error = 0;

   info_msg(3, "uudecode(%p)", u);
   info_msg(1, "Uudecoding message");

   /* Prepare output buffer */
   buf = (unsigned char *) malloc(u->len * 3 / 4);
   if (!buf) {
      err_msg("uudecode: Could not allocate memory");
      return 0;
   }

   for (i = 0, j = 0, k = 0; i < u->len; i++) {
      c = u->buf[i];

      /* Check for whitespace characters and trailing null */
      if (isspace(c))
	 continue;

      /* Check for padding symbol */
      if (c == pad64)
	 break;

      /* Get position inside the base64 array */
      pos = strchr(base64, c);
      if (pos == 0) {
	 err_msg("uudecode: non-base64 character detected");
	 error = 1;
      }

      switch (k % 4) {
      case 0:
	 buf[j] = (pos - base64) << 2;
	 break;
      case 1:
	 buf[j] |= (pos - base64) >> 4;
	 buf[++j] = ((pos - base64) & 0x0f) << 4;
	 break;
      case 2:
	 buf[j] |= (pos - base64) >> 2;
	 buf[++j] = ((pos - base64) & 0x03) << 6;
	 break;
      case 3:
	 buf[j++] |= (pos - base64);
	 break;
      }
      k++;
   }

   if (error)
      goto skip;

   /*
    * We are done decoding base-64 characters.  Let's see if we ended
    * on a byte boundary, and/or with erroneous trailing characters.
    */
   if (c == pad64) {
      switch (k % 4) {
      case 0:
      case 1:
	 /* Invalid padding in first and second position */
	 err_msg("uu_decode: Corrupt padding at end of buffer");
	 error = 1;

      case 2:
	 /* Valid one byte of info and padding, skip whitespace */
	 for (i++; i < u->len; i++)
	    if (!isspace(u->buf[i]))
	       break;

	 /* Make sure there is another trailing = sign. */
	 if (u->buf[i] != pad64) {
	    err_msg("uudecode: Invalid padding character '%c'.", u->buf[i]);
	    error = 1;
	 }
	 /* Fall through to single trailing pad64 case. */

      case 3:
	 /* Valid two bytes of msg and padding, check for garbage */
	 for (i++; i < u->len; i++)
	    if (!isspace(u->buf[i])) {
	       err_msg("uudecode: Garabage '%c' at buffer end.", u->buf[i]);
	       error = 1;
	    }
      }
   } else {
      /* 
       * No padding, check if the buffer is complete. 
       */
      if (k % 4 != 0) {
	 err_msg("uudecode: Buffer corrupt, bytes are missing");
	 error = 1;
      }
   }

 skip:
   info_msg(2, "Message size changed from %d to %d bytes", u->len, j);

   /* Wipe and destroy old buffer content */
   wipe_mem(u->buf, u->maxlen);
   free(u->buf);

   /* Set new buffer content */
   u->buf = buf;
   u->maxlen = u->len * 3 / 4;
   u->len = j;

   return !error;
}
