/*
 * Yaotp (Yet Another One-Time Pad) 
 * ---
 * (c) 2004 Plasmoid <plasmoid@thc.org>, The Hacker's Choice
 * $Id: io.c,v 1.21 2004/08/10 09:54:37 plasmoid Exp $  
 * ---
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of
 * the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU General Public 
 * License along with this program; if not, write to the Free 
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston, 
 * MA 02111-1307, USA.
 */

#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include <ctype.h>
#include <string.h>

#include "misc.h"
#include "buf.h"
#include "io.h"

/*
 * Write buffer to the given stream. If working with files an offset
 * may be specified, otherwise set it -1.
 */
int fwrite_buf(FILE * f, buf_t * b, off_t off)
{
   info_msg(3, "fwrite_buf(%p, %p, %ld)", f, b, off);

   if (off > -1) {
      if (fseek(f, off, SEEK_SET) != 0) {
	 err_msg("fwrite_buf: Failed to seek to offset position %lu", off);
	 return 0;
      }
   }

   fwrite(b->buf, b->len, 1, f);
   if (ferror(f)) {
      err_msg("fwrite_buf: Failed to write buffer of %lu bytes", b->len);
      return 0;
   }

   return 1;
}


/*
 * Read buffer of the given length from a stream. If working with files
 * an offset may be specified, otherwise set it -1.
 */
int fread_buf(FILE * f, buf_t * b, size_t len, off_t off, int wipe)
{
   size_t r;

   info_msg(3, "fread_buf(%p, %p, %lu, %ld)", f, b, len, off);

   if (off > -1) {
      if (fseek(f, off, SEEK_SET) != 0) {
	 err_msg("fread_buf: Could not seek to offset position %lu", off);
	 return 0;
      }
   }
   
   if (!resize_buf(b, len, wipe)) {
      err_msg("fread_buf: Could not resize buffer");
      return 0;
   }   

   r = fread(b->buf, 1, len, f);
   if (ferror(f)) {
      err_msg("fread_buf: Could not read buffer of %lu bytes", len);
      return 0;
   }
   b->len = r;

   return 1;
}


/*
 * Read in buffer until an EOF is detected. If working with files an offset
 * can be specified, otherwise set it to -1. The size of the stream is not 
 * known in advance, therefore the function doubles the buffer size whenever 
 * the buffer if full (btw. sounds like a memory DoS).
 */
int fread_buf_eof(FILE * f, buf_t * b, off_t off, int wipe)
{
   size_t r;
   char buf[IO_PAGE];

   info_msg(3, "fread_buf_eof(%p, %p, %ld)", f, b, off);

   if (off > -1) {
      if (fseek(f, off, SEEK_SET) != 0) {
	 err_msg("fread_buf_eof: Failed to seek to offset position %lu",
		 off);
	 return 0;
      }
   }

   b->len = 0;
   do {
      r = fread(buf, 1, IO_PAGE, f);
      if (ferror(f)) {
	 err_msg("fread_buf_eof: Failed to read i/o page buffer");
	 return 0;
      }

      /* Check if there's enough space in the buffer */
      if (b->len + IO_PAGE > b->maxlen)
	 if (!resize_buf(b, 2 * b->len, wipe)) {
	    err_msg("fread_buf_eof: Could not resize buffer");
	    return 0;
	 }

      memcpy(b->buf + b->len, buf, r);
      b->len += r;
   } while (r == IO_PAGE);

   return 1;
}

/* 
 * Print buffer to stream. The buffer has to be uuencoded or has to contain
 * printable characters only.
 */
int fprint_buf(FILE * f, buf_t * b)
{
   size_t i;

   fprintf(f, "\n%s\n   ", BUF_BEGIN_HDR);

   for (i = 0; i < b->len && b->buf[i] != 0; i++) {
      
      assert(isprint(b->buf[i]));
      fprintf(f, "%c", b->buf[i]);

      if (i % BUF_WIDTH == BUF_WIDTH - 1)
	 fprintf(f, "\n   ");
   }

   fprintf(f, "\n%s\n\n", BUF_END_HDR);

   return 1;
}

/*
 * Scan in a buffer from stream. 
 */
int fscan_buf(FILE * f, buf_t * b, int wipe)
{
   char str[IO_PAGE];
   msg_mode_t mode = BUF_NONE;

   b->len = 0;
   while (!feof(f)) {
      
      /* Read in string from the stream */
      if (!fgets(str, IO_PAGE - 1, f)) {
	 err_msg("fscan_buf: Could not read message from stream");
	 return 0;
      }

      /* If begin header was found, set mode */
      if (mode == BUF_NONE && strstr(str, BUF_BEGIN_HDR)) {
	 mode = BUF_BEGIN;
	 continue;
      }

      /* If end header was found, leave loop. */
      if (mode == BUF_BEGIN && strstr(str, BUF_END_HDR)) {
	 mode = BUF_END;
	 break;
      }

      if (mode == BUF_BEGIN) {
	 /* Resize buffer */
	 if (b->len + strlen(str) > b->maxlen)
	    if (!resize_buf(b, 2 * b->len, wipe)) {
	       err_msg("fscan_buf: Could not resize buffer");
	       return 0;
	    }

	 /* Copy string to buffer */
	 memcpy(b->buf + b->len, str, strlen(str));
	 b->len += strlen(str);
      }
   }

   if (mode != BUF_END) {
      err_msg("fscan_buf: Corrupt message. Invalid message headers.");
      return 0;
   }

   info_msg(1, "Valid message with %lu bytes scanned", b->len);

   return 1;
}
