/*
 * Yaotp (Yet Another One-Time Pad) 
 * ---
 * (c) 2004 Plasmoid <plasmoid@thc.org>, The Hacker's Choice
 * $Id: yaotp.c,v 1.42 2004/08/12 09:35:30 plasmoid Exp $  
 * ---
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of
 * the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU General Public 
 * License along with this program; if not, write to the Free 
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston, 
 * MA 02111-1307, USA.
 */

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <strings.h>

#include <config.h>

#include "misc.h"
#include "buf.h"
#include "rng.h"
#include "snd.h"
#include "otp.h"
#include "key.h"
#include "yaotp.h"

/* 
 * Global variables
 */
chash_t cmd = CMD_NONE;		        /* Yaotp command */
int verbose = 0;		        /* Verbosity */
int wipe_msg = 0;			/* Message memory wiping */
unsigned int num_ol = NUM_OL;	        /* Number of overlays */
unsigned int hash_ratio = HASH_RATIO;	/* Message digest ratio */
unsigned int hash_alg = HASH_ALG;	        /* Message digest algorithm */
size_t key_size = KEY_SIZE;	        /* Key file size in kilobyte */
char *key_file = KEY_FILE;	        /* Key file */
char *snd_dev = SND_DEV;	        /* Sound device */
char *key_label = "";		        /* Default key label */

/* 
 * Print version
 */
void print_version()
{
   printf("Yaotp v%s (Yet Another One-Time Pad) - "
	  "(c) 2004 Plasmoid <plasmoid@thc.org>\n", VERSION);
}

/*
 * Print usage
 */
void print_usage()
{
   printf("Usage: yaotp <command> [options]\n"
	  "Commands: \n"
	  "  -g         Generate new key from audio source.\n"
	  "  -e         Encrypt a message read from STDIN to STDOUT.\n"
	  "  -d         Decrypt a message read from STDIN to STDOUT.\n"
	  "  -t         Test audio source and dry run.\n"
	  "  -p         Print information about key.\n");

   printf("Options: \n"
	  "  -k file    Set key file name. [Default: %s]\n"
	  "  -z size    Set key size in kilobytes [Default: %d]\n"
	  "  -l label   Set key label (maximal 32 characters)\n"
	  "  -s dev     Set sound device. [Default: %s]\n"
	  "  -o num     Set number of byte overlays. [Default: %d]\n"
	  "  -r ratio   Set ratio for buffer digest. [Default: %d]\n"
	  "  -a alg     Set hash algorithm (MD5, SHA, RIPME). "
          "[Default:%s]\n"
	  "  -w         Wipe message memory (slows down drastically)\n",
	  KEY_FILE, KEY_SIZE >> 10, SND_DEV, NUM_OL, HASH_RATIO,
	  (HASH_ALG == HASH_MD5) ? "MD5" : "SHA1");

   printf("  -q         Be really quiet.\n"
	  "  -v         Print verbose information (multiple use possible).\n"
	  "  -h         Print this help screen.\n"
	  "  -V         Print version and copyright notice.\n");
}

/*
 * Parse options from argv[]
 */
void parse_options(int argc, char **argv)
{
   int c;

   /*
    * Parse commandline options.
    */
   while ((c = getopt(argc, argv, "pqz:k:s:o:r:a:l:tewdghvV")) != EOF)
      switch (c) {
	 /* Commands */
      case 'e':
	 cmd = CMD_ENCRYPT;
	 break;
      case 'd':
	 cmd = CMD_DECRYPT;
	 break;
      case 'g':
	 cmd = CMD_GEN_KEY;
	 break;
      case 't':
	 cmd = CMD_TEST_SND;
	 break;
      case 'p':
	 cmd = CMD_PRINT_KEY;
	 break;

	 /* Options */
      case 'w':
         wipe_msg = 1;
         break;	 
      case 'l':
	 key_label = optarg;
	 break;
      case 'z':
	 key_size = atoi(optarg);
	 if (key_size < 8) {
	    err_msg("Key size < 8kb not supported. Use larger key");
	    exit(EXIT_FAILURE);
	 }
	 if (key_size > 128 * 1024) {
	    err_msg("Key size > 128mb not supported. Use multiple keys");
	    exit(EXIT_FAILURE);
	 }
	 /* Convert kilobytes to bytes */
	 key_size = key_size << 10;
	 break;
      case 'k':
	 key_file = optarg;
	 break;
      case 's':
	 snd_dev = optarg;
	 if (access(snd_dev, R_OK)) {
	    err_msg("Cannot read from sound device %s", snd_dev);
	    exit(EXIT_FAILURE);
	 }
	 break;
      case 'v':
	 if (verbose >= 0)
	    verbose++;
	 break;
      case 'q':
	 verbose = -1;
	 break;
      case 'o':
	 num_ol = atoi(optarg);
	 if (num_ol < 0) {
	    err_msg("Number of overlays < 0 not allowed");
	    exit(EXIT_FAILURE);
	 }
	 if (num_ol % 2) {
	    err_msg("Number of overlays has to be even");
	    exit(EXIT_FAILURE);
	 }
	 break;
      case 'r':
	 hash_ratio = atoi(optarg);
	 if (hash_ratio < 1) {
	    err_msg("Digest ratio %d < 1", hash_ratio);
	    exit(EXIT_FAILURE);
	 }
	 break;
      case 'a':
	 if (!strncasecmp(optarg, "SHA", 4)) {
	    hash_alg = HASH_SHA;
	 } else if (!strncasecmp(optarg, "MD5", 3)) {
	    hash_alg = HASH_MD5;
         } else if (!strncasecmp(optarg, "RIPEMD", 3)) {
	    hash_alg = HASH_RIPEMD;
	 } else {
	    err_msg("Unknown message digest algorithm %s", optarg);
	    exit(EXIT_FAILURE);
	 }
	 break;
      case 'V':
	 print_version();
	 exit(EXIT_SUCCESS);
      case 'h':
	 print_usage();
	 exit(EXIT_FAILURE);
      default:
	 err_msg("Use 'yatop -h' to get a list of available options.");
	 exit(EXIT_FAILURE);
      }
}

/*
 * Main function
 */
int main(int argc, char **argv)
{
   parse_options(argc, argv);

   /* Switch commands */
   switch (cmd) {
   case CMD_GEN_KEY:
      info_msg(1, "Command: Generate key");
      generate_key(key_file, key_size, snd_dev, num_ol, hash_alg, hash_ratio,
		   key_label);
      break;
   case CMD_ENCRYPT:
      info_msg(1, "Command: Encrypt message");
      otp_encrypt_msg(key_file, wipe_msg);
      break;
   case CMD_DECRYPT:
      info_msg(1, "Command: Decrypt message");
      otp_decrypt_msg(key_file, wipe_msg);
      break;
   case CMD_TEST_SND:
      info_msg(1, "Command: Test sound device");
      test_snd(snd_dev, key_size);
      break;
   case CMD_PRINT_KEY:
      info_msg(1, "Command: Print key information");
      fprint_key_info(stdout, key_file);
      break;
   default:
   case CMD_NONE:
      err_msg("No command specified. Use 'yatop -h' to get a list of "
	      "commands.");
      break;
   }

   info_msg(1, "Command successful. We are done.");

   return EXIT_SUCCESS;
}
