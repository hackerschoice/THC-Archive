/*
 * Yaotp (Yet Another One-Time Pad) 
 * ---
 * (c) 2004 Plasmoid <plasmoid@thc.org>, The Hacker's Choice
 * $Id: buf.c,v 1.38 2004/08/12 12:55:39 plasmoid Exp $  
 * ---
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of
 * the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU General Public 
 * License along with this program; if not, write to the Free 
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston, 
 * MA 02111-1307, USA.
 */

#include <sys/types.h>
#include <netinet/in.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include <openssl/md5.h>

#include "buf.h"
#include "misc.h"
#include "wipe.h"

extern int verbose;

/*
 * Create and allocate a buffer
 */
int create_buf(buf_t ** b, size_t len)
{

   info_msg(3, "create_buf(%p, %lu)", *b, len);

   *b = (buf_t *) malloc(sizeof(buf_t));
   if (!*b) {
      err_msg("create_buf: Could not create buffer struct");
      return 0;
   }

   (*b)->buf = (unsigned char *) malloc(sizeof(unsigned char) * len);
   if (!(*b)->buf) {
      err_msg("create_buf: Could not allocate buffer of %lu bytes", len);
      return 0;
   }

   (*b)->len = 0;
   (*b)->maxlen = len;

   return 1;
}

/*
 * Allocate new buffer and copy provided buffer
 */
buf_t *clone_buf(buf_t * b)
{
   buf_t *t;

   info_msg(3, "clone_buf(%p)", b);

   if (!create_buf(&t, b->maxlen)) {
      err_msg("clone_buf: Could not create buffer");
      return NULL;
   }

   t->len = b->len;
   t->maxlen = b->maxlen;

   memcpy(t->buf, b->buf, b->len);

   return t;
}

/*
 * Resize the given buffer. If the wipe option is not set, this function
 * is similar to a realloc(). If wipe is set the old buffer is copied and 
 * the old memory is wiped before free().
 */
int resize_buf(buf_t * b, size_t len, int wipe)
{
   unsigned char *tmp;

   info_msg(3, "resize_buf(%p, %lu)", b, len);
   
   if(!wipe) {
      tmp = realloc(b->buf, sizeof(unsigned char) * len);
      if (!tmp) {
         err_msg("resize_buf: Could not allocate buffer of %lu bytes", len);
         return 0;
      }
      goto ret;
   }   

   tmp = (unsigned char *) malloc(sizeof(unsigned char) * len);
   if (!tmp) {
      err_msg("resize_buf: Could not allocate buffer of %lu bytes", len);
      return 0;
   }

   /* Copy old to new buffer */
   memcpy(tmp, b->buf, b->len);

   /* Wipe current buffer */
   wipe_mem(b->buf, b->maxlen);

   /* Free wiped memory and set new pointer */
   free(b->buf);

ret:
   b->maxlen = len;
   b->buf = tmp;

   return 1;
}

/*
 * Wipe and free memory associated with the provided buffer.
 */
void free_buf(buf_t * b, int wipe)
{
   if (!b)
      return;

   info_msg(3, "free_buf(%p)", b);

   if (wipe)
      wipe_mem(b->buf, b->maxlen);

   free(b->buf);
   free(b);
}

/*
 * Generate and append a MD5 message digest to the end of the buffer. 
 */
int append_md5(buf_t * b, int wipe)
{
   unsigned char md5[MD5_DIGEST_LENGTH];
   char md5_1[MD5_DIGEST_LENGTH * 2 + 1];

   info_msg(2, "Generating MD5 message digest");

   /* Calculate MD5 message digest */
   MD5(b->buf, b->len, md5);

   if (!resize_buf(b, b->len + MD5_DIGEST_LENGTH + 1, wipe)) {
      err_msg("append_md5: Could not resize buffer");
      return 0;
   }

   /* Append message digest to the end of the buffer */
   memcpy(b->buf + b->len, md5, MD5_DIGEST_LENGTH);

   if (verbose > 1) {
      bin_to_str(b->buf + b->len, md5_1, MD5_DIGEST_LENGTH,
		 MD5_DIGEST_LENGTH * 2);
   }

   info_msg(2, "Message MD5: %s", md5_1);
   b->len += MD5_DIGEST_LENGTH + 1;

   return 1;
}

/*
 * Verify and remove a MD5 message digest from the end of the buffer.
 */
int verify_md5(buf_t * b)
{
   unsigned char md5[MD5_DIGEST_LENGTH];
   char md5_1[MD5_DIGEST_LENGTH * 2 + 1];
   char md5_2[MD5_DIGEST_LENGTH * 2 + 1];

   info_msg(2, "Verifying MD5 message digest");

   /* Calculate MD5 message digest */
   b->len -= MD5_DIGEST_LENGTH + 1;
   MD5(b->buf, b->len, md5);

   if (verbose > 1) {
      bin_to_str(md5, md5_1, MD5_DIGEST_LENGTH, MD5_DIGEST_LENGTH * 2 + 1);
      bin_to_str(b->buf + b->len, md5_2, MD5_DIGEST_LENGTH,
		 MD5_DIGEST_LENGTH * 2 + 1);
   }

   info_msg(2, "Message MD5: %s", md5_1);

   /* Compare appended message digest with generated one */
   if (memcmp(b->buf + b->len, md5, MD5_DIGEST_LENGTH)) {
      err_msg("buf_verify: Message intergrity corrupt.");
      info_msg(2, " Target MD5: %s", md5_2);
      return 0;
   }

   return 1;
}
