/*
 * Yaotp (Yet Another One-Time Pad) 
 * ---
 * (c) 2004 Plasmoid <plasmoid@thc.org>, The Hacker's Choice
 * $Id: wipe.c,v 1.11 2004/08/05 13:29:37 plasmoid Exp $  
 * ---
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of
 * the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU General Public 
 * License along with this program; if not, write to the Free 
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston, 
 * MA 02111-1307, USA.
 */

#include <sys/types.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>

#include "misc.h"
#include "buf.h"
#include "io.h"

/*
 * Wipe technique proposed by Peter Gutmann at Usenix 1996
 * http://www.cs.auckland.ac.nz/~pgut001/pubs/secure_del.html
 */
static unsigned char write_modes[27][3] = {
   {"\x55\x55\x55"}, {"\xaa\xaa\xaa"}, {"\x92\x49\x24"}, {"\x49\x24\x92"},
   {"\x24\x92\x49"}, {"\x00\x00\x00"}, {"\x11\x11\x11"}, {"\x22\x22\x22"},
   {"\x33\x33\x33"}, {"\x44\x44\x44"}, {"\x55\x55\x55"}, {"\x66\x66\x66"},
   {"\x77\x77\x77"}, {"\x88\x88\x88"}, {"\x99\x99\x99"}, {"\xaa\xaa\xaa"},
   {"\xbb\xbb\xbb"}, {"\xcc\xcc\xcc"}, {"\xdd\xdd\xdd"}, {"\xee\xee\xee"},
   {"\xff\xff\xff"}, {"\x92\x49\x24"}, {"\x49\x24\x92"}, {"\x24\x92\x49"},
   {"\x6d\xb6\xdb"}, {"\xb6\xdb\x6d"}, {"\xdb\x6d\xb6"}
};

void wipe_mem(unsigned char *addr, size_t len)
{
   int i, j;

   info_msg(3, "wipe_mem(%p, %lu)", addr, len);

   /* Weak seed; hopefully somehow secure in this context */
   srand48(time(NULL) + getpid());

   /* Overwrite the buffer four time with random data */
   for (i = 0; i < 4; i++)
      for (j = 0; j < len; j++)
	 *(addr + j) = lrand48();

   /* Overwrite the buffer with 27 different byte triples */
   for (i = 0; i < 28; i++)
      for (j = 0; j < len; j++)
	 *(addr + j) = write_modes[i][j % 3];

   /* Overwrite the buffer four times with random data */
   for (i = 0; i < 4; i++)
      for (j = 0; j < len; j++)
	 *(addr + j) = lrand48();
}

int fwipe(FILE * f, size_t len, off_t off)
{
   unsigned char *buf;
   size_t i, j;
   int error = 0;

   info_msg(3, "fwipe(%p, %lu, %ld)", f, len, off);

   /* Weak seed; hopefully somehow secure in this context */
   srand48(time(NULL) + getpid());

   buf = (unsigned char *) malloc(len);
   if (!buf) {
      err_msg("fwipe: Could not allocate buffer of %lu bytes", len);
      return 0;
   }

   for (i = 0; !error && i < 35; i++) {
      if (i < 4 || i > 30) {	/* Four random passes at start and end */
	 for (j = 0; j < len; j++)
	    *(buf + j) = lrand48();
      } else {			/* 27 byte triple passes */
	 for (j = 0; j < len; j++)
	    *(buf + j) = write_modes[i - 4][j % 3];
      }

      if (fseek(f, off, SEEK_SET) != 0) {
	 err_msg("fwipe: Failed to seek to offset position %lu", off);
	 error = 1;
      }

      if (!error && fwrite(buf, 1, len, f) != len) {
	 err_msg("fwipe: Failed to write buffer of %lu bytes", len);
	 error = 1;
      }

      /* Sync with phyisical i/o */
      fflush(f);
      fsync(fileno(f));

   }

   free(buf);

   return !error;
}
