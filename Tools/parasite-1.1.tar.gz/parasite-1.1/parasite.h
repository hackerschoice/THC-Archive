#include "config.h"

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#ifdef HAVE_STRING_H
#include <string.h>
#else
#ifdef HAVE_STRINGS_H
#include <strings.h>
#endif
#endif
#include <unistd.h>
#define _USE_BSD
#include <sys/types.h>
#include <sys/resource.h>
#include <sys/wait.h>
#include <sys/param.h>
#ifdef HAVE_SYS_SOCKET_H
#include <sys/socket.h>
#endif
#include <signal.h>
#ifdef HAVE_PATHS_H
#include <paths.h>
#endif
#include <netinet/in.h>
#ifdef HAVE_NET_IF_ARP_H
#include <net/if_arp.h>
#endif
#ifdef HAVE_NET_IF_ETHER_H
#include <net/if_ether.h>
#endif
#include <pcap.h>
#include <libnet.h>
#ifdef HAVE_CTYPE_H
#include <ctype.h>
#endif
#include <netdb.h>
#ifdef HAVE_PCAP_NAMEDB_H
#include <pcap-namedb.h>
#endif
#include <sys/ioctl.h>
#ifdef HAVE_SYS_SOCKIO_H
#include <sys/sockio.h>
#endif
#include <errno.h>
#ifndef MAXHOSTNAMELEN
#define MAXHOSTNAMELEN 256
#endif
#ifdef HAVE_SIGSET
#define SIGNALFUNC sigset
#else
#define SIGNALFUNC signal
#endif

#define IP_ADDR_LEN 4

#ifdef LINUX_SPEED_HACK
 #define ETH_HW_ADDR_LEN 6
 #define ARP_FRAME_TYPE 0x0806
 #define ETHER_HW_TYPE 1
 #define IP_PROTO_TYPE 0x0800
 #define OP_ARP_REQUEST 2
 struct arp_packet {
        u_char targ_hw_addr[ETH_HW_ADDR_LEN];
        u_char src_hw_addr[ETH_HW_ADDR_LEN];
        u_short frame_type;
        u_short hw_type;
        u_short prot_type;
        u_char hw_addr_size;
        u_char prot_addr_size;
        u_short op;
        u_char sndr_hw_addr[ETH_HW_ADDR_LEN];
        u_char sndr_ip_addr[IP_ADDR_LEN];
        u_char rcpt_hw_addr[ETH_HW_ADDR_LEN];
        u_char rcpt_ip_addr[IP_ADDR_LEN];
        u_char padding[18];
 };
#endif
