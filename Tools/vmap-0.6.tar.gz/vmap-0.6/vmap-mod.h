#ifndef _vmap_MOD_H
#define _vmap_MOD_H

#include "vmap.h"

extern void  vmap_register_socket(int s);
extern char *vmap_get_next_pair();
extern char *vmap_get_next_login();
extern char *vmap_get_next_password();
extern void  vmap_completed_pair();
extern void  vmap_report_found(FILE *fp);
extern int   vmap_connect_tcp(unsigned long int host, int port);
extern int   vmap_disconnect(int socket);
extern int   vmap_data_ready(int socket);
extern char *vmap_receive_line(int socket);
extern int   vmap_send(int socket, char *buf, int size, int options);
extern int   make_to_lower(char *buf);

int debug;
int verbose;
int waittime;
int port;
#endif
