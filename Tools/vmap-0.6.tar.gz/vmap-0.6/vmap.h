#ifndef _vmap_H
#define _vmap_H
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <signal.h>
#include <string.h>
#include <time.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <fcntl.h>
#include <ctype.h>
#include <sys/resource.h>
#include <sys/wait.h>
#include <dirent.h>
#include <regex.h>

typedef struct results {
	char *file_name;
	double matches;
} results;

int service_ftp(unsigned long int ip, char *login, char *pw, int port, int);
int service_pop3(unsigned long int ip, char *login, char *pw, int port, int);
int service_smtp(unsigned long int ip, char *login, char *pw, int port, int);
int service_imap(unsigned long int ip, char *login, char *pw, int port, int);
int service_http(unsigned long int ip, int port, int mode);
int service_named(unsigned long int ip, char *protocol, int port);
int vmap_send(int socket, char *buf, int size, int options);
char *vmap_receive_line(int socket);
int vmap_disconnect(int socket);
int vmap_reconnect(char *service, unsigned long int ip, char* login, char *pass, int port, int verbose);
char *fingerprint(int sock, unsigned long int ip, int port, char *login, char *pass, char *command_ptr, char *service);
char *recv_reply(int sock);

#endif
