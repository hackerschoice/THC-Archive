#include "vmap-mod.h"

extern char *vmap_EXIT;
char *buf;

int login_pop3(int s, char *login, char *pass) {
    char buffer[300];
    int i = 1;

    //printf("Logging in (pop3) .\r");
    while (i > 0 && vmap_data_ready(s) > 0)
        i = recv(s, buffer, 300, 0);
    sprintf(buffer, "USER %.250s\r\n", login);
    if (vmap_send(s, buffer, strlen(buffer), 0) < 0) {
        return -1;
    }
    //usleep(300000);
    buf = vmap_receive_line(s);
    if (buf == NULL) return -1;
    if (buf[0] != '+') {
        fprintf(stderr,"Error2: Not an POP3 protocol or service shutdown: %s\n", buf);
        free(buf);
        return(-1);
    }
    free(buf);

    sprintf(buffer, "PASS %.250s\r\n", pass);
    if (vmap_send(s, buffer, strlen(buffer), 0) < 0) {
        return -1;
    }
    buf = vmap_receive_line(s);
    if (buf == NULL)
        return -1;
    if (buf[0] == '+') {
            return 1;
    }

    free(buf);
    return -1;
}

int service_pop3(unsigned long int ip, char *login, char *pw, int port, int banner) {
    int sock = -1, myport = 110;
    int sp = 0;
    vmap_register_socket(sp);
    if (port != 0) myport = port;
    if (sock >= 0) sock = vmap_disconnect(sock);
       usleep(300000);
    if ((sock = vmap_connect_tcp(ip, myport)) < 0) {
       fprintf(stderr, "Error: Can't connect\n");
       exit(-1); 
    }
    buf = vmap_receive_line(sock);
    if (buf == NULL || buf[0] != '+') { /* check the first line */
       fprintf(stderr,"Error1: Not a POP3 protocol or service shutdown: %s\n", buf);
       free(buf);
       exit(-1);
    }
    if (banner)
	    printf("Banner says: %s", buf);
    free(buf);
    buf=malloc(1024);
    while (vmap_data_ready(sock) > 0)
          recv(sock, buf, 1024, 0);
          free(buf);
/* run the login function */
    if (login != NULL)
    {
	  if (login_pop3(sock, login, pw) < 0) {
	    fprintf(stderr,"Error: Can't login\n");
	    exit(-1);
	  }
    }
    return (sock);    
}
