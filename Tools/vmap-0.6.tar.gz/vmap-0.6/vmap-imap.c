#include "vmap-mod.h"

extern char *vmap_EXIT;
char *buf;

int login_imap(int s, char *login, char *pass) {
    char buffer[300];
    int i = 1;

    while (i > 0 && vmap_data_ready(s) > 0)
        i = recv(s, buffer, 300, 0);
    sprintf(buffer, "1 login \"%.100s\" \"%.100s\"\r\n", login, pass);
    if (vmap_send(s, buffer, strlen(buffer), 0) < 0) {
        return -1;
    }
    buf = vmap_receive_line(s);
    if (buf == NULL) return -11;
    if (strstr(buf, " NO ") != NULL || strstr(buf, "failed") != NULL) {
        free(buf);
        return(-1);
    }
    free(buf);

    return 1;
}

int service_imap(unsigned long int ip, char *login, char *pw, int port, int banner) {
    int sock = -1, myport = 143;
    int sp = 0;
    vmap_register_socket(sp);
    if (port != 0) myport = port;
    if (sock >= 0) sock = vmap_disconnect(sock);
       usleep(275000);
    if ((sock = vmap_connect_tcp(ip, myport)) < 0) {
       fprintf(stderr, "Error: Can't connect\n");
       exit(-1); 
    }
    buf = vmap_receive_line(sock);
    if (buf == NULL && strstr(buf, "OK") == NULL && buf[0] != '*')
    { /* check the first line */
       fprintf(stderr,"Error1: Not a IMAP protocol or service shutdown: %s\n", buf);
       free(buf);
       exit(-1);
    }
    if (banner)
    	printf("Banner says: %s", buf);
    free(buf);
    buf=malloc(1024);
    while (vmap_data_ready(sock) > 0)
          recv(sock, buf, 1024, 0);
          free(buf);
/* run the login function */
    if(login != NULL) {
	  if (login_imap(sock, login, pw) < 0) {
	    fprintf(stderr,"Error: Can't login\n");
	    exit(-1);
	  }
    }
    //else printf("WARNING: Not logging in. Without a login, results will be much less reliable.\n");
    return (sock);    
}
