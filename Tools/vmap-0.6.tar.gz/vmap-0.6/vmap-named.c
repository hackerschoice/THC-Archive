/* named support is very alpha and not functional at all,
 * if you know good ways to identify named daemons, please
 * drop me a mail. Regards */
 
  
#include "vmap-mod.h"

extern char *vmap_EXIT;
char *buf;

int service_named(unsigned long int ip, char *protocol, int port) {
    int sock = -1, myport = 53;
    int sp = 0;
    vmap_register_socket(sp);
    if (port != 0) myport = port;
    if (sock >= 0) sock = vmap_disconnect(sock);
       usleep(300000);
    if ((sock = vmap_connect_tcp(ip, myport)) < 0) {
       fprintf(stderr, "Error: Can't connect\n");
       exit(-1); 
    }
    usleep(300000);
    return (sock);
}

