#include "vmap-mod.h"

int service_http(unsigned long int ip, int port, int mode) {
    int sock = -1, myport = 80;
    int sp = 0;
    char *buf = malloc(2048);
    char *buf2, *buf3;
    vmap_register_socket(sp);
    if (port != 0) myport = port;
    if (sock >= 0) sock = vmap_disconnect(sock);
     usleep(300000);
    if ((sock = vmap_connect_tcp(ip, myport)) < 0) {
       fprintf(stderr, "Error: Can't connect\n");
       exit(-1); 
    }
    /* If we already connected, skip the banner check */
    if (mode == 1)
	    return (sock);
    
    if (vmap_send(sock, "HEAD / HTTP/1.0\r\n\r\n", 19, 0) < 0)
    	   return -1;
    
    usleep(300000);
    buf = vmap_receive_line(sock);
    if (buf == NULL) exit (-1);
    buf2 = strstr(buf, "Server: ");
    if (buf2 == NULL)
	    fprintf(stderr, "No Banner\n");
    buf2 += 8;
    buf3 = strchr(buf2, '\n');
    buf3++;
    buf3[0] = 0;
    if (buf2 != NULL)
	    printf("Banner says: %s", buf2);
    free (buf);
    vmap_disconnect(sock);
    vmap_register_socket(sp);
    if (port != 0) myport = port;
    if (sock >= 0) sock = vmap_disconnect(sock);
     usleep(300000);
    if ((sock = vmap_connect_tcp(ip, myport)) < 0) {
       fprintf(stderr, "Error: Can't connect\n");
       exit(-1); 
    }

    return (sock);
}
