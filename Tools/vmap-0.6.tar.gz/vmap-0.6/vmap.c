#include "vmap.h"

#define SERVICES "ftp smtp pop3 imap http"

#define MAXBUF 2048 

#define PROGRAM "vmap"
#define VERSION "v0.6"
#define AUTHOR "Whyking"
#define EMAIL "whyking@thc.org"

char *prg;
extern int port;
DIR *verz = NULL;
int verbose = 0;
struct dirent *directory = NULL;
unsigned int countcommand, sizecommand;

void help() {
	printf ("%s %s (c) 2003 by %s %s
Syntax: 
%s [-v] [-l LOGIN] [-p PASSWORD] [-a] [-s PORT] [-g VERSION] server service

Options:
	-v		verbose
	-l LOGIN 	login with LOGIN name
	-p PASSWORD 	login with PASSWORD
	-a		login as anonymous (ftp mode only)	
	-P PORT 	the port to connect to
	-c VERSION	create a new fingerprint and saves it to VERSION
	server 		the server to connect to
	service 	what service to run on [%s]

With %s you can find out the version of a daemon. %s tries to identify the version of the daemon according to the replies of some bogus commands.
Use this tool only for legal purposes!
", PROGRAM, VERSION, AUTHOR, EMAIL, prg, SERVICES, PROGRAM, PROGRAM);
	exit (-1);
}

void bail(char *text) {
	fprintf(stderr, "Error: %s\n", text);
	exit(-1);
}

unsigned long int countlines(FILE *fp) {
	size_t lines = 0, size = 0;
	char *buf = malloc(MAXBUF);

	while (!feof(fp)) {
		if (fgets(buf, MAXBUF, fp) != NULL) {
			if (buf[0] != 0) {
			size += strlen(buf);
			lines++;
			}
		}
	
	};
	rewind(fp);
	free(buf);
	size++;
	sizecommand = size;
	return lines;
}

void fill_mem(char *ptr, FILE *fp) {
	char *tmp = malloc(MAXBUF);
#ifdef DEBUG
        char *x = ptr;
#endif
	memset(ptr, 0, sizecommand + countcommand + 2);
	while (! feof(fp)) {
		if (fgets(tmp, MAXBUF, fp) != NULL) {
		        if (tmp[0] != 0) {
			        if (tmp[strlen(tmp)-1] == '\n')
				        tmp[strlen(tmp)-1] = '\0';
			        if (tmp[strlen(tmp)-1] == '\r')
				        tmp[strlen(tmp)-1] = '\0';
			        memcpy(ptr, tmp, strlen(tmp) + 1);
			        ptr += strlen(tmp);
			        ptr++;
		        }
		}
	}
	fclose(fp);
#ifdef DEBUG
    printf("DEBUG: fill_mem: %d (into alloc %d + %d + 2 = %d)\n", ptr - x, countcommand, sizecommand, countcommand + sizecommand + 2);
#endif
}

void save_to_file(char *receive_ptr, char *service, char *gather) {
        FILE *fingerprint_file;
        int i;
	char *buf = malloc(MAXBUF);
        char file_to_open[MAXBUF];
	char *receive_ptr_tmp = receive_ptr;
	char command[MAXBUF];
	
	if (service != "")
		snprintf(file_to_open, sizeof(file_to_open), "./%s/%s", service, gather);
	else
		snprintf(file_to_open, sizeof(file_to_open), "./%s", gather);

        if ((fingerprint_file = fopen(file_to_open, "w")) == NULL)
	{
		printf("Error: Can't open %s", file_to_open);
		exit(-1);
	}
	
	for (i = 0; i < countcommand; i++) 
	{
		memset(buf, 0, MAXBUF);
		while (*receive_ptr_tmp != '\0')
		{
			while(*receive_ptr_tmp != '\n')
			{	
				buf[strlen(buf)] = *receive_ptr_tmp;
				receive_ptr_tmp++;
			}
			if (*(receive_ptr_tmp+1) == '\0')
			{
				strcat(buf, "\n");
				receive_ptr_tmp++;
				break;
			}
			else
			{
				buf[strlen(buf)] = '\\';
				buf[strlen(buf)] = '+';
				buf[strlen(buf)] = '\n';
			}
			receive_ptr_tmp++;
		}
		strcat(buf, "\0");
	        fputs(buf, fingerprint_file);
	        if (*receive_ptr_tmp == '\0')
	              receive_ptr_tmp++;
	   
	}
	if (fclose(fingerprint_file) == -1)
	    bail("Error while fclose()");
	    
	    /* Escape Fingerprint with a little Perl script. I know... but I'm lazy ;). */
	snprintf(command, sizeof(command), "perl -pe 's/([.^\\$*+?{}\\[\\]\\\\|()])/\\\\$1/g;s/\\\\\\\\\\+/\\+/g' < %s > %s.tmp; mv %s.tmp %s;", file_to_open, file_to_open, file_to_open, file_to_open);
	if (system(command) == -1)
	    bail("Error in perl parser");
	if (service != "")
	    printf("Please send the file %s to %s so we can include it in our next release!\nDo not forget to tell us the exact type and version information...\n", file_to_open, EMAIL);
	free(buf);
}

char *return_file(char *dir) {
	if (verz == NULL)
		verz = opendir(dir);
	do {
		if ((directory = readdir(verz)) == NULL)
			return(NULL);
	} while (strcmp(directory->d_name, ".") == 0 || strcmp(directory->d_name, "..") == 0);
	return(directory->d_name);
}

void compare_to_files(char *receive_ptr, char *service) {
	FILE *fingerprint_file = NULL;
	int i = 0, j = 0, k, matched = 0, number=0, counter=0;
	char *buf = malloc(MAXBUF*16);
	char *buf2 = malloc(MAXBUF);
	char *buf_regex = malloc(MAXBUF);
	char *unknown = malloc(MAXBUF);
	char file_to_open[MAXBUF];
	char *saved_receive_ptr = receive_ptr;
	int uncomplete = 0;
	struct results result_db[MAXBUF]; /* MAXBUF == max number of fingerprints */
	struct results result_switch;
	regex_t *preg;
	regmatch_t *result;
	int err_no=0; /* For regerror() */
	
  	/* Make space for the regular expression */
  	preg = (regex_t *) malloc(sizeof(regex_t));
  	memset(preg, 0, sizeof(regex_t));
	if((result = (regmatch_t *) malloc(sizeof(regmatch_t)))==0)
    		 bail("Not enough memory");
	
     	while (return_file(service) != NULL) {
		snprintf(file_to_open, sizeof(file_to_open), "./%s/%s", service, directory->d_name);
		if ((fingerprint_file = fopen(file_to_open, "r")) == NULL)
			fprintf(stderr, "Error: Can not open %s for reading.\n", file_to_open);
		else {
		    if (verbose)
		        printf("Comparing now with %s", file_to_open);
		    for (j = 0; j < countcommand; j++) {
			if (fgets(buf, MAXBUF, fingerprint_file) == NULL)
			{
				if (verbose)
				    printf(" (File does not contain all fingerprints) ");
				uncomplete = 1;
				break;
			}
			if (buf[strlen(buf)-2]=='\r') {
  			    buf[strlen(buf)-2]='\n';
  			    buf[strlen(buf)-1]=0;
  			}
  			while ((buf[strlen(buf)-3] == '+' && buf[strlen(buf)-4] == '\\') || (buf[strlen(buf)-2] == '+' && buf[strlen(buf)-3] == '\\')) {
			        i = strlen(buf);
				if (buf[strlen(buf)-3] == '+') {
			    		//buf[i-4] = '\r';
			    		buf[i-4] = '\n';
			    		buf[i-3] = 0;
				}
				if (buf[strlen(buf)-2] == '+') {
					buf[i-3] = '\n';
					buf[i-2] = 0;
				}
				if (fgets(buf2, MAXBUF, fingerprint_file) != NULL) {
	   				if (buf2[strlen(buf2)-2]=='\r') {
	  			    	    buf2[strlen(buf2)-2]='\n';
  				            buf2[strlen(buf2)-1]=0;
  					}
  					if (strlen(buf) + strlen(buf2) + 2 > MAXBUF*16)
  					    bail("buffer would overflow");
					strcat(buf, buf2);
					memset(buf2, 0, MAXBUF);
				}
			}
			/* Does the reply match the database entry? */
                	sprintf(buf_regex, "^%s$", buf);    
			if ((err_no = regcomp(preg, buf_regex, REG_EXTENDED)) != 0)
			{
				size_t length;
      				char *errormsg;
			        length = regerror (err_no, preg, NULL, 0);
				errormsg = malloc(length);
				regerror (err_no, preg, errormsg, length);
				fprintf(stderr, "Error in regex expression: %s\n", errormsg);
				free(errormsg);
				regfree(preg);
			}
		    
  			if (regexec(preg, receive_ptr, 1, result, 0) == 0)
				matched++;
			else
			        if (strstr(receive_ptr, buf) != NULL)
	 				matched++;
			regfree(preg);
  			while (*receive_ptr != '\0') receive_ptr++;
			receive_ptr++;
			memset(buf, 0, MAXBUF);
			}
		    }
	
			receive_ptr = saved_receive_ptr;
		    if (matched > countcommand/2)
		    {
			    result_db[counter].file_name = malloc(MAXBUF);
			    strncpy(result_db[counter].file_name, directory->d_name, MAXBUF-1);
			    result_db[counter].matches = (double)matched/j*100;
			    /*Substract 5% if the fingerprint is not uptodate*/
			    if (uncomplete == 1)
			    {
				    result_db[counter].matches -= 5;
				    uncomplete = 0;
			    }
			    number++;
		    }
		    if (verbose)
		        printf(" -> %.2f%%\n", result_db[counter].matches);
		    counter++;
		    matched = 0;
		    memset(buf, 0, MAXBUF);
		    memset(buf2, 0, MAXBUF);
		    fclose(fingerprint_file);
		
	}
	if (number == 0)
	{
		//printf("---- vmap FINGERPRINT: DAEMON %s ----\n", service);
		service[strlen(service)-3] = 0;
		snprintf(unknown, MAXBUF, "unknown_%sd.fp", service);
		save_to_file(receive_ptr, "", unknown);
		//printf("---- END OF FINGERPRINT ----\n");
		printf("Unknown fingerprint!\nIf you know the exact version, please send the file %s to %s so we can include it in our next release!\nDo not forget to tell us the exact type and version information...\n", unknown, EMAIL);
	}
	/* Simple Bubble Sort Alg, I don't care about your cycles ;) */
	else {
		for (i=0; i < counter; i++)
		{
			for (k=0; k < counter-1; k++)
			{
				if(result_db[k].matches < result_db[k+1].matches)
				{
					result_switch = result_db[k];
					result_db[k] = result_db[k+1];
					result_db[k+1] = result_switch;
				}
			}
		}
		printf("Remote Daemon guess: %s with %.2f%%.\n", result_db[0].file_name, result_db[0].matches);
		if (result_db[1].file_name != NULL)
			printf("2nd guess: %s with %.2f%%.\n", result_db[1].file_name, result_db[1].matches);
	}
	
	free(buf);
	free(buf2);
	free(buf_regex);
	free(preg);
}		
		
int main(int argc, char *argv[])
{
	FILE *cfp;
	struct hostent *target;
	char *command_ptr = NULL, *reply_ptr;
	char *login = NULL, *pass = NULL, *gather = NULL;
	char *server, *service, *service_dir = malloc(MAXBUF);
	unsigned long int ip;
	int i, sock = 0, delay = 0;

	prg = argv[0];
	if (argc < 2 || strcmp(argv[1], "-h") == 0) help();
	port = 0;
	
	setvbuf(stdout, NULL, _IONBF, 0);

	while ((i = getopt(argc, argv, "al:p:P:c:d:v")) >= 0) {
		switch (i) {
			case 'l': login = optarg; break;
			case 'p': pass = optarg; break;
			case 'a': login = malloc(12);
				  pass = malloc(8);
				  strcpy(login, "anonymous");
				  strcpy(pass, "vmap@");
				  break;
			case 'P': port = atoi(optarg); break;
			case 'c': gather = optarg; break;
			case 'd': delay = atoi(optarg); break;
			case 'v': verbose = 1; break;
			default: fprintf (stderr, "Error: unknown option -%c\n", i); help();
		}
	}
	server = argv[argc-2];
	service = argv[argc-1];
	
	/* resolve target */
	if ((ip = inet_addr(server)) == -1) {
	    if ((target = gethostbyname(server)) == NULL) {
	        perror(server);
	        exit(-1);
	    }
	    memcpy(&ip, target->h_addr, target->h_length);
	}
	    
	i = 0;
	if (strcmp(service, "ftp") == 0) {
		i = 1;
		if ((cfp = fopen("./commands/ftp", "r")) == NULL)
		       	bail("File with FTP commands not found!");
		countcommand = countlines(cfp);
		if (countcommand == 0)
		          bail("File with FTP commands is empty!");
		command_ptr = malloc(sizecommand + countcommand + 2);
		fill_mem(command_ptr, cfp);
		sock = service_ftp(ip, login, pass, port, 1);
	}

	if (strcmp(service, "smtp") == 0) {
		i=1;
		if ((cfp = fopen("./commands/smtp", "r")) == NULL)
			bail("File with SMTP commands not found!");
		countcommand = countlines(cfp);
		if (countcommand == 0)
			bail("File with SMTP commands is empty!");
		command_ptr = malloc(sizecommand + countcommand + 2);
		fill_mem(command_ptr, cfp);
		sock = service_smtp(ip, login, pass, port, 1);
	}

	if (strcmp(service, "pop3") == 0) {
		i=1;
		if ((cfp = fopen("./commands/pop3", "r")) == NULL)
			bail("File with POP3 commands not found!");
		countcommand = countlines(cfp);
		if (countcommand == 0)
			bail("File with POP3 commands is empty!");
		command_ptr = malloc(sizecommand + countcommand + 2);
		fill_mem(command_ptr, cfp);
		sock = service_pop3(ip, login, pass, port, 1);
	}
	
	if (strcmp(service, "imap") == 0) {
		i=1;
		if ((cfp = fopen("./commands/imap", "r")) == NULL)
			bail("File with IMAP commands not found!");
		countcommand = countlines(cfp);
		if (countcommand == 0)
			bail("File with IMAP commands is empty!");
		command_ptr = malloc(sizecommand + countcommand + 2);
		fill_mem(command_ptr, cfp);
		sock = service_imap(ip, login, pass, port, 1);
	}
	
	if (strcmp(service, "http") == 0) {
		i=1;
		if ((cfp = fopen("./commands/http", "r")) == NULL)
			bail("File with HTTP commands not found!");
		countcommand = countlines(cfp);
		if (countcommand == 0)
			bail("File with HTTP commands is empty!");
		command_ptr = malloc(sizecommand + countcommand + 2);
		fill_mem(command_ptr, cfp);
		sock = service_http(ip, port, 0);
	}


	if (strcmp(service, "named") == 0) {
		i=1;
		sock = service_named(ip, "tcp", port);
		//fingerprint_named();
	}

	if (i==0) bail("Unknown service");

	/* Fingerprint */
	if ((reply_ptr = fingerprint(sock, ip, port, login, pass, command_ptr, service)) == NULL)
		bail("Error while fingerprinting");
	
        /* Check if we fingerprint with or without login */
        if (login != NULL)
                sprintf(service_dir, "%s/wl", service);
        else
                sprintf(service_dir, "%s/wo", service);

        if (gather != NULL)
                save_to_file(reply_ptr, service_dir, gather);
        else
                compare_to_files(reply_ptr, service_dir);

        vmap_disconnect(sock);
        free(service_dir);
        return 0;
}

char *fingerprint(int sock, unsigned long int ip, int port, char *login, char *pass, char *command_ptr, char *service)	
{
	int a, b;
	unsigned int length = 0;
	char sb[MAXBUF];
	char *buf;
	char *reply_ptr, *tmp_reply_ptr;
	int ms = 0; /* MS-FTPs seem to hang on certain commands and stop responding*/
	printf("Fingerprinting...\n");
	tmp_reply_ptr = reply_ptr = malloc(countcommand * MAXBUF);
	memset(reply_ptr, 0, countcommand * MAXBUF);

	for (a=0; a < countcommand; a++) {
		/* HTTP disconnects us after each try */
		if (strcmp(service, "http") == 0)
		{
			vmap_disconnect(sock);
			sock = service_http(ip, port, 1);
			snprintf(sb, sizeof(sb), "%s\r\n\r\n", command_ptr);
		}
		else
			snprintf(sb, sizeof(sb), "%s\r\n", command_ptr);
		
		/* Sends the command */
		b = vmap_send(sock, sb, strlen(sb), 0);

		/* Receive a reply */
		if (b < 0 || (buf = recv_reply(sock)) == NULL) 
		{
			/* We got disconnected */
                        if((sock = vmap_reconnect(service, ip, login, pass, port, verbose)) == -1)
		        	bail("Error: Can't reconnect.\n");
			if (++ms < 2 || b < 0)
			{
				a--;
                        	continue;
			}
			buf = malloc(MAXBUF);
			strcpy(buf,"\0");
			ms = 0;
		}	
		
		/* Check if the other side just sent sth */
		if (buf[0] == '\0')
		{
			strcpy(buf, "\n\0");
			if (++ms >= 2)
			{
				//printf("The other side isn't responding to our commands, we reconnect and skip this command\n");
				if((sock = vmap_reconnect(service, ip, login, pass, port, verbose)) == -1)
					bail("Error: Can't reconnect");
				a--;
				ms = 0;
				continue;
			}
		} 
		/* Append the reply to the receive_ptr */
		if (buf[strlen(buf)-2] == '\r') {
		    buf[strlen(buf)-2] = '\n';
		    buf[strlen(buf)-1] = 0;
		}
		length += strlen(buf);
                if (length < countcommand * MAXBUF) {
                    memcpy(tmp_reply_ptr, buf, strlen(buf));
                } else
                    bail("Reply buffer would overflow");
                tmp_reply_ptr += strlen(buf);
		tmp_reply_ptr++;
		length++;
		free(buf);

                /* Step until the end of *command_ptr */
                if (a < countcommand) {
                        while (*command_ptr != '\0') command_ptr++;
                        command_ptr++;
                }
	}
	return reply_ptr;
}

char *recv_reply(int sock)
{
	char *reply  = malloc(MAXBUF);
	char *buf = NULL;
	char *newline = NULL;
	int  length  = 0;
	int  result  = 0;
	int  flag    = 0;
	fd_set readfds;
	struct timeval tv;
	tv.tv_usec   = 0;
	tv.tv_sec    = 3;
	memset(reply, 0, sizeof(reply));
	
	/* Receives the reply */
	while(1)
	{
		FD_ZERO(&readfds);
                FD_SET(sock, &readfds);
                result = select(sock+1, &readfds, NULL, NULL, &tv);
                if (FD_ISSET(sock, &readfds) && result > 0) 
		{
                	/* If true, append it to the end of the reply */
                	if ((buf = vmap_receive_line(sock)) != NULL) 
			{
                        	flag = 1;
				length += strlen(buf);
				/* Check if reply is empty */
				if (*reply != 0)
				{
					/* Append it to the end */
					if (strlen(reply) + strlen(buf) >= MAXBUF)
						bail("Reply buffer would overflow");
					else
						strcat(reply, buf);
				} 
				else
				  if (strlen(buf) >= MAXBUF)
				  	bail("Reply buffer would overflow");
				  else
				  	strcpy(reply, buf);
			} 
			else 
				if (*reply != 0) 
					return reply;
			else return NULL;
		} else break;
		/* We don't want to wait 5 seconds for more traffic to come */
		tv.tv_sec  = 0;
		tv.tv_usec = 550000;
	} 
	if (flag != 0)
		free(buf);
	/* Cut out the \r */
	while ((newline = strstr(reply, "\r\n"))!=NULL)
		memmove(newline, newline+1, strlen(newline));

	return reply;
}

