/* ripped from van hauser's hydra-1.3 */

#include "vmap-mod.h"

#define MAX_CONNECT_RETRY 1
#define WAIT_BETWEEN_CONNECT_RETRY 3

int intern_socket, extern_socket;
char pair[260];
char vmap_EXIT[5] = "\x00\xff\x00\xff\x00";
char *vmap_EMPTY = "\x00\x00\x00\x00";
int fail = 0;
int alarm_went_off = 0;

void interrupt() {
    if (debug) printf("DEBUG_INTERRUPTED\n");
}

void vmap_register_socket(int s) {
    intern_socket = s;
}

int vmap_reconnect(char *service, unsigned long int ip, char* login, char *pass, int port, int verbose)
{
	int sock=-1;
	sleep(2);
	signal(SIGPIPE, SIG_IGN);
	if (verbose)
		printf("We got disconnected, trying to reconnect...\n");
	if (!strcmp(service, "ftp"))
		sock=service_ftp(ip, login, pass, port, 0);
	if (!strcmp(service, "smtp"))
		sock=service_smtp(ip, login, pass, port, 0);
	if (!strcmp(service, "pop3"))
		sock=service_pop3(ip, login, pass, port, 0);
	if (!strcmp(service, "imap"))
		sock=service_imap(ip, login, pass, port, 0);
	return sock;
}

int vmap_connect_tcp(unsigned long int host, int port) {
    int s, ret = -1;
    struct sockaddr_in target;
    if ((s = socket(PF_INET, SOCK_STREAM, 6)) >= 0) {
          target.sin_port=htons(port);
          target.sin_family=AF_INET;
          memcpy(&target.sin_addr.s_addr,&host,4);
          do {
              if (fail > 0) sleep(WAIT_BETWEEN_CONNECT_RETRY);
              alarm_went_off = 0;
              alarm(waittime);
              ret = connect(s,(struct sockaddr*) &target, sizeof(target));
              alarm(0);
              if (ret < 0 && alarm_went_off == 0) {
                  fail++;
                  if (verbose && fail <= MAX_CONNECT_RETRY) fprintf(stderr, "Process %d: Can not connect [unreachable], retrying (%d of %d retries)\n", getpid(), fail, MAX_CONNECT_RETRY);
              }
          } while (ret < 0 && fail <= MAX_CONNECT_RETRY);
          if (ret < 0 && fail > MAX_CONNECT_RETRY) {
              if (debug) printf("DEBUG_CONNECT_UNREACHABLE\n");
              extern_socket = -1;
              ret = -1;
              return ret;
          }
          ret = s;
          extern_socket = s;
          if (debug) printf("DEBUG_CONNECT_OK\n");
          fail = 0;
    }
    return ret;
}

int vmap_disconnect(int socket) {
    close(socket);
    if (debug) printf("DEBUG_DISCONNECT\n");
    return -1;
}

int vmap_data_ready_writing_timed(int socket, long sec, long usec) {
    fd_set fds;
    struct timeval tv;

    FD_ZERO(&fds);
    FD_SET(socket, &fds);
    tv.tv_sec = sec;
    tv.tv_usec = usec;

    return(select(socket + 1, &fds, NULL, NULL, &tv));
}

int vmap_data_ready_writing(int socket) {
    return(vmap_data_ready_writing_timed(socket, 30, 0));
}

int vmap_data_ready_timed(int socket, long sec, long usec) {
    fd_set fds;
    struct timeval tv;

    FD_ZERO(&fds);
    FD_SET(socket, &fds);
    tv.tv_sec = sec;
    tv.tv_usec = usec;

    return(select(socket + 1, &fds, NULL, NULL, &tv));
}

int vmap_data_ready(int socket) {
    return(vmap_data_ready_timed(socket, 0, 100));
}

char *vmap_receive_line(int socket) {
    char buf[1024], *buff;
    int i = 0, j = 0, k;
   
    buff = malloc(sizeof(buf));
    memset(buff, 0, sizeof(buf));

    i = vmap_data_ready_timed(socket, 15, 0);
    if (i > 0) {
	  if ((i = recv(socket, buff, sizeof(buf), 0)) < 0) {
            		free(buff);
            		return NULL;
          }
	  if (i == 0)
		  i = -1;

    }
    if (i == 0)
    {
	    strcpy(buff, "\r\n");
    }
    if (i < 0) {
        if (debug) printf("DEBUG_RECV_BEGIN|%s|END\n", buff);
        free(buff);
        return NULL;
    } else {
        for(k = 0; k < i; k++)
            if (buff[k] == 0)
                buff[k] = 32;
    }

    j = 1;
    while(vmap_data_ready(socket) > 0 && j > 0) {
        j = recv(socket, buf, sizeof(buf), 0);
        if (j > 0) {
            for(k = 0; k < j; k++)
                if (buff[k] == 0)
                    buff[k] = 32;
            buff=realloc(buff,i+j);
            memcpy(buff+i,&buf,j);
	    i=i+j;
	}
    }

    if (debug) printf("DEBUG_RECV_BEGIN|%s|END\n", buff);
    return buff;
}

int vmap_send(int socket, char *buf, int size, int options) {
    if (debug) printf("DEBUG_SEND_BEGIN|%s|END\n", buf);
    return(send(socket, buf, size, options));
}

int make_to_lower(char *buf) {
    if (buf == NULL) return 1;
    while (buf[0] != 0) {
        buf[0]=tolower(buf[0]);
        buf++;
    }
    return 1;
}
