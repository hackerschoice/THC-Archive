/*
 * $Id:$
 */

#ifndef __THCRUT_ARP_MAIN_H__
#define __THCRUT_ARP_MAIN_H__ 1

int arp_main(int argc, char *argv[]);

#endif /* !__THCRUT_ARP_MAIN_H__ */
