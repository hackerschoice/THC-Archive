/* bscan - icmp include file
 */

#ifndef THCRUT_DCD_ICMP_H
#define THCRUT_DCD_ICMP_H 1

#define	ICMP_HDRSIZE	8

const char *
icmp_str (int type, int code);

#endif  /* !THCRUT_DCD_ICMP_H */

