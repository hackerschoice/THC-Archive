/*
 * $Id:$
 */

#ifndef __THCRUT_TTY_H__
#define __THCRUT_TTY_H__ 1

void tty_init(void);
void tty_dinit(void);

#endif
