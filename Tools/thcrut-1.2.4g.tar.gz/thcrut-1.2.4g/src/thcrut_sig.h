/*
 * $Id: thcrut_sig.h,v 1.1 2002/11/22 18:54:49 skyper Exp $
 */

#ifndef __THCRUT_SIGNAL_H__
#define __THCRUT_SIGNAL_H__ 1

void signal_parent_init(void);
void signal_child_init(void);

#endif /* !__THCRUT_SIGNAL_H__ */
