/*
 * thc-rut config.h (from acconfig.h) file
 * anonymous@segfault.net
 */

/* Some define */
#undef WITH_LEETO

/* Some other define */
#undef WITH_MANUF

/* whether to include README help file in compilation */
#undef WITH_README

@TOP@
