#ifndef THCRUT_NETWORK_RAW_H
#define THCRUT_NETWORK_RAW_H 1

#define int_ntoa(x)   inet_ntoa(*((struct in_addr *)&(x)))

int vrfy_ip (struct ip *, uint32_t, u_short *);
int vrfy_udp (struct udphdr *, uint32_t);
int vrfy_icmp (struct icmp *, uint32_t);
char *int_ntop(char *, struct in_addr);
char *val2mac(unsigned char *);

#endif /* !THCRUT_NETWORK_RAW_H */

