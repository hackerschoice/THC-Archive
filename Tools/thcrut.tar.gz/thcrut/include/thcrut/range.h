#ifndef THCRUT_RANGE_H
#define THCRUT_RANGE_H 1

#ifndef ETH_ALEN
#define ETH_ALEN               6
#endif

struct _bmac
{
    unsigned char  start_mac[ETH_ALEN];
    unsigned char  saved_sm[ETH_ALEN];
    unsigned char  end_mac[ETH_ALEN];
    unsigned char  saved_em[ETH_ALEN];
    unsigned char  current[ETH_ALEN];
    unsigned char  ltag;       /* left tag value */
    unsigned char  saved_ltag;
    unsigned char  firstround; /* err..dirty */
    unsigned long  count;   /* -1 means REALLY MANY, 1 is min. value */
};

struct _bip
{
    unsigned long  start_ip;       /* HBO */
    unsigned long  end_ip;         /* HBO */
    unsigned long  current;        /* HBO */
};


int init_next_ip(char *, struct _bip *);
int init_next_mac(unsigned char *, struct _bmac *);
int reset_next_mac(struct _bmac *);
unsigned long *next_ip(struct _bip *, unsigned long *);
unsigned char *next_mac(struct _bmac *);

#endif /* !THCRUT_RANGE_H */
