#!/bin/sh
test -e "$1" || { echo -e 'Syntax: $0 file\nFile to unique the coordinates from'; exit 1; }

cat $1 | awk '{print $3" "$4}' | grep -v '?' | egrep '[0-9][NS] .*[0-9][EW]' | sort | uniq
