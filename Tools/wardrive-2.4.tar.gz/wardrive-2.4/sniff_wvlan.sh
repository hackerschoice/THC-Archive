#!/bin/sh
test -z "$DEV" && DEV="$DEVICE"
test -z "$DEV" && DEV=eth0

dsniff=dsniff.$$.sniff
tcpd=tcpdump.$$.sniff

dsniff -i $DEV -n -m -s 2500 > $dsniff 2> /dev/null &
{
tcpdump -l -i $DEV -n -s 2500 -w $tcpd ip or arp 2> /dev/null

for i in $tcpd $dsniff ; do
    test -e "$i" && {
	SIZE=`/bin/ls -ld -- $i|awk '{print $5}'`
	test "$SIZE" -le 24 && rm -f -- $i
    }
    test -e "$i" -a -e wardrive.stat && (
	WINFO=`grep -w SSID wardrive.stat | tail -1 | sed 's/.*SSID:"//' | \
	    sed 's/".*Point:/-/' | sed 's/[ !;.]//g'`
	test -z "$WINFO" && WINFO="unknown"
	TIME=`/bin/ls -ld -- $i|awk '{print $6"-"$7"-"$8}'|sed 's/ //g'`
	j=`echo "$i" | sed "s/\..*/_${WINFO}_${TIME}.sniff/"`
	mv $i $j
    )
done
} &
