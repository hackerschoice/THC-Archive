#ifndef __MINSOCK_H
#define __MINSOCK_H

int             sck_listen_accept_tcp(int);
int             sck_connect_tcp(char *, int);
void            sck_close(int);

#endif
