#include <minsock.h>
#include <unistd.h>
#include <string.h>
#include <misc.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/time.h>
#include <fcntl.h>

#ifdef __WINDOWS__
#include <winsock2.h>

int             wsa_init = 0;
#endif

/*
 * listen on tcp port p and accept one connection.
 * return the socket or -1.
 */
int
sck_listen_accept_tcp(int p)
{
    struct timeval  tv;
    fd_set          fds;
    int             sock = 0, f, nlen = sizeof(struct sockaddr_in);
    struct sockaddr_in sin;

#ifdef __WINDOWS__
    WSADATA         wsaData;

    if (!wsa_init) {
	if (WSAStartup(MAKEWORD(2, 1), &wsaData) != 0) {
	    die("WSAStartup failed.");
	}
	wsa_init = 1;
    }
#endif

    memset(&sin, 0, nlen);
    sin.sin_family = AF_INET;
    sin.sin_port = htons(p);
    sin.sin_addr.s_addr = INADDR_ANY;

    if ((sock = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP)) == -1)
	return -1;

#ifdef SO_REUSEPORT
    f = 1;
    if (setsockopt(sock, SOL_SOCKET, SO_REUSEPORT, &f, sizeof(int)) != 0)
	return -1;
#endif

    if (bind(sock, (struct sockaddr *) & sin, nlen) == -1)
	return -1;

    if (listen(sock, 1) == -1)
	return -1;

    //if (fcntl(sock, F_SETFL, O_NONBLOCK) == -1)
	//return -1;

    if (sock > FD_SETSIZE)
	return -1;

    FD_ZERO(&fds);
    FD_SET(sock, &fds);

    tv.tv_usec = 0;
    tv.tv_sec = 10;

    if (select(sock + 1, &fds, NULL, NULL, &tv) <= 0) {
	close(sock);
	return -1;
    }
    if ((f = accept(sock, (struct sockaddr *) & sin, &nlen)) == -1)
	return -1;

    close(sock);

    return f;
}


int
sck_connect_tcp(char *server, int w)
{
    int             sock, nlen = sizeof(struct sockaddr_in);
    struct sockaddr_in sin;

#ifdef __WINDOWS__
    WSADATA         wsaData;

    if (!wsa_init) {
	if (WSAStartup(MAKEWORD(2, 1), &wsaData) != 0) {
	    die("WSAStartup failed.");
	}
	wsa_init = 1;
    }
#endif

    sin.sin_family = AF_INET;
    sin.sin_port = htons(w);
    sin.sin_addr.s_addr = inet_addr(server);

    if ((sock = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP)) == -1)
	return -1;

    if (connect(sock, (struct sockaddr *) & sin, nlen) != 0)
	return -1;

    return sock;
}


void
sck_close(int f)
{
#ifndef __WINDOWS__
    close(f);
#else
    shutdown(f, 1);
    closesocket(f);
#endif
}
