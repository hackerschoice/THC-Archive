/*
 *  lua utils library
 *  Authors: rd@thc.org, anonymous
 */

#include <utils_lua.h>
#include <stdio.h>
#include <stdlib.h>
#include <lua.h>
#include <lauxlib.h>
#include <lualib.h>

#include <main.h>
#include <nids.h>
#include <misc.h>
#include <base64.h>
#include <packlib.h>

/*
 * utils lua library functions
 */
static int
utils_base64(lua_State * s, int enc)
{
    const char     *b;
    char           *buf;
    size_t          l = 0;

    if ((b = luaL_checklstring(s, 1, &l)) == NULL)
	return 1;

    l = base64(enc, b, l, &buf);

    if (buf == NULL) {
	lua_pushnil(s);
	return 1;
    }
    lua_pushlstring(s, buf, l);

    return 1;
}

static inline int
utils_base64_encode(lua_State * s)
{
    return utils_base64(s, 1);
}

static inline int
utils_base64_decode(lua_State * s)
{
    return utils_base64(s, 0);
}

static inline int
utils_pack(lua_State * s)
{
    return utils_lib_pack(s);
}

static inline int
utils_unpack(lua_State * s)
{
    return utils_lib_unpack(s);
}

static const luaL_reg lib_utils[] = {
    {"base64_encode", utils_base64_encode},
    {"base64_decode", utils_base64_decode},
    {"bpack", utils_pack},
    {"bunpack", utils_unpack},
    {NULL, NULL}
};

int
luaopen_utils(lua_State * state)
{
    luaL_openlib(state, LUA_UTILSLIBNAME, lib_utils, 1);
    return 1;
}
