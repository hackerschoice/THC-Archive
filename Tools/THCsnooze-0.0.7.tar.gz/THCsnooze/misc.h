#ifndef __MISC_HH
#define __MISC_HH

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>

char           *xstrdup(const char *);
void           *xmalloc(const size_t);
void           *xrealloc(void *, const size_t);

int             file_exists(const char *);
off_t           file_size(const char *);
int             file_is_symlink(const char *);

void            die(char *);
void            debug_set_level(int);
void            debug(int, char *,...);
int             xstr2num(char *);

int             snooze_memcmp (void *, size_t, void *, size_t);
#endif
