#!/bin/sh

FILE_LIBNIDS=libnids-1.19.tar.gz
FILE_PCRE=pcre-5.0.tar.bz2
FILE_LUA=lua-5.0.2.tar.gz
FILE_PCAP=libpcap-0.8.3.tar.gz
FILE_AMAP=amap-5.0.tar.gz


URL_LIBNIDS=http://umn.dl.sourceforge.net/sourceforge/libnids/libnids-1.19.tar.gz
URL_PCRE=ftp://ftp.csx.cam.ac.uk/pub/software/programming/pcre/pcre-5.0.tar.bz2
URL_LUA=http://www.lua.org/ftp/lua-5.0.2.tar.gz
URL_PCAP=http://www.tcpdump.org/release/libpcap-0.8.3.tar.gz
URL_AMAP=http://www.thc.org/releases/amap-5.0.tar.gz

check_curl () {
	if [ ! -z "$CURL" ]; then
		return
	fi

	echo -n "Cheching for curl ... "
	CURL=`which curl | grep -v no -`
	if [ -z "$CURL" ]; then
		WGET=`which wget | grep -v no -`
		if [ -z "$WGET" ]; then
			echo "nope! no wget found."
			exit 1
		else
			echo "no. but found wget."
		fi
	else
		echo $CURL
	fi
}

check_tar () {
	if [ ! -z "$TAR" ]; then
		return
	fi

	echo -n "Checking for tar ... "
	TAR=`which tar | grep -v no -`
	if [ ! -z "$TAR" ]; then
		echo $TAR
	else
		TAR=`which gnutar`
		if [ ! -z "$TAR" ]; then
			echo $TAR
		else
			echo "nope! exiting."
		fi
	fi
}

check_bunzip2 () {
	if [ ! -z "$BUNZIP2" ]; then
		return
	fi

	echo -n "Checking for bunzip2 ... "
	BUNZIP2=`which bunzip2 | grep -v no -`
	if [ -z "$BUNZIP2" ]; then
		echo "nope! exiting."
		exit 1
	else
		echo $BUNZIP2
	fi
}

check_gunzip () {
	if [ ! -z "$GUNZIP" ]; then
		return
	fi

	echo -n "Checking for gunzip ... "
	GUNZIP=`which gunzip | grep -v no -`
	if [ -z "$GUNZIP" ]; then
		echo "nope! exiting."
		exit 1
	else
		echo $GUNZIP
	fi
}

#
#
#
get_amap () {
	if [ ! -f $FILE_LIBNIDS ]; then
		echo "Fetching amap ..."
		if [ ! -z $CURL ]; then
			$CURL $URL_AMAP > $FILE_AMAP
		else
			$WGET $URL_AMAP
		fi
		echo "done."
	fi
}

get_libnids () {
	if [ ! -f $FILE_LIBNIDS ]; then
		echo "Fetching libnids ..."
		if [ ! -z $CURL ]; then
			$CURL $URL_LIBNIDS > $FILE_LIBNIDS
		else
			$WGET $URL_LIBNIDS
		fi
		echo "done."
	fi
}

get_pcre () {
	if [ ! -f $FILE_PCRE ]; then
		echo "Fetching pcre ..."
		if [ ! -z $CURL ]; then
			$CURL $URL_PCRE > $FILE_PCRE
		else
			$WGET $URL_PCRE
		fi
		echo "done."
	fi
}


get_lua () {
	if [ ! -f $FILE_LUA ]; then
		echo "Fetching lua ..."
		if [ ! -z $CURL ]; then
			$CURL $URL_LUA > $FILE_LUA
		else
			$WGET $URL_LUA
		fi
		echo "done."
	fi
}

get_pcap () {
	if [ ! -f $FILE_PCAP ]; then
		echo "Fetching libpcap ..."
		if [ ! -z $CURL ]; then
			$CURL $URL_PCAP > $FILE_PCAP
		else
			$WGET $URL_PCAP
		fi
		echo "done."
	fi
}


amap_install () {
	if [ ! -f $FILE_AMAP ]; then
		check_curl
		get_amap
	fi

	if [ ! -d amap-5.0 ]; then
		check_tar
		check_gunzip
		$TAR xzf $FILE_AMAP
		chmod 755 amap-5.0
	fi

	if [ ! -f amap-5.0/amap ]; then
		cd amap-5.0 && ./configure && make && cd ..
	fi
}


nids_install () {
	if [ ! -f $FILE_LIBNIDS ]; then
		check_curl
		get_libnids
	fi

	if [ ! -d libnids-1.19 ]; then
		check_tar
		check_gunzip
		$TAR xzf $FILE_LIBNIDS
	fi

	if [ ! -f src/libnids.a ]; then
		cd libnids-1.19 && ./configure --disable-libnet && make && cd src && ranlib libnids.a && cd ../..
	fi
}

pcre_install () {
	if [ ! -f $FILE_PCRE ]; then
		check_curl
		get_pcre
	fi

	if [ ! -d pcre-5.0 ]; then
		check_tar
		check_bunzip2
		$TAR xjf $FILE_PCRE
	fi

	if [ ! -f .libs/libpcre.a ]; then
		cd pcre-5.0 && ./configure --disable-shared && make && cd ..
	fi
}

lua_install () {
	if [ ! -f $FILE_LUA ]; then
		check_curl
		get_lua
	fi
	if [ ! -d lua-5.0.2 ]; then
		check_tar
		check_gunzip
		$TAR xzf $FILE_LUA
	fi

	if [ ! -f lib/liblua.a ]; then
		cd lua-5.0.2 && ./configure && make && cd ..
	fi
}

pcap_install () {
	if [ ! -f $FILE_PCAP ]; then
		check_curl
		get_pcap
	fi
	if [ ! -d libpcap-0.8.3.tar.gz ]; then
		check_tar
		check_gunzip
		$TAR xzf $FILE_PCAP
	fi

	if [ ! -f lib/liblua.a ]; then
		cd libpcap-0.8.3 && ./configure && make && cd ..
	fi
}


if [ -z $1 ]; then
	echo "Usage: $0 <lib>"
	echo "   where libs is one of:"
	echo "       libnids"
	echo "       libpcre"
	echo "       liblua"
	echo "       libpcap"
	echo "       amap"
fi

case $1 in
libnids)
	nids_install
	;;
libpcre)
	pcre_install
	;;
liblua)
	lua_install
	;;
libpcap)
	pcap_install
	;;
amap)
	amap_install
	;;
esac
