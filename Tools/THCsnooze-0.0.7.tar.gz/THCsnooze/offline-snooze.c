#include <stdio.h>
#include <stdlib.h>
#include <misc.h>
#include <offline-snooze.h>
#include <snooze_lua.h>
#include <module.h>

FILE           *f = NULL;

int             udp = 0, tcp = 0, data_len = 0, finished = 0;

unsigned short  src_port = 0, dst_port = 0;
unsigned int    src_addr = 0, dst_addr = 0;

unsigned char  *server_data = NULL, *client_data = NULL, *udp_data = NULL, *save_data = NULL;


void
read_until(char *b, int l, char d)
{
    char            buf[2];

    while (!feof(f) && l) {
	if (fread(buf, 1, 1, f) < 1)
	    return;

	if (buf[0] == ':') {
	    *b = '\0';
	    return;
	}
	*b++ = buf[0];
	l--;
    }
}


void
pull_data()
{
    char            buf[64];
    int             c = 0, s = 0;

    if (udp) {
	if (udp_data != NULL)
	    free(udp_data);
    } else {
	if (server_data != NULL)
	    free(server_data);
	if (client_data != NULL)
	    free(client_data);
    }

    udp_data = NULL;
    server_data = NULL;
    client_data = NULL;
    data_len = 0;

    if (feof(f))
	return;

    if (tcp) {
	memset(buf, 0, 64);
	do {
	    if (fread(buf, 1, 7, f) != 7)
		die("fread");

	    if (!strncmp(buf, "CLIENT:", 7))
		c = 1;
	    else if (!strncmp(buf, "SERVER:", 7))
		s = 1;
	    else
		die("err");

	    memset(buf, 0, 64);
	    read_until(buf, 64, ':');
	    data_len = atoi(buf);
	} while (data_len == 0);

	if (c) {
	    client_data = xmalloc(data_len);
	    fread(client_data, 1, data_len, f);
	} else {
	    server_data = xmalloc(data_len);
	    fread(server_data, 1, data_len, f);
	}
    } else {
	udp_data = xmalloc(4096);
	data_len = fread(udp_data, 1, 4096, f);
    }
}


int
main(int argc, char **argv)
{
    lua_State      *s = NULL;
    char           *ptr = NULL;
    int             r = 0;
    snooze_module_t *m = NULL;

    printf("offline-snooze by THC\n");

    if (argc < 3) {
	printf("Usage: %s <-t|-u> <log-file> <module>\n", argv[0]);
	return 0;
    }
    /* parse arg1 */
    if (!strcmp("-t", argv[1]))
	tcp = 1;
    else if (!strcmp("-u", argv[1]))
	udp = 1;
    else
	die("unknown protocol.");

    /* parse arg2 */
    if ((f = fopen(argv[2], "r")) == NULL)
	die("fopen");

    if ((ptr = strtok(argv[2], "_")) == NULL)
	die("logfile");

    src_addr = (unsigned int) atoi(ptr);

    if ((ptr = strtok(NULL, "_")) == NULL)
	die("logfile");

    src_port = (unsigned short) atoi(ptr);

    if ((ptr = strtok(NULL, "_")) == NULL)
	die("logfile");

    dst_addr = (unsigned int) atoi(ptr);

    if ((ptr = strtok(NULL, "_")) == NULL)
	die("logfile");

    dst_port = (unsigned short) atoi(ptr);

    printf("Running ...\n");
    m = module_load(argv[3]);


    while (!feof(f) && !finished) {
	pull_data();
	s = snooze_lua_init(m->program_code);
	snooze_lua_reset(m->program_code);
	r = snooze_lua_start_offline(s);
	switch (r) {
	case LUA_ERRSYNTAX:
	case LUA_ERRRUN:
	case LUA_ERRFILE:
	case LUA_ERRMEM:
	case LUA_ERRERR:
	    printf("program is broken. exiting ...\n");
	    exit(0);
	    break;
	}
    }

    printf("done.\n");
    return 0;
}
