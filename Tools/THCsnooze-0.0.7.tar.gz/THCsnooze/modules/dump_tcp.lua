-- :xxx_no_proto:1:tcp:
x = snooze.get_server()
print (snooze.src_addr () .. "\n")

if x ~= nil then
	snooze.save ("SERVER:" .. string.len(x) .. ":" .. x)
end

x = snooze.get_client()

if x ~= nil then
	snooze.save ("CLIENT:" .. string.len(x) .. ":" .. x)
end
