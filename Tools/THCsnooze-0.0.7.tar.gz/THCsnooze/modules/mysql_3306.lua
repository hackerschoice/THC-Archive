-- :mysql:3306:tcp:

-- read from s, stating at offset i,  until the first '\0'
function get_c_string(s, i)
	u = ""

	while string.byte(s,i) ~= 0 and i < string.len(s) do
		u = u .. string.char(string.byte(s,i))
		i = i + 1
	end

	return u
end

b = snooze.get()

if b ~= nil then
	w = string.sub(b, 1, 4)
	w_cut = string.sub(b, 5)

	if w == "PASS" then
		x = snooze.get_client()
		if string.byte(x,5) == 255 then
			-- failure
			snooze.finished()
		end

		if string.byte(x,8) == 2 then
			-- success
			snooze.save (w_cut)
			snooze.finished()
		end
		return
	end

	if w == "INIT" then
		x = snooze.get_server()
		if x == nil or string.len(x) < 1 then
			return
		end

		--len = string.byte(x, 1)

		-- XXX: bug ahead!!! i have no idea how the
		--      offset to the username has to be computed.
		--      the docs i found on the web were wrong
		--      on this. (ethereal does this wrong, too).
		--      at least for protocol version 10. 

		off = 37
		user = get_c_string (x, off)
		pass = get_c_string (x, 1 + off + string.len(user))

		--print ("len:" .. len)
		--print ("user:" .. user)
		--print ("pass:" .. pass)

		snooze.set ("PASS" .. user .. ":" .. pass .. ":" .. w_cut)
		return
	end
end

x = snooze.get_client ()
if x ~= nil and string.len(x) > 1 then
	--len = string.byte(x, 1)
	--print ("len:" .. len)
	--proto = string.byte(x, 5)
	--print ("proto:" .. proto)

	version = get_c_string (x, 6)
	salt = get_c_string (x, 11 + string.len(version))
	snooze.set("INIT" .. salt)

	--print ("version:" .. version)
	--print ("salt:" .. salt)
	return
end

