-- :cvspserver:2401:tcp:
-- XXX:TODO: descramble password
--         0 111           P 125           p  58
-- ! 120   1  52   A  57   Q  55   a 121   q 113
-- "  53   2  75   B  83   R  54   b 117   r  32
--         3 119   C  43   S  66   c 104   s  90
--         4  49   D  46   T 124   d 101   t  44
-- % 109   5  34   E 102   U 126   e 100   u  98
-- &  72   6  82   F  40   V  59   f  69   v  60
-- ' 108   7  81   G  89   W  47   g  73   w  51
-- (  70   8  95   H  38   X  92   h  99   x  33
-- )  64   9  65   I 103   Y  71   i  63   y  97
-- *  76   : 112   J  45   Z 115   j  94   z  62
-- +  67   ;  86   K  50           k  93
-- , 116   < 118   L  42           l  39
-- -  74   = 110   M 123           m  37
-- .  68   > 122   N  91           n  61
-- /  87   ? 105   O  35   _  56   o  48
-- cvs -d:pserver:anonymous@cvs.sourceforge.net:/cvsroot/csound login

x = snooze.get_client()
if x == nil or x == "" then
	y = snooze.get()
	s = ""
	if y == nil then
		s = snooze.get_server()
	else
		s = y .. snooze.get_server()
	end
	snooze.set(s)
	return
else
	f = string.gfind(x, "I LOVE YOU")

	if f() then
		snooze.save (snooze.get())
		snooze.finished()
		return
	end

	f = string.gfind(x, "I HATE YOU")

	if f() then
		snooze.finished()
	end
end
