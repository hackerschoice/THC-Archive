-- :portmap:111:tcp:

function conv4(x,o)
	a = string.byte(x, o)
	a = a * 256 + string.byte(x, o + 1)
	a = a * 256 + string.byte(x, o + 2)
	a = a * 256 + string.byte(x, o + 3)
	return a
end

b = snooze.get()

if b == nil then
	x=snooze.get_server()
	if x == nil then
		print("sad")
		return
	end

	if string.len(x) < 4 then
		print("short")
		return
	end

	a = conv4(x, 1)

	if a == tonumber("0x80000028") then
		snooze.set ("REQ")
		return
	end
end

if b == "REQ" then
	x=snooze.get_client()
	if x == nil then
		print ("nul\n")
		return
	end

	off = 29
	log = ""
	while conv4(x, off) == 1 do
		off = off + 4
		tolog = tostring(conv4(x, off))
		off = off + 4
		tolog = tolog .. ":" .. tostring(conv4(x, off))
		off = off + 4
		tolog = tolog .. ":" .. tostring(conv4(x, off))
		off = off + 4
		tolog = tolog .. ":" .. tostring(conv4(x, off)) .. "\n"
		off = off + 4
		log = log .. tolog
	end
	snooze.save(log)
	snooze.finished()
end
