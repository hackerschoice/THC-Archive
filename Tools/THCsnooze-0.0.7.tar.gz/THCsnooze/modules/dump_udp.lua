-- :xxx_no_proto:1:udp:
snooze.save(snooze.get_udp())
