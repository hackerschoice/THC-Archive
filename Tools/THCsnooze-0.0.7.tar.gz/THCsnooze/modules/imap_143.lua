-- :imap4:143:tcp:
-- UNTESTED

b = snooze.get()

if b == nil or b == "" then
	x = snooze.get_server()
	f = string.gfind (x, " LOGIN ")

	if f() then
		snooze.set("USER" .. x)
		return
	end
end

c = string.sub(b, 1, 4)
b_cut = string.sub(b, 5)

if c == "USER" then
	x = snooze.get_client()

	f = string.gfind(x, " OK ")
	if f() then
		snooze.save(b_cut .. x)
		snooze.finished()
		return

	end

	f = string.gfind(x, " NO ")
	if f() then
		snooze.set("")
		return
	end
end

