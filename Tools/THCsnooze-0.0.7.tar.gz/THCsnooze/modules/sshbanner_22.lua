-- :ssh:22:tcp:
-- get the server banner only.

x=snooze.get_client()
if x == nil then
	return
end

snooze.save(x)
snooze.finished()
