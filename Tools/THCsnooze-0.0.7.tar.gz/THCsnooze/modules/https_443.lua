-- :https:443:tcp:
--
-- just check which ssl version the client wants
-- XXX:
-- :nntps:448:
-- :imap4-ssl:585:
-- :ldaps:636:
-- :ftps:990:
-- :telnets:992:
-- :imaps:993:
-- :ircs:994:
-- :pop3s:995:
-- ...
--

x = snooze.get_server()

if x == nil then
	return
end

if string.byte(x, 3)==1 then
	if string.byte(x,4)==0 then
		if string.byte(x,5)==2 then
		snooze.save("client uses SSLv2\n")
		end
	end
end

snooze.finished()
