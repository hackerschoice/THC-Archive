-- :rsh:514:tcp:
-- we just check if the server replies with Permission denied.
-- if it dosnt, we know there is a trust relation between the hosts.
x=snooze.get_client()
d=snooze.get()
if d == nil then
	d = x
else
	d = d .. x
end

f=string.gfind(d,"Permission denied.")

if f() then
	snooze.finished()
	return
end

if string.len(d)>18 then
	snooze.save("trust\n")
	snooze.finished()
	return
end

snooze.set (d)
