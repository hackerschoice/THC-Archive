-- :telnet:23:tcp:

b = snooze.get ()

if b == nil or b == "" then
	s = snooze.get_client()

	if s == nil then
		return
	end

	f = string.gfind (s, "ogin:")
	if f () == nil then
		return
	end

	snooze.set ("USER")
	return
end

c = string.sub (b, 1, 4)
b_cut = string.sub (b, 5)

if c == "USER" then
	s = snooze.get_server()
	if s == nil or s == "" then
		return
	end

	if s == "\r\0" then
		snooze.set ("USE2" .. b_cut .. ":")
		return
	end

	snooze.set ("USER" .. b_cut .. s)
	return
end

if c == "USE2" then
	s = snooze.get_client()
	f = string.gfind (s, "assword:")

	if f () == nil then
		return
	end

	snooze.set ("PASS" .. b_cut)
	return
end

if c == "PASS" then
	s = snooze.get_server()

	if s == nil then
		return
	end

	if s == "\r\0" then
		snooze.set ("PAS2" .. b_cut)
		return
	end

	snooze.set ("PASS" .. b_cut .. s)
end

if c == "PAS2" then
	s = snooze.get_client()

	f = string.gfind(s, "Last")
	if f() then
		snooze.save(b_cut)
		snooze.finished()
		return
	end

	f = string.gfind(s, "login:")
	if f() then
		snooze.set("USER")
	end
end

