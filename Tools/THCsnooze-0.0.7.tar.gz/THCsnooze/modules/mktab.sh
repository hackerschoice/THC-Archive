#!/bin/sh
#
# shell script to create some html code for the project page.
#
for x in `ls *.lua`; do
	echo "<tr>"

	echo "<td>"
	echo "<a href=\"module_files/"$x"\">$x</a>";
	echo "</td>"

	echo "<td>"
	echo "-"
	echo "</td>"

	echo "<td>"
	echo `ls -l $x | awk '{print $5}' -`;
	echo "</td>"

	echo "<td>"
	echo `md5 $x | awk '{print $4}' -`;
	echo "</td>"

	echo "<td>"
	echo `sed -n 1p $x  | awk -F: '{print $4}' -`;
	echo "</td>"

	echo "</tr>"
done
