-- :http:80:tcp:
x=snooze.get_server()
for y in string.gfind(x, "[ %w%p]*\r\n") do
	f=string.gfind (y, "GET")
	if f() then
		g=y
	end

	f=string.gfind (y, "Host:")
	if f() then
		h=y
	end

	f=string.gfind (y, "Authorization:")
	if f() then
		save=y
	end
end

if save ~= nil then
	snooze.save(g .. h .. save)
	-- XXX: check reply code.
	-- XXX: if the connection is keept alive we shouldnt finish
	snooze.finished()
end

print("leave ...")
