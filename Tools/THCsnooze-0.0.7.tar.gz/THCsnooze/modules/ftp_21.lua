-- :ftp:21:tcp:
b = snooze.get ()

if b == nil or b == "" then
	-- connection was just established
	-- use snooze.set to keep track of the session state.
	snooze.set ("USER")
	return
end

c = string.sub (b, 1, 4)
b_cut = string.sub (b, 5)

if c == "USER" then
	-- we are awaiting a USER command
	x = snooze.get_server ()
	t = string.sub (x, 1, 4)
	if t == "USER" then
		snooze.set ("USE2" .. string.sub (x, 5))
	end
end

if c == "USE2" then
	-- got a user command wait for server reply
	x = snooze.get_client ()
	t = tonumber (string.sub (x, 1, 3))

	if t == 331 then
		snooze.set ("PASS" .. b_cut)
	end
end

if c == "PASS" then
	-- user should send PASS now
	x = snooze.get_server ()
	t = string.sub (x, 1, 4)
	if t == "PASS" then
		snooze.set ("PAS2" .. string.sub (x, 5) .. b_cut)
	end

	-- another user command, shouldnt happen, but, well ...
	if t == "USER" then
		snooze.set ("USE2" .. string.sub (x, 5))
	end
end

if c == "PAS2" then
	-- look if the server accepted the login
	x = snooze.get_client ()
	t = tonumber (string.sub (x, 1, 3))

	if t == 530 then
		-- login incorrect
		snooze.set ("USER")
	end

	if t == 230 then
		-- accepted
		snooze.save (b_cut)
		snooze.finished ()
	end
end

