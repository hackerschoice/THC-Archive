#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <win_compat.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <dirent.h>
#include <unistd.h>
#include <signal.h>

#include <nids.h>
#include <amap-inc.h>
#include <amap.h>
#include <amap-lib.h>
#include <misc.h>
#include <main.h>
#include <traq.h>
#include <module.h>
#include <ssl.h>


#define PROGRAM	"THCsnoozed"
#define AUTHOR	"THC"

#define DEFAULT_DEBUG		0
#define MAX_DET_DATA		512

/*
 * logfiles are tagged with this when the module
 * that created it has finished. so the child can
 * identify which files it may schramel with.
 */
const char      c_tag[] = ".complete";
const int       c_tag_len = 9;

/*
 *
 */
amap_struct_responses *amap_resp = NULL;

/*
 * these indicate that a signal was recieved.
 */
int             do_restart_child = 0, do_stats = 0, do_reload_modules = 0;

/*
 * configuration.
 */
snoozed_conf_t  snoozed_conf;

/*
 * prototypes.
 */
void            listener();
void            module_load_all();
void            snooze_atexit();
#define int_ntoa(x)     inet_ntoa(*((struct in_addr *)&x))


/*
 * returns a filename, not existing in the current directory.
 */
char           *
unique_filename(struct tuple4 * a)
{
    char           *ret = NULL;
    int             x = 0;

    ret = xmalloc(128);

    do {
	if (snprintf(ret, 128, "%s_%d_%s_%d_%04x", \
		     int_ntoa(a->saddr), \
		     a->source, \
		     int_ntoa(a->daddr), \
		     a->dest, x) == -1) {
	    die("snprintf");
	}
	++x;
    } while (file_exists(ret) || snooze_traq_fname_in_use(ret));

    return ret;
}


/*
 * signal handlers.
 */
void
signal_sighup(int a)
{
    debug(7, "recieved SIGHUP");
    do_reload_modules = 1;
}


void
signal_sigchld(int a)
{
    debug(7, "recieved SIGCHLD");
    if (snoozed_conf.port)
	do_restart_child = 1;
}


void
signal_sigusr1(int a)
{
    debug(7, "recieved SIGUSR1");
    if (!snoozed_conf.fork_bg)
	do_stats = 1;
}


/*
 * print some information (for sigusr handler).
 */
void
print_stats()
{
    snooze_module_t *w = snooze_module_root;
    snooze_traq_t  *t = snooze_traq_root;
    printf("Loaded Modules:\n");
    printf("---------------\n");
    if (w == NULL) {
	printf("None\n");
    } else {
	while (w != NULL) {
	    printf("%s\t(%d, %s)\n", w->name, w->port, w->program_file);
	    w = w->n;
	}
    }
    printf("---------------\n\n");

    printf("Running Trackers:\n");
    printf("-----------------\n");
    if (t == NULL) {
	printf("None\n");
    } else {
	while (t != NULL) {
	    printf("%s:%d -> %s:%d\n",
		   int_ntoa(t->addr.saddr), \
		   t->addr.source, \
		   int_ntoa(t->addr.daddr), \
		   t->addr.dest);
	    t = t->n;
	}
    }
    printf("-----------------\n\n");
}


void
restart_child()
{
    int             x;

    /* nacht der reitenden leichen! */
    wait(&x);

    /* restart child */
    if ((snoozed_conf.cid = fork()) == 0) {
	if (snoozed_conf.fork_bg)
	    debug_set_level(0);

	listener(snoozed_conf.port);
    }
    if (snoozed_conf.cid == -1) {
	debug(1, "fork failed: could not restart child.");
    }
}


/*
 * reload modules, relink in trackers.
 */
void
reload_modules()
{
    snooze_module_t *o_m_root = NULL, *o_m = NULL;
    snooze_traq_t  *w = NULL;

    /* backup old modules. */
    o_m_root = snooze_module_root;
    snooze_module_root = NULL;

    /* load all modules. */
    module_load_all();

    /*
     * match modules by file names. we are expecting
     * that there will be new modules, not old ones
     * deleted. if a module is deleted we catch it
     * in the next loop.
     */
    for (w = snooze_traq_root; w != NULL; w = w->n) {
	o_m = w->w;

	w->w = snooze_module_find_by_file_name(w->w->name);

	if (w->w == NULL) {
	    debug(1, "No module for %s anymore.\n", o_m->name);
	}
    }

    /* check if we found a new module for each tracker */
    for (w = snooze_traq_root; w != NULL; w = w->n) {
	if (w->w == NULL) {
	    snooze_traq_delete(w);
	    snooze_traq_free(w);
	    w = snooze_traq_root;
	}
    }

    /* delete old modules */
    snooze_module_delete_all(o_m_root);
}


/*
 * load all modules from directory f.
 */
void
module_load_all()
{
    DIR            *d = NULL;
    struct dirent  *di = NULL;
    char           *t = NULL;
    snooze_module_t *m = NULL;


    debug(1, "loading modules ...");

    if ((d = opendir(snoozed_conf.moddir)) == NULL) {
	die("opendir");
    }
    while ((di = readdir(d)) != NULL) {
	if (strlen(di->d_name) < 4)
	    continue;

	if (strcmp(di->d_name + strlen(di->d_name) - 4, ".lua"))
	    continue;

	t = xmalloc(strlen(WC_FILE_SEPERATOR) + \
		    strlen(di->d_name) + \
		    strlen(snoozed_conf.moddir) + 1);

	/* construct absolute path to module */
	strcpy(t, snoozed_conf.moddir);
	strcat(t, WC_FILE_SEPERATOR);
	strcat(t, di->d_name);

	if ((m = module_load(t)) == NULL) {
	    debug(0, "module_load");
	    continue;
	}
	/* check if the tagline was ok */
	if (m->name == NULL || m->port == 0 || m->proto == 0) {
	    snooze_module_free(m);
	    debug(0, "Module %s: cannot load (missing/malformed tag line). ", di->d_name);
	    continue;
	}
	snooze_module_add(m);
	debug(2, "Loaded: %s (%s:%d)", di->d_name, m->name, m->port);
    }

    closedir(d);
}


/*
 * libnids udp callback.
 */
void
udp_callback(struct tuple4 * addr, char *buf, int len, struct ip * iph)
{
    snooze_module_t *m = NULL;
    lua_State      *s;
    int             c_idx = 0;
    char           *buf_cpy;
    struct tuple4  *addr_cpy;

    debug(9, "udp_callback enter ...");
    while ((m = snooze_module_find_by_port_udp(addr->dest, m)) != NULL) {
	/* XXX: amap / detect support */

	debug(8, "udp_callback: found (udp) module %s", m->name);
	debug(8, "calling program ...");

	buf_cpy = xmalloc(len);
	memcpy(buf_cpy, buf, len);

	addr_cpy = xmalloc(sizeof(struct tuple4));
	memcpy(addr_cpy, addr, sizeof(struct tuple4));

	s = snooze_lua_init(m->program_code);
	snooze_lua_reset(m->program_code);

	c_idx = snooze_get_i(s);

	lua_ctx[c_idx].w = IPPROTO_UDP;
	lua_ctx[c_idx].cur_udp_data = buf_cpy;
	lua_ctx[c_idx].cur_udp_data_len = len;
	lua_ctx[c_idx].cur_udp_fname = unique_filename(addr);
	lua_ctx[c_idx].cur_udp_tuple4 = addr_cpy;

	snooze_lua_start(c_idx);
    }
}


/*
 * libnids tcp callback.
 */
void
tcp_tracker(struct tcp_stream * t)
{
    lua_State      *s;
    snooze_module_t *m = NULL;
    snooze_traq_t  *tr = NULL;
    char          **are = NULL;
    int             i = 0, c_idx = 0;

    debug(9, "tcp_tracker enter ...");

    switch (t->nids_state) {
    case NIDS_JUST_EST:
	debug(10, "NIDS_JUST_EST");

	if ((m = snooze_module_find_by_port_tcp(t->addr.dest, NULL)) == NULL) {
	    debug(10, "no module for dst port %d", t->addr.dest);

	    if (snoozed_conf.detect) {
		debug(7, "will try to detect protocol");
		t->server.collect++;
		t->client.collect++;
		tr = xmalloc(sizeof(snooze_traq_t));
		tr->fname = unique_filename(&t->addr);
		tr->w = NULL;	/* set to NULL so we know its unidentified */
		memcpy(&tr->addr, &t->addr, sizeof(struct tuple4));
		snooze_traq_add(tr);
	    }
	} else {
	    /* if we have a module (or more) for dst port add a traq for each */
	    do {
		t->server.collect++;
		t->client.collect++;

		tr = xmalloc(sizeof(snooze_traq_t));
		tr->w = m;
		tr->fname = unique_filename(&t->addr);

		memcpy(&tr->addr, &t->addr, sizeof(struct tuple4));
		snooze_traq_add(tr);
		debug(5, "adding tracker for dst port %d (%s)", t->addr.dest, m->name);
	    } while ((m = snooze_module_find_by_port_tcp(t->addr.dest, m)) != NULL);
	}
	break;
    case NIDS_DATA:
	debug(10, "NIDS_DATA");

	/*
	 * this big while loop will, for each tracker:
	 * - check if there is a module assigned to it.
	 *   if not and detection is enabled:
	 *      try to find the protocol and add a tracker for each
	 *	module for this protocol.
	 * - call the module assigned to the tracker.
	 *
	 * note that it is possible if detection is enabled that
	 * not just the current handled tracker is modified but
	 * it is also possible that more trackers are added. with
	 * the current snooze_traq_find and snooze_traq_add function
	 * this is ok, because add will append to a list which is
	 * traversed by find.
	 */
	while ((tr = snooze_traq_find(&t->addr, tr)) != NULL) {
	    if (tr->w == NULL) {
		/* try to identitfy the protocol by the data we recieved */
		if ((are = amap_lib_identify(t->client.data, \
					     t->client.count_new, \
					     'T',
					     amap_resp)) == NULL) {
		    /* no hit. delete the tracker. */
		    if (t->client.count > MAX_DET_DATA) {
			debug(8, "detect failed.");
			snooze_traq_delete(tr);
			snooze_traq_free(tr);
		    }
		    continue;
		}
		/* XXX: will only catch first detected protocol. */
		while (are[i] != NULL) {
		    if ((m = snooze_module_find_by_name(are[i], NULL)) != NULL) {
			debug(8, "detect succeded, found module (%s).", are[i]);
			tr->w = m;

			while ((m = snooze_module_find_by_name(are[i], m)) != NULL) {
			    /* add traqs for other modules for this protocol. */
			    debug(8, "detect succeded, found module (%s).", are[i]);
			    tr = xmalloc(sizeof(snooze_traq_t));
			    tr->fname = unique_filename(&t->addr);
			    tr->w = m;
			    memcpy(&tr->addr, &t->addr, sizeof(struct tuple4));
			    snooze_traq_add(tr);
			}
			break;
		    }
		    i++;
		}

		if (are[i] == NULL) {
		    debug(8, "detect succeded, no module.");
		    snooze_traq_delete(tr);
		    snooze_traq_free(tr);
		    break;
		}
		tr->w = m;
	    }			/* end tr->w == NULL */
	    s = snooze_lua_init(tr->w->program_code);
	    snooze_lua_reset(tr->w->program_code);

	    c_idx = snooze_get_i(s);

	    lua_ctx[c_idx].w = IPPROTO_TCP;
	    lua_ctx[c_idx].cur_tcp_stream = snooze_copy_tcp_stream(t);
	    lua_ctx[c_idx].cur_snooze_traq = tr;

	    debug(8, "calling program ...");
	    snooze_lua_start(c_idx);
	}
	break;
    case NIDS_CLOSE:
    case NIDS_RESET:
    case NIDS_TIMED_OUT:
	debug(10, "NIDS_RESET or NIDS_CLOSE");
	while ((tr = snooze_traq_find(&t->addr, NULL)) != NULL) {
	    snooze_traq_delete(tr);
	    snooze_traq_free(tr);
	}
	break;
    case NIDS_EXITING:
	debug(10, "NIDS_EXITING");
	/* child will be killed by atexit handler. */
	break;
    }
}


void
snooze_no_mem()
{
    debug(1, "libnids called snooze_no_mem.");

    /*
     * libnids doc suggest to kill the process now.
     */
    die("Out of Memory");
}


void
snooze_syslog(int type, int errnum, struct ip * iph, void *data)
{
    debug(5, "syslog: %d:%d", type, errnum);
}


void
usage(char *s)
{
    printf("Usage: %s [Options]\n", s);
    printf("Options:\n");
    printf("\t-i <if>:\t use interface if.\n");
    printf("\t-f <f>:\t\t use pcap filter.\n");
    printf("\t-p:\t\t do not enter promisc. mode.\n");
    printf("\t-b:\t\t do not fork into background.\n");
    printf("\t-M <d>:\t\t load modules from dir d.\n");
    printf("\t-D <n>:\t\t set debug level to n (0 ... 10, default: %d).\n", DEFAULT_DEBUG);
    printf("\t-c <d>:\t\t mkdir+chdir to d.\n");
    printf("\t-U <p>:\t\t listen on udp port p.\n");
    printf("\t-s <sum>:\t sha1 checksum of client certificate.\n");
    printf("\t-a <f>:\t\t try protocol detection (load fp from file f).\n");
    printf("\n");
    exit(0);
}


char           *
snooze_abs_path(char *p)
{
    char           *ret = NULL;
    int             s = 0;

    if (*p == '/')
	return p;

    if (p[strlen(p) - 1] != '/')
	s = 1;

    ret = xmalloc(strlen(snoozed_conf.old_cwd) + strlen(p) + s + 1);

    strcpy(ret, snoozed_conf.old_cwd);

    if (s)
	strcat(ret, WC_FILE_SEPERATOR);

    strcat(ret, p);

    return ret;
}


int
main(int argc, char **argv)
{
    int             x = 1, s_opt = 0;
    char            old_cwd[512];


    printf(PROGRAM "-" VERSION " by " AUTHOR "\n");

    if (argc < 2)
	usage(argv[0]);

    memset(&snoozed_conf, 0, sizeof(snoozed_conf_t));
    debug_set_level(DEFAULT_DEBUG);

    snoozed_conf.fork_bg = 1;
    snoozed_conf.promisc = 1;

    if (getcwd(old_cwd, sizeof(old_cwd)) == NULL)
	die("getcwd");

    snoozed_conf.old_cwd = strdup(old_cwd);

    while (x < argc) {
	if (argv[x][0] == '-') {
	    switch (argv[x][1]) {
	    case 'U':
		snoozed_conf.port = atoi(argv[++x]);
		break;
	    case 's':
		ssl_set_digest(argv[++x]);
		s_opt = 1;
		break;
	    case 'a':
		snoozed_conf.detect = 1;
		snoozed_conf.amap_fp = argv[++x];
		break;
	    case 'c':
		snoozed_conf.dir = snooze_abs_path(argv[++x]);
		break;
	    case 'i':
		snoozed_conf.device = argv[++x];
		break;
	    case 'p':
		snoozed_conf.promisc ^= 1;
		break;
	    case 'b':
		snoozed_conf.fork_bg ^= 1;
		break;
	    case 'M':
		snoozed_conf.moddir = snooze_abs_path(argv[++x]);
		break;
	    case 'f':
		snoozed_conf.filter = argv[++x];
		break;
	    case 'D':
		debug_set_level(atoi(argv[++x]));
		break;
	    case 'h':
	    default:
		usage(argv[0]);
		break;
	    }
	} else {
	    usage(argv[0]);
	}
	x++;
    }

    if ((!s_opt && snoozed_conf.port) || (!snoozed_conf.port && s_opt))
	die("need either -s and -U or none of them.");

    if (atexit(&snooze_atexit) != 0)
	die("atexit");

    if (snoozed_conf.dir == NULL) {
	snoozed_conf.dir = snoozed_conf.old_cwd;
    } else {
	if (mkdir(snoozed_conf.dir, S_IXUSR | S_IWUSR | S_IRUSR) != 0)
	    die("mkdir");
    }

    if (snoozed_conf.port != 0) {
	if ((snoozed_conf.cid = fork()) == 0) {
	    debug(1, "Starting listener.");

	    if (snoozed_conf.fork_bg)
		debug_set_level(0);

	    chdir(snoozed_conf.moddir);
	    listener();
	}
    }
    if (snoozed_conf.amap_fp != NULL)
	amap_resp = amap_lib_init(snoozed_conf.amap_fp);

    /* setup signal handling */
    if (signal(SIGHUP, &signal_sighup) == SIG_ERR)
	die("signal");

    if (signal(SIGCHLD, &signal_sigchld) == SIG_ERR)
	die("signal");

    if (signal(SIGUSR1, &signal_sigusr1) == SIG_ERR)
	die("signal");

    module_load_all();

    if (snoozed_conf.dir != NULL)
	chdir(snoozed_conf.dir);

    /* libnids setup */
    nids_params.device = snoozed_conf.device;
    nids_params.syslog = snooze_syslog;
    nids_params.scan_num_hosts = 0;
    nids_params.no_mem = &snooze_no_mem;
    /* nids_params.ip_filter = NULL; */
    nids_params.pcap_filter = snoozed_conf.filter;
    nids_params.promisc = snoozed_conf.promisc;

    if (!nids_init())
	die("nids_init");

    nids_register_tcp(&tcp_tracker);
    nids_register_udp(&udp_callback);

    /* fork */
    if (snoozed_conf.fork_bg) {
	debug(0, "Forking into background. seting debuglevel to 0.");
	debug_set_level(0);
	switch (fork()) {
	case -1:
	    die("fork");
	    break;
	case 0:
	    break;
	default:
	    exit(0);
	}
    }
    debug(1, "Entering loop ...");
    while (1) {
	nids_next();

	if (do_restart_child) {
	    if (snoozed_conf.cid != -1) {
		restart_child();
		do_restart_child = 0;
	    } else {
		/*
		 * restart failed once, maybe we should wait a while. otoh,
		 * we can forget about it immediately.
		 */
		restart_child();
	    }
	}
	if (do_reload_modules) {
	    reload_modules();
	    do_reload_modules = 0;
	}
	if (do_stats) {
	    print_stats();
	    do_stats = 0;
	}
    }
    return 0;
}


void
snooze_atexit()
{
    debug(7, "snooze_atexit. snooze is exiting!");

    if (snoozed_conf.cid != 0)
	kill(snoozed_conf.cid, SIGKILL);
}
