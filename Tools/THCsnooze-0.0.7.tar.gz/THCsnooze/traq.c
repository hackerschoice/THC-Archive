#include <traq.h>
#include <main.h>
#include <misc.h>
#ifdef __THREAD
#include <pthread.h>

pthread_mutex_t snooze_traq_mutex = PTHREAD_MUTEX_INITIALIZER;
#endif

snooze_traq_t  *snooze_traq_root = NULL;

int
snooze_traq_fname_in_use(char *f)
{
    snooze_traq_t  *ret = NULL;

#ifdef __THREAD
    pthread_mutex_lock(&snooze_traq_mutex);
#endif

    ret = snooze_traq_root;

    while (ret != NULL) {
	if (!strcmp(f, ret->fname)) {
#ifdef __THREAD
	    pthread_mutex_unlock(&snooze_traq_mutex);
#endif

	    return 1;
	}
	ret = ret->n;
    }

#ifdef __THREAD
    pthread_mutex_unlock(&snooze_traq_mutex);
#endif

    return 0;
}


void
snooze_traq_add(snooze_traq_t * t)
{
#ifdef __THREAD
    pthread_mutex_lock(&snooze_traq_mutex);
#endif
    if (snooze_traq_root == NULL) {
	snooze_traq_root = t;
    } else {
	t->n = snooze_traq_root;
	snooze_traq_root = t;
    }
#ifdef __THREAD
    pthread_mutex_unlock(&snooze_traq_mutex);
#endif
}


void
snooze_traq_free(snooze_traq_t * t)
{
    free(t->fname);
    if (t->data != NULL)
	free(t->data);
}


void
snooze_traq_delete(snooze_traq_t * t)
{
    snooze_traq_t  *w, *l = NULL;
    char           *n = NULL;

#ifdef __THREAD
    pthread_mutex_lock(&snooze_traq_mutex);
#endif
    w = snooze_traq_root;

    if (file_exists(t->fname)) {
	/*
	 * rename logfile.
	 * we should probably rely on t->fin
	 * hmmm ...
	 */
	n = xmalloc(strlen(t->fname) + c_tag_len + 1);
	strcpy(n, t->fname);
	strcat(n, c_tag);
	rename(t->fname, n);
	free(n);
    }
    while (w != t && w != NULL) {
	l = w;
	w = w->n;
    }

#ifdef __THREAD
    pthread_mutex_unlock(&snooze_traq_mutex);
#endif

    if (w == NULL)
	return;

    if (l == NULL) {
	snooze_traq_root = snooze_traq_root->n;
	return;
    }
    l->n = w->n;
}


snooze_traq_t  *
snooze_traq_find(struct tuple4 * w, snooze_traq_t * last)
{
    snooze_traq_t  *ret = NULL;

#ifdef __THREAD
    pthread_mutex_lock(&snooze_traq_mutex);
#endif

    ret = snooze_traq_root;
    if (last != NULL)
	ret = last->n;

    while (ret != NULL) {
	if (!memcmp(&ret->addr, w, sizeof(struct tuple4))) {
#ifdef __THREAD
	    pthread_mutex_unlock(&snooze_traq_mutex);
#endif

	    return ret;
	}
	ret = ret->n;
    }

#ifdef __THREAD
    pthread_mutex_unlock(&snooze_traq_mutex);
#endif

    return ret;
}
