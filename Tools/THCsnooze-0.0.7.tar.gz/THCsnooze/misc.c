#include <misc.h>
#include <stdarg.h>
#ifdef __THREAD
#include <pthread.h>

pthread_mutex_t misc_debug_mutex = PTHREAD_MUTEX_INITIALIZER;
#endif
int             debug_level = 0;

char           *
xstrdup(const char *x)
{
    char           *r;

    if (x == NULL) {
	return NULL;
    }
    r = xmalloc(strlen(x) + 1);
    memcpy(r, x, strlen(x));

    return r;
}


void           *
xmalloc(const size_t x)
{
    void           *r;

    r = malloc(x);

    if (r == NULL) {
	die("malloc");
    }
    memset(r, 0x00, x);

    return r;
}


void           *
xrealloc(void *x, const size_t s)
{
    void           *r;

    r = realloc(x, s);

    if (r == NULL) {
	die("realloc");
    }
    return r;
}


void
die(char *x)
{
    printf("%s\n", x);
    exit(EXIT_FAILURE);
}


int
file_exists(const char *x)
{
    struct stat     s;

    if (stat(x, &s) == 0) {
	return 1;
    }
    return 0;
}


off_t
file_size(const char *x)
{
    struct stat     s;

    if (stat(x, &s) != 0) {
	return 0;
    }
    return s.st_size;
}


int
file_is_symlink(const char *x)
{
#ifndef __WINDOWS__
    struct stat     s;

    if (stat(x, &s) != 0) {
	return 0;
    }
    return s.st_mode & S_IFLNK;
#else
    /* XXX: does windows have unix-like symlinks? */
    return 0;
#endif
}


void
debug_set_level(int a)
{
    debug_level = a;
}


void
debug(int a, char *m,...)
{
    va_list         args;

    if (a <= debug_level) {
#ifdef __THREAD
	pthread_mutex_lock(&misc_debug_mutex);
#endif
	va_start(args, m);
	printf("DEBUG: ");
	vfprintf(stdout, m, args);
	printf("\n");
	va_end(args);
#ifdef __THREAD
	pthread_mutex_unlock(&misc_debug_mutex);
#endif
    }
}


int
xstr2num(char *s)
{
    if (!strncmp(s, "0x", 2))
	return strtol(s + 2, NULL, 16);
    return strtol(s, NULL, 10);
}


int
snooze_memcmp (void *a, size_t la, void *b, size_t lb)
{
    if (la != lb)
	return 0;

    if (la == 0)
	return 1;

    ++la;

    while (la >= 1) {
	if (*((char *) a) != *((char *) b))
	    return 0;
	--la;
    }

    return 1;
}
