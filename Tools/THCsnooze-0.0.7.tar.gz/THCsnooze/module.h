#ifndef __MODULE_H
#define __MODULE_H

#include <stdio.h>
#include <snooze_lua.h>

struct snooze_module {
    char           *name, *program_file;
    snooze_lua_mod_code_t *program_code;
    unsigned short  port;
    int             proto;
    struct snooze_module *n;
};
typedef struct snooze_module snooze_module_t;


extern snooze_module_t *snooze_module_root;

void            snooze_module_free(snooze_module_t *);
void            snooze_module_delete_all(snooze_module_t *);
void            snooze_module_add(snooze_module_t *);

snooze_module_t *snooze_module_find_by_file_name(const char *);
snooze_module_t *snooze_module_find_by_port_tcp(unsigned short, snooze_module_t *);
snooze_module_t *snooze_module_find_by_port_udp(unsigned short, snooze_module_t *);
snooze_module_t *snooze_module_find_by_name(const char *, snooze_module_t *);
snooze_lua_mod_code_t *module_load_code(FILE *);
snooze_module_t *module_load(const char *);

#endif
