/*
 *  base64 encode/decode
 *  Author: rd@thc.org
 */

#include <openssl/buffer.h>
#include <openssl/bio.h>
#include <openssl/pem.h>
#include <string.h>

int
base64(int enc, const char *in, int len, char **out)
{
    BIO            *b64;
    BIO            *rbio = NULL;
    BIO            *wbio = NULL;
    BUF_MEM        *bm;
    char           *buf;
    char           *p;
    int             n = -1;
    int             bsize = len;

    if (out)
	*out = NULL;

    if (!in || !out || len < 1)
	return -1;

    buf = (unsigned char *) OPENSSL_malloc(EVP_ENCODE_LENGTH(bsize));
    if ((buf == NULL))
	goto end;

    if (!(rbio = BIO_new(BIO_s_mem())))
	goto end;

    if (!(bm = BUF_MEM_new()))
	goto end;

    if (!BUF_MEM_grow(bm, len))
	goto end;

    memcpy(bm->data, in, len);
    BIO_set_mem_buf(rbio, bm, 0);

    if (!(wbio = BIO_new(BIO_s_mem())))
	goto end;

    if (!(b64 = BIO_new(BIO_f_base64())))
	goto end;

    BIO_set_flags(b64, BIO_FLAGS_BASE64_NO_NL);

    if (enc)
	wbio = BIO_push(b64, wbio);
    else
	rbio = BIO_push(b64, rbio);

    for (;;) {
	if ((n = BIO_read(rbio, (char *) buf, bsize)) <= 0)
	    break;
	if (BIO_write(wbio, (char *) buf, n) != n)
	    goto end;
    }

    if (!BIO_flush(wbio))
	goto end;

    n = BIO_get_mem_data(wbio, &p);
    if (!((*out) = malloc(n + 1)))
	goto end;

    memcpy(*out, p, n);
    (*out)[n] = '\0';

end:
    if (buf)
	OPENSSL_free(buf);
    if (wbio)
	BIO_free_all(wbio);
    if (rbio)
	BIO_free_all(rbio);

    return n;
}
