#ifndef __WIN_COMPAT_H
#define __WIN_COMPAT_H

#ifdef __WINDOWS__
#define WC_FILE_SEPERATOR	"\\"
#else
#define WC_FILE_SEPERATOR	"/"
#endif

#endif
