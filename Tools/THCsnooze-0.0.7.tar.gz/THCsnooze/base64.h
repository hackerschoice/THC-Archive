#ifndef __BASE64_H
#define __BASE64_H

int             base64(int, const char *, int, char **);

#endif
