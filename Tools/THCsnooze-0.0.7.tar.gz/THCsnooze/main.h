#ifndef __MAIN_H
#define __MAIN_H

#include <snooze_lua.h>
#include <snooze_lua_thread.h>
#include <nids.h>
#include <traq.h>

typedef struct {
    int             detect,	/* use amap protocol detection. */
                    port,	/* if != 0: daemon mode */
                    fork_bg,	/* 1 == fork bk */
                    promisc;
    char           *moddir,	/* directory of the modules */
                   *old_cwd,	/* cwd */
                   *dir,	/* logdir */
                   *device,	/* interface to use */
                   *filter, *amap_fp;
    pid_t           cid;

}               snoozed_conf_t;

extern snoozed_conf_t snoozed_conf;

extern const char c_tag[];
extern const int c_tag_len;
#endif
