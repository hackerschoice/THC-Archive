#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <dirent.h>
#include <unistd.h>
#include <signal.h>

#include <listener.h>
#include <main.h>
#include <misc.h>
#include <minsock.h>
#include <ssl.h>

#define PAT_SIZE	32


/*
 * handle get log request.
 */
void
listener_get_log()
{
    int             r, f;
    char            buf[128];
    FILE           *fd = NULL;
    DIR            *d = NULL;
    struct dirent  *di = NULL;
    ssl_t          *ssl = NULL;


    if ((f = sck_listen_accept_tcp(snoozed_conf.port + 2)) == -1)
	return;

    debug(7, "listener_get_log: connection accepted.");

    if ((ssl = ssl_do_connect(f)) == NULL) {
	sck_close(f);
	return;
    }
    debug(7, "listener_get_log: connection is now SSL'ed.");

    chdir(snoozed_conf.dir);

    if ((d = opendir(".")) == NULL)
	goto ret;

    while ((di = readdir(d)) != NULL) {
	if (strlen(di->d_name) < c_tag_len)
	    continue;

	if (strcmp(di->d_name + strlen(di->d_name) - c_tag_len, c_tag))
	    continue;

	if (SSL_write(ssl->ssl, di->d_name, strlen(di->d_name)) != strlen(di->d_name))
	    continue;

	if (SSL_write(ssl->ssl, ":", 1) != 1)
	    continue;

	snprintf(buf, sizeof(buf), "%d", (int) file_size(di->d_name));

	if (SSL_write(ssl->ssl, buf, strlen(buf)) != strlen(buf))
	    continue;

	if (SSL_write(ssl->ssl, ":\n", 2) != 2)
	    continue;

	if ((fd = fopen(di->d_name, "r")) == NULL) {
	    /* file disappered */
	    continue;
	}
	while (!feof(fd)) {
	    r = fread(buf, 1, sizeof(buf), fd);
	    SSL_write(ssl->ssl, buf, r);
	}

	if (!file_is_symlink(di->d_name)) {
	    unlink(di->d_name);
	}
    }

ret:
    SSL_shutdown(ssl->ssl);
    ssl_free(ssl);
    closedir(d);
    sck_close(f);
}


/*
 * handle new module.
 */
void
listener_new_mod()
{
    int             r, f;
    char            buf[8192];
    char           *fname = NULL, *fn = NULL;
    FILE           *fd = NULL;
    ssl_t          *ssl = NULL;

    if ((f = sck_listen_accept_tcp(snoozed_conf.port + 1)) == -1)
	return;

    debug(7, "listener_new_mod: connection accepted.");

    if ((ssl = ssl_do_connect(f)) == NULL) {
	sck_close(f);
	return;
    }
    debug(7, "listener_new_mod: connection is now SSL'ed.");

    chdir(snoozed_conf.moddir);

    do {
	fn = tempnam(".", "mod");
    } while (file_exists(fname));

    fname = xmalloc(strlen(fn) + 5);
    strcpy(fname, fn);
    strcat(fname, ".lua");

    if ((fd = fopen(fname, "w")) == NULL)
	die("fopen");

    printf("recieving module ...\n");
    while ((r = SSL_read(ssl->ssl, buf, sizeof(buf))) > 0) {
	if (fwrite(buf, 1, r, fd) != r)
	    die("listener_new_mod: fwrite");
    }

    fclose(fd);
    SSL_shutdown(ssl->ssl);
    ssl_free(ssl);
    sck_close(f);
    free(fname);

    if (kill(getppid(), SIGHUP) == -1)
	die("kill");

    sleep(1);
}


typedef void    (*listener_op_func_t) ();

struct listener_ops {
    char            pat[PAT_SIZE], *name;
    listener_op_func_t f;
}               ops[] = {
    {
	L_NEW_MOD, "new module", listener_new_mod
    },
    {
	L_GET_LOG, "get logs", listener_get_log
    }
};


void
listener()
{
    int             sock = 0, r, nlen = sizeof(struct sockaddr_in), x;
    struct sockaddr_in sin;
    char            buf[PAT_SIZE];

    ssl_init();

    memset(&sin, 0, nlen);
    sin.sin_family = AF_INET;
    sin.sin_port = htons(snoozed_conf.port);
    sin.sin_addr.s_addr = INADDR_ANY;

    if ((sock = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP)) == -1)
	die("socket");

    if (bind(sock, (struct sockaddr *) & sin, nlen) == -1)
	die("bind");

    debug(3, "listening ...");

    while (1) {
	if ((r = recv(sock, buf, PAT_SIZE, MSG_WAITALL)) == -1)
	    die("recv");

	if (r < PAT_SIZE)
	    continue;

	x = 0;
	while (x < sizeof(ops) / sizeof(struct listener_ops)) {
	    if (!memcmp(buf, ops[x].pat, PAT_SIZE)) {
		debug(3, "listener: %s.", ops[x].name);
		ops[x].f();
		break;
	    }
	    x++;
	}
    }
}
