/*
 * traq.h:
 * manage currently tracked tcp connections in a list.
 * 
 * snooze_traq_* functions are thread save.
 *
 */
#ifndef __TRAQ_H
#define __TRAQ_H

#include <nids.h>
#include <module.h>


struct snooze_traq {
    struct tuple4   addr;
    char           *fname, *data;
    int             fin;
    snooze_module_t *w;
    struct snooze_traq *n;
};
typedef struct snooze_traq snooze_traq_t;

extern snooze_traq_t *snooze_traq_root;

void            snooze_traq_add(snooze_traq_t *);
void            snooze_traq_free(snooze_traq_t *);
void            snooze_traq_delete(snooze_traq_t *);

snooze_traq_t  *snooze_traq_find(struct tuple4 *, snooze_traq_t *);
int             snooze_traq_fname_in_use(char *);

#endif
