#include <module.h>
#include <misc.h>

#include <netinet/in.h>
#ifdef __THREAD
#include <pthread.h>
#endif

snooze_module_t *snooze_module_root = NULL;

void
snooze_module_free(snooze_module_t * m)
{
    if (m->name != NULL)
	free(m->name);

    if (m->program_file != NULL)
	free(m->program_file);

    if (m->program_code != NULL) {
	if (m->program_code->code != NULL)
	    free(m->program_code->code);

	free(m->program_code);
    }
    free(m);
}


void
snooze_module_delete_all(snooze_module_t * m)
{
    snooze_module_t *o = NULL;

    while (m != NULL) {
	o = m->n;
	snooze_module_free(m);
	m = o;
    }
}


void
snooze_module_add(snooze_module_t * m)
{
    if (snooze_module_root == NULL) {
	snooze_module_root = m;
    } else {
	m->n = snooze_module_root;
	snooze_module_root = m;
    }
}


snooze_module_t *
snooze_module_find_by_file_name(const char *n)
{
    snooze_module_t *ret = snooze_module_root;

    while (ret != NULL) {
	if (!strcmp(ret->program_file, n))
	    return ret;

	ret = ret->n;
    }

    return ret;
}


snooze_module_t *
snooze_module_find_by_port_tcp(unsigned short p, snooze_module_t * last)
{
    snooze_module_t *ret = snooze_module_root;

    if (last != NULL)
	ret = last->n;

    while (ret != NULL) {
	if (ret->proto == IPPROTO_TCP && p == ret->port)
	    return ret;

	ret = ret->n;
    }

    return ret;
}


snooze_module_t *
snooze_module_find_by_port_udp(unsigned short p, snooze_module_t * last)
{
    snooze_module_t *ret = snooze_module_root;

    if (last != NULL)
	ret = last->n;

    while (ret != NULL) {
	if (ret->proto == IPPROTO_UDP && p == ret->port)
	    return ret;

	ret = ret->n;
    }

    return ret;
}


snooze_module_t *
snooze_module_find_by_name(const char *n, snooze_module_t * last)
{
    snooze_module_t *ret = snooze_module_root;

    if (last != NULL)
	ret = last->n;

    while (ret != NULL) {
	if (!strcmp(n, ret->name))
	    return ret;

	ret = ret->n;
    }

    return ret;
}


snooze_lua_mod_code_t *
module_load_code(FILE * f)
{
    int             l;
    char            buf[1024];
    snooze_lua_mod_code_t *ret = NULL;


    ret = xmalloc(sizeof(snooze_lua_mod_code_t));

    /* wer rasen saeht wird maeher ernten. */
#ifdef __THREAD
    pthread_mutex_init(&ret->lock, NULL);
#endif

    while (!feof(f)) {
	l = fread(buf, 1, 1024, f);

	if (ret->code == NULL) {
	    ret->code = xmalloc(ret->code_len + l);
	} else {
	    ret->code = xrealloc(ret->code, ret->code_len + l);
	}

	memcpy(ret->code + ret->code_len, buf, l);
	ret->code_len += l;
    }

    return ret;
}


snooze_module_t *
module_load(const char *t)
{
    char            buf[512];
    snooze_module_t *m = NULL;
    FILE           *fd = NULL;


    m = xmalloc(sizeof(snooze_module_t));
    m->program_file = (char *) t;

    if ((fd = fopen(m->program_file, "r")) == NULL)
	return NULL;

    fgets(buf, 512, fd);
    rewind(fd);

    m->program_code = module_load_code(fd);

    if (strtok(buf, ":") == NULL) {
	snooze_module_free(m);
	return NULL;
    }
    if ((t = strtok(NULL, ":")) != NULL)
	m->name = xstrdup(t);
    if ((t = strtok(NULL, ":")) != NULL)
	m->port = (unsigned short) atoi(t);
    if ((t = strtok(NULL, ":")) != NULL) {
	if (!strcmp(t, "tcp")) {
	    m->proto = IPPROTO_TCP;
	} else if (!strcmp(t, "udp")) {
	    m->proto = IPPROTO_UDP;
	}
    }
    return m;
}
