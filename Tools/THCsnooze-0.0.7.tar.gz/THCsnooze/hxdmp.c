#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>

FILE           *f = NULL;

/* text colors */
#define BLUE	34
#define GREEN	32
#define RED	31
#define DEFAULT	39


void
color(int c)
{
    printf("\033[%im", c);
}


int
read_until(char *b, int l, char w)
{
    int             x = 0, y;

    while (x < l && !feof(f)) {
	y = fgetc(f);
	b[x++] = y & 0xff;
	if ((y & 0xff) == w) {
	    b[x] = 0;
	    return x;
	}
    }
    return x;
}


/*
 * what a mess!
 */
void
color_dump()
{
    char            buf[4096], lbuf[16];
    int             r, c_c[16], c_len = 0, co = 0, ow = 0, a = 0, len = 0, lc = 0,
                    w = DEFAULT, l, x = 0;


    printf("%08x ", len);
    while (!feof(f)) {
	if (fread(buf, 1, 7, f) != 7)
	    continue;

	if (!strncmp(buf, "CLIENT:", 7)) {
	    ow = w;
	    w = RED;
	} else if (!strncmp(buf, "SERVER:", 7)) {
	    ow = w;
	    w = GREEN;
	}
	if (ow != w)
	    c_c[c_len++] = lc;

	color(w);

	if (read_until(buf, 4096, ':') < 1)
	    continue;

	l = atoi(buf);

	if (l == 0)
	    continue;

	if (l > 4096)
	    l = 4096;		/* XXX */

	r = fread(buf, 1, l, f);

	x = 0;
	while (x < r) {
	    while (lc < 16 && x < r) {
		printf("%02x ", buf[x] & 0xff);
		lbuf[lc] = buf[x];
		x++;
		lc++;
		if (lc == 8)
		    printf(" ");
	    }

	    if (lc == 16) {
		color(DEFAULT);
		printf("| ");
		a = 0;

		color(w);

		for (l = 0; l < 16; l++) {
		    if (c_len != 0) {
			while (c_c[a] == l && a < c_len) {
			    if (co == GREEN)
				co = RED;
			    else
				co = GREEN;
			    color(co);
			    a++;
			}
		    }
		    printf("%c", isprint(lbuf[l]) ? lbuf[l] : '.');
		    if (l == 7)
			printf(" ");
		}

		printf("\n");

		len += 16;
		color(DEFAULT);
		printf("%08x ", len);

		color(w);

		lc = 0;
		c_len = 0;

		c_c[c_len++] = 0;
		c_c[c_len++] = 0;
	    }
	}
    }

    color(DEFAULT);
    if (lc != 16) {
	l = 0;
	while (l < 16 - lc) {
	    printf("   ");
	    l++;
	    if (l == 8 && lc != 8)
		printf(" ");
	}

	printf("| ");
	a = 0;
	color(w);
	for (l = 0; l < lc; l++) {
	    if (c_len != 0) {
		while (c_c[a] == l && a < c_len) {
		    if (co == GREEN)
			co = RED;
		    else
			co = GREEN;
		    color(co);
		    a++;
		}
	    }
	    printf("%c", isprint(lbuf[l]) ? lbuf[l] : '.');
	    if (l == 7)
		printf(" ");
	}
	printf("\n");
	color(DEFAULT);
    }
}


void
simple_dump()
{
    char            buf[16];
    int             r, x, len = 0;

    while (!feof(f)) {
	r = fread(buf, 1, 16, f);

	if (r < 1)
	    continue;

	printf("%08x ", len);
	len += 16;

	for (x = 0; x < r; x++) {
	    printf("%02x ", buf[x] & 0xff);
	    if (x == 7)
		printf(" ");
	}

	for (; x < 16; x++) {
	    printf("   ");
	    if (x == 7)
		printf(" ");
	}

	printf("| ");
	for (x = 0; x < r; x++) {
	    printf("%c", isprint(buf[x]) ? buf[x] : '.');
	    if (x == 7)
		printf(" ");
	}
	printf("\n");
    }
}


void
usage(char *s)
{
    printf("Usage: %s [Options] <file>\n", s);
    printf("Options:\n");
    printf("\t-s:\t simple dump (simple hexdump).\n");
    printf("\t-c:\t colored dump (use with files created by the dump module).\n");
    printf("\n");
    exit(0);
}


int
main(int argc, char **argv)
{
    int             x, simple = 0, color = 0;


    printf("hxdmp - THCsnooze hexdump by THC\n");

    if (argc < 2) {
	usage(argv[0]);
    }
    if ((f = fopen(argv[argc - 1], "r")) == NULL)
	usage(argv[0]);


    for (x = 1; x < argc - 1; x++) {
	if (argv[x][0] == '-') {
	    switch (argv[x][1]) {
	    case 's':
		simple = 1;
		break;
	    case 'c':
		color = 1;
		break;
	    default:
		usage(argv[0]);
		break;
	    }
	} else {
	    usage(argv[0]);
	}
    }

    if (!color && !simple)
	usage(argv[0]);

    if (simple)
	simple_dump();

    if (color)
	color_dump();

    return 0;
}
