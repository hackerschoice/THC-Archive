#ifndef __OFFLINE_SNOOZE_H
#define __OFFLINE_SNOOZE_H

extern int      udp, tcp, data_len, finished;

extern unsigned short src_port, dst_port;

extern unsigned int src_addr, dst_addr;

extern unsigned char *server_data, *client_data, *udp_data, *save_data;


#endif
