#include <snooze_lua.h>
#include <stdio.h>
#include <stdlib.h>

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include <lua.h>
#include <lauxlib.h>
#include <lualib.h>
#include <nids.h>
#include <misc.h>
#include <utils_lua.h>
#include <snooze_lua_thread.h>

#ifdef OFFLINE
#include <offline-snooze.h>
#else
#include <main.h>
#endif

#define BUFF_SIZE	8192


/*
 * snooze lue library functions
 */
static int
snooze_src_port(lua_State * s)
{
#ifdef OFFLINE
    lua_pushnumber(s, (lua_Number) src_port);
#else
    int             c_idx = snooze_s_to_i(s);
    if (lua_ctx[c_idx].w == IPPROTO_TCP) {
	lua_pushnumber(s, (lua_Number) lua_ctx[c_idx].cur_tcp_stream->addr.source);
    } else if (lua_ctx[c_idx].w == IPPROTO_UDP) {
	lua_pushnumber(s, (lua_Number) lua_ctx[c_idx].cur_udp_tuple4->source);
    } else {
	lua_pushnil(s);
    }
#endif
    return 1;
}


static int
snooze_dst_port(lua_State * s)
{
#ifdef OFFLINE
    lua_pushnumber(s, (lua_Number) dst_port);
#else
    int             c_idx = snooze_s_to_i(s);
    if (lua_ctx[c_idx].w == IPPROTO_TCP) {
	lua_pushnumber(s, (lua_Number) lua_ctx[c_idx].cur_tcp_stream->addr.dest);
    } else if (lua_ctx[c_idx].w == IPPROTO_UDP) {
	lua_pushnumber(s, (lua_Number) lua_ctx[c_idx].cur_udp_tuple4->dest);
    } else {
	lua_pushnil(s);
    }
#endif
    return 1;
}


static int
snooze_src_addr(lua_State * s)
{
    char           *ptr = NULL, *r = NULL;
    struct in_addr  a;

#ifdef OFFLINE
    a.s_addr = src_addr;
#else
    int             c_idx = snooze_s_to_i(s);
    if (lua_ctx[c_idx].w == IPPROTO_TCP)
	a.s_addr = lua_ctx[c_idx].cur_tcp_stream->addr.saddr;
    else if (lua_ctx[c_idx].w == IPPROTO_UDP)
	a.s_addr = lua_ctx[c_idx].cur_udp_tuple4->saddr;
#endif
    ptr = inet_ntoa(a);

    r = xmalloc(strlen(ptr) + 1);
    strcpy(r, ptr);

    lua_pushlstring(s, r, strlen(r));

    return 1;
}


static int
snooze_dst_addr(lua_State * s)
{
    char           *ptr = NULL, *r = NULL;
    struct in_addr  a;

#ifdef OFFLINE
    a.s_addr = dst_addr;
#else
    int             c_idx = snooze_s_to_i(s);
    if (lua_ctx[c_idx].w == IPPROTO_TCP)
	a.s_addr = lua_ctx[c_idx].cur_tcp_stream->addr.daddr;
    else if (lua_ctx[c_idx].w == IPPROTO_UDP)
	a.s_addr = lua_ctx[c_idx].cur_udp_tuple4->daddr;
#endif
    ptr = inet_ntoa(a);

    r = xmalloc(strlen(ptr) + 1);
    strcpy(r, ptr);

    lua_pushlstring(s, r, strlen(r));

    return 1;
}


static int
snooze_get_client(lua_State * s)
{
#ifdef OFFLINE
    if (!tcp || !client_data) {
	lua_pushnil(s);
	return 1;
    }
    lua_pushlstring(s, client_data, data_len);
#else
    int             c_idx = snooze_s_to_i(s);
    if (lua_ctx[c_idx].w == IPPROTO_TCP) {
	lua_pushlstring(s, \
			lua_ctx[c_idx].cur_tcp_stream->client.data, \
			lua_ctx[c_idx].cur_tcp_stream->client.count_new);
    } else {
	lua_pushnil(s);
    }
#endif
    return 1;
}


static int
snooze_get_server(lua_State * s)
{
#ifdef OFFLINE
    if (!tcp || !server_data) {
	lua_pushnil(s);
	return 1;
    }
    lua_pushlstring(s, server_data, data_len);
#else
    int             c_idx = snooze_s_to_i(s);
    if (lua_ctx[c_idx].w == IPPROTO_TCP) {
	lua_pushlstring(s, \
			lua_ctx[c_idx].cur_tcp_stream->server.data, \
			lua_ctx[c_idx].cur_tcp_stream->server.count_new);
    } else {
	lua_pushnil(s);
    }
#endif
    return 1;
}


static int
snooze_get_udp(lua_State * s)
{
#ifdef OFFLINE
    if (!udp || !data_len || !udp_data) {
	lua_pushnil(s);
	return 1;
    }
    lua_pushlstring(s, udp_data, data_len);
#else
    int             c_idx = snooze_s_to_i(s);
    if (lua_ctx[c_idx].w != IPPROTO_UDP) {
	lua_pushnil(s);
	return 1;
    }
    lua_pushlstring(s, \
		    lua_ctx[c_idx].cur_udp_data, \
		    lua_ctx[c_idx].cur_udp_data_len);
#endif
    return 1;
}


static int
snooze_get(lua_State * s)
{
#ifdef OFFLINE
    if (udp || !save_data) {
	lua_pushnil(s);
	return 1;
    }
    lua_pushlstring(s, save_data, strlen(save_data));
#else
    int             c_idx = snooze_s_to_i(s);
    if (lua_ctx[c_idx].w != IPPROTO_TCP) {
	lua_pushnil(s);
	return 1;
    }
    if (lua_ctx[c_idx].cur_snooze_traq->data == NULL) {
	lua_pushnil(s);
	return 1;
    }
    lua_pushlstring(s, \
		    lua_ctx[c_idx].cur_snooze_traq->data, \
		    strlen(lua_ctx[c_idx].cur_snooze_traq->data));
#endif
    return 1;
}


static int
snooze_set(lua_State * s)
{
    const char     *b;
    size_t          l = 0;
#ifndef OFFLINE
    int             c_idx = snooze_s_to_i(s);
#endif

    if ((b = luaL_checklstring(s, 1, &l)) == NULL)
	return 1;

#ifdef OFFLINE
    if (save_data != NULL)
	free(save_data);

    save_data = xstrdup(b);
#else
    if (lua_ctx[c_idx].w != IPPROTO_TCP)
	return 1;

    if (lua_ctx[c_idx].cur_snooze_traq->data != NULL)
	free(lua_ctx[c_idx].cur_snooze_traq->data);

    lua_ctx[c_idx].cur_snooze_traq->data = xstrdup(b);
#endif
    return 1;
}


static int
snooze_save(lua_State * s)
{
    const char     *b = NULL;
    size_t          l = 0;
    FILE           *f = NULL;
#ifndef OFFLINE
    int             c_idx = snooze_s_to_i(s);
#endif

    if ((b = luaL_checklstring(s, 1, &l)) == NULL)
	return 1;

#ifndef OFFLINE
    if (lua_ctx[c_idx].w == IPPROTO_UDP) {
	if ((f = fopen(lua_ctx[c_idx].cur_udp_fname, "a")) == NULL)
	    return 1;
    } else {
	if (lua_ctx[c_idx].w != IPPROTO_TCP)
	    return 1;

	if ((f = fopen(lua_ctx[c_idx].cur_snooze_traq->fname, "a")) == NULL)
	    return 1;
    }

    fwrite(b, l, 1, f);
    fclose(f);
#else
    f = stdin;
    printf("snooze_save: +++++++++++++++++\n");
    printf("%s\n", b);
    printf("++++++++++++++++++++++++++++++\n");
#endif
    return 1;
}


static int
snooze_finished(lua_State * s)
{
#ifdef OFFLINE
    finished = 1;
#else
    int             c_idx = snooze_s_to_i(s);
    if (lua_ctx[c_idx].w == IPPROTO_TCP)
	lua_ctx[c_idx].cur_snooze_traq->fin = 1;
#endif
    return 1;
}


static const luaL_reg lib_snooze[] = {
    {"src_addr", snooze_src_addr},
    {"dst_addr", snooze_dst_addr},
    {"src_port", snooze_src_port},
    {"dst_port", snooze_dst_port},
    {"get_client", snooze_get_client},
    {"get_server", snooze_get_server},
    {"get_udp", snooze_get_udp},
    {"save", snooze_save},
    {"get", snooze_get},
    {"set", snooze_set},
    {"finished", snooze_finished},
    {NULL, NULL}
};


static const char *
read_data(lua_State * s, void *fd, size_t * size)
{
    static char     buff[BUFF_SIZE];
    snooze_lua_mod_code_t *mc = NULL;

    if (fd == NULL)
	return NULL;

    mc = (snooze_lua_mod_code_t *) fd;

    if (mc->off >= mc->code_len)
	return NULL;

    if (mc->code_len - mc->off > BUFF_SIZE) {
	*size = BUFF_SIZE;
	memcpy(buff, mc->code + mc->off, BUFF_SIZE);
	mc->off += BUFF_SIZE;
    } else {
	*size = mc->code_len - mc->off;
	memcpy(buff, mc->code + mc->off, mc->code_len - mc->off);
	mc->off += mc->code_len - mc->off;
    }

    return buff;
}


void
snooze_lua_reset(snooze_lua_mod_code_t * mc)
{
    mc->off = 0;
#ifdef __THREAD
    pthread_mutex_unlock(&mc->lock);
#endif
}


lua_State      *
snooze_lua_init(snooze_lua_mod_code_t * mc)
{
    lua_State      *state = NULL;


    if ((state = lua_open()) == NULL)
	die("snooze_lua_init: lua_open");

    luaopen_string(state);
    luaopen_base(state);
    luaL_openlib(state, "snooze", lib_snooze, 1);
    luaopen_utils(state);

#ifdef __THREAD
    pthread_mutex_lock(&mc->lock);
#endif

    lua_load(state, read_data, mc, "=stdin");

    return state;
}

#ifndef OFFLINE
void           *
snooze_lua_start_thread(void *a)
{
    int            *idx_ptr = (int *) a, idx;

    idx = *idx_ptr;
    lua_pcall(lua_ctx[idx].s, 0, 0, 0);

    if (lua_ctx[idx].w == IPPROTO_TCP) {
	if (lua_ctx[idx].cur_snooze_traq->fin == 1) {
	    snooze_traq_delete(lua_ctx[idx].cur_snooze_traq);
	    snooze_traq_free(lua_ctx[idx].cur_snooze_traq);
	}
    }
    snooze_free_i(idx);

    return NULL;
}
#endif


int
snooze_lua_start_offline (lua_State *s)
{
    return lua_pcall(s, 0, 0, 0);
}


#ifndef OFFLINE
void
snooze_lua_start(int idx)
{
#ifdef __THREAD
    pthread_t       th;
#endif
    int            *arg;

    arg = xmalloc(sizeof(int));
    *arg = idx;

#ifdef __THREAD
    pthread_create(&th, NULL, &snooze_lua_start_thread, arg);
#else
    snooze_lua_start_thread (arg);
#endif
}
#endif
