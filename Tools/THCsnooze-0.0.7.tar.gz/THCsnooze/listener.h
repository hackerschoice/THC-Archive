#ifndef __LISTENER_H
#define __LISTENER_H

/*
 * magic values send from the client telling the listener what to do.
 */
#define L_NEW_MOD	"asdasdasdasdasdasdasdasdasdasdas"
#define L_GET_LOG	"asasdasdasdasdasdasdasdasdasdasd"

void            listener();

#endif
