#ifndef __UTILS_LUA_H
#define __UTILS_LUA_H

#include <lua.h>

#define LUA_UTILSLIBNAME  "utils"

int             luaopen_utils(lua_State *);

#endif
