#include <ssl.h>
#include <misc.h>

/*
 * the client verifies the server certificate agains this checksum.
 */
char            vrfy_digest[EVP_MAX_MD_SIZE];

void
ssl_set_digest(char *c)
{
    int             x = 0;
    char           *ptr = NULL;

    memset(vrfy_digest, 0, EVP_MAX_MD_SIZE);

    ptr = strtok(c, ":");
    do {
	vrfy_digest[x++] = strtol(ptr, NULL, 16) & 0xff;
    } while ((ptr = strtok(NULL, ":")) != NULL && x < EVP_MAX_MD_SIZE);
}


void
ssl_init()
{
    SSL_load_error_strings();
    SSLeay_add_ssl_algorithms();
}


ssl_t          *
ssl_setup(int sock, int w, char *key, char *cert)
{
    SSL_METHOD     *meth = NULL;
    SSL_CTX        *ctx = NULL;
    SSL            *ssl = NULL;
    ssl_t          *ret = NULL;

    ssl_init();

    if (w == SSL_CLIENT) {
	if ((meth = TLSv1_client_method()) == NULL)
	    die("TLSv1_client_method");
    } else if (w == SSL_SERVER) {
	if ((meth = TLSv1_server_method()) == NULL)
	    die("TLSv1_client_method");
    } else {
	die("ssl_setup: what?");
    }

    if ((ctx = SSL_CTX_new(meth)) == NULL)
	die("SSL_CTX_new");

    if (cert != NULL) {
	if (SSL_CTX_use_certificate_file(ctx, cert, SSL_FILETYPE_PEM) <= 0)
	    die("SSL_CTX_use_certificate_file");
    }
    if (key != NULL) {
	if (SSL_CTX_use_PrivateKey_file(ctx, key, SSL_FILETYPE_PEM) <= 0)
	    die("SSL_CTX_usePrivateKey_file");
    }
    if (key && !SSL_CTX_check_private_key(ctx))
	die("SSL_CTX_check_private_key");

    if ((ssl = SSL_new(ctx)) == NULL)
	die("SSL_new");

    SSL_set_fd(ssl, sock);

    ret = xmalloc(sizeof(ssl_t));
    ret->ssl = ssl;
    ret->ctx = ctx;

    return ret;
}


int
ssl_post_init(ssl_t * s)
{
    char            digest[EVP_MAX_MD_SIZE];
    unsigned int    len = 0;
    int             x;
    X509           *c = NULL;


    if (s->who == SSL_SERVER)
	return 1;

    if ((c = SSL_get_peer_certificate(s->ssl)) == NULL)
	return 0;

    if (!X509_digest(c, EVP_sha1(), digest, &len) || len != 20)
	return 0;

    for (x = 0; x < len; x++) {
	if (digest[x] != vrfy_digest[x]) {
	    return 0;
	}
    }

    return 1;
}


ssl_t          *
ssl_do_accept(int s, char *key, char *cert)
{
    ssl_t          *ssl = NULL;

    if ((ssl = ssl_setup(s, SSL_SERVER, key, cert)) == NULL)
	return NULL;

    SSL_accept(ssl->ssl);
    ssl->who = SSL_SERVER;

    if (ssl_post_init(ssl) != 1) {
	return NULL;
    }
    return ssl;
}


ssl_t          *
ssl_do_connect(int s)
{
    ssl_t          *ssl = NULL;

    if ((ssl = ssl_setup(s, SSL_CLIENT, NULL, NULL)) == NULL)
	return NULL;

    SSL_connect(ssl->ssl);
    ssl->who = SSL_CLIENT;

    if (ssl_post_init(ssl) != 1) {
	return NULL;
    }
    return ssl;
}


void
ssl_free(ssl_t * s)
{
    if (s->ssl != NULL)
	SSL_free(s->ssl);

    if (s->ctx != NULL)
	SSL_CTX_free(s->ctx);
}
