#ifndef __SNOOZE_LUA_H
#define __SNOOZE_LUA_H

#include <lua.h>
#include <pthread.h>

typedef struct {
    char           *code;
    int             code_len, off;
    pthread_mutex_t lock;
}               snooze_lua_mod_code_t;


lua_State      *snooze_lua_init(snooze_lua_mod_code_t *);
void            snooze_lua_start(int);
void            snooze_lua_reset(snooze_lua_mod_code_t *);
int             snooze_lua_start_offline (lua_State *);

#endif
