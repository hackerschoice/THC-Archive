#ifndef __SSL_H
#define __SSL_H

#include <openssl/ssl.h>

#define SSL_SERVER	1
#define SSL_CLIENT	2

typedef struct {
    SSL            *ssl;
    SSL_CTX        *ctx;
    int             who;
}               ssl_t;

void            ssl_init();
void            ssl_free(ssl_t *);
ssl_t          *ssl_setup(int, int, char *, char *);
ssl_t          *ssl_do_connect(int);
ssl_t          *ssl_do_accept(int, char *, char *);
void            ssl_set_digest(char *);

#endif
