#!/bin/sh
clear

echo "This script will generate a private key and certificate for use with"
echo "THCsnooze. just follow the instructions. the certificate will be named"
echo "cert.pem. the keyfile file be named private.pem."
echo
echo

openssl req -new -out tmp.csr
echo
echo "Enter here the passphrase you entered above."
openssl rsa -in privkey.pem -out private.pem > /dev/null 2> /dev/null
openssl x509 -in tmp.csr -out cert.pem -req -signkey private.pem -days 365 > /dev/null 2> /dev/null
echo
echo
echo "The following fingerprint has to be supplied to THCsnoozed:"
openssl x509 -sha1 -fingerprint < cert.pem | grep SHA1 -
rm tmp.csr privkey.pem
echo "done."
echo
