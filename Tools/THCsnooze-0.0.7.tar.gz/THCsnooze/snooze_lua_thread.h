#ifndef __SNOOZE_LUA_THREAD_H
#define __SNOOZE_LUA_THREAD_H

#ifdef __THREAD
#define THREAD_NR	32
#else
#define THREAD_NR	1
#endif

#include <lua.h>
#include <pthread.h>
#include <traq.h>

typedef struct {
    int             w, use;

    lua_State      *s;

    struct tcp_stream *cur_tcp_stream;
    snooze_traq_t  *cur_snooze_traq;

    struct tuple4  *cur_udp_tuple4;
    char           *cur_udp_data, *cur_udp_fname;
    int             cur_udp_data_len;
}               snooze_lua_ctx_t;

extern snooze_lua_ctx_t lua_ctx[];


/*
 * return index into lua_ctx for lua_State s.
 */
int             snooze_s_to_i(lua_State * s);


/*
 * for lua_State s return an index into lua_ctx.
 */
int             snooze_get_i(lua_State * s);


/*
 * free lua_ctx i;
 */
void            snooze_free_i(int i);


struct tcp_stream *snooze_copy_tcp_stream(struct tcp_stream *);
void            snooze_free_tcp_stream(struct tcp_stream *);

#endif
