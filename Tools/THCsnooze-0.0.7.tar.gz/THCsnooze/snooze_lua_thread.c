#include <snooze_lua_thread.h>
#include <string.h>
#include <stdlib.h>
#include <netinet/in.h>
#include <misc.h>

snooze_lua_ctx_t lua_ctx[THREAD_NR];


int 
snooze_s_to_i(lua_State * s)
{
    int             x;

    for (x = 0; x < THREAD_NR; x++) {
	if (s == lua_ctx[x].s && lua_ctx[x].use == 1)
	    return x;
    }

    return -1;
}


int 
snooze_get_i(lua_State * s)
{
    int             x;

    for (x = 0; x < THREAD_NR; x++) {
	if (lua_ctx[x].use == 0) {
	    lua_ctx[x].use = 1;
	    lua_ctx[x].s = s;
	    return x;
	}
    }

    return -1;
}


struct tcp_stream *
snooze_copy_tcp_stream(struct tcp_stream * i)
{
    struct tcp_stream *ret;

    ret = xmalloc(sizeof(struct tcp_stream));
    memcpy(&ret->addr, &i->addr, sizeof(struct tuple4));

    memcpy(&ret->client, &i->client, sizeof(struct half_stream));
    ret->client.data = xmalloc(i->client.count_new);
    memcpy(ret->client.data, i->client.data, i->client.count_new);

    memcpy(&ret->server, &i->server, sizeof(struct half_stream));
    ret->server.data = xmalloc(i->server.count_new);
    memcpy(ret->server.data, i->server.data, i->server.count_new);

    return ret;
}


void
snooze_free_tcp_stream(struct tcp_stream * s)
{
    free(s->server.data);
    free(s->client.data);
    free(s);
}


void 
snooze_free_i(int i)
{
    if (lua_ctx[i].w == IPPROTO_UDP) {
	free(lua_ctx[i].cur_udp_data);
	free(lua_ctx[i].cur_udp_fname);
	free(lua_ctx[i].cur_udp_tuple4);
    } else {
	snooze_free_tcp_stream(lua_ctx[i].cur_tcp_stream);
    }

    lua_ctx[i].use = 0;
}
