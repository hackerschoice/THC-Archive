#!/bin/sh

cardctl eject $1
echo "Ejected $1"
sleep 1
cardctl insert $1
echo "Inserted $1"

