#!/bin/sh
# count 100 beacon pkts
# -------------------------------------------------------------------------

tcpdump -c 100 -i aj0 -e "ether[0] & 0xff == 0x80"|awk '{print $2}'|sort -u
