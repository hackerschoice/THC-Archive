... use the makeall.sh script to compile the source code.
If you don't have installed the airjack driver yet, install it
before compiling these programms or don't use 'getleap' and deauth'.
(The makeall.sh script will ask you, if you want to compile these
tools or not.)

Dependencies:
-------------
- OpenSSL and OpenSSL Devel Libs e.g openssl-0.9.7-devel

get_leap and deauth tool:
--------------------------
- min. libpcap version 0.8 
- airjack wireless card driver (tested ver.0.6.6b)
  (see http://802.11ninja.net/airjack/ for details)
- PrismII-based wless card 

... and some others, look into the src code to find them :)

BTW there is no warranty for anything, use it on your own risk.
Don't use it for any illegal actions, you are responsible for
everything you are doing.

have fun ...
deX7er

