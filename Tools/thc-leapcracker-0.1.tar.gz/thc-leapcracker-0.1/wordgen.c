/*-----------------------------------------------------------------------------------------------------

	Password/Number Generator bad coded by DeX7er (dexter@thc.org) Version 0.1
	
	See -h for usage. This code is POC and comes without any warranty, use it on your own risk.
	
	Compile: gcc -Wall -o filename filename
 
 -------------------------------------------------------------------------------------------------------	


	License:
	--------
	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.
	
	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.
	
	You should have received a copy of the GNU General Public License
	along with this program; if not, write to the Free Software
	Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

-------------------------------------------------------------------------------------------------------
*/


#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <getopt.h>	
#include <unistd.h>

#define MAX_STR_LENGTH	1000
#define ALLOWED_CHARS		" abcdefghijklmnopqrstuvwxyz����ABCDEFGHIJKLMNOPQRSTUVWXYZ���1234567890._-!/~"

//#define PARANOID		// uncomment it if you want alphabet input checking against allowed characters
					// usually it makes not much sense to do that

// Structs
typedef struct {
	u_int		a[255]; 
	u_char 		*pwd;
	u_char 		*cmpstr;
} PWD;

// Prototyping
void usage(char *PrgName);
unsigned long long power(u_int val, u_int pow);
char *givepwd(char *alpha,u_int alphalength,u_int pwdlength, PWD *i);
char *getalpha(char *alpha);
char *strsub(char *S1, char *S2, char *S3);
int checkinput(u_char *allowed_alphabet, u_int allowed_alphalength, u_char *input, u_int inputlen);

//globals
u_char *allowed_alphabet = ALLOWED_CHARS;
u_int   allowed_alphalength;

// Main
int main(int argc, char **argv) 
{   
	u_char *alpha=NULL,output_verbose=0,check=0;
	u_int pwdlength=0;
	u_int alphalength=0;
	u_int c;
	u_int m;
	u_char *prefix;
	u_char *postfix;
	u_int prefixlen=0;
	u_int postfixlen=0;
	
	unsigned long long rounds;
	
	PWD sPwd;
	
	allowed_alphalength = strlen(allowed_alphabet);
	
	while((c = getopt(argc, argv, "l:a:w:p:o:vch")) != EOF)
    {      
        switch (c)
        {
			case 'l':
				pwdlength = atoi(optarg);
				sPwd.pwd    = malloc(pwdlength);
				if(sPwd.pwd == NULL) { printf("Malloc failed\n"); exit(EXIT_FAILURE); }
				break;
			case 'a':
				if(alpha != NULL) { printf("Error: you can't use -a and -w at the same time�\n"); usage(argv[0]); }
				alpha = optarg;
				alphalength = strlen(alpha);
				break;
			case 'w':
				if(alpha != NULL) { printf("Error: you can't use -a and -w at the same time�\n"); usage(argv[0]); }
				alpha = optarg;
				alpha = getalpha(alpha); // substitute wildcards (a-z ; A-Z; 0-9)
				alphalength = strlen(alpha); 
				break;
			case 'p':
				prefix = optarg;
				prefixlen = strlen(prefix);
				break;
			case 'o':
				postfix = optarg;
				postfixlen = strlen(postfix);
				break;
			case 'v':
				output_verbose=1;
				break;
			case 'c':
				check=1;
				break;
			
			default:
				usage(argv[0]);
				
        }
	}
	if((alphalength == 0) || (pwdlength == 0 )) { printf("\nError: Please set alphabet and password length.\n\n"); usage(argv[0]); }
		
	if((power(alphalength,pwdlength) >= power(2,(8*sizeof(rounds)))-1 ) || (power(alphalength,pwdlength) == 0)) { 
		printf("\nError: Too many combinations. \n\n");
		usage(argv[0]);
	} 
	
	u_char password[pwdlength+prefixlen+postfixlen+1];
	memset(password,0,pwdlength+prefixlen+postfixlen+1);
	memcpy(password,prefix,prefixlen);
	memcpy(password+pwdlength+prefixlen,postfix,postfixlen);
	
	for(m = 0; m < pwdlength; m++) sPwd.a[m] = 0;
	
	for(m = 0; m < pwdlength; m++) sPwd.pwd[m] = alpha[0];
	sPwd.pwd[pwdlength] = '\0';
	
	sPwd.cmpstr = malloc(pwdlength);
	if(sPwd.cmpstr == NULL) { printf("Malloc failed\n"); exit(EXIT_FAILURE); }
	for(m = 0; m < pwdlength; m++) sPwd.cmpstr[m] = alpha[alphalength-1];
	sPwd.cmpstr[pwdlength] = '\0';
	
	if(check) {	// -c set ?
		printf("\nThat means %llu combinations (Go -> hit enter) or Ctrl-C",power(alphalength,pwdlength));
		getchar();
		printf("\n");
	}
	
	// Main Loop
	for(rounds=0;rounds < power(alphalength,pwdlength); rounds++) {
		givepwd(alpha,alphalength,pwdlength,&sPwd);
		
		memcpy(password+prefixlen,sPwd.pwd,pwdlength);
		
		if(output_verbose)  
			printf("%llu. Generated Pwd:\t%s\n",rounds+1,password);
		else 
			printf("%s\n",password);
	}
	
	free(sPwd.pwd);
	free(sPwd.cmpstr);
	exit(EXIT_SUCCESS);
}

// Password Generator Function
char *givepwd(char *alpha,u_int alphalength,u_int pwdlength, PWD *i) {
	u_int n;
	
	for(n = 0; n < pwdlength; n++) { 
		i->pwd[pwdlength-(n + 1)] = alpha[ i->a[n] ];		
		}
	i->a[0]++;															// inc lowest number
	if(i->a[0] >= alphalength) i->a[0] = 0; 							// make sure a[0] gets not too big
																		// overflow to lowest number in system			
	for(n = 1; n < pwdlength; n++) {
		if(!strncmp(&i->pwd[pwdlength-n],&i->cmpstr[pwdlength-n],n)) { 	// end in numbersystem reached ? -> inc. number
			i->a[n]++;												   	// e.g dec-system:last number xx19; next = xx20
			if(i->a[n] >= alphalength) i->a[n] = 0;  					// make sure a[n] gets not too big
		}
	}
	return(i->pwd);	
}

char *getalpha(char *alpha) {
	
	char *az = "abcdefghijklmnopqrstuvwxyz";
	char *AZ = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	char *num = "0123456789";
	char *input;
	
	if(strlen(alpha) > MAX_STR_LENGTH) { printf("Alphabetstring too long\n"); exit(EXIT_FAILURE); }	
	if ((input = malloc(strlen(alpha)+1)) == NULL ) { printf("Malloc failed\n"); exit(EXIT_FAILURE); }
	strncpy(input,alpha,strlen(alpha));
	input[strlen(alpha)] = '\0';
	
	input = strsub(input,"a-z",az);
	input = strsub(input,"A-Z",AZ);
	input = strsub(input,"0-9",num);

	return(input);
}

// find S2 in S1 and substitute it with S3 
char *strsub(char *S1, char *S2, char *S3) {
	
	u_int a;
	char *psHelp;
	char *psNewStr = NULL; 
	u_int psNewStrLen = 0;
	
#ifdef PARANOID	
	int check_S1;
	int check_S2;
	int check_S3;
#endif	
	
	// some basic tests
	if(strlen(S1) > MAX_STR_LENGTH) { printf("S1 too long\n"); exit(EXIT_FAILURE); }
	if(strlen(S2) > MAX_STR_LENGTH) { printf("S2 too long\n"); exit(EXIT_FAILURE); }
	if(strlen(S3) > MAX_STR_LENGTH) { printf("S3 too long\n"); exit(EXIT_FAILURE); }
	
#ifdef PARANOID		
	check_S1 = checkinput(allowed_alphabet, allowed_alphalength, S1, strlen(S1));
	if( check_S1 == EXIT_FAILURE ) { printf("S1 includes illegal characters\n"); exit(EXIT_FAILURE); }
	check_S2 = checkinput(allowed_alphabet, allowed_alphalength, S2, strlen(S2));
	if( check_S2 == EXIT_FAILURE ) { printf("S2 includes illegal characters\n"); exit(EXIT_FAILURE); }
	check_S3 = checkinput(allowed_alphabet, allowed_alphalength, S3, strlen(S3));
	if( check_S3 == EXIT_FAILURE ) { printf("S3 includes illegal characters\n"); exit(EXIT_FAILURE); }
#endif
	
	if((psHelp = strstr(S1,S2)) != NULL ) {
		
		a = psHelp - S1;
		psNewStrLen = strlen(S1)+strlen(S3)-strlen(S2)+1;
		if ((psNewStr = malloc(psNewStrLen)) == NULL ){ printf("Malloc failed\n"); exit(EXIT_FAILURE); }
		memcpy(psNewStr,S1,a);
		memcpy(psNewStr+a,S3,strlen(S3));	
		memcpy(psNewStr+a+strlen(S3),psHelp+strlen(S2),strlen(psHelp+strlen(S2)));	
		psNewStr[psNewStrLen-1] = '\0';
	}
	else {
		//printf("Ret=%s\n",S1);
		return(S1);
	}
	S1 = realloc(S1,strlen(psNewStr)+1);
	if(S1 == NULL) { printf("Realloc failed\n"); exit(EXIT_FAILURE); }
	strncpy(S1,psNewStr,strlen(psNewStr));
	S1[strlen(psNewStr)] = '\0';
	
	free(psNewStr);
	
	//printf("Ret=%s\n",S1);
	return(S1);
}

// Power Function without math.h
unsigned long long power(u_int val, u_int pow)
{       long long ret_val = 1;
        u_int i;
        for(i = 0; i < pow; i++)
                ret_val *= val;
        return(ret_val);
}

int checkinput(u_char *allowed_alphabet, u_int allowed_alphalength, u_char *input, u_int inputlen) {
	
	u_int i;
	u_char *p;
	
	for(i=0; i < inputlen; i++) {
		p = (u_char *) memchr(allowed_alphabet,input[i],allowed_alphalength);
		if (p == NULL) {
			printf("Error ASCII:0x%02x(%c) not allowed !\n",input[i],input[i]);
			return(EXIT_FAILURE);
		}
	}
	return(EXIT_SUCCESS);
}

// Usage Function
void usage(char *PrgName) {
	double maxnumber;
	maxnumber = power(2,(8*sizeof(long long)))-1;
	printf("\n");
	printf("Password/Number Generator written by DeX7er '03 (dexter@thc.org) Version 0.1    \n");
	printf("You will always get the latest version and other cool stuff at www.thc.org    \n\n");
	printf("Usages: %s -l <Password length> -a <Alphabet string> [-p] [-o] [-v] [-c]\n",PrgName);
	printf("           -l length of the password string\n");
	printf("           -a alphabet for password generator\n");
	printf("           -w alphabet input with wildcars: a-z; A-Z; 0-9\n");
	printf("           -p password prefix\n");
	printf("           -o password postfix\n");
	printf("           -v verbose output to stdout\n");
	printf("           -c check number of cominations\n");
	printf("\nmax. number of combinations = %.lf\n\n",maxnumber);
	exit(1);
}
