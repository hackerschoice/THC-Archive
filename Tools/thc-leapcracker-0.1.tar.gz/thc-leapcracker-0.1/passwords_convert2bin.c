//
//  passwords_convert2bin: bad coded by DeX7er '03 (dexter@thc.org)
//
//  Converts 'password.txt' to 'password.bin' for bruteforcer tool
//
//  ------------------------------------------------------------------------

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <getopt.h>
#include <string.h>
#include <openssl/ssl.h>
#include <openssl/evp.h>

#define MAXPWDLENGTH 	15
#define READLINELENGTH  80

#define ALLOWED_CHARS		" abcdefghijklmnopqrstuvwxyz����ABCDEFGHIJKLMNOPQRSTUVWXYZ���1234567890-+!?._/"

// MD4 defines
#define S11 3
#define S12 7
#define S13 11
#define S14 19
#define S21 3
#define S22 5
#define S23 9
#define S24 13
#define S31 3
#define S32 9
#define S33 11
#define S34 15

/* F, G and H are basic MD4 functions. */
#define F(x, y, z) (((x) & (y)) | ((~x) & (z)))
#define G(x, y, z) (((x) & (y)) | ((x) & (z)) | ((y) & (z)))
#define H(x, y, z) ((x) ^ (y) ^ (z))

/* ROTATE_LEFT rotates x left n bits. */
#define ROTATE_LEFT(x, n) (((x) << (n)) | ((x) >> (32-(n))))

/* FF, GG and HH are transformations for rounds 1, 2 and 3 */
/* Rotation is separate from addition to prevent recomputation */
#define FF(a, b, c, d, x, s, round) {(a) += F ((b), (c), (d)) + (x); (a) = ROTATE_LEFT ((a), (s));/*print_vars((a),(b),(c),(d),(x),(s),(round));*/}
#define GG(a, b, c, d, x, s, round) {(a) += G ((b), (c), (d)) + (x) + (UINT4)0x5a827999; (a) = ROTATE_LEFT ((a), (s));/*print_vars((a),(b),(c),(d),(x),(s),(round));*/}
#define HH(a, b, c, d, x, s, round) {(a) = (a) + H ((b), (c), (d)) + (x) + (UINT4)0x6ed9eba1;(a) = ROTATE_LEFT ((a), (s));/*print_vars((a),(b),(c),(d),(x),(s),(round));*/}

typedef unsigned long int UINT4;	
	
// prototyping
int NtChallengeResponse(u_char *Challenge,u_char *PwdStr, u_char *DESHash);
void StrToHex(unsigned char *cpString, unsigned int nSizeString,unsigned char *cpHexValue,unsigned int uSizeHexValue );
unsigned char *DESencrypt( unsigned char *cpData, int uDataLength, unsigned char *cpDesKey,unsigned char *cpDesHash);
static void Decode (UINT4 *output, unsigned char *input, unsigned int len);
unsigned char *md4(unsigned char *str,unsigned char *md4hashvalue);	
int checkinput(u_char *alphabet, u_int alphalength, u_char *input, u_int inputlen);
u_char *DESParityCorrection(u_char *c, u_char *cc);
void printhex(u_char *bs, u_int n);
void usage();

// globals
u_char *prg;
u_int  slen;
u_char *alphabet = ALLOWED_CHARS;
u_int alphalength;

int main (int argc, char **argv) {
 	
	prg = argv[0];
	alphalength = strlen(alphabet);
	
	FILE 	*fpr,*fpw;
	u_char 	*fileread = NULL;
	u_char 	*filewrite = NULL;
	u_char   PwdStr[MAXPWDLENGTH+1];
    u_char   Challenge[8] = { 0xde, 0xad, 0xde, 0xad, 0xde, 0xad, 0xde, 0xad }; // in case -c is not set
	u_char   DESHash[24];
	u_int    c,n;
	u_char 	verbose=0;
	
	while((c = getopt(argc, argv, "r:w:c:v-h?")) != EOF)
    {      
        switch (c)
        {
            case 'r':
				if(checkinput(alphabet, alphalength, optarg, strlen(optarg)) == EXIT_FAILURE) {
					printf("Error: wrong ASCII-file format\n");
					exit(EXIT_FAILURE);
				}
				fileread = optarg;
                break;
			case 'w':
				if(checkinput(alphabet, alphalength, optarg, strlen(optarg)) == EXIT_FAILURE) {
					printf("Error: wrong binary-file format\n");
					exit(EXIT_FAILURE);
				}
				filewrite = optarg;
				break;
			case 'c':
				StrToHex(optarg,strlen(optarg),Challenge,8);
				break;
			case 'v':
				verbose = 1;
				break;
			case '-':
			case 'h':
			case '?':
				usage();		
        }
	}
	
	printf("Challenge: "); printhex(Challenge,8); printf("\n");
	
	if((fpr = fopen(fileread , "r")) == NULL ) { printf("\nError: opening file %s\n\n",fileread); usage(); }
	if((fpw = fopen(filewrite, "a")) == NULL ) { printf("\nError: opening file %s\n\n",fileread); usage(); }
		
	while(fgets(PwdStr,READLINELENGTH,fpr) != NULL) {
		
		if(strlen(PwdStr) > MAXPWDLENGTH+1) { printf("Error: max. password length = 15 characters\n"); usage(); }
		
		if(strlen(PwdStr) == 1) break;
		
		//printf("Length: %d\n",strlen(PwdStr));
		PwdStr[MAXPWDLENGTH] = '\0'; 
		
		// kill the LF and fill the pwd string with zero padding
		if(PwdStr[strlen(PwdStr)-1] == '\n') memset(PwdStr+(strlen(PwdStr)-1),0,MAXPWDLENGTH-(strlen(PwdStr)-1));
		else memset(PwdStr+(strlen(PwdStr)),0,MAXPWDLENGTH-(strlen(PwdStr)));
		
		if(verbose) printf("Password: %s\n",PwdStr);
		
		// calculate the DES HASH
		NtChallengeResponse(Challenge, PwdStr, DESHash);
		
		if(verbose) { printf("DESHash : ");printhex(DESHash,24);printf("\n\n"); }
		
		// write to file
		for(n=0; n <= MAXPWDLENGTH; n++) fputc(PwdStr[n],fpw); 
		for(n=0; n < 24			  ; n++) fputc(DESHash[n],fpw);
	}
	
	fclose(fpr);
	fclose(fpw);
	
	exit(EXIT_SUCCESS);
	
}

int NtChallengeResponse(u_char *Challenge,u_char *PwdStr, u_char *DESHash) {
	
	u_int pwdlength = strlen(PwdStr);
	u_int n;
	u_char md4hashvalue1_fixed_key[8];
	u_char md4hashvalue2_fixed_key[8];
	u_char md4hashvalue3_fixed_key[8];
	
	u_char md4hashvalue[16];
	u_char md4hashvaluelast2[7] = { 0,0,0,0,0,0,0 };

	// prepare unicode transformation (it's faster than malloc)
	slen = pwdlength*2;
	u_char str[slen];
	
	// quick'n dirty, but fast :) unicode transformation (abcd -> ab00cd00)
	for(n = 0; n < pwdlength; n++) {
		*(((u_short *) str) + n) = *(u_char *)(PwdStr+n);  
	}
	
	md4(str,md4hashvalue);
	//printf("MD4    : ");printhex(md4hashvalue,16);printf("\n");
	
	memcpy(md4hashvaluelast2,md4hashvalue+14,2);
	DESParityCorrection(md4hashvalue     , md4hashvalue1_fixed_key);
	DESParityCorrection(md4hashvalue+7   , md4hashvalue2_fixed_key);
	DESParityCorrection(md4hashvaluelast2, md4hashvalue3_fixed_key);
	
	DESencrypt(Challenge, 8, md4hashvalue1_fixed_key ,DESHash);
	DESencrypt(Challenge, 8, md4hashvalue2_fixed_key ,DESHash+8);
	DESencrypt(Challenge, 8, md4hashvalue3_fixed_key ,DESHash+16);
	
	return(EXIT_SUCCESS);
}

// String to Hex Conversion
void StrToHex(unsigned char *cpString, unsigned int nSizeString,unsigned char *cpHexValue,unsigned int uSizeHexValue ) 
{
int i,x,y;
unsigned char hex[nSizeString];
	
//printf("\nInput Challenge String= %s SizeString=%d SizeHexval=%d",cpString,nSizeString,uSizeHexValue);	
x = 0;
y = 0;	
	
for (i = 0;i < nSizeString; i++)
	{
		switch ( cpString[i] )
		{
			case '0' :
				hex[i] = 0;
				break;
			case '1' :
				hex[i] = 1;
				break;
			case '2' :
				hex[i] = 2;
				break;
			case '3' :
				hex[i] = 3;
				break;
			case '4' :
				hex[i] = 4;
				break;
			case '5' :
				hex[i] = 5;
				break;
			case '6' :
				hex[i] = 6;
				break;
			case '7' :
				hex[i] = 7;
				break;
			case '8' :
				hex[i] = 8;
				break;
			case '9' :
				hex[i] = 9;
				break;			
			case 'a' :
			case 'A' :
				hex[i] = 0x0A;
				break;
			case 'b' :
			case 'B' :
				hex[i] = 0x0B;
				break;
			case 'c' :
			case 'C' :
				hex[i] = 0x0C;
				break;
			case 'd' :
			case 'D' :
				hex[i] = 0x0D;
				break;
			case 'e' :
			case 'E' :
				hex[i] = 0x0E;
				break;
			case 'f' :
			case 'F' :
				hex[i] = 0x0F;
				break;
			case ' ' :
			case '-' :
			case ':' :
			case '\t':
				continue;
			default:
				printf("\nError: %c is not a hexvalue \n\n",cpString[i]);
				exit(EXIT_FAILURE);
		}
		
		if (x % 2) // every odd value (1,3,5,..) 
			{
			if ( y >= uSizeHexValue ) { printf("\nError: Buffer too small \n\n"); exit(EXIT_FAILURE); }  	// Protect Buffer				
			cpHexValue[y] = hex[i] | (hex[i-1]<<4);	// last low nibble OR with high nibble (shift to high)
			y++;
			}
		x++;
	}
	if ( y <  uSizeHexValue ) { printf("\nError: Buffer bigger than value\n\n"); exit(EXIT_FAILURE); }	// value too short ?
}

void printhex(u_char *bs, u_int n) {
	
	u_int i;
	
	for(i=0; i < n; i++) {
		printf("%02x ",bs[i]);
	}
}

// Decodes input (unsigned char) into output (UINT4). Assumes len is a multiple of 4. 
static void Decode (UINT4 *output, unsigned char *input, unsigned int len)
{
unsigned int i, j;

for (i = 0, j = 0; j < len; i++, j += 4)
 	output[i] = ((UINT4)input[j]) | (((UINT4)input[j+1]) << 8) | (((UINT4)input[j+2]) << 16) | (((UINT4)input[j+3]) << 24);
}

// calculate the md4 hash
unsigned char *md4(unsigned char *str,unsigned char *md4hashvalue) {
	
	UINT4 A = 0x67452301;
	UINT4 B = 0xefcdab89;
	UINT4 C = 0x98badcfe;
	UINT4 D = 0x10325476;
		
	UINT4 a = A, b = B, c = C, d = D;
	
	UINT4 x[16];
	
	unsigned char block[64] = { 0,0,0,0,0,0,0,0,0,0,    // yep, calloc(64,sizeof(char)) works also;
								0,0,0,0,0,0,0,0,0,0,	// but the heap is mutch, mutch slower ...
								0,0,0,0,0,0,0,0,0,0,
								0,0,0,0,0,0,0,0,0,0,
								0,0,0,0,0,0,0,0,0,0,
								0,0,0,0,0,0,0,0,0,0,
								0,0,0,0 };
								
	// quick'n dirty padding, works only up to 31 character input (Pwd length) ,but should be enough for us ..
	memcpy(block,str,slen);
	block[slen] = 0x80;
	block[56] = slen * 8;  
								
	Decode (x, block, 64);
	
	/* Round 1 */
	FF (a, b, c, d, x[ 0], S11,"R1 01:"); 			/* 1 */
	FF (d, a, b, c, x[ 1], S12,"R1 02:"); 			/* 2 */
	FF (c, d, a, b, x[ 2], S13,"R1 03:"); 			/* 3 */
	FF (b, c, d, a, x[ 3], S14,"R1 04:"); 			/* 4 */
	FF (a, b, c, d, x[ 4], S11,"R1 05:"); 			/* 5 */
	FF (d, a, b, c, x[ 5], S12,"R1 06:"); 			/* 6 */
	FF (c, d, a, b, x[ 6], S13,"R1 07:"); 			/* 7 */
	FF (b, c, d, a, x[ 7], S14,"R1 08:"); 			/* 8 */
	FF (a, b, c, d, x[ 8], S11,"R1 09:"); 			/* 9 */
	FF (d, a, b, c, x[ 9], S12,"R1 10:"); 			/* 10 */
	FF (c, d, a, b, x[10], S13,"R1 11:"); 			/* 11 */
	FF (b, c, d, a, x[11], S14,"R1 12:"); 			/* 12 */
	FF (a, b, c, d, x[12], S11,"R1 13:"); 			/* 13 */
	FF (d, a, b, c, x[13], S12,"R1 14:"); 			/* 14 */
	FF (c, d, a, b, x[14], S13,"R1 15:"); 			/* 15 */
	FF (b, c, d, a, x[15], S14,"R1 16:"); 			/* 16 */
	
	/* Round 2 */
	GG (a, b, c, d, x[ 0], S21,"R2 17:"); 			/* 17 */
	GG (d, a, b, c, x[ 4], S22,"R2 18:"); 			/* 18 */
	GG (c, d, a, b, x[ 8], S23,"R2 19:"); 			/* 19 */
	GG (b, c, d, a, x[12], S24,"R2 20:"); 			/* 20 */
	GG (a, b, c, d, x[ 1], S21,"R2 21:"); 			/* 21 */
	GG (d, a, b, c, x[ 5], S22,"R2 22:"); 			/* 22 */
	GG (c, d, a, b, x[ 9], S23,"R2 23:"); 			/* 23 */
	GG (b, c, d, a, x[13], S24,"R2 24:"); 			/* 24 */
	GG (a, b, c, d, x[ 2], S21,"R2 25:"); 			/* 25 */
	GG (d, a, b, c, x[ 6], S22,"R2 26:"); 			/* 26 */
	GG (c, d, a, b, x[10], S23,"R2 27:"); 			/* 27 */
	GG (b, c, d, a, x[14], S24,"R2 28:"); 			/* 28 */
	GG (a, b, c, d, x[ 3], S21,"R2 29:"); 			/* 29 */
	GG (d, a, b, c, x[ 7], S22,"R2 30:"); 			/* 30 */
	GG (c, d, a, b, x[11], S23,"R2 31:"); 			/* 31 */
	GG (b, c, d, a, x[15], S24,"R2 32:"); 			/* 32 */
	
	/* Round 3 */
	HH (a, b, c, d, x[ 0], S31,"R3 33:");			/* 33 */
	HH (d, a, b, c, x[ 8], S32,"R3 34:"); 			/* 34 */
	HH (c, d, a, b, x[ 4], S33,"R3 35:"); 			/* 35 */
	HH (b, c, d, a, x[12], S34,"R3 36:"); 			/* 36 */
	HH (a, b, c, d, x[ 2], S31,"R3 37:"); 			/* 37 */
	HH (d, a, b, c, x[10], S32,"R3 38:"); 			/* 38 */
	HH (c, d, a, b, x[ 6], S33,"R3 39:"); 			/* 39 */
	HH (b, c, d, a, x[14], S34,"R3 40:"); 			/* 40 */
	HH (a, b, c, d, x[ 1], S31,"R3 41:"); 			/* 41 */
	HH (d, a, b, c, x[ 9], S32,"R3 42:"); 			/* 42 */
	HH (c, d, a, b, x[ 5], S33,"R3 43:"); 			/* 43 */
	HH (b, c, d, a, x[13], S34,"R3 44:"); 			/* 44 */
	HH (a, b, c, d, x[ 3], S31,"R3 45:"); 			/* 45 */
	HH (d, a, b, c, x[11], S32,"R3 46:"); 			/* 46 */
	HH (c, d, a, b, x[ 7], S33,"R3 47:"); 			/* 47 */
	HH (b, c, d, a, x[15], S34,"R3 48:");			/* 48 */
	
	A += a;
	B += b;
	C += c;
	D += d;
	
	// some magic typecasts :)
	*(UINT4 *)  md4hashvalue     = A;
	*(UINT4 *) (md4hashvalue+4)  = B;
	*(UINT4 *) (md4hashvalue+8)  = C;
	*(UINT4 *) (md4hashvalue+12) = D;
	
	return(md4hashvalue);
}

u_char *DESParityCorrection(u_char *c, u_char *cc)
{
	unsigned int i;
	unsigned int parity;
	
	memset(cc,0,8);  // for sure. delete it if you are sure that cc is zero
	
	cc[0]  = c[0];
	cc[1]  = (c[1] >> 1) & 0x7e; 
	cc[2]  = (c[2] >> 2) & 0x3e; 
	cc[3]  = (c[3] >> 3) & 0x1e; 
	cc[4]  = (c[4] >> 4) & 0xfe; 
	cc[5]  = (c[5] >> 5) & 0xfe; 
	cc[6]  = (c[6] >> 6) & 0xfe;
	
	cc[1]  |= ((c[0] & 1)   << 7);
	cc[2]  |= ((c[1] & 3)   << 6);
	cc[3]  |= ((c[2] & 7)   << 5);
	cc[4]  |= ((c[3] & 15)  << 4);
	cc[5]  |= ((c[4] & 31)  << 3);
	cc[6]  |= ((c[5] & 63)  << 2);	
	cc[7]  |= ((c[6] & 127) << 1);	
		
	for(i=0; i < 9; i++) {
		parity = (((cc[i] & 128) >> 7) + ((cc[i] & 64) >> 6) + ((cc[i] & 32) >> 5) 
				 +((cc[i] & 16 ) >> 4) + ((cc[i] & 8 ) >> 3) + ((cc[i] & 4 ) >> 2) + ((cc[i] & 2) >> 1));
		
		(parity % 2) ? (cc[i] &= 0xfe) : (cc[i] |= 0x01);
	}
	
	return(cc);
}

unsigned char *DESencrypt( unsigned char *cpData, int uDataLength, unsigned char *cpDesKey,unsigned char *cpDesHash)
{
	EVP_CIPHER_CTX ctx;
	int templen,encdatalen;
    unsigned char *DESHelpBuffer;		// help buffer because the DES output could be twice the input buffer 
										// because of internal padding,etc of OpenSSL Libary
	if ( (DESHelpBuffer = (unsigned char *) malloc(16)) == NULL) exit(0);
	
	int d1,d2,d3;
	encdatalen = 0;
	if ( (d1 = EVP_EncryptInit(&ctx,EVP_des_ecb(),cpDesKey,NULL)) != 1 ) exit(0);	
	if ( (d2 = EVP_EncryptUpdate(&ctx,DESHelpBuffer,&encdatalen,cpData,uDataLength)) != 1 ) exit(0);	
	if ( (d3 = EVP_EncryptFinal(&ctx,&DESHelpBuffer[encdatalen],&templen)) != 1 ) exit(0);
	encdatalen += templen; 
	memcpy(cpDesHash,DESHelpBuffer,8);

	free(DESHelpBuffer);
 	return (cpDesHash);
}

int checkinput(u_char *alphabet, u_int alphalength, u_char *input, u_int inputlen) {
	
	u_int i;
	u_char *p;
	
	for(i=0; i < inputlen; i++) {
		p = (u_char *) memchr(alphabet,input[i],alphalength);
		if (p == NULL) {
			printf("Error ASCII:0x%02x(%c) not allowed !\n",input[i],input[i]);
			return(EXIT_FAILURE);
		}
	}
	return(EXIT_SUCCESS);
}

void usage() {
	printf("\n");
	printf("Password file converter written by DeX7er '03 (dexter@thc.org) Version 0.1      \n");
	printf("You will always get the latest version and other cool stuff at www.thc.org    \n\n");
	printf("Usage: %s -r <passwords.txt> -w <passwords.bin>\n[-c <challenge>] [-v]\n\n",prg);
	printf("Options: -r <filename>   ASCII Passwordlist file.\n");
	printf("         -w <filename>   binary Password file to generate for bruteforcer.  \n");
	printf("         -c <challenge>  8 byte random Challenge for NtChallengeResponse.   \n");
	printf("                         Default:deaddeaddeaddead\n");
	printf("         -v              verbose output\n\n");
	
	exit(EXIT_FAILURE);
}
