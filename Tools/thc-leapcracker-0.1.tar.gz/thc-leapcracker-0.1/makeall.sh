#!/bin/sh

echo
echo "Make sure you have openssl-devel installed !"
echo "Tested with gcc-Version 3.3.1 (SuSE Linux)"
echo
echo "Hit RETURN to continue ..."
read

echo "compiling leap-cracker..."
gcc -Wall -o leap-cracker leap-cracker.c -lssl -D_FILE_OFFSET_BITS=64 -D_LARGEFILE_SOURCE
echo "compiling passwords_convert2bin..."
gcc -Wall -o passwords_convert2bin passwords_convert2bin.c -lssl -D_FILE_OFFSET_BITS=64 -D_LARGEFILE_SOURCE
echo "compiling wordgen..."
gcc -Wall -o wordgen wordgen.c

echo -n "Do you also want to compile the AirJack based tools (getleap and deauth) (y/n) ? "
read a

if [ "$a" == "y" ]; then
	echo "compiling get_leap..."
	gcc -Wall -o get_leap get_leap.c -I. -L. -lpcap  
	echo "compiling deauth-all..."
	gcc -Wall -o deauth-all deauth-all.c -I. -L. -lpcap 
fi

echo "done."

