/* Secure FILL - by van Hauser / [THC], vh@reptile.rug.ac.be
 *
 * Secure FILL overwrites all available free diskspace by creating a file,
 * wiping all free diskspace it gets and finally deleting the file.
 *
 * Standard mode is a real security wipe for 38 times, flushing
 * the caches after every write. The wipe technique was proposed by Peter
 * Gutmann at Usenix '96 and includes 10 random overwrites plus 28 special
 * defined characters. Take a look at the paper of him, it's really worth
 * your time.
 * The option -l overwrites two times the data. (0xff + random)
 * The option -ll overwrites the data once. (random)
 * New with v2.3: wipes all inodes
 *
 * Read the manual for limitations.
 * Compiles clean on OpenBSD, Linux, Solaris and AIX
 *
 */

#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <strings.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <dirent.h>
#include <signal.h>

#include <sys/time.h>
#include <sys/resource.h>

#define RANDOM_DEVICE	"/dev/urandom"  /* must not exist */
#define DIR_SEPERATOR	'/'
#define FLUSH		sync()
#define BLOCKSIZE	131073

#ifndef O_SYNC
 #ifdef O_FSYNC
  #define O_SYNC O_FSYNC
 #else
  #define O_SYNC 0
 #endif
#endif
 
char *VERSION = "v2.3 by van Hauser/THC <vh@reptile.rug.ac.be> http://www.infowar.co.uk/thc";
char *prog;
int verbose = 0;
char newname[1024];
char buf[BLOCKSIZE];
char **array;
int file;
int slow = O_SYNC;
int debug = 1;
FILE *f;
FILE *devrandom = NULL;

void help() {
    printf("%s %s\n\n",prog, VERSION);
    printf("Syntax: %s [-flv] directory\n\n", prog);
    printf("%s does a secure overwrite of the free diskspace area of the partition.\n", prog);
    printf("Standard is secure mode (38 writes).\n");
    printf("Options:\n");
    printf("\t-f  fast (and insecure mode): no /dev/urandom, no synchronize mode.\n");
    printf("\t-l  lessens the security (use twice for total insecure mode).\n");
    printf("\t-v  is verbose mode.\n");
    exit(1);
}

void fill_buf(char pattern[3]) {
    int loop;
    int where;

    for (loop = 0; loop < (BLOCKSIZE / 3); loop++) {
        where = loop * 3;
       buf[where] = pattern[0];
       buf[where+1] = pattern[1];
       buf[where+2] = pattern[2];
    }
}

void random_buf() {
    int loop;

    if (devrandom == NULL)
        for (loop = 0; loop < BLOCKSIZE; loop++)
            buf[loop] = (unsigned char) (256.0*rand()/(RAND_MAX+1.0));
    else
        fread(&buf, BLOCKSIZE, 1, devrandom);
}
 
int smash_it(char *filename, int mode)  {
    unsigned char write_modes[27][3] = {
        {"\x55\x55\x55"}, {"\xaa\xaa\xaa"}, {"\x92\x49\x24"}, {"\x49\x24\x92"},
        {"\x24\x92\x49"}, {"\x00\x00\x00"}, {"\x11\x11\x11"}, {"\x22\x22\x22"},
        {"\x33\x33\x33"}, {"\x44\x44\x44"}, {"\x55\x55\x55"}, {"\x66\x66\x66"},
        {"\x77\x77\x77"}, {"\x88\x88\x88"}, {"\x99\x99\x99"}, {"\xaa\xaa\xaa"},
        {"\xbb\xbb\xbb"}, {"\xcc\xcc\xcc"}, {"\xdd\xdd\xdd"}, {"\xee\xee\xee"},
        {"\xff\xff\xff"}, {"\x92\x49\x24"}, {"\x49\x24\x92"}, {"\x24\x92\x49"},
        {"\x6d\xb6\xdb"}, {"\xb6\xdb\x6d"}, {"\xdb\x6d\xb6"}
    };

    unsigned char std_array[3] = "\xff\xff\xff";
    int turn;

/* open the file, get the filesize, calculate the numbers of needed writings */
    if (verbose) printf("Creating %s ", filename);
    if ((file = open(filename, O_RDWR | O_EXCL | O_CREAT | slow, 0600 )) < 0)
        return 1;
    if ((f = fdopen(file, "r+b")) == NULL)
        return 1;

    if (mode > 0) {
        fill_buf(std_array);
        do {} while (fwrite(&buf, 1, BLOCKSIZE, f) == BLOCKSIZE);
        if (verbose)
            printf("*");
        fflush(f);
        fsync(file);
     }

/* do the overwriting stuff */
        for (turn=0; turn<=36; turn++) {
            rewind(f);
            if ((mode < 2) && (turn > 0)) break;
            if ((turn>=5) && (turn<=31)) {
               fill_buf(write_modes[turn-5]);
               do {} while (fwrite(&buf, 1, BLOCKSIZE, f) == BLOCKSIZE);
            } else {
               do {
                   random_buf();
               } while (fwrite(&buf, 1, BLOCKSIZE, f) == BLOCKSIZE);
            }
            fflush(f);
            fsync(file);
            FLUSH;
            if (verbose)
                printf("*");
        }

    (void) fclose(f);
/* Hard Flush -> Force cached data to be written to disk - the defines above! */
    FLUSH;
    if ((file = open(filename, O_WRONLY | O_TRUNC)) >= 0)
	close(file);

    return 0;
}

/* this is new since 2.3: fillup inodes to wipe their data */
void wipe_inodes(char *loc) {
    {
       char *template = malloc(strlen(loc)+10);
       char *temptemplate = malloc(strlen(loc)+10);
       char *tt;
       int i = 0, fail = 0, fd;

       array=malloc(65536*sizeof(template));
       strcpy(template, loc);
       strcat(template, "/sfXXXXXX");
       strcpy(temptemplate, template);
       while(((tt = mktemp(temptemplate)) != NULL) && i < 65535 && fail < 3) {
           if (open(tt, O_CREAT | O_EXCL | O_WRONLY, 0600) < 0)
               fail++;
           else {
               array[i]=calloc(strlen(loc)+10,1);
               strcpy(array[i],tt);
               i++;
           }
           strcpy(temptemplate, template);
       }
       FLUSH;
       array[i] = NULL;
       fd = 0;
       while(fd < i) {
           unlink(array[fd]);
           free(array[fd]);
           fd++;
       }
    }
    free(array);
    array = NULL;
    FLUSH;
    if (verbose)
        printf("+");
}

void cleanup(int signo) {
    fprintf(stderr,"Terminated by signal. Clean exit.\n");
    if (f) {
        fflush(f);
        fsync(file);
        (void) fclose(f);
        if (unlink(newname) != 0 )
    	    fprintf (stderr,"Warning: Can't remove %s!\n",newname);
    }
    if (file >=0)
        close(file);
    FLUSH;
    if (array != NULL) {
	int i = 0;
	while(array[i] != NULL) {
	    unlink(array[i]);
	    i++;
	}
    }
    FLUSH;
    fflush(stdout);
    fflush(stderr);
    exit(1);
}

int main (int argc, char *argv[]) {
    int result;
    int secure = 2; /* standard is secure mode */
    int loop;
    int turn;
    int counter;
    struct stat filestat;
    struct rlimit rlim;

    if (getuid() != 0)
        fprintf(stderr,"Warning: you are not root. You might not be able to wipe the whole filesystem.\n");

    prog = argv[0];
    if (argc==1)
        help();

    while (1) {
        result = getopt(argc, argv, "fFlLsSvV");
        if (result<0) break;
        switch (result) {
            case 'f' :
            case 'F' : slow = 0;
            	       break;
            case 'l' :
            case 'L' : if (secure) secure--;
            	       break;
	    case 's' :
            case 'S' : secure++;
                       break;
	    case 'v' :
            case 'V' : verbose++;
                       break;
            default :  help();        
        }
    }
    loop = optind;
    if (loop >= argc)
	help();
    (void) setvbuf(stdout, NULL, _IONBF, 0);

    do {
       strncpy(newname, argv[loop], sizeof(newname));    
       if (opendir(newname) == NULL) {  /* no need for ensuring close */
           fprintf(stderr,"%s : not a directory\n",newname);
       } else {

/* Generate random unique name for tempfile */
	    srand(getpid()+getuid());

            if (newname[strlen(newname)-1] != DIR_SEPERATOR) {
               result = strlen(newname);
               newname[result] = DIR_SEPERATOR;
               newname[result+1] = 0;
	    }    

	    turn = 0; result = 0;
            (void)strcat(newname, "oooooooo.ooo");
            result = lstat(newname, &filestat);

            while ((result >= 0)&&(turn<=250)) {
                for (counter=strlen(newname)-1; (newname[counter] != DIR_SEPERATOR); counter--) 
                    if (newname[counter] != '.') 
                       newname[counter] = 97+(int) (27.0*rand()/(RAND_MAX+1.0));
		result = lstat(newname, &filestat);
		turn++;
            };
            if (result>=0) fprintf(stderr,"%s : couldn't find a free filename\n",argv[loop]);
            else {

               signal(SIGINT, cleanup);
               signal(SIGTERM, cleanup);
               signal(SIGHUP, cleanup);

	       if (BLOCKSIZE % 3 > 0)
		   fprintf(stderr, "Warning: incompiled blocksize is not a multiple of 3!\n");

	       if (slow && secure)
	           if ((devrandom = fopen(RANDOM_DEVICE, "r")) != NULL)
                       if (verbose)
                           printf("Using %s for random input.\n", RANDOM_DEVICE);

    	       if (verbose) {
        	   switch (secure) {
           	       case 0 : printf("Wipe mode is insecure (one pass [random])\n");
                                break;
           	       case 1 : printf("Wipe mode is insecure (two passes [0xff/random])\n");
                                break;
           	       default: printf("Wipe mode is secure (38 special passes)\n");
           	   }
		   printf("Wiping now ...\n");
               }

#ifdef RLIM_INFINITY
               rlim.rlim_cur = RLIM_INFINITY;
               rlim.rlim_max = RLIM_INFINITY;
 #ifdef RLIMIT_FSIZE
               if (setrlimit(RLIMIT_FSIZE, &rlim) != 0)
                   fprintf(stderr, "Warning: Could not reset ulimit for filesize.\n");
 #endif
#endif                    

               result = smash_it(newname, secure);
               if (result == 0) wipe_inodes(argv[loop]);
               switch (result) {
                   case 0 : if (verbose) printf(" Finished\n");
                            break;
                   case 1 : fprintf(stderr,"%s : no write permission. ", argv[loop]);
			    perror("");
                            break;
                   default: fprintf(stderr,"Unknown error\n");
               }
               (void) unlink(newname);
            }
       }
       loop++;
    } while (loop<argc);
    if (devrandom)
        fclose(devrandom);
    exit(0);
}
