#include "hydra-mod.h"
#include "ntlm.h"
#ifdef LIBOPENSSLNEW
  #include <openssl/md5.h>
  #include <openssl/sha.h>
#endif

extern char *HYDRA_EXIT;

char *buf;
int counter;

#define AUTH_CLEAR 0
#define AUTH_LOGIN 1
#define AUTH_PLAIN 2
#define AUTH_CRAMMD5 3
#define AUTH_CRAMSHA1 4
#define AUTH_CRAMSHA256 5
#define AUTH_DIGESTMD5 6
#define AUTH_NTLM 7


int imap_auth_mechanism=AUTH_CLEAR;

int
start_imap(int s, char *ip, int port, unsigned char options, char *miscptr, FILE * fp)
{
  char *empty = "";
  char *login, *pass, buffer[500], buffer2[500];

  if (strlen(login = hydra_get_next_login()) == 0)
    login = empty;
  if (strlen(pass = hydra_get_next_password()) == 0)
    pass = empty;

  while (hydra_data_ready(s)) {
    if ((buf = hydra_receive_line(s)) == NULL)
      return (1);
    free(buf);
  }

  if (verbose)
	hydra_report(stderr, "Testing login: %s with password: %s\n", login ,pass);

  switch (imap_auth_mechanism) {
     case AUTH_LOGIN:
	sprintf(buffer, "%d AUTHENTICATE LOGIN\r\n", counter);
	if (hydra_send(s, buffer, strlen(buffer), 0) < 0) {
	  return 1;
	}
	if ((buf = hydra_receive_line(s)) == NULL)
	  return 1;
	if (strstr(buf, " NO ") != NULL || strstr(buf, "failed") != NULL || strstr(buf, " BAD ") != NULL) {
	  hydra_report(stderr, "Error: IMAP LOGIN AUTH error: %s\n", buf);
	  free(buf);
	  return 3;
	}
	free(buf);
	strcpy(buffer2, login);
        hydra_tobase64((unsigned char *) buffer2, strlen(buffer2), sizeof(buffer2));

	sprintf(buffer, "%.250s\r\n", buffer2);
	if (hydra_send(s, buffer, strlen(buffer), 0) < 0) {
	  return 1;
	}
	if ((buf = hydra_receive_line(s)) == NULL)
	  return 1;
	if (strstr(buf, " NO ") != NULL || strstr(buf, "failed") != NULL || strstr(buf, " BAD ") != NULL) {
	  hydra_report(stderr, "Error: IMAP LOGIN AUTH error: %s\n", buf);
	  free(buf);
	  return 3;
	}
	free(buf);
	strcpy(buffer2, pass);
        hydra_tobase64((unsigned char *) buffer2, strlen(buffer2), sizeof(buffer2));
	sprintf(buffer, "%.250s\r\n", buffer2);
	break;

     case AUTH_PLAIN:
	sprintf(buffer, "%d AUTHENTICATE PLAIN\r\n", counter);
	if (hydra_send(s, buffer, strlen(buffer), 0) < 0) {
	  return 1;
	}
	if ((buf = hydra_receive_line(s)) == NULL)
	  return 1;
	if (strstr(buf, " NO ") != NULL || strstr(buf, "failed") != NULL || strstr(buf, " BAD ") != NULL) {
	  hydra_report(stderr, "Error: IMAP PLAIN AUTH error: %s\n", buf);
	  free(buf);
	  return 3;
	}
	free(buf);

	memset(buffer, 0, sizeof(buffer));
	if (2*strlen(login) + 3 + strlen(pass) < 250) {
	  strcpy(buffer, login);
	  strcpy(buffer +  strlen(login) + 1, login);
	  strcpy(buffer + 2*strlen(login) + 2, pass);
 	  hydra_tobase64((unsigned char *) buffer, strlen(login)*2+strlen(pass)+2, sizeof(buffer));
	  sprintf(buffer, "%.250s\r\n", buffer);
	}
	break;

#ifdef LIBOPENSSLNEW
    case AUTH_CRAMMD5:
    case AUTH_CRAMSHA1: 
    case AUTH_CRAMSHA256: {
	MD5_CTX md5c;
	SHA_CTX shac;
	SHA256_CTX sha256c;
	int i=0;
	unsigned char md5_raw[MD5_DIGEST_LENGTH];
	unsigned char sha1_raw[SHA_DIGEST_LENGTH];
	unsigned char sha256_raw[SHA256_DIGEST_LENGTH];

	char ipad[64];
	char opad[64];

	memset(ipad, 0, sizeof(ipad));
	memset(opad, 0, sizeof(opad));
	switch (imap_auth_mechanism) {
	  case AUTH_CRAMMD5:
	    sprintf(buffer, "%d AUTHENTICATE CRAM-MD5\r\n", counter);
	    break;
	  case AUTH_CRAMSHA1:
	    sprintf(buffer, "%d AUTHENTICATE CRAM-SHA1\r\n", counter);
	    break;
	  case AUTH_CRAMSHA256:
	    sprintf(buffer, "%d AUTHENTICATE CRAM-SHA256\r\n", counter);
	    break;
	}
	if (hydra_send(s, buffer, strlen(buffer), 0) < 0) {
	  return 1;
	}
	//get the one-time BASE64 encoded challenge
	if ((buf = hydra_receive_line(s)) == NULL)
	  return 1;
	if (strstr(buf, " NO ") != NULL || strstr(buf, "failed") != NULL || strstr(buf, " BAD ") != NULL || strstr(buf, "BYE") != NULL) {
	  switch (imap_auth_mechanism) {
	    case AUTH_CRAMMD5:
	      hydra_report(stderr, "Error: IMAP CRAM-MD5 AUTH error: %s\n", buf);
	      break;
	    case AUTH_CRAMSHA1:
	      hydra_report(stderr, "Error: IMAP CRAM-SHA1 AUTH error: %s\n", buf);
	      break;
	    case AUTH_CRAMSHA256:
	      hydra_report(stderr, "Error: IMAP CRAM-SHA256 AUTH error: %s\n", buf);
	      break;
	  }
	  free(buf);
	  return 3;
	}
	
	memset(buffer, 0, sizeof(buffer));
	from64tobits((char*)buffer, buf+2);
	free(buf);

	switch(imap_auth_mechanism) {
	  case AUTH_CRAMMD5: {
	    if (strlen(pass) >= 64) {
		  MD5_Init(&md5c);
		  MD5_Update(&md5c, pass, strlen(pass));
		  MD5_Final(md5_raw, &md5c);
		  memcpy(ipad, md5_raw, MD5_DIGEST_LENGTH);
		  memcpy(opad, md5_raw, MD5_DIGEST_LENGTH);
	    } else {
		    strcpy(ipad, pass); // safe
		    strcpy(opad, pass); // safe
	    }

	    for (i = 0; i < 64; i++) {
		    ipad[i] ^= 0x36;
        	    opad[i] ^= 0x5c;
	    }

	    MD5_Init(&md5c);
	    MD5_Update(&md5c, ipad, 64);
	    MD5_Update(&md5c, buffer, strlen(buffer));
	    MD5_Final(md5_raw, &md5c);

	    MD5_Init(&md5c);
	    MD5_Update(&md5c, opad, 64);
	    MD5_Update(&md5c, md5_raw, MD5_DIGEST_LENGTH);
	    MD5_Final(md5_raw, &md5c);	

	    char *pbuffer = buffer2;
	    for(i = 0; i < MD5_DIGEST_LENGTH; i++) {
		    sprintf(pbuffer, "%02x", md5_raw[i]);
		    pbuffer +=2;
	    }

	    sprintf(buffer, "%s %.250s", login, buffer2);
	  }
	  break;
	  case AUTH_CRAMSHA1: {
	    if (strlen(pass) >= 64) {
		    SHA1_Init(&shac);
		    SHA1_Update(&shac, pass, strlen(pass));
		    SHA1_Final(sha1_raw, &shac);
		    memcpy(ipad, sha1_raw, SHA_DIGEST_LENGTH);
		    memcpy(opad, sha1_raw, SHA_DIGEST_LENGTH);
	    } else {
		    strcpy(ipad, pass); // safe
		    strcpy(opad, pass); // safe
	    }

	    for (i = 0; i < 64; i++) {
		    ipad[i] ^= 0x36;
        	    opad[i] ^= 0x5c;
	    }

	    SHA1_Init(&shac);
	    SHA1_Update(&shac, ipad, 64);
	    SHA1_Update(&shac, buffer, strlen(buffer));
	    SHA1_Final(sha1_raw, &shac);

	    SHA1_Init(&shac);
	    SHA1_Update(&shac, opad, 64);
	    SHA1_Update(&shac, sha1_raw, SHA_DIGEST_LENGTH);
	    SHA1_Final(sha1_raw, &shac);	

	    char *pbuffer = buffer2;
	    for(i = 0; i < SHA_DIGEST_LENGTH; i++) {
		    sprintf(pbuffer, "%02x", sha1_raw[i]);
		    pbuffer +=2;
	    }
	    sprintf(buffer, "%s %.250s", login, buffer2);
	  }
	  break;
	  case AUTH_CRAMSHA256: {
	    if (strlen(pass) >= 64) {
		    SHA256_Init(&sha256c);
		    SHA256_Update(&sha256c, pass, strlen(pass));
		    SHA256_Final(sha256_raw, &sha256c);
		    memcpy(ipad, sha256_raw, SHA256_DIGEST_LENGTH);
		    memcpy(opad, sha256_raw, SHA256_DIGEST_LENGTH);
	    } else {
		    strcpy(ipad, pass); // safe
		    strcpy(opad, pass); // safe
	    }

	    for (i = 0; i < 64; i++) {
		    ipad[i] ^= 0x36;
        	    opad[i] ^= 0x5c;
	    }

	    SHA256_Init(&sha256c);
	    SHA256_Update(&sha256c, ipad, 64);
	    SHA256_Update(&sha256c, buffer, strlen(buffer));
	    SHA256_Final(sha256_raw, &sha256c);

	    SHA256_Init(&sha256c);
	    SHA256_Update(&sha256c, opad, 64);
	    SHA256_Update(&sha256c, sha256_raw, SHA256_DIGEST_LENGTH);
	    SHA256_Final(sha256_raw, &sha256c);	

	    char *pbuffer = buffer2;
	    for(i = 0; i < SHA256_DIGEST_LENGTH; i++) {
		    sprintf(pbuffer, "%02x", sha256_raw[i]);
		    pbuffer +=2;
	    }
	    sprintf(buffer, "%s %.250s", login, buffer2);
	  }
	  break;
	}
	hydra_tobase64((unsigned char *) buffer, strlen(buffer), sizeof(buffer));
	sprintf(buffer, "%.250s\r\n", buffer);
	}
	break;
     case AUTH_DIGESTMD5: {

	MD5_CTX md5c;
	unsigned char response[MD5_DIGEST_LENGTH];
	char *pbuffer;
	int array_size=10;
	char *array[array_size];
	char buffer3[500], nonce[200], realm[50];
	int i, ind=0, lastpos=0, currentpos=0, intq=0;

	sprintf(buffer, "%d AUTHENTICATE DIGEST-MD5\r\n", counter);

	if (hydra_send(s, buffer, strlen(buffer), 0) < 0) return 1;
	//receive
	if ((buf = hydra_receive_line(s)) == NULL)
	  return 1;
	if (strstr(buf, " NO ") != NULL || strstr(buf, "failed") != NULL || strstr(buf, " BAD ") != NULL || strstr(buf, "BYE") != NULL) {
	  hydra_report(stderr, "Error: IMAP DIGEST-MD5 AUTH error: %s\n", buf);
	  free(buf);
	  return 3;
	}
	memset(buffer, 0,sizeof(buffer));
	from64tobits((char*)buffer, buf);

	if (verbose)
	  hydra_report(stderr, "DEBUG S: %s\n", buffer);

	pbuffer=buffer;

	do{
	  currentpos++;
	  if (pbuffer[0] == '"') {
	    if (intq == 0)
	      intq=1;
	    else {
	      intq=0;
	    }
	  }

	  if ((pbuffer[0] == ',') && (intq==0)) {
	    array[ind]=malloc(currentpos);
	    strncpy(array[ind],buffer+lastpos,currentpos-1);
	    array[ind][currentpos-1]='\0';
	    ind++;
	    lastpos+=currentpos;
	    currentpos=0;
	  }
	  pbuffer++;
	} while ((pbuffer[0] != '\0') && (ind<array_size));

	//save the latest one	
	array[ind]=malloc(currentpos+1);
	strncpy(array[ind],buffer+lastpos,currentpos+1);
	array[ind][currentpos]='\0';
	ind++;

	for(i=0;i<ind;i++) {
	  if (strstr(array[i], "nonce=") != NULL) {
	    strcpy(nonce, array[i]+strlen("nonce=")+1);
	    nonce[strlen(nonce)-1]='\0';
	  }
	  if (strstr(array[i], "realm=") != NULL) {
	    strcpy(realm, array[i]+strlen("realm=")+1);
	    realm[strlen(realm)-1]='\0';
	  }
	  if (strstr(array[i], "qop=") != NULL) {
            if ((strstr(array[i], "\"auth\"") == NULL) && (strstr(array[i], "\"auth,") == NULL) && (strstr(array[i], ",auth\"") == NULL)) {
    	     hydra_report(stderr, "Error: IMAP DIGEST-MD5 quality of protection is not supported\n");
	     return 3;
	    }
	 }
	 free(array[i]);
	}

	//compute ha1
	sprintf(buffer, "%s:%s:%s", login, realm, pass);
	MD5_Init(&md5c);
	MD5_Update(&md5c, buffer, strlen(buffer));
	MD5_Final(response, &md5c);
	sprintf(buffer, "%s:%s:%s", response ,nonce, "hydra");
	MD5_Init(&md5c);
	MD5_Update(&md5c, buffer, strlen(buffer));
	MD5_Final(response, &md5c);
	pbuffer = buffer3;
	for(i = 0; i < MD5_DIGEST_LENGTH; i++) {
	  sprintf(pbuffer, "%02x", response[i]);
	  pbuffer +=2;
	}

	//compute ha2
	sprintf(buffer, "AUTHENTICATE:imap/%s", hydra_address2string(ip));
	MD5_Init(&md5c);
	MD5_Update(&md5c, buffer, strlen(buffer));
	MD5_Final(response, &md5c);

	pbuffer = buffer2;
	for(i = 0; i < MD5_DIGEST_LENGTH; i++) {
	  sprintf(pbuffer, "%02x", response[i]);
	  pbuffer +=2;
	}

	//compute response
	sprintf(buffer, "%s:%s:%s:%s:%s", nonce,"00000001", "hydra", "auth", buffer2);
	MD5_Init(&md5c);
	MD5_Update(&md5c, buffer3, strlen(buffer3));
	MD5_Update(&md5c, ":", 1);
	MD5_Update(&md5c, buffer, strlen(buffer));
	MD5_Final(response, &md5c);
	pbuffer = buffer;
	for(i = 0; i < MD5_DIGEST_LENGTH; i++) {
	  sprintf(pbuffer, "%02x", response[i]);
	  pbuffer +=2;
	}

	sprintf(buffer2, "username=\"%s\",realm=\"%s\",nonce=\"%s\",cnonce=\"hydra\",nc=00000001,qop=\"auth\",digest-uri=\"imap/%s\",response=%s", login, realm, nonce, hydra_address2string(ip),buffer);
	if (verbose)
	  hydra_report(stderr, "DEBUG C: %s\n", buffer2);
	hydra_tobase64((unsigned char *) buffer2, strlen(buffer2), sizeof(buffer2));
	sprintf(buffer, "%s\r\n", buffer2);

       }
       break;
#endif

     case AUTH_NTLM: {
	unsigned char buf1[4096];
	unsigned char buf2[4096];

	//Send auth request
	sprintf(buffer, "%d AUTHENTICATE NTLM\r\n", counter);

	if (hydra_send(s, buffer, strlen(buffer), 0) < 0) return 1;
	//receive
	if ((buf = hydra_receive_line(s)) == NULL)
	  return 1;
	if (strstr(buf, " NO ") != NULL || strstr(buf, "failed") != NULL || strstr(buf, " BAD ") != NULL || strstr(buf, "BYE") != NULL) {
	  hydra_report(stderr, "Error: IMAP NTLM AUTH error: %s\n", buf);
	  free(buf);
	  return 3;
	}
	//send auth and receive challenge
	//send auth request: lst the server send it's own hostname and domainname
	buildAuthRequest((tSmbNtlmAuthRequest*)buf2,0,NULL,NULL);
	to64frombits(buf1, buf2, SmbLength((tSmbNtlmAuthRequest*)buf2));

	sprintf(buffer, "%s\r\n", buf1);
	if (hydra_send(s, buffer, strlen(buffer), 0) < 0) return 1;
	if ((buf = hydra_receive_line(s)) == NULL) return (1);

	//recover challenge
	from64tobits((char*)buf1, buf+2);

	//Send response
	buildAuthResponse((tSmbNtlmAuthChallenge*)buf1,(tSmbNtlmAuthResponse*)buf2,0,login,pass,NULL,NULL);
	to64frombits(buf1, buf2, SmbLength((tSmbNtlmAuthResponse*)buf2));

	sprintf(buffer, "%s\r\n", buf1);
	}
        break;
     default:
	//clear authentication
	sprintf(buffer, "%d LOGIN \"%.100s\" \"%.100s\"\r\n", counter, login, pass);
   }

  if (hydra_send(s, buffer, strlen(buffer), 0) < 0) {
    return 1;
  }
  if ((buf = hydra_receive_line(s)) == NULL)
    return (1);

  if (strstr(buf, " NO ") != NULL || strstr(buf, "failed") != NULL || strstr(buf, " BAD ") != NULL || strstr(buf, "BYE") != NULL) {
    free(buf);
    hydra_completed_pair();
    if (memcmp(hydra_get_next_pair(), &HYDRA_EXIT, sizeof(HYDRA_EXIT)) == 0)
      return 3;
    if (counter == 4)
      return 1;
    return (2);
  }
  free(buf);

  hydra_report_found_host(port, ip, "imap", fp);
  hydra_completed_pair_found();
  if (memcmp(hydra_get_next_pair(), &HYDRA_EXIT, sizeof(HYDRA_EXIT)) == 0)
    return 3;
  return 1;
}

void
service_imap(char *ip, int sp, unsigned char options, char *miscptr, FILE * fp, int port)
{
  int run = 1, next_run, sock = -1;
  int myport = PORT_IMAP, mysslport = PORT_IMAP_SSL;
  int resp=0;
  char *ptr;
  char *buffer1 = "1 CAPABILITY\r\n";

  hydra_register_socket(sp);
  if (memcmp(hydra_get_next_pair(), &HYDRA_EXIT, sizeof(HYDRA_EXIT)) == 0)
    return;
  while (1) {
    switch (run) {
    case 1:                    /* connect and service init function */
      if (sock >= 0)
        sock = hydra_disconnect(sock);
//      usleep(275000);
      if ((options & OPTION_SSL) == 0) {
        if (port != 0)
          myport = port;
        sock = hydra_connect_tcp(ip, myport);
        port = myport;
      } else {
        if (port != 0)
          mysslport = port;
        sock = hydra_connect_ssl(ip, mysslport);
        port = mysslport;
      }
      if (sock < 0) {
        hydra_report(stderr, "Error: Child with pid %d terminating, can not connect\n", (int) getpid());
        hydra_child_exit(1);
      }
      buf = hydra_receive_line(sock);

      if ((buf == NULL ) ||  ( strstr(buf, "OK") == NULL && buf[0] != '*')) {  /* check the first line */
        hydra_report(stderr, "Error: Not an IMAP protocol or service shutdown:\n");
        if ( buf != NULL ) {
	     	free(buf);   
        }
        hydra_child_exit(2);
        exit(-1);
      }
      free(buf);
      counter = 2;
      /* send capability request */
      if (hydra_send(sock, buffer1, strlen(buffer1), 0) < 0)
	exit(-1);
      resp = 0;
      do {
        ptr = buf = hydra_receive_line(sock);
        if (buf != NULL) {
          if (strstr(buf, "CAPABILITY") !=  NULL && buf[0] == '*') {
            resp = 1;
	    //we got the capability info then get the completed warning info from server
  	    while (hydra_data_ready(sock)) {
    	      hydra_receive_line(sock);
  	    }
          }
          else {
            if (buf[strlen(buf) - 1] == '\n')
              buf[strlen(buf) - 1] = 0;
            if (buf[strlen(buf) - 1] == '\r')
              buf[strlen(buf) - 1] = 0;
            if (isdigit((int)*ptr) && *(ptr + 1) == ' ')
                resp = 1;
          }
        }
      } while (buf != NULL && resp == 0);
      if (buf == NULL) {
        exit(-1); 
      }

      if ((strstr(buf, "LOGIN") == NULL) && (strstr(buf, "NTLM") != NULL)) {
	imap_auth_mechanism=AUTH_NTLM;
      }

#ifdef LIBOPENSSLNEW
      if ((strstr(buf, "LOGIN") == NULL) && (strstr(buf, "DIGEST-MD5") != NULL)) {
	imap_auth_mechanism=AUTH_DIGESTMD5;
      }

      if ((strstr(buf, "LOGIN") == NULL) && (strstr(buf, "CRAM-SHA256") != NULL)) {
	imap_auth_mechanism=AUTH_CRAMSHA256;
      }

      if ((strstr(buf, "LOGIN") == NULL) && (strstr(buf, "CRAM-SHA1") != NULL)) {
	imap_auth_mechanism=AUTH_CRAMSHA1;
      }

      if ((strstr(buf, "LOGIN") == NULL) && (strstr(buf, "CRAM-MD5") != NULL)) {
	imap_auth_mechanism=AUTH_CRAMMD5;
      }
#endif

      if ((strstr(buf, "LOGIN") == NULL) && (strstr(buf, "PLAIN") != NULL)) {
	imap_auth_mechanism=AUTH_PLAIN;
      }
    
      if (strstr(buf, "LOGIN") != NULL) {
	imap_auth_mechanism=AUTH_LOGIN;
      }
      free(buf);

      if ((miscptr != NULL) && (strlen(miscptr) > 0)) {
	      int i;
	      for (i = 0; i < strlen(miscptr); i++)
       		miscptr[i] = (char) toupper((int)miscptr[i]);

	       if (strncmp (miscptr,"CLEAR",5) == 0)
 		imap_auth_mechanism=AUTH_CLEAR;

	       if (strncmp (miscptr,"LOGIN",5) == 0)
 		imap_auth_mechanism=AUTH_LOGIN;

	       if (strncmp (miscptr,"PLAIN",5) == 0)
 		imap_auth_mechanism=AUTH_PLAIN;

#ifdef LIBOPENSSLNEW
	       if (strncmp (miscptr,"CRAM-MD5",8) == 0)
 		imap_auth_mechanism=AUTH_CRAMMD5;

	       if (strncmp (miscptr,"CRAM-SHA1",9) == 0)
 		imap_auth_mechanism=AUTH_CRAMSHA1;

	       if (strncmp (miscptr,"CRAM-SHA256",11) == 0)
 		imap_auth_mechanism=AUTH_CRAMSHA256;

	       if (strncmp (miscptr,"DIGEST-MD5",10) == 0)
 		imap_auth_mechanism=AUTH_DIGESTMD5;
#endif

	       if (strncmp (miscptr,"NTLM",4) == 0)
 		imap_auth_mechanism=AUTH_NTLM;
      }

      if (verbose) {
	switch (imap_auth_mechanism) {
		case AUTH_CLEAR:
			hydra_report(stderr, "using IMAP CLEAR LOGIN mechanism\n");
			break;
		case AUTH_LOGIN:
			hydra_report(stderr, "using IMAP LOGIN AUTH mechanism\n");
			break;
		case AUTH_PLAIN:
			hydra_report(stderr, "using IMAP PLAIN AUTH mechanism\n");
			break;
#ifdef LIBOPENSSLNEW
		case AUTH_CRAMMD5:
			hydra_report(stderr, "using IMAP CRAM-MD5 AUTH mechanism\n");
			break;
		case AUTH_CRAMSHA1:
			hydra_report(stderr, "using IMAP CRAM-SHA1 AUTH mechanism\n");
			break;
		case AUTH_CRAMSHA256:
			hydra_report(stderr, "using IMAP CRAM-SHA256 AUTH mechanism\n");
			break;
		case AUTH_DIGESTMD5:
			hydra_report(stderr, "using IMAP DIGEST-MD5 AUTH mechanism\n");
			break;
#endif
		case AUTH_NTLM:
			hydra_report(stderr, "using IMAP NTLM AUTH mechanism\n");
			break;

		}

      }

      next_run = 2;
      break;
    case 2:                    /* run the cracking function */
      next_run = start_imap(sock, ip, port, options, miscptr, fp);
      counter++;
      break;
    case 3:                    /* clean exit */
      if (sock >= 0)
        sock = hydra_disconnect(sock);
      hydra_child_exit(0);
      return;
    default:
      hydra_report(stderr, "Caught unknown return code, exiting!\n");
      hydra_child_exit(0);
      exit(-1);
    }
    run = next_run;
  }
}
