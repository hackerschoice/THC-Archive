the intention to write this small tool was
that most admins forget or just don't know
how to configure ssl-servers safe, eg. most webservers
like apache on the internet, allow to connect with
SSLv2, which is known to be broken.
even good methods, like sslv3, support weak ciphers
like rc4, which should also be disabled.

and if you take the apache for example, it's really easy to configure safe.

edit the HTTPD.CONF and change or if not existent add:

	SSLProtocol -all +SSLv3
	SSLCipherSuite HIGH
	
the tool THCSSLCheck tests SSLv2, SSLv3, TLSv1 with their supported ciphers.

NOTE: if every cipher in a method, eg. SSLv2, is unsupported, the method seems 
      to be disabled on the remote site.
      
the included DLLs libeay32.dll + ssleay32.dll are openssl 0.9.7e libs.

NOTE: if some ciphers, eg. AES-ciphers, are marked as "unsupported", it could
      indicate, that the remote site, is not using an up-to-date openssl, 
      coz AES first was supported with 0.9.7b, as i remember.

i think the tool is useful for both, admins and pentesters, to easily find out 
what's configured on the remote service.

cheers,
johnny cyberpunk / thc
