/* 
 * $Id:$
 */

#ifndef __PPTP_BRUTER_NET_H__
#define __PPTP_BRUTER_NET_H__ 1


int tcp_open(int ip, unsigned short port);

#endif
