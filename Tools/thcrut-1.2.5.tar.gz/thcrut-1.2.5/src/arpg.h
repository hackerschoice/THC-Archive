#ifndef THCRUT_ARPG_H
#define THCRUT_ARPG_H 1

int send_arp(u_short, u_long, u_char *, u_long, u_char *);

#endif /* !THCRUT_ARPG_H */

