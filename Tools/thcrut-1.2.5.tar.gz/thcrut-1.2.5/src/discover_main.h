/*
 * $Id: discover_main.h,v 1.1 2002/12/17 16:18:20 skyper Exp $
 */

#ifndef __THCRUT_SCANNER_MAIN_H__
#define __THCRUT_SCANNER_MAIN_H__ 1

int scanner_main(int argc, char **argv);

#endif /* !__THCRUT_SCANNER_MAIN_H__ */
