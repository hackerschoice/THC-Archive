#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <strings.h>
#include <unistd.h>
#define _USE_BSD
#include <sys/types.h>
#include <sys/resource.h>
#include <sys/wait.h>
#include <sys/param.h>
#include <sys/socket.h>
#include <signal.h>
#include <netinet/in.h>
#include <pcap.h>
#include <libnet.h>
#include <ctype.h>
#include <netdb.h>
#include <pcap-namedb.h>
#include <sys/ioctl.h>
#include <errno.h>
#ifndef MAXHOSTNAMELEN
 #define MAXHOSTNAMELEN 256
#endif

#ifndef IP_ADDR_LEN
 #define IP_ADDR_LEN 4
#endif

#ifndef ETH_P_RARP
 #define ETH_P_RARP      0x8035
#endif

#ifdef SPEED_HACK
 #define ETH_HW_ADDR_LEN 6
 #define ARP_FRAME_TYPE 0x0806
 #define ETHER_HW_TYPE 1
 #define IP_PROTO_TYPE 0x0800
 #define OP_ARP_REQUEST 2
 struct arp_packet {
        u_char targ_hw_addr[ETH_HW_ADDR_LEN];
        u_char src_hw_addr[ETH_HW_ADDR_LEN];
        u_short frame_type;
        u_short hw_type;
        u_short prot_type;
        u_char hw_addr_size;
        u_char prot_addr_size;
        u_short op;
        u_char sndr_hw_addr[ETH_HW_ADDR_LEN];
        u_char sndr_ip_addr[IP_ADDR_LEN];
        u_char rcpt_hw_addr[ETH_HW_ADDR_LEN];
        u_char rcpt_ip_addr[IP_ADDR_LEN];
        u_char padding[18];
 };
#endif
