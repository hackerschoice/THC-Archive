/*
 * <ths@dev.io>
 */
/* TSNG config file parser */

#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <err.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include "tsng-client.h"

tsng_config * tsng_getconfig(char *config_file)
{
   tsng_config *tsng_cfg;

   return(tsng_cfg);
}

int tsng_writeconfig(tsng_config *tsng_cfg, char *config_file)
{


   return(0);
}
/*
 * <ths@dev.io>
 */

u_int tsng_parse_cmd(char *cmd) {


   return(0);
}
