#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <stdarg.h>
#include <sys/time.h>
#include <sys/resource.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <signal.h>
#include <unistd.h>
#include <fcntl.h>
#include <ctype.h>
#include <netdb.h>
#ifdef _HAVE_OPENSSL
 #include <openssl/ssl.h>
 #include <openssl/err.h>
 #include <openssl/sha.h>
#endif

#include "tsng.h"
#include "tsng-general-lib.h"

#define MAX_CONNECT_RETRY          0
#define WAIT_BETWEEN_CONNECT_RETRY 3
#define CONNECT_WAITTIME          31
#define TSNG_DUMP_ROWS            16

extern int debug;

int waittime = CONNECT_WAITTIME;

/* TCP/IP VARS */
#ifdef _HAVE_OPENSSL
 SSL     *ssl = NULL;
 SSL_CTX *sslContext = NULL;
 RSA     *rsa = NULL;
#endif

typedef struct {
  FILE *f;
  int fd;
  char buf[MAX_LINE];
  int len;
  struct tsng_stream *next;
} tsng_stream;

int intern_socket, extern_socket;
char pair[260];
int fail = 0;
int alarm_went_off = 0;
int use_ssl = 0;
tsng_stream *streams = NULL;


char *tsng_build_time() {
  static char datetime[24];
  struct tm *the_time;
  time_t epoch;

  time(&epoch);
  the_time = localtime(&epoch);
  strftime(datetime, sizeof(datetime), "%Y-%m-%d %H:%M:%S", the_time);

  return (char *) &datetime;
}

char *tsng_time2string(unsigned long int sec) {
  static char timestring[24] = "";
  char blastring[24];
  struct tm *the_time;
  int days;
  
  days = sec / 86400;
  sec += 31532400;
  the_time = localtime(&sec);
  strftime(timestring, 8, "%H:%M", the_time);
  if (days > 0) {
    sprintf(blastring, "%d days %s", days, timestring);
    strcpy(timestring, blastring);
  }
  return (char *) &timestring;
}

int tsng_split_line(int max_argc, int *argc, char *argv[], char *line, int line_max_len) {
  char *ptr = line;
  int argcs = 0;
  int i;

  if (line == NULL || max_argc < 0 || argc == NULL || line_max_len < 0)
    return -1;
    
  for (i = 0; i < max_argc; i++)
    argv[i] = NULL;

  if (line[strlen(line) - 1] == '\n')
    line[strlen(line) - 1] = 0;
  if (line[strlen(line) - 1] == '\r')
    line[strlen(line) - 1] = 0;
  
  while (argcs < max_argc && *ptr && ptr < line + line_max_len) {
    while (*ptr && ptr < line + line_max_len && (*ptr == ' ' || *ptr == '\t'))
      ptr++;
    if (*ptr && ptr < line + line_max_len) {
     argv[argcs] = ptr;
      while (*ptr != ' ' && *ptr != '\t' && *ptr != 0 && ptr < line + line_max_len)
        ptr++;
      *ptr = 0;
      ptr++;
      /* upcase if 1st command is not nudge or data */
      if (argcs == 0 || (strncmp(argv[0], "NUDGE", strlen("NUDGE")) != 0 && strncmp(argv[0], "DATA", strlen("DATA")) != 0))
        for (i = 0; i < strlen(argv[argcs]); i++)
          if (argv[argcs][i] >= 'a' && argv[argcs][i] <= 'z')
            argv[argcs][i] = argv[argcs][i] & 95; // remove lowcase flag
      argcs++;
    }
  }
  *argc = argcs;
  if (argcs < 1)
    return -1;
  else
    return 0;
}

void tsng_log(FILE *f, char *source, char delimiter, char *fmt, ...) {
  char line[MAX_LINE];
  va_list ap;
  char del[4];
  if (f == NULL || fmt == NULL || strlen(fmt) == 0)
    return;
  del[0] = delimiter; del[1] = delimiter, del[2] = ' ', del[3] = 0;
  va_start(ap, fmt);
  vsnprintf(line, sizeof(line), fmt, ap);
  va_end(ap);
  fprintf(f, "%s %s%s%s%s%s", tsng_build_time(),
          del, source, *source == 0 ? "" : " ", del, line);
}

int tsng_fprintf(FILE *f, char *fmt, ...) {
  char line[MAX_LINE];
  va_list ap;
  int ret;
  if (f == NULL || fmt == NULL || strlen(fmt) == 0)
    return 0;
  va_start(ap, fmt);
  vsnprintf(line, sizeof(line), fmt, ap);
  va_end(ap);
  ret = fprintf(f, "%s", line);
  fflush(f);
//  usleep(125000);
  return ret;
}


/**********/
/* TCP/IP */
/**********/

// ----------------- alarming functions ----------------

void alarming() {
    fail++;
    alarm_went_off++;
//    tsng_error(ERROR_ERROR, "Process %d: Can not connect [timeout], process exiting", (int)getpid());
//    tsng_verbose(VERBOSE_DEBUG, "CONNECT TIMEOUT");
}

void interrupt() {
//    tsng_verbose(VERBOSE_DEBUG, "INTERRUPTED");
}

// ----------------- internal functions -----------------

int internal__tsng_connect(unsigned long int host, int port, int protocol, int type) {
    int s, ret = -1;
    struct sockaddr_in target;
    if ((s = socket(PF_INET, protocol, type)) >= 0) {
          target.sin_port=htons(port);
          target.sin_family=AF_INET;
          memcpy(&target.sin_addr.s_addr,&host,4);
          signal(SIGALRM,alarming);
          do {
              if (fail > 0) sleep(WAIT_BETWEEN_CONNECT_RETRY);
              alarm_went_off = 0;
              alarm(waittime);
              ret = connect(s,(struct sockaddr*) &target, sizeof(target));
              alarm(0);
              if (ret < 0 && alarm_went_off == 0) {
                  fail++;
//                  if (fail <= MAX_CONNECT_RETRY) tsng_verbose(VERBOSE_VERBOSE, "Process %d: Can not connect [unreachable], retrying (%d of %d retries)", (int)getpid(), fail, MAX_CONNECT_RETRY);
              }
          } while (ret < 0 && fail <= MAX_CONNECT_RETRY);
          if (ret < 0 && fail > MAX_CONNECT_RETRY) {
//              tsng_verbose(VERBOSE_DEBUG, "CONNECT UNREACHABLE");
              extern_socket = -1;
              ret = -1;
              return ret;
          }
          ret = s;
          extern_socket = s;
//          tsng_verbose(VERBOSE_DEBUG, "CONNECT OK");
          fail = 0;
    }
    return ret;
}

#ifdef _HAVE_OPENSSL
RSA *ssl_temp_rsa_cb(SSL *ssl, int export, int keylength) {
    if (rsa == NULL)
        rsa = RSA_generate_key(512, RSA_F4, NULL, NULL);
    return rsa;
}


int internal__tsng_connect_ssl(unsigned long int host, int port, int protocol, int type) {
    int socket, err;

    // XXX is this needed?
    SSL_load_error_strings();
    SSLeay_add_ssl_algorithms();

    // context: ssl2 + ssl3 is allowed, whatever the server demands
    if ((sslContext = SSL_CTX_new(SSLv23_method())) == NULL) {
        if (verbose) {
            err = ERR_get_error();
//            tsng_error(ERROR_ERROR, "SSL: Error allocating context: %s", ERR_error_string(err, NULL));
        }
        return -1;
    }

    // set the compatbility mode
    SSL_CTX_set_options(sslContext, SSL_OP_ALL);

    // we set the default verifiers and dont care for the results
    (void) SSL_CTX_set_default_verify_paths(sslContext);
    SSL_CTX_set_tmp_rsa_callback(sslContext, ssl_temp_rsa_cb);
    SSL_CTX_set_verify(sslContext, SSL_VERIFY_NONE, NULL);

    if ((socket = internal__tsng_connect(host, port, protocol, type)) < 0)
        return -1;

    if ((ssl = SSL_new(sslContext)) == NULL){
        if (verbose) {
            err = ERR_get_error();
//            tsng_error(ERROR_ERROR, "Error preparing an SSL context: %s", ERR_error_string(err, NULL));
        }
        return -1;
    }
    SSL_set_fd(ssl, socket);
    if (SSL_connect(ssl) <= 0) {
//        tsng_error(ERROR_ERROR, "Could not create an SSL session: %s", ERR_error_string(ERR_get_error(), NULL));
        return -1;
    }

//    tsng_verbose(VERBOSE_DEBUG, "SSL negotiated cipher: %s\n", SSL_get_cipher(ssl));

    use_ssl = 1;

    return socket;
}
#endif

/*
int internal__tsng_recv(int socket, char *buf, int length) {
#ifdef _HAVE_OPENSSL
    if (use_ssl) {
        return SSL_read(ssl, buf, length);
    } else
#endif
        return recv(socket, buf, length, 0);
}

int internal__tsng_send(int socket, char *buf, int size, int options) {
#ifdef _HAVE_OPENSSL
    if (use_ssl) {
	return SSL_write(ssl, buf, size);
    } else
#endif
        return send(socket, buf, size, options);
}
*/

unsigned long int internal__tsng_resolve(char *host) {
    unsigned long int ip;
    struct in_addr in;
    struct hostent *target;
#ifdef AF_INET6
    if (inet_pton(AF_INET, host, &in) <= 0) {
#else
    if (inet_aton(host, &in) <= 0) {
#endif
      if ((target = gethostbyname(host)) != NULL)
        memcpy((char*)&ip, (char*)target->h_addr, 4);
      else
        return -1; /* could not resolve */
    } else
      memcpy((char*)&ip, (char*)&in.s_addr, 4);
    return ip;
}


int internal__tsng_bind_and_listen(int proto, int port, int instances) {
  struct sockaddr_in master;
  int s, on = 1;

  if ((s = socket(AF_INET, proto, 0)) < 0)
    return -1;
  master.sin_family = AF_INET;
  master.sin_addr.s_addr = htonl(INADDR_ANY);
  master.sin_port = htons(port);
  setsockopt(s, SOL_SOCKET, SO_REUSEADDR, &on, sizeof(on));
#ifdef SO_REUSEPORT
  setsockopt(s, SOL_SOCKET, SO_REUSEPORT, &on, sizeof(on));
#endif
  if (bind(s, (struct sockaddr *) &master, sizeof(master)) < 0)
    return -1;
  listen(s, instances);
  return s;
}


// ------------------ public functions ------------------


int tsng_bind_tcp(int port, int instances) {
  return (internal__tsng_bind_and_listen(SOCK_STREAM, port, instances));
}

/*
int tsng_connect_ssl(unsigned long int host, int port) {
#ifdef _HAVE_OPENSSL
    return (internal__tsng_connect_ssl(host, port, SOCK_STREAM, 6));
#else
//    tsng_error(ERROR_ERROR, "VH-LIB not compiled with _HAVE_OPENSSL, no SSL connect possible!");
    return -1;
#endif
}

int tsng_connect_host_ssl(char *host, int port) {
    unsigned long int ip;
    if ((ip = internal__tsng_resolve(host)) < 0)
      return -1;
    return (tsng_connect_ssl(ip, port));
}
*/

int tsng_connect_tcp(unsigned long int host, int port) {
    return (internal__tsng_connect(host, port, SOCK_STREAM, 6));
}
int tsng_connect_host_tcp(char *host, int port) {
    unsigned long int ip;
    if ((ip = internal__tsng_resolve(host)) < 0)
      return -1;
    return (tsng_connect_tcp(ip, port));
}

int tsng_disconnect(int socket) {
    shutdown(socket, SHUT_RDWR);
    close(socket);
//    tsng_verbose(VERBOSE_DEBUG,"DISCONNECT");
    return -1;
}

int tsng_data_ready_writing_timed(int socket, long sec, long usec) {
    fd_set fds;
    struct timeval tv;

    FD_ZERO(&fds);
    FD_SET(socket, &fds);
    tv.tv_sec = sec;
    tv.tv_usec = usec;

    return(select(socket + 1, NULL, &fds, NULL, &tv));
}

int tsng_data_ready_writing(int socket) {
    return(tsng_data_ready_writing_timed(socket, 30, 0));
}

int tsng_data_ready_timed(int socket, long sec, long usec) {
    fd_set fds;
    struct timeval tv;

    FD_ZERO(&fds);
    FD_SET(socket, &fds);
    tv.tv_sec = sec;
    tv.tv_usec = usec;

    return(select(socket + 1, &fds, NULL, NULL, &tv));
}

int tsng_data_ready(int socket) {
    return(tsng_data_ready_timed(socket, 0, 100));
}

FILE *tsng_stream_fdopen(int fd, char *ptr) {
  tsng_stream *stream;
  FILE *f;
  
  if (fd < 0 || (f = fdopen(fd, ptr)) == NULL)
    return NULL;
  if ((stream = malloc(sizeof(tsng_stream))) != NULL) {
    memset(stream, 0, sizeof(tsng_stream));
    stream->f = f;
    stream->fd = fd;
    stream->len = 0;
    stream->buf[0] = 0;
    if (streams == NULL)
      stream->next = NULL;
    else
      stream->next = (struct tsng_stream *) streams;
    streams = stream;
  }

  return f;
}

FILE *tsng_stream_connect_host_tcp(char *host, int port) {
    int socket = tsng_connect_host_tcp(host, port);
    if (socket < 0)
      return NULL;
    fcntl(socket, F_SETFL, O_NONBLOCK);
    return tsng_stream_fdopen(socket, "a+");
}

FILE *tsng_stream_connect_tcp(unsigned long int host, int port) {
    int socket = internal__tsng_connect(host, port, SOCK_STREAM, 6);
    if (socket < 0)
      return NULL;
    fcntl(socket, F_SETFL, O_NONBLOCK);
    return tsng_stream_fdopen(socket, "a+");
}

FILE *tsng_stream_disconnect(FILE *f) {
    tsng_stream *stream = NULL, *tmp_stream = streams;

    if (f == NULL)
      return NULL;
    shutdown(fileno(f), SHUT_RDWR);
    while (tmp_stream != NULL && tmp_stream->f != f) {
      stream = tmp_stream;
      tmp_stream = (tsng_stream *) tmp_stream->next;
    }
    if (tmp_stream != NULL) {
      if (stream == NULL) {
        if (tmp_stream->next == NULL)
          streams = NULL;
        else
          streams = (tsng_stream *) tmp_stream->next;
      } else {
        if (tmp_stream->next == NULL)
          stream->next = NULL;
        else
          stream->next = tmp_stream->next;
      }
      free(tmp_stream);
    }
    fclose(f);
//    tsng_verbose(VERBOSE_DEBUG,"DISCONNECT");
    return NULL;
}

char *tsng_stream_fgets(char *s, int size, FILE *f) {
  char *ptr;
  tsng_stream *tmp_stream = streams;
  int i, j, rest_len;
  int k = 0;

  if (size != 0)
    s[0] = 0;
  if (f == NULL || size == 0)
    return NULL;
  while (tmp_stream != NULL && tmp_stream->f != f)
    tmp_stream = (tsng_stream *) tmp_stream->next;
  if (tmp_stream == NULL)
{fprintf(stderr, "stream not found! programmer error! please report\n"); exit(-1);}    
//    return(tsng_fgets(s, size, S));
  
  if (debug && tmp_stream->len > 0) { printf("==%d==\n", k++); tsng_dump_asciihex(tmp_stream->buf, tmp_stream->len); }
  i = fread(tmp_stream->buf + tmp_stream->len, 1, MAX_LINE - tmp_stream->len, tmp_stream->f);
  if (i > 0) {
    if (debug) { printf("RR%dRR\n", k++); tsng_dump_asciihex(tmp_stream->buf + tmp_stream->len, i); }
    for (j = 0; j < i; j++)
      if (tmp_stream->buf[tmp_stream->len + j] == 0)
        tmp_stream->buf[tmp_stream->len + j] = '\n';
    tmp_stream->len += i;
    if (debug) { printf("read: %d, total now: %d\n", i, tmp_stream->len); }
  }

  if ((ptr = index(tmp_stream->buf, '\n')) == NULL)
    return NULL;

  *ptr++ = 0;
  if (tmp_stream->buf[strlen(tmp_stream->buf) - 1] == '\r')
    tmp_stream->buf[strlen(tmp_stream->buf) - 1] = 0;
  rest_len = tmp_stream->len - (ptr - tmp_stream->buf);

  strncpy(s, tmp_stream->buf, size - 1);
  s[size - 1] = 0;

  if (debug && tmp_stream->len > 0) { printf("==%d==\n", k++); tsng_dump_asciihex(tmp_stream->buf, tmp_stream->len); }
  for (i = 0; i < rest_len; i++)
    tmp_stream->buf[i] = ptr[i];
  tmp_stream->len = rest_len;
  if (debug && tmp_stream->len > 0) { printf("==%d==\n", k++); tsng_dump_asciihex(tmp_stream->buf, tmp_stream->len); }
  
  return s;
}

void tsng_stream_resetbuffer(FILE *f) {
  tsng_stream *tmp_stream = streams;

  if (f == NULL)
    return;
  while (tmp_stream != NULL && tmp_stream->f != f)
    tmp_stream = (tsng_stream *) tmp_stream->next;
  if (tmp_stream != NULL) {
    tmp_stream->buf[0] = 0;
    tmp_stream->len = 0;
  }
}

char *tsng_fgets(char *s, int size, FILE *f) {
  char *ptr;
  
  if (f == NULL || s == NULL || size < 2)
    return NULL;
  if ((ptr = fgets(s, size, f)) == NULL)
    return NULL;
  if (*s == 0 || *s == '\r' || *s == '\n')
    return NULL;
  if (s[strlen(s) - 1] == '\n')
    s[strlen(s) - 1] = 0;
  if (s[strlen(s) - 1] == '\r')
    s[strlen(s) - 1] = 0;
  
  return ptr;
}

char *tsng_getpeer(struct sockaddr_in addr) {
  static char ip[16];
  strcpy(ip, inet_ntoa(addr.sin_addr));

  return (char *) &ip;
}



/*
int tsng_recv(int socket, char *buf, int length) {
    int ret;
    ret = internal__tsng_recv(socket, buf, length);
//    tsng_verbose(VERBOSE_DEBUG, "RECV BEGIN|%s|END", buf);
    return ret;
}

char *tsng_receive_line(int socket) {
    char buf[300], *buff;
    int i = 0, j = 0, k;

    buff = malloc(sizeof(buf));
    memset(buff, 0, sizeof(buf));

    i = tsng_data_ready_timed(socket, (long) waittime, 0);
    if (i > 0) {
        if ((i = internal__tsng_recv(socket, buff, sizeof(buf))) < 0) {
            free(buff);
            return NULL;
        }
    }
    if (i <= 0) {
//        tsng_verbose(VERBOSE_DEBUG, "RECV BEGIN|%s|END", buff);
        free(buff);
        return NULL;
    } else {
        for(k = 0; k < i; k++)
            if (buff[k] == 0)
                buff[k] = 32;
    }

    j = 1;
    while(tsng_data_ready(socket) > 0 && j > 0) {
        j = internal__tsng_recv(socket, buf, sizeof(buf));
        if (j > 0)
            for(k = 0; k < j; k++)
                if (buff[k] == 0)
                    buff[k] = 32;
        buff=realloc(buff,i+j);
        memcpy(buff+i,&buf,j);
        i=i+j;
    }

//    tsng_verbose(VERBOSE_DEBUG, "RECV BEGIN|%s|END\n", buff);
    return buff;
}

int tsng_send(int socket, char *buf, int size, int options) {
    char debugbuf[size+1];
    int k;
    for (k = 0; k < size; k++)
        if (buf[k] == 0)
            debugbuf[k] = 32;
        else
            debugbuf[k] = buf[k];
    debugbuf[size] = 0;
//    tsng_verbose(VERBOSE_DEBUG, "SEND_BEGIN|%s|END", debugbuf);
//    if (tsng_data_ready_writing(socket)) < 1) return -1; // XXX maybe needed in the future
    return(internal__tsng_send(socket, buf, size, options));
}
*/
void tsng_dump_asciihex(unsigned char *string, int length) {
    unsigned char *p = (unsigned char *) string;
    unsigned char lastrow_data[16];
    int rows = length / TSNG_DUMP_ROWS;
    int lastrow = length % TSNG_DUMP_ROWS;
    int i, j;

    for (i = 0; i < rows; i++) {
        printf("%04hx:  ", i * 16);
        for (j = 0; j < TSNG_DUMP_ROWS; j++) {
            printf("%02x", p[(i * 16) + j]);
            if (j % 2 == 1)
                printf(" ");
        }
        printf("   [ ");
        for (j = 0; j < TSNG_DUMP_ROWS; j++) {
            if (isprint(p[(i * 16) + j]))
                printf("%c", p[(i * 16) + j]);
            else
                printf(".");
        }
        printf(" ]\n");
    }
    if (lastrow > 0) {
        memset(lastrow_data, 0, sizeof(lastrow_data));
        memcpy(lastrow_data, p + length - lastrow, lastrow);
        printf("%04hx:  ", i * 16);
        for (j = 0; j < lastrow; j++) {
            printf("%02x", p[(i * 16) + j]);
            if (j % 2 == 1)
                printf(" ");
        }
        while(j < TSNG_DUMP_ROWS) {
            printf("  ");
            if (j % 2 == 1)
                printf(" ");
            j++;
        }
        printf("   [ ");
        for (j = 0; j < lastrow; j++) {
            if (isprint(p[(i * 16) + j]))
                printf("%c", p[(i * 16) + j]);
            else
                printf(".");
        }
        while(j < TSNG_DUMP_ROWS) {
            printf(" ");
            j++;
        }
        printf(" ]\n");
    }
}
