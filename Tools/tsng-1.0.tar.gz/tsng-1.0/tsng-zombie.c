#define _DEFINE_TSNG_ZOMBIE
#include <stdio.h>
#include <string.h>
#include <stdarg.h>
#include <stdlib.h>
#include <termios.h>
#include <unistd.h>
#include <ctype.h>
/* network */
#include <signal.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <fcntl.h>
/* misc */
#include <time.h>
#include <errno.h>

#include "tsng-zombie.h"
#include "tsng-conf-lib.h"
#include "tsng-modem-lib.h"
#include "tsng-com-lib.h"
#include "tsng.h"
#include "tsng-general-lib.h"

int debug = 0;

int tsng_mode = TSNG_ZOMBIE;
tsng_modem_config *current_tsng_conf;
int dialing = 0;
int to_dial = 0;
int dial_index = 0;
int dial_max = 0;
int rings = 0;
int stop = 0;
int go = 1;
int connected = 0;
int reading_scanarray = 0;
int lost_pongs = 0;
int cancel = 0;
unsigned long int last_seen;
time_t dial_elapsed;
time_t dial_time;
char numbers[MAX_ARRAY_ZOMBIE][MAX_NUMBER_LENGTH];
FILE *LOG = NULL;

/* dead functions, dont touch */
int     tsng_com_ext_timeout(int count, char *id) { return 0; }
int     tsng_com_ext_busyout(int count, char *id) { return 0; }
int     tsng_com_ext_ringout(int count, char *id) { return 0; }
int     tsng_com_ext_errorout(int count, char *id) { return 0; }
int     tsng_com_ext_nudge(char *nudge, char *id) { return 0; }
int     tsng_com_ext_scan(char *string, char *id) { return 0; }
int     tsng_com_ext_drop(char *string, char *id) { return 0; }
int     tsng_com_ext_add(char *host, char *port) { return 0; }
int     tsng_com_ext_del(char *host, char *port, int kill) { return 0; }
int     tsng_com_ext_watch(char *onoffstatus) { return 0; }
int     tsng_com_ext_continue(char *id) { return 0; }
int     tsng_com_ext_dump(char *id) { return 0; }
int     tsng_com_ext_export(char *id) { return 0; }
int     tsng_com_ext_dialmode(int type, char *id) { return 0; }
int     tsng_com_ext_priority(char *prio, char *id) { return 0; }
int     tsng_com_ext_release(char *id) { return 0; }
int     tsng_com_ext_restore(char *id) { return 0; }

/* real functions */
int     tsng_com_ext_list(char *id){
  tsng_fprintf(current_tsng_conf->streamsocket,
    "INFO STATUS State: %s, Numbers to dial: %d, Current Number: %s\n",
    dialing ? "Scanning/Dialing" : stop ? "Stopped" : "Active", to_dial, numbers[dial_index] != NULL && numbers[dial_index][0] != 0 ? numbers[dial_index] : "none");
  return 0;
}

void     tsng_com_ext_scanarray(char *id) {
  reading_scanarray = 1;
}

int     tsng_com_ext_start(char *id) {
  cancel = stop = 0;
  return 0;
}

void     tsng_com_ext_stop() {
  if (dialing)
    tsng_modem_hangup(current_tsng_conf);
  cancel = stop = 1;
}

int     tsng_com_ext_kill(char *host, char *port) {
  if (dialing)
    tsng_modem_hangup(current_tsng_conf);
  dial_max = connected = to_dial = dial_index = go = 0;
  cancel = 1;
  return 0;
}

int     tsng_com_ext_cancel(char *id) {
  if (dialing)
    tsng_modem_hangup(current_tsng_conf);
  dial_max = dial_index = to_dial = 0;
  cancel = 1;
  return 0;
}

void tsng_zombie_disconnect(int lost) {
  tsng_fprintf(current_tsng_conf->streamsocket, "QUIT\n");
  if (lost) {
    tsng_log(LOG, "INTERNAL", '|', "CONNECTION TO MASTER LOST\n");
    tsng_log(stdout, "INTERNAL", '|', "CONNECTION TO MASTER LOST\n");
  } if (lost == 0) {
    tsng_log(LOG, "INTERNAL", '|', "CONNECTION TO MASTER CLOSED ON REQUEST\n");
    tsng_log(stdout, "INTERNAL", '|', "CONNECTION TO MASTER CLOSED ON REQUEST\n");
  }
  connected = 0;
  dial_index = dial_max = to_dial = 0;
  if (dialing)
    tsng_modem_hangup(current_tsng_conf);
  current_tsng_conf->streamsocket = tsng_stream_disconnect(current_tsng_conf->streamsocket);
  current_tsng_conf->socket = -1;
}

void tsng_zombie_terminate() {
  if (dialing)
    tsng_modem_hangup(current_tsng_conf);
  fclose(LOG);
  exit(0);
}

void check_master_com() {
  char line[5000], reply[5000];
  int ret;
  char *args[TSNG_MAX_ARGC];

  if (current_tsng_conf->streamsocket != NULL){
    if (tsng_stream_fgets(line, sizeof(line), current_tsng_conf->streamsocket) != NULL) {
      last_seen = time(NULL);
      lost_pongs = 0;
      if (debug) {
        tsng_log(stdout, "MASTER", '>', "%s\n", line);
      }
      tsng_log(LOG, "MASTER", '>', "%s\n", line);
      if (reading_scanarray) {
        if ((ret = tsng_com_scanarray(line, (char *)numbers[dial_max], to_dial, MAX_ARRAY_ZOMBIE)) == 0) {
          to_dial++;
          if (dial_max < 9)
            dial_max++;
          else
            dial_max = 0;
        } else {
          if (ret == -2) {
            reading_scanarray = 0;
            tsng_com_ok(reply, "SCANARRAY-END");
          } else if (ret == 3) {
            tsng_com_error(reply, line);
          }
          if (ret != -1) {
            tsng_log(LOG, "MASTER", '<', "%s\n", reply);
            tsng_fprintf(current_tsng_conf->streamsocket, "%s\n", reply);
/*
          if (tsng_fprintf(current_tsng_conf->streamsocket, "%s\n", reply) < 0) {
            tsng_zombie_disconnect(1);
            return;
          }
*/
          }
        }
      } else {
        if (tsng_split_line(TSNG_MAX_ARGC, &ret, args, line, sizeof(line) - 1) == 0) {
          ret = tsng_com_cmd(&ret, args, reply);
          tsng_fprintf(current_tsng_conf->streamsocket, "%s\n", reply);
/*
        if (tsng_fprintf(current_tsng_conf->streamsocket, "%s\n", reply) < 0) {
          tsng_zombie_disconnect(1);
          return;
        }
*/
          if (debug) {
            tsng_log(stdout, "MASTER", '<', "%s\n", reply);
          }
          tsng_log(LOG, "MASTER", '<', "%s\n", reply);
          if (ret == 1) { /* client wants to quit */
            fsync(current_tsng_conf->socket);
            tsng_zombie_disconnect(0);
            return;
          }
        } else {
          tsng_log(LOG, "MASTER", '<', "ERROR INVALID-INPUT\n");
          tsng_fprintf(current_tsng_conf->streamsocket, "ERROR INVALID-INPUT\n");
/*
        if (tsng_fprintf(current_tsng_conf->streamsocket, "ERROR INVALID-INPUT\n") < 0) {
          tsng_zombie_disconnect(1);
          return;
        }
*/
        }
      }
//if (debug) printf("DEBUG ret %d, to_dial %d, dial_index %d, current number pointer %p, sent line: %s\n", ret, to_dial, dial_index, numbers[dial_index], reply);
    } else {
      if (last_seen + current_tsng_conf->timeout + 15 < time(NULL)) {
        lost_pongs++;
        if (lost_pongs < 3) {
          last_seen = time(NULL);
          tsng_fprintf(current_tsng_conf->streamsocket, "PONG\n");
        } else {
          tsng_zombie_disconnect(1);
          return;
        }
      }
    }
  }
}

int main(int argc, char *argv[]) {
  tsng_modem_config *conf;
  char reply[5000];
  char line[5000];
//  struct sockaddr_in master;
  struct sockaddr_in addr;
  int i, s = -1, fd = -1, ret = 0, cs = 0, err = 0, wait = 0;
  socklen_t size = sizeof(addr);
  time_t wait_until;
  char *conffile = "./tsng-zombie.conf";
  char *ptr;
  FILE *ss;
  unsigned char c;

  if (argc != 2 || *argv[1] == '-') {
    printf("THC-SCAN Next Generation - ZOMBIE - %s\n\n", VERSION);
    printf("Syntax: %s [configfile]\n", argv[0]);
    exit(-1);
  }

  conffile = argv[1];

  if ((conf = tsng_modem_config_new(conffile)) == NULL) {
//    fprintf(stderr, "ERROR: Configfile %s not found!\n", conffile);
    exit(-1);
  }
  current_tsng_conf = conf;
  if (current_tsng_conf->debug)
    tsng_modem_lib_debug = 1;

  if (current_tsng_conf->modem == NULL) {
    fprintf(stderr, "ERROR: modem not defined in config file!\n");
    exit(-1);
  }
/*
  if (current_tsng_conf->password == NULL) {
    fprintf(stderr, "ERROR: password not defined in config file!\n");
    exit(-1);
  }
*/
  if (current_tsng_conf->logfile != NULL) {
    if ((LOG = fopen(current_tsng_conf->logfile, "a")) == NULL) {
      fprintf(stderr, "ERROR: can not create logfile %s\n", current_tsng_conf->logfile);
      exit(-1);
    }
  } else
    fprintf(stderr, "WARNING: no logfile defined\n");

  if ((s = tsng_bind_tcp(conf->port, 1)) < 0) {
    fprintf(stderr, "ERROR: socket/bind failed\n");
    exit(-1);
  }

  conf->fd = -1;
  conf->stream = NULL;
  /* init modem */
  if (strcmp(conf->modem, "TEST") != 0 && (ret = tsng_modem_init(conf, reply)) != 0) {
    tsng_log(stderr, "INTERNAL", '|', "ERROR: can not initialize modem (code %d %s)\n", ret, reply);
    tsng_log(LOG, "INTERNAL", '|', "ERROR: can not initialize modem (code %d %s)\n", ret, reply);
    close(s);
    exit(-1);
  }
  tsng_log(stdout, "INTERNAL", '|', "Listening for master connections on port %d\n", conf->port);
  tsng_log(LOG, "INTERNAL", '|', "Listening for master connections on port %d\n", conf->port);
  signal(SIGHUP, SIG_IGN);
  signal(SIGPIPE, SIG_IGN);
  signal(SIGTERM, tsng_zombie_terminate);
  signal(SIGSEGV, tsng_zombie_terminate);
  signal(SIGINT, tsng_zombie_terminate);
  signal(SIGABRT, tsng_zombie_terminate);
  while (go) {
    if ((fd = accept(s, (struct sockaddr *)&addr, &size)) >= 0) {
      tsng_log(stdout, "MASTER", '>', "INFO Incoming connection from %s\n", tsng_getpeer(addr));
      tsng_log(LOG, "MASTER", '>', "INFO Incoming connection from %s\n", tsng_getpeer(addr));

      if ((ss = tsng_stream_fdopen(fd, "a+")) == NULL) {
        tsng_log(stderr, "MASTER", '>', "ERROR: Opening socket as stream\n");
        tsng_log(LOG, "MASTER", '>', "ERROR: Opening socket as stream\n");
        connected = 0;
        close(fd);
      } else {
        connected = 1;
        dialing = 0;
        to_dial = 0;
        dial_max = 0;
        dial_index = 0;
        fcntl(fd, F_SETFL, O_NONBLOCK);
        conf->socket = fd;
        conf->streamsocket = ss;
      }
      
      last_seen = time(NULL);
      lost_pongs = 0;

      while (connected) {
        check_master_com();
        if (to_dial > 0 && stop == 0 && wait == 0) {
          ret = -5;
          dialing = 1;
          dial_elapsed = 0;
          rings = 0;
          reply[0] = 0;
          if (conf->fd >= 0 && strlen(numbers[dial_index]) > 0 &&  (wait = 1) == 1 &&
              (ret = tsng_modem_dial(conf, numbers[dial_index], reply)) == 0) {
             /* We have a CARRIER CONNECT */
            tsng_log(LOG, "MASTER", '<', "DATA %s CARRIER %d %d %s\n", numbers[dial_index], dial_elapsed, rings, reply);
            cs = tsng_fprintf(ss, "DATA %s CARRIER %d %d %s\n", numbers[dial_index], dial_elapsed, rings, reply);
            ptr = current_tsng_conf->nudgestring;
            errno = 0;
            while (*ptr && errno == 0) {
              switch(*ptr) {
                case '~' : sleep(1); break;
                case '^' : if (*(ptr + 1)) {
                             ptr++;
                             if (*ptr == '^')
                               fwrite("^", 1, 1, current_tsng_conf->stream);
                             else if (*ptr == 'M')
                               fwrite("\r\n", 2, 1, current_tsng_conf->stream);
                             else {
                               c = 'M';
                               if (*ptr >= 'A' && *ptr <= 'Z')
                                 c = *ptr - 'A';
                               if (*ptr >= 'a' && *ptr <= 'z')
                                 c = *ptr - 'a';
                               if (*ptr == '@')
                                 c = 0;
                               if (c != 'M')
                                 fwrite(&c, 1, 1, current_tsng_conf->stream);
                               else {
                                 tsng_log(stderr, "INTERAL", '|', "ERROR: invalid sequence in nudgestring: ^%c\n", *ptr);
                                 tsng_log(LOG, "INTERAL", '|', "ERROR: invalid sequence in nudgestring: ^%c\n", *ptr);
                               }
                             }
                           }
                           break;
                default:
                  fwrite(ptr, 1, 1, current_tsng_conf->stream);
              }
              ptr++;
              fflush(current_tsng_conf->stream);
            }
            ret = fread(line, 1, 2000, current_tsng_conf->stream);
            ptr = reply;
            sleep(1);
            for (i = 0; i < ret; i++)
              switch(line[i]) {
                case 0: *ptr++ = '\\'; *ptr++ = '0'; break;
                case '\n': *ptr++ = '\\'; *ptr++ = 'n'; break;
                case '\r': *ptr++ = '\\'; *ptr++ = 'r'; break;
                default:
                  *ptr++ == line[i];
              }
            *ptr = 0;
            tsng_log(LOG, "MASTER", '<', "DATA %s BANNER %s\n", numbers[dial_index], reply);
            cs = tsng_fprintf(ss, "DATA %s BANNER %s\n", numbers[dial_index], reply);
            tsng_modem_hangup(current_tsng_conf);
          } else {
            switch(ret) {
              case -1:
                 tsng_log(LOG, "MASTER", '<', "DATA %s ERROR-MODEM-COMMUNICATION %d %d %s\n", numbers[dial_index], dial_elapsed, rings, reply);
                 cs = tsng_fprintf(ss, "DATA %s ERROR-MODEM-COMMUNICATION %d %d %s\n", numbers[dial_index], dial_elapsed, rings, reply);
                 tsng_modem_hangup(current_tsng_conf);
                 err = 1;
               break;
              case -2:
                 tsng_log(LOG, "MASTER", '<', "DATA %s ERROR-MODEM-ERROR %d %d %s\n", numbers[dial_index], dial_elapsed, rings, reply);
                 cs = tsng_fprintf(ss, "DATA %s ERROR-MODEM-ERROR %d %d %s\n", numbers[dial_index], dial_elapsed, rings, reply);
                 err = 1;
               break;
              case -3:
                 tsng_log(LOG, "MASTER", '<', "DATA %s ERROR-NO-DIALTONE %d %d %s\n", numbers[dial_index], dial_elapsed, rings, reply);
                 cs = tsng_fprintf(ss, "DATA %s ERROR-NO-DIALTONE %d %d %s\n", numbers[dial_index], dial_elapsed, rings, reply);
                 err = 1;
               break;
              case -4:
                 tsng_log(LOG, "MASTER", '<', "DATA %s ERROR-UNKNOWN-RESPONSE %d %d %s\n", numbers[dial_index], dial_elapsed, rings, reply);
                 cs = tsng_fprintf(ss, "DATA %s ERROR-UNKNOWN-RESPONSE %d %d %s\n", numbers[dial_index], dial_elapsed, rings, reply);
                 tsng_modem_hangup(current_tsng_conf);
                 err = 1;
               break;
              case -5:
                 tsng_log(LOG, "MASTER", '<', "DATA xxx ERROR-MEMORY-CORRUPTED %d 0\n", dial_elapsed);
                 cs = tsng_fprintf(ss, "DATA xxx ERROR-MEMORY-CORRUPTED %d 0\n", dial_elapsed);
               break;
              case 1:
                 tsng_log(LOG, "MASTER", '<', "DATA %s NOANSWER %d %d %s\n", numbers[dial_index], dial_elapsed, rings, reply);
                 cs = tsng_fprintf(ss, "DATA %s NOANSWER %d %d %s\n", numbers[dial_index], dial_elapsed, rings, reply);
               break;
              case 2:
                 tsng_log(LOG, "MASTER", '<', "DATA %s BUSY %d %d %s\n", numbers[dial_index], dial_elapsed, rings, reply);
                 cs = tsng_fprintf(ss, "DATA %s BUSY %d %d %s\n", numbers[dial_index], dial_elapsed, rings, reply);
               break;
              case 3:
                 tsng_log(LOG, "MASTER", '<', "DATA %s OK %d %d %s\n", numbers[dial_index], dial_elapsed, rings, reply);
                 cs = tsng_fprintf(ss, "DATA %s OK %d %d %s\n", numbers[dial_index], dial_elapsed, rings, reply);
                 tsng_modem_hangup(current_tsng_conf);
               break;
              case 5:
                 tsng_log(LOG, "MASTER", '<', "DATA %s RINGOUT %d %d %s\n", numbers[dial_index], dial_elapsed, rings, reply);
                 cs = tsng_fprintf(ss, "DATA %s RINGOUT %d %d %s\n", numbers[dial_index], dial_elapsed, rings, reply);
               break;
              case 6:
                 tsng_log(LOG, "MASTER", '<', "DATA %s TIMEOUT %d %d %s\n", numbers[dial_index], dial_elapsed, rings, reply);
                 cs = tsng_fprintf(ss, "DATA %s TIMEOUT %d %d %s\n", numbers[dial_index], dial_elapsed, rings, reply);
               break;
              case 7:
                 tsng_log(LOG, "MASTER", '<', "DATA %s VOICE %d %d %s\n", numbers[dial_index], dial_elapsed, rings, reply);
                 cs = tsng_fprintf(ss, "DATA %s VOICE %d %d %s\n", numbers[dial_index], dial_elapsed, rings, reply);
               break;
              case 10: // aborted by master
                 tsng_log(LOG, "MASTER", '<', "DATA %s ABORTED %d %d %s\n", numbers[dial_index], dial_elapsed, rings, reply);
                 cs = tsng_fprintf(ss, "DATA %s ABORTED %d %d %s\n", numbers[dial_index], dial_elapsed, rings, reply);
                 tsng_modem_hangup(current_tsng_conf);
               break;
              default:
                 tsng_log(LOG, "MASTER", '<', "DATA %s ERROR-UNKNOWN-RETURN-CODE %d %d %s\n", numbers[dial_index], dial_elapsed, rings, reply);
                 cs = tsng_fprintf(ss, "DATA %s ERROR-UNKNOWN-RETURN-CODE %d %d %s\n", numbers[dial_index], dial_elapsed, rings, reply);
                 tsng_modem_hangup(current_tsng_conf);
            }
/*
            if (cs < 0) {
              tsng_zombie_disconnect(1);
              ss = NULL;
            }
*/
          }
          dialing = 0;
          to_dial--;
          *numbers[dial_index] = 0;
          if (dial_index < 9)
            dial_index++;
          else
            dial_index = 0;
          
          if (to_dial == 0) {
            tsng_log(LOG, "MASTER", '<', "INFO DONE WITH SCANNING\n");
            tsng_fprintf(ss, "INFO DONE WITH SCANNING\n");
          }
        }
        if (to_dial == 0 || stop != 0)
          usleep(200);
        if (wait == 2) {
          if (wait_until <= time(NULL))
            err = wait = 0;
        }
        if (wait == 1) {
          if (err == 0) {
            if (current_tsng_conf->dial_wait == 0)
              wait = 0;
            else {
              wait_until = time(NULL) + current_tsng_conf->dial_wait;
              wait = 2;
            }
          } else {
            if (current_tsng_conf->dial_wait_errors == 0)
              wait = 0;
            else {
              wait_until = time(NULL) + current_tsng_conf->dial_wait_errors;
              wait = 2;
            }
          }
          if (debug && wait)
            printf("DEBUG: Waiting %d seconds\n", err == 0 ? current_tsng_conf->dial_wait :
                   current_tsng_conf->dial_wait_errors);
        }
      }
      tsng_log(stdout, "INTERNAL", '|', "INFO Connection closed\n");
      tsng_log(LOG, "INTERNAL", '|', "INFO Connection closed\n");
      tsng_zombie_disconnect(-1);
      ss = NULL;
      close(fd);
      fd = -1;
    }
  }
  tsng_log(stdout, "INTERNAL", '|', "INFO Terminated on request\n");
  tsng_log(LOG, "INTERNAL", '|', "INFO Terminated on request\n");
  if (LOG != NULL)
    fclose(LOG);

  return 0;
}
