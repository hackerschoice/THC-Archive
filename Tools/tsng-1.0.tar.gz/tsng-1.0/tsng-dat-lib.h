#ifndef _TSNG_DAT_LIB_H
#define _TSNG_DAT_LIB_H

#define DAT_UNDIALED   0
#define DAT_DROPPED    1
#define DAT_INPROGRESS 2
#define DAT_CARRIER    3
#define DAT_OK         4
#define DAT_NOANSWER   5
#define DAT_VOICE      6
#define DAT_BUSY       7
#define DAT_RINGOUT    8
#define DAT_TIMEOUT    9
#define DAT_ERROROUT  10
#define DAT_BUSYOUT   11
#define DAT_UNKNOWNERROR 12
/* 0 2 4 8 = 4 bit, 4 bit for busy or ringout */




#endif
