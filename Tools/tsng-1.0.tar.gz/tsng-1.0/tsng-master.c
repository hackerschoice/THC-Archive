#include <stdio.h>
#include <netinet/in.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <netinet/in.h>
#include <ctype.h>
#include <errno.h>
#include <time.h>
#include <signal.h>
#include <fcntl.h>
#include <string.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <stdarg.h>

#include "tsng.h"
#include "tsng-conf-lib.h"
#include "tsng-com-lib.h"
#include "tsng-general-lib.h"

#define _DEFINE_TSNG_MASTER
#define TSNG_MAX_ARGC 16

int debug = 1;

typedef struct {
        char *id;
        char *id2;
        tsng_modem_config *conf;
        int amount;
        int x;
        int done;
        int dropped;
        char *numberstring;
        char *diallist;
        int diallist_size;
        unsigned char *dialarray;
        char *datfilename;
        char *logfilename;
        FILE *log;
        unsigned long int timeout;
        unsigned int start;
        unsigned int stop;
        unsigned int duration;
        unsigned int scantime;
        unsigned int starttime;
        int priority;
        int day_of_week;
        int disabled;
        struct tsng_scan *next;
} tsng_scan;
typedef struct {
	FILE *stream;
	int fd;
	int state;
	unsigned long int ip;
	char ipstring[16];
	int port;
	int todo;
	int errors;
	int totalerrors;
	char *numbers[MAX_ARRAY_ZOMBIE];
	int ints[MAX_ARRAY_ZOMBIE];
	unsigned long int last_seen;
	int lost_pongs;
	int disabled;
	int rc;
	struct tsng_zombie *next;
} tsng_zombie;
typedef struct {
	FILE *stream;
	int fd;
	unsigned int ip;
	char ipstring[16];
	int state;
	int watch;
	unsigned long int last_seen;
	int lost_pongs;
	int rc;
	struct tsng_client *next;
} tsng_client;

int tsng_mode = TSNG_MASTER;
int master_fd = -1;
FILE *LOG = NULL;
tsng_modem_config *orig_tsng_conf = NULL;
tsng_modem_config *tsng_conf = NULL;
tsng_modem_config *tmp_tsng_conf = NULL;
tsng_modem_config *current_tsng_conf = NULL;
tsng_scan *scans = NULL;
tsng_scan *tmp_scan = NULL;
tsng_scan *current_scan = NULL;
tsng_zombie *zombies = NULL;
tsng_zombie *current_zombie = NULL;
tsng_client *clients = NULL;
tsng_client *current_client = NULL;
int  zombie_num = 0;
int  client_num = 0;
int  scan_num = 0;
int  watch_num = 0;
int  scanning = 1;
unsigned long int last_save;
char last_error[1024];

void tsng_log_scan(char *source, char *fmt, ...) {
  char line[MAX_LINE];
  va_list ap;
  va_start(ap, fmt);
  vsnprintf(line, sizeof(line), fmt, ap);
  va_end(ap);
  fprintf(LOG, "%s %s %s", tsng_build_time(), source, line);
  if (current_scan != NULL && current_scan->log != NULL)
    fprintf(current_scan->log, "%s %s %s", tsng_build_time(), source, line);
}

tsng_scan *tsng_master_lookup_scan(char *id) {
  tsng_scan *tmp_scan = scans;
  if (id == NULL)
    return NULL;
  while (tmp_scan != NULL) {
    if (tmp_scan->id != NULL && strcasecmp(tmp_scan->id, id) == 0)
      return tmp_scan;
    tmp_scan = (tsng_scan *)tmp_scan->next;
  }
  // not found? lets try with the secondary ID (can be the same as primary)
  tmp_scan = scans;
  while (tmp_scan != NULL) {
    if (tmp_scan->id2 != NULL && strcasecmp(tmp_scan->id2, id) == 0)
      return tmp_scan;
    tmp_scan = (tsng_scan *)tmp_scan->next;
  }
  return NULL;
}

void tsng_master_send2zombies(char *fmt, ...) {
  tsng_zombie *tmp_zombie = zombies;
  char line[MAX_LINE];
  va_list ap;

  if (fmt == NULL || *fmt == 0)
    return;
  va_start(ap, fmt);
  vsnprintf(line, sizeof(line), fmt, ap);
  va_end(ap);
  while (tmp_zombie != NULL) {
    tmp_zombie->rc = tsng_fprintf(tmp_zombie->stream, "%s", line);
    tmp_zombie = (tsng_zombie*) tmp_zombie->next;
  }
}

void tsng_master_send2clients(int watchonly, char *fmt, ...) {
  tsng_client *tmp_client = clients;
  char line[MAX_LINE];
  va_list ap;

  if (fmt == NULL || *fmt == 0)
    return;
  va_start(ap, fmt);
  vsnprintf(line, sizeof(line), fmt, ap);
  va_end(ap);
  while (tmp_client != NULL) {
    if (tmp_client->watch > 0 || watchonly == 0)
      tmp_client->rc = tsng_fprintf(tmp_client->stream, "%s", line);
    tmp_client = (tsng_client*)tmp_client->next;
  }
}

void tsng_master_save_dat(tsng_scan *this_scan) {
  FILE *f;
  tsng_scan *scan = this_scan;
  char bakfile[550], *ptr;
  struct stat st;
  
  if (scan == NULL)
    scan = current_scan;
  if (scan == NULL || scan->datfilename == NULL || scan->dialarray == NULL)
    return;
  if (strlen(scan->datfilename) < sizeof(bakfile) - 4 && strlen(scan->datfilename) > 4 &&
      rindex(scan->datfilename, '.') != NULL && stat(scan->datfilename, &st) == 0 && st.st_size > 0) {
    strcpy(bakfile, scan->datfilename);
    ptr = rindex(bakfile, '.');
    *ptr = 0;
    strcat(bakfile, ".bak");
    if (debug) printf("DEBUG: Moving %s to %s\n", scan->datfilename, bakfile);
    rename(scan->datfilename, bakfile);
  }
  if ((f = fopen(scan->datfilename, "w")) == NULL) {
    if (this_scan == NULL) {
      tsng_master_send2zombies("CANCEL\n");
      if (scan->log != stdout) {
        fclose(scan->log);
        scan->log = NULL;
      }
      tsng_conf = orig_tsng_conf;
      current_scan = NULL;
      current_scan->scantime += time(NULL) - current_scan->starttime;
      tsng_master_send2clients(0, "ERROR CURRENT SCAN CANCELED BECAUSE DAT SAVEFILE COULD NOT BE WRITTEN - FREE SPACE!!\n");
    }
    scan->disabled = 1;
    return;
  }
  if (
   fprintf(f, "VERSION:%d\nTYPE:%c\n%s\n%s\n%s\n%d %d %d %d %d\n%s\n%s\n%u %u %u %u %d\n%d %d\n%d %d %d %d\n%s\n",
     TSNG_DAT_VERSION, scan->diallist == NULL ? 'X' : 'F', scan->id, scan->id2 == NULL ? "" : scan->id2, scan->numberstring == NULL ? "" : scan->numberstring,
     scan->x, scan->amount, scan->done, scan->dropped, scan->diallist_size,
     scan->datfilename, scan->logfilename, scan->start, scan->stop, scan->duration, scan->scantime + (int) (time(NULL) - scan->starttime), scan->day_of_week,
     scan->priority, scan->conf->dialmode,
     scan->conf->timeout, scan->conf->busyout, scan->conf->errorout, scan->conf->ringout, scan->conf->nudgestring)
    < 32 ||
   fwrite(scan->dialarray, 1, scan->amount, f) != scan->amount ||
   (scan->diallist != NULL &&
    fwrite(scan->diallist, 1, scan->diallist_size, f) != scan->diallist_size)) {
    if (this_scan == NULL) {
      tsng_master_send2zombies("CANCEL\n");
      if (scan->log != stdout) {
        fclose(scan->log);
        scan->log = NULL;
      }
      tsng_conf = orig_tsng_conf;
      current_scan = NULL;
      current_scan->scantime += time(NULL) - current_scan->starttime;
      tsng_master_send2clients(0, "ERROR CURRENT SCAN CANCELED BECAUSE DAT FILE COULD NOT BE SAVED - FILESYSTEM FULL? FREE SPACE!!\n");
    }
    scan->disabled = 1;
  }
  fclose(f);
}

tsng_scan *tsng_master_remove_scan(tsng_scan *scan) {
  tsng_scan *tmp_scan;

  if (scans == NULL || scan == NULL)
    return NULL;
  tsng_master_save_dat(scan); // ensure all data is written to disk
  if ((tmp_scan = scans) == scan) {
    if (scan->next != NULL)
      scans = (tsng_scan*)scan->next;
    else
      scans = NULL;
  } else {
    while (tmp_scan != NULL && tmp_scan->next != (struct tsng_scan*)scan)
      tmp_scan = (tsng_scan*)tmp_scan->next;
    if (tmp_scan == NULL) {
      tsng_log(stderr, "INTERNAL", 0, "SCAN NOT FOUND IN MEMORY - BUG!!\n");
      tsng_log(LOG, "INTERNAL", 0, "SCAN NOT FOUND IN MEMORY - BUG!!\n");
    } else
      tmp_scan->next = scan->next;
  }
  if (scan == current_scan) {
    tsng_com_ext_cancel(NULL);
    current_scan = NULL;
  }
  if (scan->id != NULL)
    free(scan->id);
  if (scan->id2 != NULL)
    free(scan->id2);
  if (scan->numberstring != NULL)
    free(scan->numberstring);
  if (scan->dialarray != NULL)
    free(scan->dialarray);
  if (scan->diallist != NULL)
    free(scan->diallist);
  if (scan->datfilename != NULL)
    free(scan->datfilename);
  if (scan->logfilename != NULL)
    free(scan->logfilename);
  if (scan->log != NULL)
    fclose(scan->log);
  if (scan->conf != NULL) {
    if (scan->conf->nudgestring != NULL)
      free(scan->conf->nudgestring);
    free(scan->conf);
  }
  tmp_scan = (tsng_scan*) scan->next;  
  scan_num--;
  free(scan);
  if (scan_num == 0 || scans == NULL) {
    scans = NULL;
    scan_num = 0;
    return NULL;
  }
  return tmp_scan;
}

tsng_zombie *tsng_master_remove_zombie(tsng_zombie *zombie) {
  tsng_zombie *tmp_zombie;
  int i;

  if (zombie == NULL || zombie->stream == NULL)
    return NULL;
  tsng_stream_disconnect(zombie->stream);
  if ((tmp_zombie = zombies) == zombie) {
    if (zombie->next != NULL)
      zombies = (tsng_zombie*)zombie->next;
    else
      zombies = NULL;
  } else {
    while (tmp_zombie != NULL && tmp_zombie->next != (struct tsng_zombie*)zombie)
      tmp_zombie = (tsng_zombie*)tmp_zombie->next;
    if (tmp_zombie == NULL) {
      tsng_log(stderr, "INTERNAL", 0, "ZOMBIE NOT FOUND IN MEMORY - BUG!!\n");
      tsng_log(LOG, "INTERNAL", 0, "ZOMBIE NOT FOUND IN MEMORY - BUG!!\n");
    } else
      tmp_zombie->next = zombie->next;
  }
  if (zombie->todo > 0)
    for (i = 0; i < MAX_ARRAY_ZOMBIE; i++) {
      if (zombie->numbers[i] != NULL) {
        if (current_scan != NULL)
          if ((current_scan->dialarray[zombie->ints[i]] & 15) == DAT_INPROGRESS) {
            if (current_scan->dialarray[zombie->ints[i]] < 16)
              current_scan->dialarray[zombie->ints[i]] = DAT_UNDIALED;
            else
              current_scan->dialarray[zombie->ints[i]] += (DAT_BUSY - DAT_INPROGRESS);
          }
        free(zombie->numbers[i]);
        zombie->numbers[i] = NULL;
      }
    }
  tmp_zombie = (tsng_zombie *)zombie->next;
  zombie_num--;
  free(zombie);
  if (zombie_num == 0 || zombies == NULL) {
    zombies = NULL;
    zombie_num = 0;
    return NULL;
  }
  return tmp_zombie;
}

tsng_client *tsng_master_remove_client(tsng_client *client) {
  tsng_client *tmp_client;

  tsng_stream_disconnect(client->stream);
  if (client == NULL)
    return NULL;
  if ((tmp_client = clients) == client) {
    if (client->next != NULL)
      clients = (tsng_client*)client->next;
    else
      clients = NULL;
  } else {
    while (tmp_client != NULL && tmp_client->next != (struct tsng_client*)client)
      tmp_client = (tsng_client*)tmp_client->next;
    if (tmp_client == NULL) {
      tsng_log(stderr, "INTERNAL", 0, "CLIENT NOT FOUND IN MEMORY - BUG!!\n");
      tsng_log(LOG, "INTERNAL", 0, "CLIENT NOT FOUND IN MEMORY - BUG!!\n");
    } else
      tmp_client->next = client->next;
  }
  tmp_client = (tsng_client *)client->next;
  client_num--;
  free(client);
  if (client_num == 0 || clients == NULL) {
    clients = NULL;
    client_num = 0;
    return NULL;
  }
  return tmp_client;
}

void tsng_master_terminate(int sig) {
  tsng_scan *tmp_scan = scans;
  tsng_master_send2zombies("QUIT\n");
  while (tmp_scan != NULL) {
    if (tmp_scan->dialarray != NULL)
      tsng_master_save_dat(tmp_scan);
    if (tmp_scan->log != NULL && tmp_scan->log != stdout && tmp_scan->log != stderr)
      fclose(tmp_scan->log);
    tmp_scan = (tsng_scan*) tmp_scan->next;
  }
  fclose(LOG);
  if (sig == -1)
    fprintf(stderr, "Exiting by KILL command ...\n");
  else
    fprintf(stderr, "Exiting by signal %d ...\n", sig);
  exit(0);
}

int tsng_master_get_numbers(char *chararray[], int intarray[], int count) {
  char format[6] = "%0 d";
  int i = 0, done = 0;
  char buf[7], *ptr, *ptr2;
  int tmp_mode = current_scan->conf->dialmode;
  int tries = 0;
  char rings, type;
  int max_tries;

  format[2] = current_scan->x + '0';
  if (tmp_mode == DIALMODE_RAND) {
    max_tries = (count+10)*(count+10)+1;
    while (done < count && tries < max_tries) {
      i = lrand48() % current_scan->amount;
      type = current_scan->dialarray[i] & 15;
      if (type == DAT_UNDIALED || type == DAT_BUSY) {
        intarray[done] = i;
        chararray[done] = strdup(current_scan->numberstring);
        ptr = chararray[done];
        snprintf(buf, sizeof(buf), format, i);
        ptr2 = buf;
        while (*ptr != 0 && *ptr2 != 0) {
          if (*ptr == 'X') {
            *ptr = *ptr2;
            ptr2++;
          }
          ptr++;
        }
        rings = current_scan->dialarray[i] >> 4;
        current_scan->dialarray[i] = DAT_INPROGRESS + (rings << 4);
        done++;
      }
      tries++;
    }
    if (done < count)
      tmp_mode = DIALMODE_SEQ;
  }
  if (tmp_mode == DIALMODE_SEQ) {
    i = 0;
    while (i < current_scan->amount && done < count) {
      type = current_scan->dialarray[i] & 15;
      if (type == DAT_UNDIALED || type == DAT_BUSY) {
        intarray[done] = i;
        chararray[done] = strdup(current_scan->numberstring);
        ptr = chararray[done];
        snprintf(buf, sizeof(buf), format, i);
        ptr2 = buf;
        while (*ptr != 0 && *ptr2 != 0) {
          if (*ptr == 'X') {
            *ptr = *ptr2;
            ptr2++;
          }
          ptr++;
        }
        rings = current_scan->dialarray[i] >> 4;
        current_scan->dialarray[i] = DAT_INPROGRESS + (rings << 4);
        done++;
      }
      i++;
    }
  }
  return done;
}

void tsng_master_handle_scan() {
  tsng_zombie *zombie = zombies;
  int i, j, k, available_zombies = 0;
  char *chararray[MAX_ARRAY_ZOMBIE];
  int intarray[MAX_ARRAY_ZOMBIE];
  int max_array;
  int available = 0;
  char rings;
  char prio = 10;
  
  if (scanning && zombies != NULL) {
    last_save = 0;
    if (current_scan == NULL) {
      if (scans == NULL) {
        usleep(25000);
        return;
      }
      while (current_scan == NULL && prio >= 0 && prio <= 10) {
        current_scan = scans;
        while (current_scan != NULL && (current_scan->priority != prio ||
               current_scan->disabled != 0 || current_scan->done >= current_scan->amount))
          current_scan = (tsng_scan*)current_scan->next;
        prio--;
      }
      if (current_scan == NULL) {
        usleep(30000);
        return;
      }
      if (current_scan->dialarray == NULL) {
        if ((current_scan->dialarray = malloc(current_scan->amount)) == NULL) {
          fprintf(stderr, "Not enough memory available for scan id %s\n", current_scan->id);
          current_scan->disabled = 1;
          if (current_scan->log != stdout) {
            fclose(current_scan->log);
            current_scan->log = NULL;
          }
          current_tsng_conf = orig_tsng_conf;
          current_scan = NULL;
          return;
        }
        memset(current_scan->dialarray, 0, current_scan->amount);
      } else {
        // reset all INPROGRESS numbers to undialed
        for (i = 0; i < current_scan->amount; i++)
          if ((current_scan->dialarray[i] & 15) == DAT_INPROGRESS) {
            rings = current_scan->dialarray[i] >> 4;
            current_scan->dialarray[i] = DAT_UNDIALED + (rings << 4);
          }
        zombie = zombies;
        while (zombie != NULL) {
          if (zombie->todo > 0)
            for (i = 0; i < MAX_ARRAY_ZOMBIE; i++) {
              if (zombie->numbers[i] != NULL)
                free(zombie->numbers[i]);
              zombie->numbers[i] = NULL;
            }
          zombie->todo = 0;
          zombie = (tsng_zombie *) zombie->next;
        }
      }
      if ((current_scan->log = fopen(current_scan->logfilename, "a+")) == NULL) {
        tsng_log(LOG, "MASTER", 0, "ERROR: Can not create log file %s\n", current_scan->logfilename);
        current_scan->log = stdout;
      }
      // reconfigure zombies
      zombie = zombies;
      while (zombie != NULL) {
        zombie->disabled = 0;
        zombie = (tsng_zombie*) zombie->next;
      }
      if (current_scan->conf->timeout != current_tsng_conf->timeout) {
        tsng_master_send2zombies("TIMEOUT %d\n", current_scan->conf->timeout);
      }
      if (current_scan->conf->ringout != current_tsng_conf->ringout) {
        tsng_master_send2zombies("RINGOUT %d\n", current_scan->conf->ringout);
      }
      if (current_scan->conf->nudgestring != NULL && 
          (current_tsng_conf->nudgestring == NULL ||
           strcmp(current_scan->conf->nudgestring, current_tsng_conf->nudgestring) != 0)) {
        tsng_master_send2zombies("NUDGE %s\n", current_scan->conf->nudgestring);
      }
      current_tsng_conf = current_scan->conf;
      current_scan->starttime = last_save = time(NULL);
    }
    if (scanning == 2) {
      tsng_master_send2zombies("START\n");
      scanning = 1;
    }
    if (current_scan->done == current_scan->amount) {
      tsng_master_send2clients(0, "INFO SCAN %s%s%s IS DONE\n", current_scan->id, current_scan->id2 != NULL ? "/" : "", current_scan->id2 != NULL ? current_scan->id2 : "");
      current_tsng_conf = orig_tsng_conf;
      current_scan->disabled = 1;
      if (current_scan->log != stdout) {
        fclose(current_scan->log);
        current_scan->log = NULL;
      }
      scan_num--;
      tsng_master_save_dat(NULL);
      last_save = 0;
      current_scan->scantime += time(NULL) - current_scan->starttime;
      current_scan = NULL;
      return;
    }
    // we have a current_scan, we are scanning, numbers are undialed so lets go!!
    // the following line distributes the numbers to dial which are left evenly
    // onto the zombies
    zombie = zombies;
    while (zombie != NULL) {
      if (zombie->disabled == 0)
        available++;
      zombie = (tsng_zombie*)zombie->next;
    }
    if (available > 0) 
      max_array = (current_scan->amount - current_scan->done) / available;
    if (max_array < 4)
      max_array = 4;
    if (max_array > MAX_ARRAY_ZOMBIE)
      max_array = MAX_ARRAY_ZOMBIE;
    // now giv'em!
    zombie = zombies;
    while (zombie != NULL) {
      if (zombie->disabled == 0 && zombie->todo < max_array / 2) {
        // zombie has not much work, lets give'em
        if ((j = tsng_master_get_numbers(chararray, intarray, max_array - zombie->todo)) > 0) {
          zombie->rc = tsng_fprintf(zombie->stream, "SCANARRAY %s\n", current_scan->id);
          current_scan->timeout = 0;
          for (i = 0; i < j; i++) {
            zombie-> rc = tsng_fprintf(zombie->stream, "%s\n", chararray[i]);
            k = 0;
            while(zombie->numbers[k] != NULL && k < MAX_ARRAY_ZOMBIE)
              k++;
            if (k == MAX_ARRAY_ZOMBIE) {
              printf("ZOMBIE ARRAY PROBLEM\n");
            } else {
              zombie->numbers[k] = chararray[i];
              zombie->ints[k] = intarray[i];
            }
          }
          zombie->rc = tsng_fprintf(zombie->stream, "END\n");
          zombie->todo += j;
        } else {
          if (current_scan->timeout == 0)
            current_scan->timeout = time(NULL);
          else {
            if (current_scan->timeout + (((current_scan->conf->timeout * 2) + 15) * MAX_ARRAY_ZOMBIE) > time(NULL))
              usleep(40000);
            else { // we got over the timeout
              // this is a last resort cover-up thingy here and should never happen
              tsng_master_send2zombies("CANCEL\n");
              for (i = 0; i < current_scan->amount; i++)
                if ((current_scan->dialarray[i] & 15) == DAT_INPROGRESS) {
                  rings = current_scan->dialarray[i] >> 4;
                  current_scan->dialarray[i] = DAT_UNDIALED + (rings << 4);
                }
            }
          }
        }
        if (last_save == 0)
          last_save = time(NULL);
        else
          if (last_save + 300 < time(NULL)) {
            tsng_master_save_dat(NULL);
            last_save = time(NULL);
          }
      }
      if (zombie->disabled == 0)
        available_zombies++;
      zombie = (tsng_zombie*)zombie->next;
    }
    if (available_zombies == 0) {
      tsng_log_scan("ZOMBIE", "All Zombies disabled now because of too many errors, scanning stopped.\n");
      tsng_log(LOG, "ZOMBIE", 0, "All Zombies disabled now because of too many errors, scanning stopped.\n");
      tsng_master_send2clients(0, "ERROR ALL ZOMBIES DISABLED NOW BECAUSE OF TOO MANY ERRORS - SCANNING STOPPED\n");
      scanning = 0;
      current_scan->disabled = 1;
      current_scan = NULL;
      current_scan->scantime += time(NULL) - current_scan->starttime;
    }
  } else
    usleep(30000);
}

int tsng_com_ext_restore(char *id) {
  tsng_scan *scan;
  FILE *f;
  char filename[512], line[MAX_LINE];
  int count = 0, err = 0, i;

  if (id == NULL)
    return -1;
  if (strstr(id, "..") != NULL || index(id, '\\') != NULL || index(id, '/') != NULL || *id == '.')
    return -1;
  if (tsng_master_lookup_scan(id) != NULL)
    return -5;
  
  strncpy(filename, id, 500);
  filename[500] = 0;
  strcat(filename, ".dat");
  if ((f = fopen(filename, "r")) == NULL)
    return -1;
  if ((scan = malloc(sizeof(tsng_scan))) == NULL)
    return -2;
  memset(scan, 0, sizeof(tsng_scan));
  if ((scan->conf = malloc(sizeof(tsng_modem_config))) == NULL) {
    free(scan);
    return -2;
  }
  memset(scan->conf, 0, sizeof(tsng_modem_config));
  while(count < 12 && err == 0) {
    if (tsng_fgets(line, sizeof(line), f) != NULL) {
      switch(count) {
        case 0: if (strncmp(line, "VERSION:", strlen("VERSION:")) != 0)
                  err = 1;
                else
                  if (line[strlen("VERSION:")] > TSNG_DAT_VERSION + '0')
                    err = 2;
          break;
        case 1: if (strncmp(line, "TYPE:", strlen("TYPE:")) != 0)
                  err = 1;
          break;
        case 2: scan->id = strdup(line);
          break;
        case 3: scan->id2 = strdup(line);
          break;
        case 4: scan->numberstring = strdup(line);
          break;
        case 5: if (sscanf(line, "%d %d %d %d %d", &scan->x, &scan->amount, &scan->done, &scan->dropped, &scan->diallist_size) != 5)
                  err = 1;
          break;
        case 6: scan->datfilename = strdup(line);
          break;
        case 7: scan->logfilename = strdup(line);
          break;
        case 8: if (sscanf(line, "%u %u %u %u %d", &scan->start, &scan->stop, &scan->duration, &scan->scantime, &scan->day_of_week) != 5)
                  err = 1;
          break;
        case 9: if (sscanf(line, "%d %d", &scan->priority, &scan->conf->dialmode) != 2)
                  err = 1;
          break;
        case 10: if (sscanf(line, "%d %d %d %d", &scan->conf->timeout, &scan->conf->busyout, &scan->conf->errorout, &scan->conf->ringout) != 4)
                  err = 1;
          break;
        case 11: scan->conf->nudgestring = strdup(line);
          break;
      }
    }
    count++;
  }
  if (err == 0) {
    if ((scan->dialarray = malloc(scan->amount)) == NULL)
      err = 3;
    else
      if (fread(scan->dialarray, 1, scan->amount, f) != scan->amount)
        err = 1;
      else {
        for (i = 0; i < scan->amount; i++)
          if ((scan->dialarray[i] & 15) == DAT_INPROGRESS) {
            if (scan->dialarray[i] < 16)
              scan->dialarray[i] = DAT_UNDIALED;
            else
              scan->dialarray[i] += (DAT_BUSY - DAT_INPROGRESS);
          }
      }
  }
  if (err == 0 && scan->diallist_size > 0) {
    if ((scan->diallist = malloc(scan->diallist_size)) == NULL)
      err = 3;
    else
      if (fread(scan->diallist, 1, scan->diallist_size, f) != scan->diallist_size)
        err = 1;
  }

  fclose(f);
  if (err != 0) {
    if (scan->dialarray != NULL)
      free(scan->dialarray);
    if (scan->conf->nudgestring != NULL)
      free(scan->conf->nudgestring);
    if (scan->logfilename != NULL)
      free(scan->logfilename);
    if (scan->datfilename != NULL)
      free(scan->datfilename);
    if (scan->id != NULL)
      free(scan->id);
    if (scan->id2 != NULL)
      free(scan->id2);
    if (scan->numberstring != NULL)
      free(scan->numberstring);
    free(scan->conf);
    free(scan);
    return (-2 - err);
  }
  
  scan_num++;
  if (scan->amount == scan->done)
    scan->disabled = 1;
  scan->next = (struct tsng_scan*)scans;
  scans = scan;
  
  return 0;
}

int tsng_com_ext_release(char *id) {
  tsng_scan *tmp_scan;

  if ((tmp_scan = tsng_master_lookup_scan(id)) == NULL)
    return -1;
  tsng_master_remove_scan(tmp_scan);
  
  return 0;
}

int tsng_com_ext_timeout(int count, char *id) {
  tsng_scan *tmp_scan = NULL;

  if (id != NULL)
    tmp_scan = tsng_master_lookup_scan(id);
  if (id != NULL && tmp_scan == NULL)
    return -1;
  if (id == NULL || tmp_scan == current_scan) {
    tsng_master_send2zombies("TIMEOUT %d\n", count);
  }
  if (tmp_scan != NULL) {
    tmp_scan->conf->timeout = count;
  }

  return 0;
}

int tsng_com_ext_busyout(int count, char *id) {
  tsng_scan *tmp_scan = NULL;

  if (id == NULL)
    return 0;
  if ((tmp_scan = tsng_master_lookup_scan(id)) == NULL)
    return -1;
  tmp_scan->conf->busyout = count;

  return 0;
}

int tsng_com_ext_ringout(int count, char *id) {
  tsng_scan *tmp_scan = NULL;

  if (id != NULL)
    tmp_scan = tsng_master_lookup_scan(id);
  if (id != NULL && tmp_scan == NULL)
    return -1;
  if (id == NULL || tmp_scan == current_scan) {
    tsng_master_send2zombies("RINGOUT %d\n", count);
  }
  if (tmp_scan != NULL) {
    tmp_scan->conf->ringout = count;
  }

  return 0;
}

int tsng_com_ext_errorout(int count, char *id) {
  tsng_scan *tmp_scan = NULL;

  if (id != NULL)
    tmp_scan = tsng_master_lookup_scan(id);
  if (id != NULL && tmp_scan == NULL)
    return -1;
/*
  if (id == NULL || tmp_scan == current_scan) {
    tsng_master_send2zombies("ERROROUT %d\n", count);
  }
*/
  if (tmp_scan != NULL) {
    tmp_scan->conf->errorout = count;
  }

  return 0;
}

int tsng_com_ext_dialmode(int type, char *id) {
  tsng_scan *tmp_scan = NULL;

  if (id == NULL) {
    tsng_conf->dialmode = type;
  } else {
    if ((tmp_scan = tsng_master_lookup_scan(id)) == NULL)
      return -1;
    tmp_scan->conf->dialmode = type;
  }

  return 0;
}

int tsng_com_ext_nudge(char *nudge, char *id) {
  tsng_scan *tmp_scan = NULL;

  if (id != NULL) {
    if ((tmp_scan = tsng_master_lookup_scan(id)) == NULL)
      return -1;
  }
  if (id == NULL || tmp_scan == current_scan) {
    tsng_master_send2zombies("NUDGE %s\n", nudge);
  }
  if (id != NULL) {
    if (tmp_scan->conf->nudgestring != NULL)
      free(tmp_scan->conf->nudgestring);
    tmp_scan->conf->nudgestring = strdup(nudge);
  }

  return 0;
}

int tsng_com_ext_start(char *id) {
  tsng_scan *tmp_scan;

  if (scanning == 0) {
    scanning = 2;
    if (id != NULL) {
      if ((tmp_scan = tsng_master_lookup_scan(id)) != NULL) {
        tmp_scan->disabled = 0;
        tmp_scan->priority = 10;
      } else
        return -1;
    }
    if (current_scan != NULL) {
      tsng_master_send2zombies("START\n");
    }
  }

  return 0;
}

void tsng_com_ext_stop() {
  if (scanning == 1) {
    scanning = 0;
    if (current_scan != NULL) {
      tsng_master_send2zombies("STOP\n");
    }
  }
}

int tsng_com_ext_priority(char *prio, char *id) {
  tsng_scan *tmp_scan;

  if (id == NULL || (tmp_scan = tsng_master_lookup_scan(id)) == NULL)
    return -1;
  tmp_scan->priority = atoi(prio);

  return 0;
}

int tsng_com_ext_kill(char *host, char *port) {
  if (host == NULL)
    return -2;
  if (strcasecmp(host, "MASTER") == 0) {
    tsng_master_send2zombies("QUIT\n");
    tsng_master_send2clients(0, "OK KILL MASTER\n");
    sleep(1);
    tsng_master_terminate(-1);
  } else {
    return tsng_com_ext_del(host, port, 1);
  }
  return 0;
}

int tsng_com_ext_watch(char *onoffstatus) {
  int found = 0;

  if (onoffstatus == NULL) {
    if (current_client->watch == 0)
      return 2;
    else
      return 1;
  }
  if (strcasecmp(onoffstatus, "ON") == 0) {
    if (current_client->watch == 0)
      watch_num++;
    current_client->watch = 1;
    found = 1;
  }
  if (strcasecmp(onoffstatus, "OFF") == 0) {
    if (current_client->watch == 1)
      watch_num--;
    current_client->watch = 0;
    found = 1;
  }
  if (found == 0)
    return -1;

  return 0;
}

int tsng_com_ext_continue(char *id) {
  tsng_scan *tmp_scan;

  if (id == NULL)
    return -1;
  if ((tmp_scan = tsng_master_lookup_scan(id)) == NULL)
      return -1;
  if (tmp_scan->disabled == 0)
    return 0;
  tmp_scan->disabled = 0;
  scan_num++;

  return 0;
}

int tsng_com_ext_cancel(char *id) {
  tsng_scan *tmp_scan;
  tsng_zombie *tmp_zombie = zombies;
  int i;

  if (id != NULL) {
    if ((tmp_scan = tsng_master_lookup_scan(id)) == NULL)
      return -1;
  } else {
    if (current_scan == NULL)
      return -1;
    tmp_scan = current_scan;
  }
  if (tmp_scan == current_scan) {
    if (current_scan->log != stdout) {
      fclose(current_scan->log);
      current_scan->log = NULL;
    }
    tsng_master_send2zombies("CANCEL\n");
    current_tsng_conf = orig_tsng_conf;
    current_scan->scantime += time(NULL) - current_scan->starttime;
    while (tmp_zombie != NULL) {
      if (tmp_zombie->todo > 0) {
        for (i = 0; i < MAX_ARRAY_ZOMBIE; i++) {
          if (tmp_zombie->numbers[i] != NULL) {
            if ((current_scan->dialarray[tmp_zombie->ints[i]] & 15) == DAT_INPROGRESS) {
              if (current_scan->dialarray[tmp_zombie->ints[i]] < 16)
                current_scan->dialarray[tmp_zombie->ints[i]] = DAT_UNDIALED;
	      else
	        current_scan->dialarray[tmp_zombie->ints[i]] += (DAT_BUSY - DAT_INPROGRESS);
            }
            free(tmp_zombie->numbers[i]);
            tmp_zombie->numbers[i] = NULL;
          }
        }
      }
      tmp_zombie->todo = 0;
      tmp_zombie = (tsng_zombie*)tmp_zombie->next;
    }
    current_scan = NULL;
  }
  tmp_scan->disabled = 1;
  scan_num--;

  return 0;
}

int tsng_com_ext_drop(char *string, char *id) {
  tsng_scan *tmp_scan = NULL;
  int from = 0, to = 0, i, j = 0;
  char pfrom[12] = "", pto[12] = "", *ptr;

  if (id != NULL) {
    if ((tmp_scan = tsng_master_lookup_scan(id)) == NULL)
      return -1;
  } else
    if ((tmp_scan = current_scan) == NULL)
      return -1;
  for (i = 0; i < strlen(string); i++)
    if (isdigit(string[i]) == 0) {
      if (string[i] == 'X')
        j += 1;
      else if (string[i] == '-')
        j += 100;
      else
        return -2;
    } else
      if (j > 0 && j < 100) // 1x2x drops are not supported yet
        return -2;
  if (j > 100) // mixing of X and -, or several -
    return -2;
  if (j >= tmp_scan->x && j != 100) // too many x'es
    return -2;
  if (j == 100) { // 123-456 format
    ptr = index(string, '-');
    *ptr = 0;
    ptr++;
    if (*string == 0)
      from = 0;
    else
      from = atoi(string);
    if (*ptr == 0)
      to = tmp_scan->amount - 1;
    else
      to = atoi(ptr);
  } else if (j >= 1) { // 123xx format
    if (strlen(string) > 9)
      return -2;
    strcpy(pfrom, string);
    strcpy(pto, string);
    for (i = 0; i < strlen(string); i++) {
      if (pfrom[i] == 'X')
        pfrom[i] = '0';
      if (pto[i] == 'X')
        pto[i] = '9';
    }
    from = atoi(pfrom);
    to = atoi(pto);
  } else { // single number drop
    from = to = atoi(string);
  }
  if (from > to || to >= tmp_scan->amount || from < 0 || to < 0)
    return -2;
  if (tmp_scan->dialarray == NULL) {
    if ((tmp_scan->dialarray = malloc(tmp_scan->amount)) == NULL) {
      fprintf(stderr, "Not enough memory available for scan id %s\n", tmp_scan->id);
      tmp_scan->disabled = 1;
      return -3;
    }
    memset(tmp_scan->dialarray, 0, tmp_scan->amount);
  }
  for (i = from; i <= to; i++) {
    if (tmp_scan->dialarray[i] == DAT_UNDIALED || (tmp_scan->dialarray[i] & 15) == DAT_BUSY || (tmp_scan->dialarray[i] & 15) == DAT_INPROGRESS) {
      tmp_scan->dialarray[i] = DAT_DROPPED;
      tmp_scan->done++;
      tmp_scan->dropped++;
    }
  }

  return 0;
}

int tsng_com_ext_scan(char *string, char *id) {
  int count = 0, i = 0;
  char *ptr = string, *ptr2;
  tsng_scan *scan;
  struct stat st;
  
  while ((ptr = index(ptr, 'X')) != NULL && ptr++ != NULL)
    count++;
  if (count < 1 || count > MAX_X)
    return -1;

  scan = calloc(1, sizeof(tsng_scan));
  memset(scan, 0, sizeof(tsng_scan));
  scan->id = strdup(string);
  scan->datfilename = malloc(strlen(string) + 5);
  scan->logfilename = malloc(strlen(string) + 5);
  strcpy(scan->datfilename, scan->id);
  strcpy(scan->logfilename, scan->id);
  strcat(scan->datfilename, ".dat");
  strcat(scan->logfilename, ".log");

  if (stat(scan->datfilename, &st) >= 0) {
    free(scan->id);
    free(scan->datfilename);
    free(scan->logfilename);
    free(scan);
    return -2;
  }

  ptr = string;
  ptr2 = scan->id;
  while (*ptr != 0) {
    if ((*ptr >= '0' && *ptr <= '9') || *ptr == 'X') {
      *ptr2 = *ptr;
      ptr2++;
    }
    ptr++;
  }
  *ptr2 = 0;
  scan->numberstring = strdup(scan->id);
  scan->amount = 10;
  i = 1;
  while (i < count) {
    scan->amount = scan->amount * 10;
    i++;
  }
  scan->x = count;
  if (id != NULL)
    scan->id2 = strdup(id);
  scan->conf = malloc(sizeof(tsng_modem_config));
  memcpy(scan->conf, orig_tsng_conf, sizeof(tsng_modem_config));
  scan->conf->nudgestring = strdup(orig_tsng_conf->nudgestring);
  
  if (scans == NULL)
    scans = scan;
  else {
    scan->next = (struct tsng_scan *) scans;
    scans = scan;
  }
  scan_num++;
  
  return 0;
}

void tsng_com_ext_scanarray(char *id) {


  printf("XXX TODO FIXME\n");
}

int tsng_com_ext_add(char *host, char *port) {
  FILE *f;
  tsng_zombie *btmp, *zombie;
  int p;
  struct sockaddr_in addr;

  if (host == NULL || (port != NULL && ((p = atoi(port)) < 1 || p > 65535)))
    return -1;
  if ((zombie = malloc(sizeof(tsng_zombie))) == NULL) {
    current_client->rc = tsng_fprintf(current_client->stream, "ERROR NO MEMORY AVAILABLE FOR ZOMBIE\n");
    tsng_fprintf(stderr, "ERROR NO MEMORY AVAILABLE FOR ZOMBIE\n");
    return -1;
  }
  memset(zombie, 0, sizeof(tsng_zombie));
  if (port == NULL)
    p = TSNG_PORT_ZOMBIE;
  zombie->port = p;
  if ((zombie->ip = internal__tsng_resolve(host)) == -1 ||
      (f = tsng_stream_connect_tcp(zombie->ip, zombie->port)) == NULL) {
    free(zombie);
    return -1;
  }
  if ((btmp = zombies) == NULL)
    zombies = zombie;
  else {
    while (btmp->next != NULL)
      btmp = (tsng_zombie*)btmp->next;
    btmp->next = (struct tsng_zombie*)zombie;
  }
  zombie->last_seen = time(NULL);
  zombie_num++;
  zombie->stream = f;
  zombie->fd = fileno(zombie->stream);
  addr.sin_addr.s_addr = zombie->ip;
  strcpy(zombie->ipstring, tsng_getpeer(addr));
  zombie->rc = tsng_fprintf(zombie->stream, "TIMEOUT %d\n", current_tsng_conf->timeout);
  zombie->rc = tsng_fprintf(zombie->stream, "RINGOUT %d\n", current_tsng_conf->ringout);
  if (current_tsng_conf->nudgestring != NULL)
    zombie->rc = tsng_fprintf(zombie->stream, "NUDGE %s\n", current_tsng_conf->nudgestring);
  if (scanning == 0)
    zombie->rc = tsng_fprintf(zombie->stream, "STOP\n");

  return 0;
}

int tsng_com_ext_del(char *host, char *port, int kill) {
  unsigned long int ip;
  tsng_zombie *tmp_zombie = zombies;
  int myport;
  int found = 0;

  if (host == NULL)
    return -1;
  if (strcasecmp(host, "ALL") == 0)
    host = NULL;
  else
    if (host != NULL && (ip = internal__tsng_resolve(host)) == -1)
      return -1;
  
  if (port == NULL || atoi(port) == 0)
    myport = TSNG_PORT_ZOMBIE;
  else
    myport = atoi(port);
  if (host == NULL || (port != NULL && strcasecmp(port, "ALL") == 0))
    myport = -1;
  while (tmp_zombie != NULL) {
    if (host == NULL || tmp_zombie->ip == ip) {
      if (myport == -1 || myport == tmp_zombie->port) {
        if (kill == 0)
          tmp_zombie->rc = tsng_fprintf(tmp_zombie->stream, "QUIT\n");
        else
          tmp_zombie->rc = tsng_fprintf(tmp_zombie->stream, "KILL\n");
        tmp_zombie = tsng_master_remove_zombie(tmp_zombie);
        if (zombie_num == 0)
          zombies = NULL;
        found++;
      } else
        tmp_zombie = (tsng_zombie*) tmp_zombie->next;
    } else
      tmp_zombie = (tsng_zombie*) tmp_zombie->next;
    if (zombie_num == 0 || zombies == NULL) {
      tmp_zombie = NULL;
      zombie_num = 0;
      zombies = NULL;
    }
  }
  if (found == 0)
    return -1;

  return 0;
}

int tsng_com_ext_list(char *id) {	// can be NULL !!
  tsng_scan *scan = scans;
  tsng_zombie *zombie = zombies;
  tsng_client *client = clients;
  int count = 0;
  int done = 0;
  int all = 0;
  
  if (id != NULL && strcasecmp(id, "ALL") == 0)
    all = 1;

  current_client->rc = tsng_fprintf(current_client->stream,
    "INFO STATUS Clients: %d, Zombies: %d, Scans: %d, Current Scan: %s, Status: %s\n",
    client_num, zombie_num, scan_num, current_scan != NULL ? current_scan->id : "none", scanning ? current_scan != NULL ? "Scanning" : "Waiting" : "Stopped");
  if (all) {
    current_client->rc = tsng_fprintf(current_client->stream,
      "INFO STATUS Default Config - Timeout %d, Ringout %d, Busyout %d, Errorout %d, Nudge %s\n",
      orig_tsng_conf->timeout, orig_tsng_conf->ringout, orig_tsng_conf->busyout, orig_tsng_conf->errorout, orig_tsng_conf->nudgestring);
    if (current_scan != NULL)
      current_client->rc = tsng_fprintf(current_client->stream,
        "INFO STATUS Current Config - Timeout %d, Ringout %d, Busyout %d, Errorout %d, Nudge %s\n",
        current_scan->conf->timeout, current_scan->conf->ringout, current_scan->conf->busyout, current_scan->conf->errorout, current_scan->conf->nudgestring);
  }
  if (all || (id != NULL && strncasecmp(id, "CLIENT", 5) == 0)) {
    done = 1; count = 0;
    while (client != NULL) {
      count++;
      current_client->rc = tsng_fprintf(current_client->stream, "INFO STATUS Client %d - IP: %s\n", count, client->ipstring);
      client = (tsng_client*) client->next;
    }
  }
  if (all || (id != NULL &&  strncasecmp(id, "ZOMBIE", 6) == 0)) {
    done = 1; count = 0;
    while (zombie != NULL) {
      count++;
      current_client->rc = tsng_fprintf(current_client->stream,
        "INFO STATUS Zombie %d - IP: %s, Port: %d, Status: %s, Todo %d\n",
        count, zombie->ipstring, zombie->port, zombie->disabled ? "Disabled" : "Active", zombie->todo);
      zombie = (tsng_zombie*) zombie->next;
    }
  }
  if (all || (id != NULL &&  strncasecmp(id, "SCAN", 4) == 0)) {
    done = 1; count = 0;
    while (scan != NULL) {
      count++;
      current_client->rc = tsng_fprintf(current_client->stream,
        "INFO STATUS Scan %d - ID1: %s, ID2: %s, Range: %s, Completed: %d (%d%%), Status: %s, Scantime so far: %sh, ETA: %sh, Priority: %d\n",
        count, scan->id == NULL ? "none" : scan->id, scan->id2 == NULL ? "none" : scan->id2,
        scan->numberstring, scan->done, (100*scan->done)/scan->amount,
        scan == current_scan ? "Currently Scanning" : scan->disabled == 0 ? "Scheduled" : scan->amount == scan->done ? "Completed" : "Disabled",
        tsng_time2string(scan->scantime + (scan == current_scan ? time(NULL) - scan->starttime : 0) ),
        (scan->done - scan->dropped) == 0 || (scan->scantime == 0 && scan->starttime == 0) ? "undetermined" : tsng_time2string(
            (
              scan->scantime + 
              (scan == current_scan ? time(NULL) - scan->starttime : 0)
              / (scan->done - scan->dropped)
            )
            * (scan->amount - scan->done)
          ),
        scan->priority);
      current_client->rc = tsng_fprintf(current_client->stream,
        "INFO STATUS Scan %d - Dialmode %s, Timeout %d, Ringout %d, Busyout %d, Errorout %d, Nudge %s\n",
        count, scan->conf->dialmode == DIALMODE_SEQ ? "Sequentiell" : "Random", 
        scan->conf->timeout, scan->conf->ringout, scan->conf->busyout, scan->conf->errorout, scan->conf->nudgestring);
      scan = (tsng_scan*) scan->next;
    }
  }

  if (done || id == NULL)
    return 0;

  return -1;
}

int tsng_com_ext_dump(char *id) {
  FILE *f;
  tsng_scan *tmp_scan;
  char line[5000];

  if (current_scan != NULL) {
    fflush(current_scan->log);
    fsync(fileno(current_scan->log));
  }
  if ((id == NULL && current_scan == NULL) || (id != NULL && ((tmp_scan = tsng_master_lookup_scan(id)) == NULL))) {
    if (index(id, '\\') != NULL || index(id, '/') != NULL)
      return -1;
    snprintf(line, 1024, "%s.log", id);
    if ((f = fopen(line, "r")) == NULL)
      return -1;
  } else {
    if (id == NULL) {
      tmp_scan = current_scan;
      fflush(current_scan->log);
    }
    if ((f = fopen(tmp_scan->logfilename, "r")) == NULL)
      return -1;
  }
  current_client->rc = tsng_fprintf(current_client->stream, "OK DUMP\n");
  while (fgets(line, sizeof(line), f) != NULL) {
    if (strstr(line, "DATA ") != NULL)
      current_client->rc = tsng_fprintf(current_client->stream, "EXPORT %s", line);
  }
  current_client->rc = tsng_fprintf(current_client->stream, "EXPORT END\n");
  fclose(f);

  return 0;
}

int tsng_com_ext_export(char *id) {
  int i, x = 0, is_there = 1;
  char type, rings;
  tsng_scan *tmp_scan = NULL;
  char *my_id = NULL , *no = NULL, str[12], buf[6] = "%0 d", *ptr, *ptr2;

  if (id == NULL && current_scan == NULL)
    return -1;
  if (id == NULL) {
    tmp_scan = current_scan;
  } else {
    if ((tmp_scan = tsng_master_lookup_scan(id)) == NULL)
      is_there = 0;
  }

  if (tmp_scan != NULL)
    tsng_master_save_dat(tmp_scan);

  if (is_there == 0) {
    if (*id == '.' || index(id, '\\') != NULL || index(id, '/') != NULL) // ../ etc. protection
      return -1;
    if (tsng_com_ext_restore(id) < 0)
      return -1;
    tmp_scan = scans; // the temporary scan is the first one in the list
  }
  
  if (tmp_scan->diallist_size != 0) {
    printf("XXX TODO FIXME PROBLEM - scan from file not implemented yet!\n");
    return -2;
  } else {
    if (tmp_scan->id != NULL)
      my_id = strdup(tmp_scan->id);
    else
      my_id = "";
    for (i = 0; i < strlen(my_id); i++)
      if (my_id[i] == 'X')
        x++;
    if (x > 0) {
      buf[2] = x + '0';
      no = strdup(my_id);
    } else
      strcpy(buf, "%d");
    tsng_fprintf(current_client->stream, "OK EXPORT\n");
    
    for (i = 0; i < tmp_scan->amount; i++) {
      current_client->rc = tsng_fprintf(current_client->stream, "EXPORT ");
      snprintf(str, sizeof(str), buf, i);
      if (no == NULL)
        current_client->rc = tsng_fprintf(current_client->stream, "%s", str);
      else {
        strcpy(no, my_id);
        ptr = no;
        ptr2 = str;
        while (*ptr != 0 && *ptr2 != 0) {
          if (*ptr == 'X') {
            *ptr = *ptr2;
            ptr2++;
          }
          ptr++;
        }
        current_client->rc = tsng_fprintf(current_client->stream, "%s", no);
      }
      type = tmp_scan->dialarray[i] & 15;
      rings = tmp_scan->dialarray[i] >> 4;
      switch (type) {
        case DAT_INPROGRESS:
            if (rings == 0) current_client->rc = tsng_fprintf(current_client->stream, ";;;;;");
            else current_client->rc = tsng_fprintf(current_client->stream, ";BUSY;;;%d;", rings);
          break; // empty == undialed
        case DAT_UNDIALED: current_client->rc = tsng_fprintf(current_client->stream, ";;;;;"); break; // empty == undialed
        case DAT_DROPPED: current_client->rc = tsng_fprintf(current_client->stream, ";DROPPED;;;;"); break;
        case DAT_CARRIER: current_client->rc = tsng_fprintf(current_client->stream, ";CARRIER;;%d;;", rings); break;
        case DAT_OK: current_client->rc = tsng_fprintf(current_client->stream, ";OK;;%d;;", rings); break;
        case DAT_NOANSWER: current_client->rc = tsng_fprintf(current_client->stream, ";NOANSWER;;%d;;", rings); break;
        case DAT_VOICE: current_client->rc = tsng_fprintf(current_client->stream, ";VOICE;;%d;;", rings); break;
        case DAT_TIMEOUT: current_client->rc = tsng_fprintf(current_client->stream, ";TIMEOUT;;%d;;", rings); break;
        case DAT_RINGOUT: current_client->rc = tsng_fprintf(current_client->stream, ";RINGOUT;;%d;;", rings); break;
        case DAT_BUSY: current_client->rc = tsng_fprintf(current_client->stream, ";BUSY;;;%d;"); break;
        case DAT_BUSYOUT: current_client->rc = tsng_fprintf(current_client->stream, ";BUSYOUT;;;%d;", rings); break;
        case DAT_ERROROUT: current_client->rc = tsng_fprintf(current_client->stream, ";ERROROUT;;;;"); break;
        case DAT_UNKNOWNERROR: current_client->rc = tsng_fprintf(current_client->stream, ";UNKNOWNERROR;;;;"); break;
        default: current_client->rc = tsng_fprintf(current_client->stream, ";ERROR-UNKNOWN-ID;;%d;;%d", rings, type);
      }
      current_client->rc = tsng_fprintf(current_client->stream, "\n");
    }
    tsng_fprintf(current_client->stream, "EXPORT END\n");
    free(my_id);
    if (no != NULL)
      free(no);
  }
  
  if (is_there == 0)
    tsng_master_remove_scan(scans); // the temporary scan is the first in the list

  return 0;
}

void tsng_master_zombie_line (char *line) {
  int argcs, i, found = 0, save = 0;
  char *args[TSNG_MAX_ARGC], line2[MAX_LINE];

  if (line == NULL)
    return;
  current_zombie->lost_pongs = 0;
  current_zombie->last_seen = time(NULL);
  strcpy(line2, line);
  tsng_split_line(TSNG_MAX_ARGC, &argcs, args, line2, strlen(line2));
  if (argcs < 1)
    return;

  if (debug) printf("DEBUG ZOMBIE: %s\n", line);
  tsng_master_send2clients(1, "%s\n", line);
  tsng_log_scan("ZOMBIE", "%s\n", line);

  if (strcmp(args[0], "DATA") == 0) {
    if (argcs < 3 || current_scan == NULL) {
      tsng_log_scan("ZOMBIE", "INVALID DATA LINE - %s\n", line);
      tsng_log(stderr, "ZOMBIE", 0, "INVALID DATA LINE - %s\n", line);
      return;
    }
    // scan data, we have to analyse this, args[2] is the number
    if (strcmp(args[2], "RINGING") == 0)
      return; // ignored
    if (strcmp(args[2], "BANNER") == 0) {
//     tsng_log_scan("ZOMBIE", "%s\n", line); // done already
      return;
    }
    i = 0;
    while (i < MAX_ARRAY_ZOMBIE && found == 0) {
      if (current_zombie->numbers[i] != NULL && strcmp(current_zombie->numbers[i], args[1]) == 0)
        found = 1;
      else
        i++;
    }
    if (found == 0) {
      tsng_log_scan("ZOMBIE", "INVALID NUMBER REPORTED BY ZOMBIE - %s\n", line);
      tsng_log(stderr, "ZOMBIE", 0, "INVALID NUMBER REPORTED BY ZOMBIE - %s\n", line);
      return;
    }
    save = current_scan->dialarray[current_zombie->ints[i]] >> 4;
    if (strcmp(args[2], "ABORTED") == 0) {
      if (save > 0) {
        current_scan->dialarray[current_zombie->ints[i]] = DAT_BUSY;
        current_scan->dialarray[current_zombie->ints[i]] += (save << 4) % 256;
        save = 127;
      } else
        current_scan->dialarray[current_zombie->ints[i]] = DAT_UNDIALED;
    } else
    if (strcmp(args[2], "CARRIER") == 0) {
      current_scan->done++;
      current_scan->dialarray[current_zombie->ints[i]] = DAT_CARRIER;
    } else
    if (strcmp(args[2], "NOANSWER") == 0) {
      current_scan->done++;
      current_scan->dialarray[current_zombie->ints[i]] = DAT_NOANSWER;
    } else
    if (strcmp(args[2], "OK") == 0) {
      current_scan->done++;
      current_scan->dialarray[current_zombie->ints[i]] = DAT_OK;
    } else
    if (strcmp(args[2], "VOICE") == 0) {
      current_scan->done++;
      current_scan->dialarray[current_zombie->ints[i]] = DAT_VOICE;
    } else
    if (strcmp(args[2], "RINGOUT") == 0) {
      current_scan->done++;
      current_scan->dialarray[current_zombie->ints[i]] = DAT_RINGOUT;
    } else
    if (strcmp(args[2], "TIMEOUT") == 0) {
      current_scan->done++;
      current_scan->dialarray[current_zombie->ints[i]] = DAT_TIMEOUT;
    } else
    if (strncmp(args[2], "ERROR", strlen("ERROR")) == 0) {
      current_scan->dialarray[current_zombie->ints[i]] = DAT_BUSY;
      if (save < 14)
        save++;
      if (save >= current_scan->conf->busyout && current_scan->conf->busyout > 0) {
        current_scan->done++;
        current_scan->dialarray[current_zombie->ints[i]] = DAT_BUSYOUT;
      }
      current_zombie->errors++;
      current_zombie->totalerrors++;
      if (current_zombie->errors > current_scan->conf->errorout) {
        tsng_log_scan("ZOMBIE", "Zombie %s port %d was disabled because of too many errors.\n", current_zombie->ipstring, current_zombie->port);
        tsng_log(LOG, "ZOMBIE", 0, "Zombie %s port %d was disabled because of too many errors.\n", current_zombie->ipstring, current_zombie->port);
        tsng_master_send2clients(0, "ERROR ZOMBIE %s PORT %d DISABLED BECAUSE OF TOO MANY ERRORS\n", current_zombie->ipstring, current_zombie->port);
        current_zombie->disabled = 1;
      }
    } else
    if (strcmp(args[2], "BUSY") == 0) {
      current_scan->dialarray[current_zombie->ints[i]] = DAT_BUSY;
      if (save < 14)
        save++;
      if (save >= current_scan->conf->busyout && current_scan->conf->busyout > 0) {
        current_scan->done++;
        current_scan->dialarray[current_zombie->ints[i]] = DAT_BUSYOUT;
      }
      current_scan->dialarray[current_zombie->ints[i]] += (save << 4) % 256;
      save=127;
    } else {
      current_scan->done++;
      current_scan->dialarray[current_zombie->ints[i]] = DAT_UNKNOWNERROR;
      tsng_log_scan("ZOMBIE", "INVALID SCAN RESULT - %s\n", line);
      tsng_log(stderr, "ZOMBIE", 0, "INVALID SCAN RESULT - %s\n", line);
    }
    current_zombie->todo--;
    if (save != 127) {
      current_zombie->errors = 0;
      save = atoi(args[4]);
      if (save < 0)
        save = 15;
      if (save > current_scan->conf->ringout)
        save = 15;
      current_scan->dialarray[current_zombie->ints[i]] += (save << 4) % 256;
    }
    free(current_zombie->numbers[i]);
    current_zombie->numbers[i] = NULL;
  } else
  if (strcmp(args[0], "ERROR") == 0) {
      current_zombie->errors++;
//printf("2: errors+1: %s %s\n", args[0], args[1]);
      // currently ignored, later we maybe should disable the zombie
      // XXX TODO FIXME

  } else
  if (strcmp(args[0], "PING") == 0 || strcmp(args[0], "PONG") == 0) {
      tsng_fprintf(current_zombie->stream, "PONG\n");
  } else
  if (strcmp(args[0], "QUIT") == 0) {
      current_zombie=tsng_master_remove_zombie(current_zombie);
  } else
  if (strcmp(args[0], "OK") == 0) {
      // completely ignored
  } else
  if (strcmp(args[0], "INFO") == 0) {
      // completely ignored
  } else {
     // print stderr - should not happen
    tsng_log_scan("ZOMBIE", "ERROR: invalid message from zombie %s:%d -> %s\n", current_zombie->ipstring, current_zombie->port, line);
    tsng_log(stderr, "ZOMBIE", 0, "ERROR: invalid message from zombie %s:%d -> %s\n", current_zombie->ipstring, current_zombie->port, line);
  }
}

void tsng_master_client_line (char *line) {
  int argcs, ret = 0, i = 0;
  char *args[TSNG_MAX_ARGC];
  char reply[MAX_LINE];

  if (line == NULL)
    return;

  if (debug) printf("DEBUG CLIENT: %s\n", line);
  current_client->lost_pongs = 0;
  current_client->last_seen = time(NULL);
  if (tsng_split_line(TSNG_MAX_ARGC, &argcs, args, line, strlen(line)) < 0 || argcs < 1)
    return;
  reply[0] = 0;
  for (i = 0; i < argcs; i++) {
    strcat(reply, args[i]);
    if (i + 1 < argcs)
      strcat(reply, " ");
  }
  tsng_log(LOG, "CLIENT", 0, "%s\n", reply);
  ret = tsng_com_cmd(&argcs, args, reply);
  current_client->rc = tsng_fprintf(current_client->stream, "%s\n", reply);
  if (ret == 1)
    tsng_master_remove_client(current_client);
}

void tsng_master_loop() {
  int go = 1;
  int fd;
  char line[MAX_LINE];
  struct sockaddr_in addr;
  socklen_t size = sizeof(addr);
  tsng_zombie *tmp_zombie;
  tsng_client *tmp_client, *client;

  while(go) {
    if ((fd = accept(master_fd, (struct sockaddr *)&addr, &size)) >= 0) {
      client = (tsng_client *) malloc (sizeof (tsng_client));
      if (client == NULL) {
        send(fd, "ERROR NO MEMORY AVAILABLE\n", strlen("ERROR NO MEMORY AVAILABLE\n"), 0);
        shutdown(fd, SHUT_RDWR);
        close(fd);
        tsng_log(stderr, "CLIENT", 0, "ERROR NO MEMORY AVAILABLE FOR CLIENT\n");
        tsng_log(LOG, "CLIENT", 0, "ERROR NO MEMORY AVAILABLE FOR CLIENT\n");
      } else {
        memset(client, 0, sizeof(tsng_client));
        client->stream = tsng_stream_fdopen(fd, "a+");
        client->fd = fd;
        client->ip = addr.sin_addr.s_addr;
        if ((tmp_client = clients) == NULL)
          clients = client;
        else {
          while (tmp_client->next != NULL)
            tmp_client = (tsng_client*)tmp_client->next;
          tmp_client->next = (struct tsng_client*) client;
        }
        strcpy(client->ipstring, tsng_getpeer(addr));
        tsng_log(stderr, "CLIENT", 0, "NEW CLIENT CONNECTION FROM %s\n", client->ipstring);
        tsng_log(LOG, "CLIENT", 0, "NEW CLIENT CONNECTION FROM %s\n", client->ipstring);
	fcntl(client->fd, F_SETFL, O_NONBLOCK);
        client->last_seen = time(NULL);
        client_num++;
      }
    }

    tmp_zombie = zombies;
    while (tmp_zombie != NULL) {
      if (tsng_stream_fgets(line, sizeof(line), tmp_zombie->stream) != NULL) {
        current_zombie = tmp_zombie;
        tsng_master_zombie_line(line);
        if (current_zombie != NULL && zombies != NULL) // if zombie sent QUIT
          tmp_zombie = (tsng_zombie *) tmp_zombie->next;
        else
          tmp_zombie = NULL;
      } else {
        if (tmp_zombie->last_seen + ((current_tsng_conf->timeout + 15) * 2) < time(NULL)) {
          tmp_zombie->lost_pongs++;
          if (tmp_zombie->lost_pongs > 2) {
            tsng_master_send2clients(0, "ERROR LOST ZOMBIE %s PORT %d\n", tmp_zombie->ipstring, tmp_zombie->port);
            tmp_zombie = tsng_master_remove_zombie(tmp_zombie);
	  } else {
	    tmp_zombie->rc = tsng_fprintf(tmp_zombie->stream, "PING\n");
	    tmp_zombie->last_seen = time(NULL) - (current_tsng_conf->timeout + 15);
            tmp_zombie = (tsng_zombie *) tmp_zombie->next;
          }
        } else {
/*
          if (tmp_zombie->rc < 0) {
            tmp_zombie->rc = 0;
            tsng_master_send2clients(0, "ERROR ON ZOMBIE WRITE\n");
          }
*/
          if (zombies == NULL || (unsigned int)tmp_zombie < 2*sizeof(tsng_zombie) || (unsigned int)tmp_zombie->next < 2*sizeof(tsng_zombie))
            tmp_zombie = NULL;
          else
            tmp_zombie = (tsng_zombie *) tmp_zombie->next;
        }
      }
    }
    current_zombie = NULL;
    
    tmp_client = clients;
    while (tmp_client != NULL) {
      if (tsng_stream_fgets(line, sizeof(line), tmp_client->stream) != NULL) {
        current_client = tmp_client;
        tsng_master_client_line(line);
        if (tmp_client == NULL || tmp_client->next == NULL)
          tmp_client = NULL;
        else
          tmp_client = (tsng_client *) tmp_client->next;
      } else {
        if (tmp_client->last_seen + 300 < time(NULL)) {
          tmp_client->lost_pongs++;
          if (tmp_client->lost_pongs == 1) {
            tmp_client->last_seen = time(NULL) - 240;
            tmp_client->rc = tsng_fprintf(tmp_client->stream, "INFO WARNING - TIMEOUT ON CONNECTION OCCURING SOON\n");
            tmp_client = (tsng_client *) tmp_client->next;
          } else {
            tmp_client = tsng_master_remove_client(tmp_client);
          }
        } else {
/*
          if (tmp_client->rc < 0) {
            tmp_client->rc = 0;
            tsng_master_send2clients(0, "ERROR ON CLIENT WRITE\n");
          }
*/
          if (tmp_client == NULL || tmp_client->next == NULL)
            tmp_client = NULL;
          else
          tmp_client = (tsng_client *) tmp_client->next;
        }
      }
      if (clients == NULL || (unsigned int)tmp_client < 2*sizeof(tsng_client))
        tmp_client = NULL;
    }
    current_client = NULL;
    tsng_master_handle_scan();
    usleep(25000);
  }
}

int main(int argc, char *argv[]) {
	int port;

	if (argc < 2) {
	  printf("THC-SCAN Next Generation - MASTER - %s\n\n", VERSION);
	  printf("Syntax: %s configfile\n", argv[0]);
	  exit(0);
	}

        if ((tsng_conf = tsng_modem_config_new(argv[1])) == NULL) {
          fprintf(stderr, "ERROR: Configfile %s not found!\n", argv[1]);
          exit(-1);
        }
	orig_tsng_conf = current_tsng_conf = tsng_conf;
	port = tsng_conf->port;
	if  (tsng_conf->logfile == NULL) {
	  fprintf(stderr, "Error: no logfile defined in config file\n");
	  exit(-1);
	}
        
        signal(SIGHUP, SIG_IGN);
        signal(SIGPIPE, SIG_IGN);
	if ((LOG = fopen(tsng_conf->logfile, "a+")) == NULL) {
	  fprintf(stderr, "Error: Can not create/open logfile %s\n", tsng_conf->logfile);
	  exit(-1);
	}

	if ((master_fd = tsng_bind_tcp(port, 16)) < 0) {
          tsng_log(LOG, "MASTER", 0, "Error - binding to port %d failed!\n", port);
	  fprintf(stderr, "Error: Can not bind to port %d\n", port);
	  exit(-1);
	}
	fcntl(master_fd, F_SETFL, O_NONBLOCK);
	signal(SIGSEGV, tsng_master_terminate);
	signal(SIGTERM, tsng_master_terminate);
	signal(SIGINT, tsng_master_terminate);
	signal(SIGABRT, tsng_master_terminate);
	printf("Listening on port %d\n", port);
	tsng_log(LOG, "MASTER", 0, "Started - listening on port %d\n", port);
	tsng_master_loop();

	return 0;
}
