#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

#include "tsng.h"
#include "tsng-conf-lib.h"
#include "tsng-com-lib.h"

extern tsng_modem_config *current_tsng_conf;
extern int tsng_mode;
extern int debug;

int tsng_com_error(char *buf, char *msg) {
  strcpy(buf, "ERROR ");
  strncat(buf, msg, 1000);
//  strcat(buf, "\n");
  return -1;
}

int tsng_com_ok(char *buf, char *msg) {
  strcpy(buf, "OK ");
  strcat(buf, msg);
//  strcat(buf, "\n");
  return 0;
}

int tsng_com_scanarray(char *in, char *out, int current, int max) {
  char *ptrin = in, *ptrout;
  if (in == NULL || out == NULL || strlen(in) == 0 || strlen(in) >= MAX_NUMBER_LENGTH || current == max)
    return -1;
  if (*(in + strlen(in) - 1) == '\n')
    *(in + strlen(in) - 1) = 0;
  if (*(in + strlen(in) - 1) == '\r')
    *(in + strlen(in) - 1) = 0;
  ptrout = out;
  if (strcasecmp(in, "END") == 0) {
    *out = 0;
    return -2;
  }
  while(*ptrin) {
    switch(*ptrin) {
      case '0'...'9':
//      case 'a'...'z': *ptrin = *ptrin - 32; /* make upcase */
//      case 'A'...'Z':
                *ptrout = *ptrin;
                ptrin++; ptrout++;
                break;
      /* keep dashes if there is no previous */
/*
      case '-':
                if (ptrout != out && *(ptrout - 1) != '-') {
                  *ptrout = *ptrin;
                  ptrin++; ptrout++;
                }
                break;
*/
      /* special characters are only allowed in the dialprefix/dialappendix strings */
      default:
                ptrin++;
    }
  }
  *ptrout = 0;
  if (strlen(out) == 0) {
    *out = 0;
    return -1;
  }
  /* XXX TODO: Future blacklist check here */
if (debug) printf("INFO NEW-NUMBER %s\n", out);
  return 0;
}

int tsng_com_cmd(int *argc, char *argv[], char *result) {
  int i;
  int rc;
  
  if (argv[0] == NULL || *argc < 1)
    return tsng_com_error(result, "NO COMMAND");
  if (strncasecmp(argv[0], "PING", strlen("PING")) == 0 || strncasecmp(argv[0], "PONG", strlen("PONG")) == 0) {
    return tsng_com_ok(result, argv[0]);
  }
  
  if (strncasecmp(argv[0], "TIMEOUT", strlen("TIMEOUT")) == 0) {
    if (argv[1] == NULL || *argc < 2)
      return tsng_com_error(result, "MISSING PARAMETER (1)");
    i = atoi(argv[1]);
    if (i < 2 || i > 120)
      return tsng_com_error(result, "INVALID PARAMETER (2-120)");
    if (tsng_mode == TSNG_CLIENT || argv[2] == NULL)
      current_tsng_conf->timeout = i;
    if (tsng_mode == TSNG_MASTER && tsng_com_ext_timeout(i, argv[2]) < 0)
      return tsng_com_error(result, "SCAN ID NOT FOUND");
    else
      return tsng_com_ok(result, argv[0]);
  }
  if (strncasecmp(argv[0], "RINGOUT", strlen("RINGOUT")) == 0) {
    if (argv[1] == NULL || *argc < 2)
      return tsng_com_error(result, "MISSING PARAMETER (1)");
    i = atoi(argv[1]);
    if (i < 1 || i > 14)
      return tsng_com_error(result, "INVALID PARAMETER (1-14)");
    if (tsng_mode == TSNG_CLIENT || argv[2] == NULL)
      current_tsng_conf->ringout = i;
    if (tsng_mode == TSNG_MASTER && tsng_com_ext_ringout(i, argv[2]) < 0)
      return tsng_com_error(result, "SCAN ID NOT FOUND");
    else
      return tsng_com_ok(result, argv[0]);
  }
  if (strncasecmp(argv[0], "ERROROUT", strlen("ERROROUT")) == 0) {
    if (argv[1] == NULL || *argc < 2)
      return tsng_com_error(result, "MISSING PARAMETER (1)");
    i = atoi(argv[1]);
    if (i < 1 || i > 14)
      return tsng_com_error(result, "INVALID PARAMETER (1-14)");
    if (tsng_mode == TSNG_CLIENT || argv[2] == NULL)
      current_tsng_conf->errorout = i;
    if (tsng_mode == TSNG_MASTER && tsng_com_ext_errorout(i, argv[2]) < 0)
      return tsng_com_error(result, "SCAN ID NOT FOUND");
    else
      return tsng_com_ok(result, argv[0]);
  }
  if (strncasecmp(argv[0], "NUDGE", strlen("NUDGE")) == 0) {
    if (argv[1] == NULL || *argc < 2)
      return tsng_com_error(result, "MISSING PARAMETER (1)");
    if (tsng_mode == TSNG_CLIENT || argv[2] == NULL) {
      if (current_tsng_conf->nudgestring != NULL)
        free(current_tsng_conf->nudgestring);
      current_tsng_conf->nudgestring = malloc(strlen(argv[1]) + 1);
      strcpy(current_tsng_conf->nudgestring, argv[1]);
    }
    if (tsng_mode == TSNG_MASTER && tsng_com_ext_nudge(current_tsng_conf->nudgestring, argv[2]) < 0)
      return tsng_com_error(result, "SCAN ID NOT FOUND");
    else
      return tsng_com_ok(result, argv[0]);
  }
  if (strncasecmp(argv[0], "START", strlen("START")) == 0) {
    if (tsng_com_ext_start(argv[1]) >= 0)
      return tsng_com_ok(result, argv[0]);
    else
      return tsng_com_error(result, "SCAN ID NOT FOUND");
  }
  if (strncasecmp(argv[0], "STOP", strlen("STOP")) == 0) {
    tsng_com_ext_stop();
    return tsng_com_ok(result, argv[0]);
  }
  if (strncasecmp(argv[0], "KILL", strlen("KILL")) == 0) {
    if (tsng_mode == TSNG_MASTER && (argv[1] == NULL || *argc < 2))
      return tsng_com_error(result, "MISSING PARAMETER (HOST [PORT]|ALL|MASTER)");
    if (tsng_com_ext_kill(argv[1], argv[2]) < 0)
      return tsng_com_error(result, "CONNECTION NOT FOUND");
    else
      return tsng_com_ok(result, argv[0]);
  }
  if (strncasecmp(argv[0], "QUIT", strlen("QUIT")) == 0 ||
      strncasecmp(argv[0], "EXIT", strlen("EXIT")) == 0 ||
      strncasecmp(argv[0], "LOGOUT", strlen("LOGOUT")) == 0 ||
      strncasecmp(argv[0], "LOGOFF", strlen("LOGOFF")) == 0 ||
      strncasecmp(argv[0], "DISCONNECT", strlen("DISCONNECT")) == 0) {
    tsng_com_ok(result, argv[0]);
    return 1;
  }
  if (strncasecmp(argv[0], "SCANARRAY", strlen("SCANARRAY")) == 0) {
    if (tsng_mode == TSNG_MASTER && (argv[1] == NULL || *argc < 2))
      return tsng_com_error(result, "MISSING PARAMETER (1)");
    tsng_com_ext_scanarray(argv[1]);
    return tsng_com_ok(result, argv[0]);
  }
  if (strncasecmp(argv[0], "CANCEL", strlen("CANCEL")) == 0) {
    if (tsng_com_ext_cancel(argv[1]) < 0)
      return tsng_com_error(result, "SCAN ID NOT FOUND");
    else
      return tsng_com_ok(result, argv[0]);
  }
  if (strncasecmp(argv[0], "LIST", strlen("LIST")) == 0 ||
      strncasecmp(argv[0], "STAT", strlen("STAT")) == 0 ||
      strncasecmp(argv[0], "SHOW", strlen("SHOW")) == 0) {
    if (tsng_com_ext_list(argv[1]) < 0)
      return tsng_com_error(result, "DATA NOT AVAILABLE");
    else	// can be NULL !!
      return tsng_com_ok(result, argv[0]);
  }
  if (tsng_mode == TSNG_MASTER) {
    if (strncasecmp(argv[0], "BUSYOUT", strlen("BUSYOUT")) == 0) {
      if (argv[1] == NULL || *argc < 2)
        return tsng_com_error(result, "MISSING PARAMETER (1)");
      i = atoi(argv[1]);
      if (i < 0 || i > 14)
        return tsng_com_error(result, "INVALID PARAMETER (0-14)");
      if (argv[2] == NULL)
        current_tsng_conf->busyout = i;
      if (tsng_mode == TSNG_MASTER && tsng_com_ext_busyout(i, argv[2]) < 0)
        return tsng_com_error(result, "SCAN ID NOT FOUND");
      else
        return tsng_com_ok(result, argv[0]);
    }
    if (strncasecmp(argv[0], "CONT", strlen("CONT")) == 0) {
      if (argv[1] == NULL || *argc < 2)
        return tsng_com_error(result, "MISSING PARAMETER (1)");
      if (tsng_com_ext_continue(argv[1]) < 0)
        return tsng_com_error(result, "SCAN ID NOT FOUND");
      else
        return tsng_com_ok(result, argv[0]);
    }
    if (strncasecmp(argv[0], "PRIO", strlen("PRIO")) == 0) {
      if (argv[2] == NULL || *argc < 3)
        return tsng_com_error(result, "MISSING PARAMETERS (2)");
      if (strlen(argv[1]) != 1 || argv[1][0] < '0' || argv[1][0] > '9')
        return tsng_com_error(result, "PRIORITY ONLY FROM 0 TO 9");
      if (tsng_com_ext_priority(argv[1], argv[2]) < 0)
        return tsng_com_error(result, "SCAN ID NOT FOUND");
      else
        return tsng_com_ok(result, argv[0]);
    }
    if (strncasecmp(argv[0], "ADD", strlen("ADD")) == 0) {
      if (argv[1] == NULL /*|| argv[2] == NULL*/ || *argc < 1 /* argv[3] == NULL || *argc < 2*/)
        return tsng_com_error(result, "MISSING PARAMETERS (ADD HOST PORT PASSWORD)");
      if (tsng_com_ext_add(argv[1], argv[2]) < 0)
        return tsng_com_error(result, "CONNECTION FAILED");
      else
        return tsng_com_ok(result, argv[0]);
    }
    if (strncasecmp(argv[0], "DEL", strlen("DEL")) == 0) {
      if (argv[1] == NULL || *argc < 2)
        return tsng_com_error(result, "MISSING PARAMETER (1)");
      if (tsng_com_ext_del(argv[1], argv[2], 0) < 0)
        return tsng_com_error(result, "CONNECTION NOT FOUND");
      else
        return tsng_com_ok(result, argv[0]);
    }
    if (strncasecmp(argv[0], "DIALMODE", strlen("DIALMODE")) == 0) {
      if (argv[1] == NULL || *argc < 2)
        return tsng_com_error(result, "MISSING PARAMETER (1)");
      if (*argv[1] == 'S' || *argv[1] == 's') {
        tsng_com_ext_dialmode(DIALMODE_SEQ, argv[2]);
        return tsng_com_ok(result, argv[0]);
      }
      if (*argv[1] == 'R' || *argv[1] == 'r') {
        tsng_com_ext_dialmode(DIALMODE_RAND, argv[2]);
        return tsng_com_ok(result, argv[0]);
      }
      return tsng_com_error(result, "UNKNOWN DIALMODE");
    }
    if (strncasecmp(argv[0], "RESTORE", strlen("RESTORE")) == 0) {
      if (argv[1] == NULL || *argc < 2)
        return tsng_com_error(result, "MISSING PARAMETER (1)");
      if (tsng_com_ext_restore(argv[1]) < 0)
        return tsng_com_error(result, "DAT FILE NOT FOUND");
      else
        return tsng_com_ok(result, argv[0]);
    }
    if (strncasecmp(argv[0], "RELEASE", strlen("RELEASE")) == 0) {
      if (argv[1] == NULL || *argc < 2)
        return tsng_com_error(result, "MISSING PARAMETER (1)");
      if (tsng_com_ext_release(argv[1]) < 0)
        return tsng_com_error(result, "SCAN ID NOT FOUND");
      else
        return tsng_com_ok(result, argv[0]);
    }
    if (strncasecmp(argv[0], "DUMP", strlen("DUMP")) == 0) {
      if (argv[1] == NULL || *argc < 2)
        return tsng_com_error(result, "MISSING PARAMETER (1)");
      if (tsng_com_ext_dump(argv[1]) < 0)
        return tsng_com_error(result, "SCAN ID NOT FOUND");
      else
        return tsng_com_ok(result, argv[0]);
    }
    if (strncasecmp(argv[0], "EXPORT", strlen("EXPORT")) == 0) {
      if (argv[1] == NULL || *argc < 2)
        return tsng_com_error(result, "MISSING PARAMETER (1)");
      if (tsng_com_ext_export(argv[1]) < 0)
        return tsng_com_error(result, "SCAN ID NOT FOUND");
      else
        return tsng_com_ok(result, argv[0]);
    }
    if (strncasecmp(argv[0], "WATCH", strlen("WATCH")) == 0 ||
        strncasecmp(argv[0], "DEBUG", strlen("DEBUG")) == 0) {
      if ((i = tsng_com_ext_watch(argv[1])) < 0)
        return tsng_com_error(result, "UNKNOWN OPTION");
      if (i == 1)
        return tsng_com_ok(result, "WATCH IS ON");
      if (i == 2)
        return tsng_com_ok(result, "WATCH IS OFF");
      return tsng_com_ok(result, argv[0]);
    }
    if (strncasecmp(argv[0], "SCAN", strlen("SCAN")) == 0) {
      if (argv[1] == NULL || *argc < 2)
        return tsng_com_error(result, "MISSING PARAMETER (1)");
      if ((rc = tsng_com_ext_scan(argv[1], argv[2])) == 0)
        return tsng_com_ok(result, argv[0]);
      else if (rc == -1) 
        return tsng_com_error(result, "INVALID SCAN STRING");
      else
        return tsng_com_error(result, "DATFILE FOR SCAN ALREADY EXISTS, (RE)MOVE FIRST");
    }
    if (strncasecmp(argv[0], "DROP", strlen("DROP")) == 0) {
      if (argv[1] == NULL || *argc < 2)
        return tsng_com_error(result, "MISSING PARAMETER (1)");
      if (tsng_com_ext_drop(argv[1], argv[2]) < 0)
        return tsng_com_error(result, "INVALID DROP STRING");
      else
        return tsng_com_ok(result, argv[0]);
    }
  }

  return tsng_com_error(result, "UNKNOWN-COMMAND");
}
