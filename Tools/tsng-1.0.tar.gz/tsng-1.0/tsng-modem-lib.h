
#ifndef _TSNG_MODEM_LIB_H

#define _TSNG_MODEM_LIB_H

extern int tsng_modem_lib_debug;
extern int tsng_modem_write(tsng_modem_config *config, char *data, int datalen);
extern int tsng_modem_read(tsng_modem_config *config, char *response, int timeout, int linefeeds, int mindata, int block);
extern int tsng_modem_at(tsng_modem_config *config, char *modem_at_command, char *modem_at_response, int timeout);
extern int tsng_modem_hangup(tsng_modem_config *config);
extern int tsng_modem_init(tsng_modem_config *config, char *modem_at_response);
extern int tsng_modem_dial(tsng_modem_config *config, char *number, char *response);

#endif
