#ifndef _TSNG_GENERAL_LIB_H
#define _TSNG_GENERAL_LIB_H
#include <netdb.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

extern int      tsng_split_line(int max_argc, int *argc, char *argv[], char *line, int line_max_len);
extern char    *tsng_build_time();
extern char    *tsng_time2string(unsigned long int sec);
extern void     tsng_log(FILE *f, char *source, char delimiter, char *fmt, ...);
extern int      tsng_fprintf(FILE *f, char *fmt, ...);
extern char    *tsng_fgets(char *s, int size, FILE *stream);
extern char    *tsng_getpeer(struct sockaddr_in addr);
extern FILE    *tsng_stream_disconnect(FILE *S);
extern FILE    *tsng_stream_connect_tcp(unsigned long int host, int port);
extern FILE    *tsng_stream_connect_host_tcp(char *host, int port);
extern int      tsng_bind_tcp(int port, int instances);
extern char    *tsng_stream_fgets(char *s, int size, FILE *f);
extern FILE    *tsng_stream_fdopen(int fd, char *ptr);
extern void     tsng_dump_asciihex(unsigned char *string, int length);
extern void     tsng_stream_resetbuffer(FILE *f);

extern unsigned long int internal__tsng_resolve(char *host);
#endif
