
#ifndef _TSNG_CLIENT_H

#define _TSNG_CLIENT_H

/* TSNG CLI header file */

#define TSNG_PROGRAM   "tsng-client"
#define TSNG_MAX_LINE   512
#define TSNG_MAX_ARGC   16

//typedef unsigned int    u_int;
//typedef unsigned short  u_short;
//typedef unsigned char   u_char;
//typedef unsigned long   u_long;

/* TSNG initial config */

struct _tsng_conf{
   char *host;
   u_short port;
   u_int verbose;
   char *scriptfile;
   char *logfile;
   char *session_secret;
   char *password;
};

typedef struct _tsng_conf tsng_config;

#endif
