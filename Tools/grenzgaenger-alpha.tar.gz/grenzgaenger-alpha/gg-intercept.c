#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <dlfcn.h>
#include <errno.h>
#include <unistd.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <time.h>
#include <string.h>
#include <netinet/in.h>
#include <netdb.h>
#include "gg.h"


//////////////////////////
// CONFIG HERE
//////////////////////////

#define PROXY_IP "127.0.0.1"
#define PROXY_PORT 443

//////////////////////////
// END OF CONFIG
//////////////////////////

#define PROGRAM		"gg-intercept"
#define GG_MAX_SOCKETS  1024

typedef struct {
  char    *h_name;        /* official name of host */
  char    **h_aliases;    /* alias list */
  int     h_addrtype;     /* host address type */
  int     h_length;       /* length of address */
  char    **h_addr_list;  /* list of addresses */
} hostent;

static void *handle = NULL;
static short int supported_sockets[GG_MAX_SOCKETS];
static unsigned short int id_of_sockets[GG_MAX_SOCKETS];
static int gg = -1;
static unsigned char buf[GG_BUFSIZE];
static gg_struct_admin_sockets admin_socket;
static unsigned short int *si = (unsigned short int *) &buf[2];
static unsigned short int *sl = (unsigned short int *) &buf[4];
static unsigned short int *stmp;
static struct sockaddr_in gg_addr;
static int gg_addr_len = sizeof(gg_addr);
static struct sockaddr_in *gg_addr_ptr;
static struct in_addr target_addr;
static char *gg_ip = NULL;
static char *gg_port = NULL;
static char *gg_pass = NULL;
static char *gg_tunnel = NULL;

static int (*o_close) (int fd);
static int (*o_socket) (int domain, int type, int protocol);
static int (*o_connect) (int sockfd, const struct sockaddr *serv_addr, socklen_t addrlen);
static int (*o_sendto) (int s, const void *msg, size_t len, int flags, const struct sockaddr *to, socklen_t tolen);
static ssize_t (*o_sendmsg) (int fd, const struct msghdr *message, int flags);
static struct hostent *(*o_gethostbyname) (const char *name);
static struct hostent *(*o_gethostbyaddr) (const char *addr, int len, int type);

static void gg_intercept_connect_ggd(void);
static void gg_intercept_flush_fd(int fd, int waitforidfrom, int waitforidto);

static void dorelink(void) {
  int i;
  if (!(handle = dlopen("libc.so", RTLD_LAZY)))
    if (!(handle = dlopen("libc.so.6", RTLD_LAZY))) {
      fprintf(stderr, "%s(): cant find libc\n", __func__);
      exit(-1);
    }
  o_close = dlsym(handle, "close");
  o_socket = dlsym(handle, "socket");
  o_connect = dlsym(handle, "connect");
  o_sendto = dlsym(handle, "sendto");
  o_sendmsg = dlsym(handle, "sendmsg");
  o_gethostbyname = dlsym(handle, "gethostbyname");
  o_gethostbyaddr = dlsym(handle, "gethostbyaddr");
  dlclose(handle);
  for (i = 0; i < GG_MAX_SOCKETS; i++) {
    supported_sockets[i] = 0;
    id_of_sockets[i] = 0;
  }
}

static void gg_intercept_connect_ggd(void) {
  int count = 8;
  if ((gg_ip = getenv("GG_PROXY_IP")) == NULL)
    inet_aton(PROXY_IP, &target_addr);
  else
    inet_aton(gg_ip, &target_addr);
  if ((gg_port = getenv("GG_PROXY_PORT")) == NULL)
    gg_addr.sin_port = htons(PROXY_PORT);
  else
    gg_addr.sin_port = htons(atoi(gg_port));
  if ((gg_pass = getenv("GG_PROXY_PASS")) == NULL) {
    printf("\n%s: please enter the proxy password: ", PROGRAM);
    system("stty -echo");
    fgets(buf, sizeof(buf), stdin);
    system("stty echo");
    if (buf[strlen(buf) - 1] == '\n')
      buf[strlen(buf) - 1] = 0;
    if (buf[strlen(buf) - 1] == '\r')
      buf[strlen(buf) - 1] = 0;
    gg_pass = malloc(strlen(buf) + 1);
    strcpy(gg_pass, buf);
    printf(" thank you.\n");
  }
  if ((gg_tunnel = getenv("GG_TUNNEL")) == NULL)
    fprintf(stderr, "%s: Warning - no tunnel definition specified via the GG_TUNNEL environment variable\n", PROGRAM);
  gg_addr.sin_port = htons(PROXY_PORT);
  gg_addr.sin_family = AF_INET;
  gg_addr.sin_addr.s_addr = target_addr.s_addr;
  gg = o_socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
  if (o_connect(gg, (struct sockaddr *) &gg_addr, sizeof(gg_addr)) < 0) {
    fprintf(stderr, "%s: can not connect to proxy, terminating!\n", PROGRAM);
    exit(-1);
  }
  admin_socket.my_id = (time(NULL) + getpid() + getuid()) % 65536;
  memcpy(buf, GG_INIT_ADMIN_STRING, 4);
  stmp = (unsigned short int *) &buf[6];
  *stmp = admin_socket.my_id;
  *sl = count;
  send(gg, buf, count, 0);
  memset(buf, 0, sizeof(buf));
  if (recv(gg, buf, sizeof(buf), 0) < 1) {
    fprintf(stderr, "%s: proxy disconnected, terminating!\n", PROGRAM);
    exit(-1);
  }
  // we ignore the received data
  admin_socket.socket = gg;
  fprintf(stderr, "%s: connection to proxy established\n", PROGRAM);
}

static void gg_intercept_flush_fd(int fd, int waitforidfrom, int waitforidto) {
  int res = 0;
  fd_set rfd;
  struct timeval tv;
  int total_count, count;
  unsigned char total_buf[GG_BUFSIZE];
  int ignore;

  if (fd > 0) do {
  usleep(1000);
    tv.tv_sec = 0;
    tv.tv_usec = 0;
    FD_ZERO(&rfd);
    FD_SET(fd, &rfd);
    if ((res = select(fd + 1, &rfd, NULL, &rfd, &tv)) > 0) {
      if ((total_count = recv(fd, total_buf, sizeof(total_buf), 0)) > 0) {
        count = total_count;
        while (count > 3) {
          memcpy(buf, total_buf + total_count - count, count);
#ifdef DEBUG
printf("total_count %d  count %d (size: %d) %d %d / %d %d\n", total_count, count, *sl, buf[0], buf[1],buf[6],buf[7]);
#endif
          ignore = 0;
          if (waitforidfrom != 0 && waitforidto != 0 && buf[0] >= waitforidfrom && buf[0] <= waitforidto)
            return;
          switch(buf[0]) {
            case GG_CMD_USER_REQ_CLOSE:
              // ignore
            break;
            case GG_CMD_MSG:
              fprintf(stderr, "%s: MESSAGE: %s\n", PROGRAM, buf + 6);
            break;
            case GG_CMD_USER_REQ_RESOLVE:
            case GG_CMD_USER_REP_RESOLVE_OK:
            case GG_CMD_USER_REP_RESOLVE_FAIL:
            case GG_CMD_USER_REQ_CONNECT:
            case GG_CMD_USER_REP_CONNECT_OK:
            case GG_CMD_USER_REP_CONNECT_TIMEOUT:
            case GG_CMD_USER_REP_CONNECT_REFUSED:
            case GG_CMD_USER_REP_CONNECT_UNREACHABLE:
            case GG_CMD_USER_DATA:
            case GG_CMD_ADMIN_TUNNEL_CONNECT:
            case GG_CMD_ADMIN_TUNNEL_CONNECT_OK:
            case GG_CMD_ADMIN_TUNNEL_CONNECT_FAILED:
            case GG_CMD_ADMIN_LIST:
            case GG_CMD_ADMIN_CLOSE:
            case GG_CMD_ADMIN_SHUTDOWN:
            case GG_CMD_ADMIN_DELETE:
            case GG_CMD_ADMIN_SHELL:
            case GG_CMD_ADMIN_EXEC:
              fprintf(stderr, "%s: Error - illegal message from proxy: %d %d %d %d %d %d\n", PROGRAM, buf[0], buf[1], buf[2], buf[3], buf[4], buf[5]);
            break;
            case GG_CMD_ADMIN_TUNNEL_CONNECT_ERR:
              fprintf(stderr, "%s: Error - can not connect to next proxy in chain\n", PROGRAM);
              exit(-1);
            default:
              fprintf(stderr, "%s: Error - unknown message from proxy: %d %d %d %d %d %d\n", PROGRAM, buf[0], buf[1], buf[2], buf[3], buf[4], buf[5]);
          }
          if (*sl < 6 || *sl > count) {
            fprintf(stderr, "%s: BUG - broken message\n", PROGRAM);
            count = 0;
          } else 
            count = count - *sl;
        }
      } else
          if (total_count < 0) {
            fprintf(stderr, "%s: connection to proxy lost (connect)\n", PROGRAM);
            exit(-1);
          }
    }
  } while (res > 0 || (waitforidfrom != 0 || waitforidto != 0));
}

int close(int fd) {
  int count = 6;
  if (!handle)
    dorelink();
  else
    gg_intercept_flush_fd(admin_socket.socket, 0, 0);
  if (fd < GG_MAX_SOCKETS) {
    if (id_of_sockets[fd] != 0 && (supported_sockets[fd] == GG_TCP || supported_sockets[fd] == GG_UDP || supported_sockets[fd] == GG_UDP_CONNECTED)) {
      buf[0] = GG_CMD_USER_REQ_CLOSE;
      if (gg_tunnel == NULL || gg_tunnel[0] == 0)
        buf[1] = 0;
      else {
        buf[1] = count;
        memcpy(buf + count, gg_tunnel, strlen(gg_tunnel) + 1);
        count = count + strlen(gg_tunnel) + 1;
      }
      *si = id_of_sockets[fd];
      *sl = count;
      send(admin_socket.socket, buf, count, 0);
    }
    id_of_sockets[fd] = 0;
    supported_sockets[fd] = 0;
  }
  return(o_close(fd));
}

int socket(int domain, int type, int protocol) {
  int s;
  int unsupported = 0;
  if (!handle)
    dorelink();
  else
    gg_intercept_flush_fd(admin_socket.socket, 0, 0);
  if (domain != AF_INET) {
    fprintf(stderr, "%s: socket() parameter domain %d is not AF_INET - intercepting this socket will fail!\n", PROGRAM, domain);
    unsupported = 1;
  }
  if (type != SOCK_STREAM && type != SOCK_DGRAM) {
    fprintf(stderr, "%s: socket() parameter type %d is not SOCK_STREAM or SOCK_DGRAM - intercepting this socket will fail!\n", PROGRAM, type);
    unsupported = 1;
  }
  if (protocol != IPPROTO_TCP && protocol != IPPROTO_IP && protocol != IPPROTO_UDP) {
    fprintf(stderr, "%s: socket() parameter protocol %d is not IPPROTO_TCP or IPPROTO_UDP - intercepting this socket will fail!\n", PROGRAM, protocol);
    unsupported = 1;
  }
  s = o_socket(domain, type, protocol);
  if (unsupported == 0) {
    if (s >= GG_MAX_SOCKETS)
      fprintf(stderr, "%s: Error - increase GG_MAX_SOCKETS definition and recompile!\n", PROGRAM);
    else {
      if (protocol == IPPROTO_TCP)
        supported_sockets[s] = GG_TCP;
      else
        supported_sockets[s] = GG_UDP;
    }
  }
  return s;
}

int connect(int sockfd, const struct sockaddr *serv_addr, socklen_t addrlen) {
  int count = 15;
  int i;
  int portno;
  if (!handle)
    dorelink();
  else
    gg_intercept_flush_fd(admin_socket.socket, 0, 0);
  if (sockfd < GG_MAX_SOCKETS && (supported_sockets[sockfd] == GG_TCP || supported_sockets[sockfd] == GG_UDP)) {
    if (gg == -1)
      gg_intercept_connect_ggd();
    buf[0] = GG_CMD_USER_REQ_CONNECT;
      if (gg_tunnel == NULL || gg_tunnel[0] == 0)
        buf[1] = 0;
      else {
        buf[1] = count;
        memcpy(buf + count, gg_tunnel, strlen(gg_tunnel) + 1);
        count = count + strlen(gg_tunnel) + 1;
      }
    id_of_sockets[sockfd] = admin_socket.my_id;
    *si = admin_socket.my_id;
    *sl = count;
    admin_socket.my_id++;
    gg_addr_ptr = (struct sockaddr_in *) serv_addr;
    memcpy(&buf[6], &gg_addr_ptr->sin_addr.s_addr, 4);
    stmp = (unsigned short int *) &buf[10];
    *stmp = gg_addr_ptr->sin_port;
    portno = ntohs(gg_addr_ptr->sin_port);
    buf[12] = supported_sockets[sockfd];
    if (supported_sockets[sockfd] == GG_UDP) {
      gg_addr.sin_port = 0;
      gg_addr.sin_family = AF_INET;
      gg_addr.sin_addr.s_addr = htonl(INADDR_ANY);
      // the following might fail because the program bound the port itself, but we dont care
      bind(sockfd, (struct sockaddr *) &gg_addr, sizeof(gg_addr));
      getsockname(sockfd, (struct sockaddr *) &gg_addr, &gg_addr_len);
      stmp = (unsigned short int *) &buf[13];
      *stmp = gg_addr.sin_port;
      supported_sockets[sockfd] = GG_UDP_CONNECTED;
    }
    memset(&gg_addr, 0, sizeof(gg_addr));
    gg_intercept_flush_fd(admin_socket.socket, 0, 0);
    send(admin_socket.socket, buf, count, 0);
//printf("b1\n");
    gg_intercept_flush_fd(admin_socket.socket, GG_CMD_USER_REP_CONNECT_OK, GG_CMD_USER_REP_CONNECT_UNREACHABLE);
//printf("a1\n");
    if (buf[0] != GG_CMD_USER_REP_CONNECT_OK) {
      switch(buf[0]) {
        case GG_CMD_USER_REP_CONNECT_UNREACHABLE:
          errno = ENETUNREACH;
        break;
        case GG_CMD_USER_REP_CONNECT_TIMEOUT:
          errno = ETIMEDOUT;
        default:
          errno = ECONNREFUSED;
      }
      id_of_sockets[sockfd] = 0;
      return -1;
    }
    stmp = (unsigned short int *) &buf[6];
#ifdef DEBUG
    fprintf(stderr, "%s: Spoofed local port for %d is %d\n", PROGRAM, portno, ntohs(*stmp));
#endif
    gg_addr.sin_port = *stmp;
    gg_addr.sin_family = AF_INET;
    inet_aton(PROXY_IP, &target_addr);
    gg_addr.sin_addr.s_addr = target_addr.s_addr;
    errno = 0;
i = fcntl(sockfd, F_GETFL, 0);
fcntl(sockfd, F_SETFL, 0);
fcntl(sockfd, F_SETFL, O_RDWR);
    if (o_connect(sockfd, (struct sockaddr *) &gg_addr, sizeof(gg_addr)) < 0 && errno != EINPROGRESS) {
      fprintf(stderr, "%s: Error - we could not connect to the proxied listening socket\n", PROGRAM);
      id_of_sockets[sockfd] = 0;
      errno = ECONNREFUSED;
      return -1;
    }
fcntl(sockfd, F_SETFL, i);
#ifdef DEBUG
    if (errno == EINPROGRESS)
      fprintf(stderr, "%s: Connect to spoofed port in progress\n", PROGRAM);
    else
      fprintf(stderr, "%s: Connect to spoofed port successful\n", PROGRAM);
#endif
    if (errno == EINPROGRESS)
      return -1;
    else
      return 0;
  } else
    return o_connect(sockfd, serv_addr, addrlen);
  return 0; // not reached
}

struct hostent *gethostbyname(const char *name) {
  static struct hostent he;
  static uint32_t *ip, *ip2;
  static uint32_t ip1 = 0;
  int count = 7 + strlen(name) + 1;
  if (!handle)
    dorelink();
  else
    gg_intercept_flush_fd(admin_socket.socket, 0, 0);
  ip = &ip1;
  if (gg == -1)
    gg_intercept_connect_ggd();
  buf[0] = GG_CMD_USER_REQ_RESOLVE;
  *si = admin_socket.my_id;
  admin_socket.my_id++;
  buf[6] = 1;
  if (strlen(name) > 255) {
    fprintf(stderr, "%s: bah, buffer overflow tried on gethostbyname function: %s\n", PROGRAM, name);
    exit(-1);
  }
  strcpy(&buf[7], name);
  if (gg_tunnel == NULL || gg_tunnel[0] == 0)
    buf[1] = 0;
  else {
    buf[1] = count;
    memcpy(buf + count, gg_tunnel, strlen(gg_tunnel) + 1);
    count = count + strlen(gg_tunnel) + 1;
  }
  *sl = count;
  gg_intercept_flush_fd(admin_socket.socket, 0, 0);
  send(admin_socket.socket, buf, count, 0);
  gg_intercept_flush_fd(admin_socket.socket, GG_CMD_USER_REP_RESOLVE_OK, GG_CMD_USER_REP_RESOLVE_FAIL);
  if (buf[0] != GG_CMD_USER_REP_RESOLVE_OK) {
    fprintf(stderr, "%s: proxied gethostbyname failed, trying local resolution\n", PROGRAM);
    return o_gethostbyname(name);
  }
  he.h_name = malloc(strlen(name) + 1);
  strcpy(he.h_name, name);
  ip2 = (uint32_t*) &buf[6];
  *ip = *ip2;
  he.h_addr_list = malloc(sizeof(int) * 2);
  he.h_addr_list[0] = (char*)ip;
  he.h_addr_list[1] = NULL;
  he.h_addrtype = AF_INET;
  he.h_aliases = NULL;
  return &he;
}

struct hostent *gethostbyaddr(const void *addr, socklen_t len, int type) {
  static struct hostent he;
  static uint32_t *ip, *ip2;
  static uint32_t ip1 = 0;
  int count = 11;
  if (!handle)
    dorelink();
  else
    gg_intercept_flush_fd(admin_socket.socket, 0, 0);
  ip = &ip1;
  if (gg == -1)
    gg_intercept_connect_ggd();
  if (len != 4 || type != AF_INET) {
    fprintf(stderr, "%s: can not intercept this gethostbyaddr type\n", PROGRAM);
    return o_gethostbyaddr(addr, len, type);
  }
  buf[0] = GG_CMD_USER_REQ_RESOLVE;
  if (gg_tunnel == NULL || gg_tunnel[0] == 0)
    buf[1] = 0;
  else {
    buf[1] = count;
    memcpy(buf + count, gg_tunnel, strlen(gg_tunnel) + 1);
    count = count + strlen(gg_tunnel) + 1;
  }
  *si = admin_socket.my_id;
  *sl = count;
  admin_socket.my_id++;
  buf[6] = 2;
  memcpy(&buf[7], addr, 4);
  gg_intercept_flush_fd(admin_socket.socket, 0, 0);
  send(admin_socket.socket, buf, count, 0);
  gg_intercept_flush_fd(admin_socket.socket, GG_CMD_USER_REP_RESOLVE_OK, GG_CMD_USER_REP_RESOLVE_FAIL);
  if (buf[0] != GG_CMD_USER_REP_RESOLVE_OK) {
    fprintf(stderr, "%s: proxied gethostbyaddr failed, trying local resolution\n", PROGRAM);
    return o_gethostbyaddr(addr, len, type);
  }
  he.h_name = malloc(count - 3);
  memcpy(he.h_name, buf + 4, count - 4);
  he.h_name[count - 4] = 0;
  ip2 = (uint32_t*) addr;
  *ip = *ip2;
  he.h_addr_list = malloc(sizeof(int) * 2);
  he.h_addr_list[0] = (char*)ip;
  he.h_addr_list[1] = NULL;
  he.h_addrtype = AF_INET;
  he.h_aliases = NULL;
  return &he;
}

int sendto(int s, const void *msg, size_t len, int flags, const struct sockaddr *to, socklen_t tolen) {
  if (to == NULL || s >= GG_MAX_SOCKETS || supported_sockets[s] == 0)
    return o_sendto(s, msg, len, flags, to, tolen);
  else {
    if (supported_sockets[s] == GG_UDP) {
      connect(s, to, tolen);
      supported_sockets[s] = GG_UDP_CONNECTED;
    }
    return send(s, msg, len, flags);
  }
  return -1; // not reached
}

ssize_t sendmsg(int fd, const struct msghdr *message, int flags) {
  if (message == NULL || message->msg_name == NULL || fd >= GG_MAX_SOCKETS || supported_sockets[fd] == 0)
    return o_sendmsg(fd, message, flags);
  else {
    if (supported_sockets[fd] == GG_UDP) {
      connect(fd, message->msg_name, message->msg_namelen);
      supported_sockets[fd] = GG_UDP_CONNECTED;
    }
    return writev(fd, message->msg_iov, message->msg_iovlen);
  }
  return -1; // not reached
}
