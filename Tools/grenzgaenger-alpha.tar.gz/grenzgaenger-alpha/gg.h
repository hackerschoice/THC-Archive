#ifndef _GG_H

/* 
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.    
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *    
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#define GG_VERSION   "v0.2"

#define GG_PORT                443
#define GG_MAX_USER_SOCKETS    (1024 - GG_MAX_ADMIN_SOCKETS - GG_MAX_TUNNEL_SOCKETS - 4)
#define GG_MAX_ADMIN_SOCKETS   16
#define GG_MAX_TUNNEL_SOCKETS  4
#define GG_BUFSIZE             4096	// standard buffer size
#define GG_TCP                 6
#define GG_UDP                 17
#define GG_UDP_CONNECTED       (GG_UDP + 256)

#define GG_INIT_ADMIN_STRING         "GGA1"
#define GG_INIT_TUNNEL_STRING        "GGT1"

#define GG_CMD_USER_REQ_RESOLVE             1
#define GG_CMD_USER_REP_RESOLVE_OK          2
#define GG_CMD_USER_REP_RESOLVE_FAIL        3
#define GG_CMD_USER_REP_RESOLVE_TUNNEL_ERR  4
#define GG_CMD_USER_REQ_CONNECT             5
#define GG_CMD_USER_REP_CONNECT_OK          6
#define GG_CMD_USER_REP_CONNECT_TIMEOUT     7
#define GG_CMD_USER_REP_CONNECT_REFUSED     8
#define GG_CMD_USER_REP_CONNECT_UNREACHABLE 9
#define GG_CMD_USER_REP_CONNECT_TUNNEL_ERR  10
#define GG_CMD_USER_REQ_CLOSE               11
#define GG_CMD_USER_DATA                    12
#define GG_CMD_ADMIN_TUNNEL_CONNECT         13
#define GG_CMD_ADMIN_TUNNEL_CONNECT_OK      14
#define GG_CMD_ADMIN_TUNNEL_CONNECT_FAILED  15
#define GG_CMD_ADMIN_TUNNEL_CONNECT_ERR     16
#define GG_CMD_ADMIN_LIST                   17
#define GG_CMD_ADMIN_CLOSE                  18
#define GG_CMD_ADMIN_SHUTDOWN               19
#define GG_CMD_ADMIN_DELETE                 20
#define GG_CMD_ADMIN_SHELL                  21
#define GG_CMD_ADMIN_EXEC                   22
#define GG_CMD_MSG                          127

#define GG_STATUS_FREE                      0
//#define GG_STATUS_TUN_LISTEN                1
#define GG_STATUS_TUN_CONNECT_IN_PROGRESS   2
#define GG_STATUS_TUN_CONNECT_FAILED        3
#define GG_STATUS_TUN_ACCEPTED              4
#define GG_STATUS_TUN_INIT_REQ              5
//#define GG_STATUS_TUN_INIT_REP              6
#define GG_STATUS_TUN_OK                    7
#define GG_STATUS_USER_WAIT4TUNNEL          8
#define GG_STATUS_USER_TUNNEL               9
#define GG_STATUS_USER_LISTEN               10
#define GG_STATUS_USER_CONNECT_IN_PROGRESS  11
#define GG_STATUS_USER_CONNECT_TIMEOUT      12
#define GG_STATUS_USER_CONNECT_REFUSED      13
#define GG_STATUS_USER_CONNECT_UNREACHABLE  14
#define GG_STATUS_USER_CONNECT_ACCEPTED     15
#define GG_STATUS_USER_CONNECT_OK           16

#define GG_TYPE_ADMIN_IN                    1
#define GG_TYPE_ADMIN_OUT                   2
#define GG_TYPE_ADMIN_TUN                   3
#define GG_TYPE_USER_IN                     4
#define GG_TYPE_USER_OUT                    5
#define GG_TYPE_USER_BOTH                   6
#define GG_TYPE_USER_TUN                    7
#define GG_TYPE_USER_IN_WAIT4TUNNEL         8

typedef struct {
  char foreground;
  char syslog;
  char verbose;
  char master;
  unsigned short int port;
  int listen_socket;
  // passwords XXX
} gg_struct_options;

typedef struct {
  uint32_t ip;
  unsigned short int port;
  unsigned short int id;
  unsigned short int id_out;
  unsigned char proto;
  unsigned char type;
  unsigned char status;
  unsigned char options;
  int in_socket;
  int out_socket;
} gg_struct_user_sockets;

typedef struct {
  char *tunnel_id;    // htonl(inet_aton(IP)) + htons(PORT)
  unsigned short int my_id;
  unsigned short int his_id;
  uint32_t his_ip;
  unsigned char type;
  unsigned char status;
  unsigned char options;
  int socket;
  char *pass;
} gg_struct_admin_sockets;

#define _GG_H
#endif
