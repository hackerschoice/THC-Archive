/* 
 * proof of concept code - do NOT use for illegal purpose!
 * it wont work reliable anyway!
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.    
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *    
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

// INCLUDES //
#include "gg-inc.h"
#include "gg.h"

#ifdef OPENSSL
RSA *gg_rsa = NULL;
#endif

gg_struct_admin_sockets admin_sockets[GG_MAX_ADMIN_SOCKETS + GG_MAX_TUNNEL_SOCKETS];
gg_struct_user_sockets user_sockets[GG_MAX_USER_SOCKETS];
gg_struct_options opt;

// HELP //
void gg_help(char *prg) {
  printf("Syntax: %s [-fsv] [-p port] [-U pass] [-A pass]\n", prg);
  printf("Options:\n");
  printf("  -f         Run in foreground\n");
  printf("  -m         Master mode - disables local shells/execs, connection listings,\n");
  printf("             shutdowns and delete commands over tunnels\n");
  printf("  -s         Print messages to syslog instead of stderr\n");
  printf("  -v         Verbose mode\n");
  printf("  -p port    Port to listen for admin connects (default: %d)\n", GG_PORT);
  printf("  -U pass    User connect password. Will ask for if not supplied on cmd\n");
  printf("  -A pass    Admin connect password. Will ask for if not supplied on cmd\n");
  printf("  -h         Print this shit\n");
  exit(-1);
}

void gg_init_socket(int sock) {
  int res = 1;
#ifdef SO_REUSEADDR
  setsockopt(sock, SOL_SOCKET, SO_REUSEADDR, &res, sizeof(res));
#endif
#ifdef SO_REUSEPORT
  setsockopt(sock, SOL_SOCKET, SO_REUSEPORT, &res, sizeof(res));
#endif
  fcntl(sock, F_SETFL, O_NONBLOCK);
}



int main(int argc, char *argv[]) {
  struct sockaddr_in gg_addr;
  int gg_addr_len = sizeof(gg_addr);
  struct in_addr target_addr;
  struct hostent *he;
  struct timeval tv;
  fd_set rfd, wfd, efd;
  int maxfd;
  int end = 0;
  int count;
  int curr_count;
  int total_count;
  int res;
  int i;
  int j;
  int l;
  int error;
  int error_len = sizeof(error);
  char *ptr, *ptr1, *ptr2, *ptr3;
  unsigned char buf[GG_BUFSIZE];
  unsigned char curr_buf[GG_BUFSIZE];
  unsigned short int *si = (unsigned short int *) &buf[2];
  unsigned short int *sl = (unsigned short int *) &buf[4];
  unsigned short int *stmp;
#ifdef OPENSSL
  int err;
  SSL *ssl;
  SSL_CTX *sslContext;
#endif

  memset(admin_sockets, 0, sizeof(admin_sockets));
  memset(user_sockets, 0, sizeof(user_sockets));
  memset(&opt, 0, sizeof(opt));
  memset(&gg_addr, 0, sizeof(gg_addr));
  opt.port = GG_PORT;
opt.foreground = 1;
opt.verbose = 2;

  // GETOPT //
  if (argc == 2 && (strncmp(argv[1], "-?", 2) == 0 || strncmp(argv[1], "--h", 3) == 0))
    gg_help(argv[0]);
  while ((i = getopt(argc, argv, "fhmp:svA:U:")) >= 0) {
    switch (i) {
    case 'A': // admin password XXX
      break;
    case 'U': // user password XXX
      break;
    case 'p':
      opt.port = atoi(optarg);
      break;
    case 'v':
      opt.verbose++;
      break;
    case 's':
printf("NOT IMPLEMENTED YET - XXX\n");
      opt.syslog = 1;
      break;
    case 'm':
      opt.master = 1;
      break;
    case 'f':
      opt.foreground = 1;
      break;
    case 'h':
      gg_help(argv[0]);
      break;
    default:
      gg_help(argv[0]);
    }
  }

  if (optind != argc)
    gg_help(argv[0]);

#ifdef XXX
  if (admin_password == NULL)
     admin_password = gg_get_password();
  if (user_password == NULL)
     user_password = gg_get_password();
#endif

  if (!opt.foreground) {
    i = fork();
    if (i < 0)
      fprintf(stderr, "Error: fork failed, running in foreground\n");
    else
      if (i > 0) {
        fprintf(stderr, "Info: running with pid %d now\n", i);
        exit(0);
      }
  }

  opt.listen_socket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
  gg_addr.sin_port = htons(opt.port);
  gg_addr.sin_family = AF_INET;
  gg_addr.sin_addr.s_addr = htonl(INADDR_ANY);
  gg_init_socket(opt.listen_socket);
  bind(opt.listen_socket, (struct sockaddr *) &gg_addr, sizeof(gg_addr));
  listen(opt.listen_socket, GG_MAX_ADMIN_SOCKETS);
  gg_init_socket(opt.listen_socket);

  while(!end) {
    /* check for new incoming admin connections */
    if ((i = accept(opt.listen_socket, (struct sockaddr *) &gg_addr, &gg_addr_len)) > 0) {
      gg_init_socket(i);
      res = 0;
      for (j = 0; j < GG_MAX_ADMIN_SOCKETS; j++) {
        if (admin_sockets[j].status == GG_STATUS_FREE) {
          res = 1;
          admin_sockets[j].socket = i;
          admin_sockets[j].status = GG_STATUS_TUN_ACCEPTED;
          admin_sockets[j].type = GG_TYPE_ADMIN_IN;
          admin_sockets[j].his_ip = gg_addr.sin_addr.s_addr;
          fprintf(stderr, "Info: Admin connect from %s\n", inet_ntoa(gg_addr.sin_addr));
          j = GG_MAX_ADMIN_SOCKETS;
        }
      }
      if (!res) {
        fprintf(stderr, "Error: No structure free for new connection, dropping [BUG!]\n");
        close(i);
      }
    }

    /* check for accepted user in_socket connections */
    for (i = 0; i < GG_MAX_USER_SOCKETS; i++) {
      if (user_sockets[i].status == GG_STATUS_USER_LISTEN && (user_sockets[i].type == GG_TYPE_USER_IN || user_sockets[i].type == GG_TYPE_USER_BOTH)) {
        if ((j = accept(user_sockets[i].in_socket, NULL, NULL)) > 0) {
          gg_init_socket(j);
          close(user_sockets[i].in_socket); // no more listening required
          user_sockets[i].in_socket = j;
          user_sockets[i].status = GG_STATUS_USER_CONNECT_OK;
        }
      }
    }

    /* now check outgoing connections which are in progress */
    FD_ZERO(&wfd);
    maxfd = 0;
    count = 0;
    tv.tv_sec = 0;
    tv.tv_usec = 0;
    for (i = 0; i < GG_MAX_TUNNEL_SOCKETS; i++) {
      if (admin_sockets[GG_MAX_ADMIN_SOCKETS + i].status == GG_STATUS_TUN_CONNECT_IN_PROGRESS) {
        count++;
        FD_SET(admin_sockets[GG_MAX_ADMIN_SOCKETS + i].socket, &wfd);
        if (admin_sockets[GG_MAX_ADMIN_SOCKETS + i].socket > maxfd)
          maxfd = admin_sockets[GG_MAX_ADMIN_SOCKETS + i].socket;
      }
    }
    for (i = 0; i < GG_MAX_USER_SOCKETS; i++) {
      if (user_sockets[i].status == GG_STATUS_USER_CONNECT_IN_PROGRESS && (user_sockets[i].type == GG_TYPE_USER_OUT || user_sockets[i].type == GG_TYPE_USER_BOTH)) {
        count++;
        FD_SET(user_sockets[i].out_socket, &wfd);
        if (user_sockets[i].out_socket > maxfd)
          maxfd = user_sockets[i].out_socket;
      }	
    }
    efd = wfd;
    res = select(maxfd + 1, NULL, &wfd, &efd, &tv);

    /* if res > 0 some connections are ready now */
    if (res > 0) {
      for (i = 0; i < GG_MAX_TUNNEL_SOCKETS; i++) {
        if (FD_ISSET(admin_sockets[GG_MAX_ADMIN_SOCKETS + i].socket, &wfd) && admin_sockets[GG_MAX_ADMIN_SOCKETS + i].status == GG_STATUS_TUN_CONNECT_IN_PROGRESS) {
          error = 0;
          if (getsockopt(admin_sockets[GG_MAX_ADMIN_SOCKETS + i].socket, SOL_SOCKET, SO_ERROR, &error, &error_len) < 0 || error != 0) {
            count = 6;
            buf[0] = GG_CMD_ADMIN_TUNNEL_CONNECT_FAILED;
            buf[1] = 0;
            *si = admin_sockets[GG_MAX_ADMIN_SOCKETS + i].his_id;
            *sl = count;
            send(admin_sockets[GG_MAX_ADMIN_SOCKETS + i].socket, buf, count, 0);
            memset(&admin_sockets[GG_MAX_ADMIN_SOCKETS + i], 0, sizeof(gg_struct_admin_sockets));
          } else {
            admin_sockets[GG_MAX_ADMIN_SOCKETS + i].status = GG_STATUS_TUN_ACCEPTED;
            admin_sockets[GG_MAX_ADMIN_SOCKETS + i].my_id = (time(NULL) + getpid() + getuid()) % 65536;
//fprintf(stderr, "DEBUG: my_id: %d\n", admin_sockets[GG_MAX_ADMIN_SOCKETS + i].my_id);
            // now we send the init data
            count = 8;
            memcpy(buf, GG_INIT_TUNNEL_STRING, 4);
            *sl = count;
            stmp = (unsigned short int *) &buf[6];
            *stmp = admin_sockets[GG_MAX_ADMIN_SOCKETS + i].my_id;
            admin_sockets[GG_MAX_ADMIN_SOCKETS + i].my_id++;
            send(admin_sockets[GG_MAX_ADMIN_SOCKETS + i].socket, buf, count, 0);
            admin_sockets[GG_MAX_ADMIN_SOCKETS + i].status = GG_STATUS_TUN_INIT_REQ;
          }
        }
      }
      for (i = 0; i < GG_MAX_USER_SOCKETS; i++) {
        if (FD_ISSET(user_sockets[i].out_socket, &wfd) && user_sockets[i].status == GG_STATUS_USER_CONNECT_IN_PROGRESS && (user_sockets[i].type == GG_TYPE_USER_OUT || user_sockets[i].type == GG_TYPE_USER_BOTH)) {
          error = 0;
          if (getsockopt(user_sockets[i].out_socket, SOL_SOCKET, SO_ERROR, &error, &error_len) < 0 || error != 0) {
            switch(error) {
            // fill up with debug data
//XXXXXXX TODO NEXT
            default:
//fprintf(stderr, "DEBUG: socket connect failure no %d\n", error);
              user_sockets[i].status = GG_STATUS_USER_CONNECT_REFUSED;
              j = GG_CMD_USER_REP_CONNECT_REFUSED;
            }
            count = 6;
            buf[0] = j;
            buf[1] = 0;
            *si = user_sockets[i].id;
            *sl = count;
            send(user_sockets[i].in_socket, buf, count, 0);
            memset(&user_sockets[i], 0, sizeof(gg_struct_user_sockets));
          } else {
            j = user_sockets[i].in_socket; // keep the tunnel socket as we will overwrite it soon!
            if (user_sockets[i].type == GG_TYPE_USER_IN || user_sockets[i].type == GG_TYPE_USER_BOTH) {
              if (user_sockets[i].proto == GG_TCP) {
                user_sockets[i].status = GG_STATUS_USER_LISTEN;
                user_sockets[i].in_socket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
              } else {
                user_sockets[i].status = GG_STATUS_USER_CONNECT_OK;
                user_sockets[i].in_socket = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
              }
              gg_addr.sin_port = 0;
              gg_addr.sin_family = AF_INET;
              gg_addr.sin_addr.s_addr = htonl(INADDR_ANY);
              gg_init_socket(user_sockets[i].in_socket);
              bind(user_sockets[i].in_socket, (struct sockaddr *) &gg_addr, sizeof(gg_addr));
              if (user_sockets[i].proto == GG_TCP)
                listen(user_sockets[i].in_socket, 1);
              gg_init_socket(user_sockets[i].in_socket);
            } else {
              user_sockets[i].status = GG_STATUS_USER_CONNECT_OK;
            }
            count = 6;
            buf[0] = GG_CMD_USER_REP_CONNECT_OK;
            *si = user_sockets[i].id;
            *sl = count;
            send(j, buf, count, 0);
          }
        }
      }
    }

    /* was any data received on any connection? */
    FD_ZERO(&rfd);
    maxfd = 0;
    count = 0;
    tv.tv_sec = 0;
    tv.tv_usec = 100000;   // select waits for 100ms
    for (i = 0; i < GG_MAX_ADMIN_SOCKETS + GG_MAX_TUNNEL_SOCKETS; i++) {
      if (admin_sockets[i].status >= GG_STATUS_TUN_ACCEPTED && admin_sockets[i].socket > 0) {
        count++;
        FD_SET(admin_sockets[i].socket, &rfd);
        if (admin_sockets[i].socket > maxfd)
          maxfd = admin_sockets[i].socket;
//printf("admin socket %d recv: %d\n", i, admin_sockets[i].socket);
      }
    }
    for (i = 0; i < GG_MAX_USER_SOCKETS; i++) {
      if (user_sockets[i].status >= GG_STATUS_USER_CONNECT_ACCEPTED) {
        if ((user_sockets[i].type == GG_TYPE_USER_IN || user_sockets[i].type == GG_TYPE_USER_BOTH) && user_sockets[i].in_socket > 0) {
          count++;
          FD_SET(user_sockets[i].in_socket, &rfd);
          if (user_sockets[i].in_socket > maxfd)
            maxfd = user_sockets[i].in_socket;
//printf("user socket in/both: %d\n", user_sockets[i].in_socket);
        }
        if ((user_sockets[i].type == GG_TYPE_USER_OUT || user_sockets[i].type == GG_TYPE_USER_BOTH) && user_sockets[i].out_socket > 0) {
          count++;
          FD_SET(user_sockets[i].out_socket, &rfd);
          if (user_sockets[i].out_socket > maxfd)
            maxfd = user_sockets[i].out_socket;
//printf("user socket out/both: %d\n", user_sockets[i].out_socket);
        }
      }
    }
    efd = rfd;
    res = select(maxfd + 1, &rfd, NULL, &efd, &tv);

    /* yes theres data if res > 0 - so process it */
    if (res > 0) {

// XXX TODO implement: opt.master check

      for (i = 0; i < GG_MAX_ADMIN_SOCKETS + GG_MAX_TUNNEL_SOCKETS; i++) {
        if (FD_ISSET(admin_sockets[i].socket, &rfd)) {
          memset(buf, 0, sizeof(curr_buf));
          errno = 0;
          if ((curr_count = recv(admin_sockets[i].socket, curr_buf, sizeof(curr_buf) - 1, 0)) < 1) {
            if (opt.verbose > 1)
              fprintf(stderr, "Info: Admin connection closed\n");
            shutdown(admin_sockets[i].socket, SHUT_RDWR);
            close(admin_sockets[i].socket);
            memset(&admin_sockets[i], 0, sizeof(gg_struct_admin_sockets));
          } else {
#ifdef DEBUG
fprintf(stderr,"NEW\n");
#endif
if (i > GG_MAX_ADMIN_SOCKETS)
  printf("tunnel data\n");
            total_count = curr_count;
            curr_buf[curr_count] = 0;
            while (curr_count >=  6) {
             memcpy(buf, curr_buf + total_count - curr_count, curr_count);
             count = curr_count;
#ifdef DEBUG
fprintf(stderr,"curr_count: %d\n", curr_count);
fprintf(stderr,"data %d %d  %d %d  %d %d  %d %d\n",buf[0],buf[1],buf[2],buf[3],buf[4],buf[5],buf[6],buf[7]);
usleep(100000);
#endif
             switch(admin_sockets[i].status) {
              case GG_STATUS_TUN_ACCEPTED:
                if (memcmp(buf, GG_INIT_ADMIN_STRING, 4) == 0 || memcmp(buf, GG_INIT_TUNNEL_STRING, 4) == 0) {
                  if (memcmp(buf, GG_INIT_TUNNEL_STRING, 4) == 0 || i > GG_MAX_ADMIN_SOCKETS)
                    admin_sockets[i].type = GG_TYPE_ADMIN_TUN;
                  count = 8;
                  stmp = (unsigned short int *) &buf[6];
                  *sl = count;
                  admin_sockets[i].his_id = *stmp;
                  admin_sockets[i].my_id = (time(NULL) + getpid() + *stmp) % 65536;
                  *stmp = admin_sockets[i].my_id;
                  admin_sockets[i].my_id++;
                  send(admin_sockets[i].socket, buf, count, 0);
                  admin_sockets[i].status = GG_STATUS_TUN_OK;
                  fprintf(stderr, "Info: Admin connection successfully initiated\n");
                } else {
                  fprintf(stderr, "Error: Invalid INIT on admin connection received - connect from unknown software detected\n");
                  shutdown(admin_sockets[i].socket, SHUT_RDWR);
                  close(admin_sockets[i].socket);
                  memset(&admin_sockets[i], 0, sizeof(gg_struct_admin_sockets));
                }
                curr_count = 0;
              break;
              case GG_STATUS_TUN_INIT_REQ:
                stmp = (unsigned short int *) &buf[6];
                admin_sockets[i].his_id = *stmp;
                curr_count = 0;
              break;
//              case GG_STATUS_TUN_INIT_REP:
//                //
//                curr_count = 0;
//              break;
              case GG_STATUS_TUN_OK:
                if (buf[1] == 0) {
                  switch(buf[0]) {
                    case GG_CMD_USER_REQ_RESOLVE:
                      switch(buf[6]) {
                        case 1:
                          fprintf(stderr, "Info: Request id %d to resolv name: %s - ", *si, (char*)buf+7);
                          if (*sl >= 6 && *sl <= curr_count)
                            curr_count = curr_count - *sl;
                          else {
                            fprintf(stderr, "Error: invalid size\n");
                            curr_count = 0;
                          }
                          if ((he = gethostbyname((char*)buf+7)) == NULL) {
                            count = 6;
                            buf[0] = GG_CMD_USER_REP_RESOLVE_FAIL;
                            fprintf(stderr, "failed\n");
                          } else {
                            count = 10;
                            buf[0] = GG_CMD_USER_REP_RESOLVE_OK;
                            memcpy(buf + 6, he->h_addr, 4);
                            fprintf(stderr, "success\n");
                          }
                          *sl = count;
                          send(admin_sockets[i].socket, buf, count, 0);
                        break;
                        case 2:
                          fprintf(stderr, "Info: Request id %d to resolv addr: %d.%d.%d.%d - ", *si, buf[7],buf[8],buf[9],buf[10]);
                          if (*sl >= 6 && *sl <= curr_count)
                            curr_count = curr_count - *sl;
                          else {
                            fprintf(stderr, "Error: invalid size\n");
                            curr_count = 0;
                          }
                          if ((he = gethostbyaddr((char*)buf+7, 4, AF_INET)) == NULL) {
                            count = 6;
                            buf[0] = GG_CMD_USER_REP_RESOLVE_FAIL;
                            fprintf(stderr, "failed\n");
                          } else {
                            buf[0] = GG_CMD_USER_REP_RESOLVE_OK;
                            buf[250] = 0;
                            count = 6 + strlen(he->h_name) + 1;
                            strcpy(buf + 6, he->h_name);
                            fprintf(stderr, "success\n");
                          }
                          *sl = count;
                          send(admin_sockets[i].socket, buf, count, 0);
                        break;
                        default:
                          fprintf(stderr, "Error: unknown resolv value\n");
fprintf(stderr,"xxxcount: %d  curr_count: %d    %d %d %d %d\n",count, curr_count, buf[0],buf[1],buf[2],buf[3]);
                          curr_count = curr_count - 6;
                      }
                      //
                    break;
                    case GG_CMD_USER_REQ_CONNECT:
                      if (*sl >= 6 && *sl <= curr_count)
                        curr_count = curr_count - *sl;
                      else {
                        fprintf(stderr, "Error: invalid size\n");
                        curr_count = 0;
                      }
                      j = 0;
                      while (j < GG_MAX_USER_SOCKETS && user_sockets[j].status != 0)
                        j++;
                      if (user_sockets[j].status != 0) {
                        count = 6;
                        buf[0] = GG_CMD_USER_REP_CONNECT_TUNNEL_ERR;
                        buf[1] = 0;
                        *sl = count;
                        send(admin_sockets[i].socket, buf, count, 0);
                      } else {
                        // structure:
                        // 0:cmd, 1:0, 2-3: id, 4-7: ip, 8-9: port, 10: proto
                        user_sockets[j].in_socket = admin_sockets[i].socket;
                        if (i > GG_MAX_ADMIN_SOCKETS || admin_sockets[i].type == GG_TYPE_ADMIN_TUN)
                          user_sockets[j].type = GG_TYPE_USER_OUT;
                        else
                          user_sockets[j].type = GG_TYPE_USER_BOTH;
                        user_sockets[j].proto = buf[12];
                        if (user_sockets[j].proto == GG_TCP)
                          user_sockets[j].out_socket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
                        else if (user_sockets[j].proto == GG_UDP)
                          user_sockets[j].out_socket = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
                        else
                          fprintf(stderr, "Error: Invalid connect call (unkown protocol)\n");
                        if (user_sockets[j].proto == GG_TCP || user_sockets[j].proto == GG_UDP) {
                          user_sockets[j].id = *si;
                          stmp = (unsigned short int *) &buf[10];
                          gg_addr.sin_port = *stmp;
                          gg_addr.sin_family = AF_INET;
                          memcpy(&gg_addr.sin_addr.s_addr, &buf[6], 4);
                          errno = 0;
                          target_addr.s_addr = gg_addr.sin_addr.s_addr;
                          fprintf(stderr, "Info: Connect id %d to %s:%d/%s - ", *si, inet_ntoa(target_addr), ntohs(gg_addr.sin_port), buf[12] == GG_TCP ? "tcp" : "udp");
                          errno = 0;
                          if ((res = connect(user_sockets[j].out_socket, (struct sockaddr *) &gg_addr, sizeof(gg_addr))) >= 0) {
                            fprintf(stderr, "success\n");
                            res = user_sockets[j].in_socket; // keep the tunnel socket as we will overwrite it soon!
                            if (user_sockets[j].type == GG_TYPE_USER_IN || user_sockets[j].type == GG_TYPE_USER_BOTH) {
                              if (user_sockets[j].proto == GG_TCP) {
                                user_sockets[j].in_socket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
                              } else {
                                user_sockets[j].in_socket = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
                              }
                              count = 8;
                              *sl = count;
                              gg_addr.sin_port = 0;
                              gg_addr.sin_family = AF_INET;
                              gg_addr.sin_addr.s_addr = htonl(INADDR_ANY);
                              gg_init_socket(user_sockets[j].in_socket);
                              bind(user_sockets[j].in_socket, (struct sockaddr *) &gg_addr, sizeof(gg_addr));
                              stmp = (unsigned short int *) &buf[6];
                              getsockname(user_sockets[j].in_socket, (struct sockaddr *) &gg_addr, &gg_addr_len);
                              *stmp = gg_addr.sin_port;
                              // report local listen port
                              fprintf(stderr, "Info: listen on port %d\n", ntohs(*stmp));
                              if (user_sockets[j].proto == GG_TCP) {
                                listen(user_sockets[j].in_socket, 1);
                                user_sockets[j].status = GG_STATUS_USER_LISTEN;
                              } else {
                                user_sockets[j].status = GG_STATUS_USER_CONNECT_OK;
                                gg_addr.sin_addr.s_addr = admin_sockets[i].his_ip;
                                stmp = (unsigned short int *) &buf[13];
                                gg_addr.sin_port = *stmp;
                                connect(user_sockets[j].in_socket, (struct sockaddr *) &gg_addr, sizeof(gg_addr));
                              }
                              gg_init_socket(user_sockets[j].in_socket);
                            } else {
                              user_sockets[j].status = GG_STATUS_USER_CONNECT_OK;
                              count = 6;
                              *sl = count;
                            }
                            buf[0] = GG_CMD_USER_REP_CONNECT_OK;
                            *si = user_sockets[j].id;
                            send(res, buf, count, 0);
                          } else {
                            if (errno == EINPROGRESS) {
                              fprintf(stderr, "in progress\n");
                              user_sockets[j].status = GG_STATUS_USER_CONNECT_IN_PROGRESS;
                            } else {
                              fprintf(stderr, "failed\n");
                              switch(errno) {
                              // fill up with debug data
                              case ENETUNREACH:
                                user_sockets[j].status = GG_STATUS_USER_CONNECT_UNREACHABLE;
                                res = GG_CMD_USER_REP_CONNECT_UNREACHABLE;
                              break;
                              case ETIMEDOUT:
                                user_sockets[j].status = GG_STATUS_USER_CONNECT_TIMEOUT;
                                res = GG_CMD_USER_REP_CONNECT_TIMEOUT;
                              break;
                              default:
//fprintf(stderr, "DEBUG: socket connect failure no %d\n", errno);
                                user_sockets[j].status = GG_STATUS_USER_CONNECT_REFUSED;
                                res = GG_CMD_USER_REP_CONNECT_REFUSED;
                              }
                              count = 6;
                              buf[0] = res;
                              buf[1] = 0;
                              *sl = count;
                              send(user_sockets[j].in_socket, buf, count, 0);
                              memset(&user_sockets[j], 0, sizeof(gg_struct_user_sockets));
                            }
                          }
                        }
                      }
                    break;
//                    case GG_CMD_ADMIN_CLOSE:
//                      curr_count = curr_count - XXX;
//                    break;
                    case GG_CMD_USER_REQ_CLOSE:
                      if (*sl >= 6 && *sl <= curr_count)
                        curr_count = curr_count - *sl;
                      else {
                        fprintf(stderr, "Error: invalid size\n");
                        curr_count = 0;
                      }
                      count = 6;
                      *sl = count;
                      j = 0;
                      while (j < GG_MAX_USER_SOCKETS && (user_sockets[j].id != *si || user_sockets[j].in_socket != admin_sockets[i].socket))
//{ if (user_sockets[j].id > 0) printf("IN %d -> %d > %d\n", j, user_sockets[j].id, user_sockets[j].id_out);
                        j++;
//}
                      if (user_sockets[j].id == *si) {
                        if (user_sockets[j].type == GG_TYPE_USER_IN || user_sockets[j].type == GG_TYPE_USER_BOTH) {
                          close(user_sockets[j].in_socket);
                          fprintf(stderr, "Info: Executed close command on listening port\n");
                        } else {
                          *si = user_sockets[j].id_out;
                          send(user_sockets[j].out_socket, buf, count, 0);
//printf("send in close cmd to tunnel with id %d\n", *si);
                        }
                        if (user_sockets[j].type == GG_TYPE_USER_OUT || user_sockets[j].type == GG_TYPE_USER_BOTH) {
                          close(user_sockets[j].out_socket);
                          fprintf(stderr, "Info: Executed close command on connect port\n");
                        } else {
                          *si = user_sockets[j].id_out;
                          send(user_sockets[j].out_socket, buf, count, 0);
//printf("send in close cmd to tunnel\n");
                        }
                        memset(&user_sockets[j], 0, sizeof(gg_struct_user_sockets));
                      } else
                        j = 0;
                        while (j < GG_MAX_USER_SOCKETS && (user_sockets[j].id_out != *si || user_sockets[j].out_socket != admin_sockets[i].socket))
//{ if (user_sockets[j].id_out > 0) printf("OUT %d -> %d < %d\n", j, user_sockets[j].id_out, user_sockets[j].id);
                          j++;
//}
                        if (user_sockets[j].id_out == *si) {
                          if (user_sockets[j].type == GG_TYPE_USER_IN || user_sockets[j].type == GG_TYPE_USER_BOTH) {
                            close(user_sockets[j].in_socket);
                            fprintf(stderr, "Info: Executed close command on listening port\n");
                          } else {
                            *si = user_sockets[j].id;
                            send(user_sockets[j].in_socket, buf, count, 0);
//printf("send in close cmd to tunnel\n");
                          }
                          if (user_sockets[j].type == GG_TYPE_USER_OUT || user_sockets[j].type == GG_TYPE_USER_BOTH) {
                            close(user_sockets[j].out_socket);
                            fprintf(stderr, "Info: Executed close command on connect port\n");
                          } else {
                            *si = user_sockets[j].id;
                            send(user_sockets[j].in_socket, buf, count, 0);
//printf("send in close cmd to tunnel\n");
                          }
                          memset(&user_sockets[j], 0, sizeof(gg_struct_user_sockets));
                        } else
                          fprintf(stderr, "Warning: Request to close connection NOT fulfilled, id %d was not found\n", *si);

//HERETODO
                    break;
//                    case GG_CMD_ADMIN_LIST:
//                    curr_count = curr_count - XXX;
                      //
//                    break;
                    case GG_CMD_ADMIN_SHUTDOWN:
//                    curr_count = curr_count - XXX;
                      fprintf(stderr, "shutting down\n");
                      exit(0);
                    break;
                    case GG_CMD_ADMIN_DELETE:
//                    curr_count = curr_count - XXX;
                      //
                    break;
                    case GG_CMD_ADMIN_SHELL:
//                    curr_count = curr_count - XXX;
                      //
                    break;
                    case GG_CMD_ADMIN_EXEC:
//                    curr_count = curr_count - XXX;
                      //
                    break;
                    default:
                      switch(buf[0]) {
                        case GG_CMD_USER_REP_CONNECT_OK:
                          j = 0;
                          while (j < GG_MAX_USER_SOCKETS && (*si != user_sockets[j].id_out || user_sockets[j].out_socket != admin_sockets[i].socket || user_sockets[j].status != GG_STATUS_USER_WAIT4TUNNEL))
                            j++;
                          if (*si == user_sockets[j].id_out && user_sockets[j].out_socket == admin_sockets[i].socket && user_sockets[j].status == GG_STATUS_USER_WAIT4TUNNEL) {
#ifdef DEBUG
  fprintf(stderr, "yes! target tunnel told us connection was successful!\n");
#endif
                            if (*sl >= 6 && *sl <= curr_count)
                              curr_count = curr_count - *sl;
                            else {
                              fprintf(stderr, "Error: invalid size\n");
                              curr_count = 0;
                            }
                            res = user_sockets[j].in_socket; // keep the tunnel socket as we will overwrite it soon!
                            if (user_sockets[j].proto == GG_TCP) {
                              user_sockets[j].in_socket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
                            } else {
                              user_sockets[j].in_socket = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
                            }
                            count = 8;
                            *sl = count;
                            gg_addr.sin_port = 0;
                            gg_addr.sin_family = AF_INET;
                            gg_addr.sin_addr.s_addr = htonl(INADDR_ANY);
if (user_sockets[j].proto != GG_TCP)
                            gg_init_socket(user_sockets[j].in_socket);
                            bind(user_sockets[j].in_socket, (struct sockaddr *) &gg_addr, sizeof(gg_addr));
                            stmp = (unsigned short int *) &buf[6];
                            getsockname(user_sockets[j].in_socket, (struct sockaddr *) &gg_addr, &gg_addr_len);
                            *stmp = gg_addr.sin_port;
                            // report local listen port
                            fprintf(stderr, "Info: listen on port %d\n", ntohs(*stmp));
                            if (user_sockets[j].proto == GG_TCP) {
                              listen(user_sockets[j].in_socket, 1);
                              user_sockets[j].status = GG_STATUS_USER_LISTEN;
                            } else {
                              user_sockets[j].status = GG_STATUS_USER_CONNECT_OK;
                              gg_addr.sin_addr.s_addr = admin_sockets[i].his_ip;
                              stmp = (unsigned short int *) &buf[13];
                              gg_addr.sin_port = *stmp;
                              connect(user_sockets[j].in_socket, (struct sockaddr *) &gg_addr, sizeof(gg_addr));
                            }
                            buf[0] = GG_CMD_USER_REP_CONNECT_OK;
                            *si = user_sockets[j].id;
                            send(res, buf, count, 0);

// XXX WORKAROUND BUG TODO
// wir muessen auf den connect warten!!! ansonsten crash wenn target
// daten sendet, und accept() noch nicht vollzogen!!
// workaround, eine queue waere besser
                            if (user_sockets[j].proto == GG_TCP) {
                              if ((res = accept(user_sockets[j].in_socket, NULL, NULL)) > 0) {
                                gg_init_socket(res);
                                close(user_sockets[j].in_socket); // no more listening required
                                user_sockets[j].in_socket = res;
                                user_sockets[j].status = GG_STATUS_USER_CONNECT_OK;
                              } else {
                                perror("");
                                fprintf(stderr, "Error: going down (errno %d, type %d, proto %d)\n", errno, user_sockets[j].type, user_sockets[j].proto);
                                exit(-1);
                              }
                            }

                            gg_init_socket(user_sockets[j].in_socket);
                            user_sockets[j].type = GG_TYPE_USER_IN;
                            break;
                          }
                        case GG_CMD_USER_REP_RESOLVE_OK:
                        case GG_CMD_USER_REP_RESOLVE_FAIL:
                        case GG_CMD_USER_REP_RESOLVE_TUNNEL_ERR:
                        case GG_CMD_USER_REP_CONNECT_TIMEOUT:
                        case GG_CMD_USER_REP_CONNECT_REFUSED:
                        case GG_CMD_USER_REP_CONNECT_UNREACHABLE:
                        case GG_CMD_USER_REP_CONNECT_TUNNEL_ERR:
                        case GG_CMD_ADMIN_TUNNEL_CONNECT_ERR:
                        case GG_CMD_USER_DATA:
                          j = 0;
                          while (j < GG_MAX_USER_SOCKETS && (
                                   ((*si != user_sockets[j].id_out || user_sockets[j].out_socket != admin_sockets[i].socket))
                                  &&
                                   (buf[0] == GG_CMD_USER_DATA && (*si != user_sockets[j].id || user_sockets[j].in_socket != admin_sockets[i].socket))
                                ))
//{ if (user_sockets[j].id != 0 || user_sockets[j].id_out != 0) printf("%d -> id: %d  id_out: %d -> admin_socket %d|in_socket %d|out_socket %d\n", j, user_sockets[j].id, user_sockets[j].id_out,admin_sockets[i].socket,user_sockets[j].in_socket,user_sockets[j].out_socket);
                            j++;
//}
                          if (
                                   ((*si != user_sockets[j].id_out || user_sockets[j].out_socket != admin_sockets[i].socket))
                                  &&
                                   (buf[0] == GG_CMD_USER_DATA && (*si != user_sockets[j].id || user_sockets[j].in_socket != admin_sockets[i].socket))
                             ) {
                            fprintf(stderr, "Warning: can not find id %d in user_socket by tunnel response\n", *si);
                          } else {
#ifdef DEBUG
printf("DATA CONNECTION FOUND! (type %d)\n", user_sockets[j].type);
#endif
                            if (buf[0] == GG_CMD_USER_DATA) {
                              if (user_sockets[j].type == GG_TYPE_USER_IN)
                                send(user_sockets[j].in_socket, buf + 6, *sl - 6, 0);
                              if (user_sockets[j].type == GG_TYPE_USER_OUT)
                                send(user_sockets[j].out_socket, buf + 6, *sl - 6, 0);
                              if (user_sockets[j].type == GG_TYPE_USER_TUN) {
                                if (*si == user_sockets[j].id_out) {
                                  *si = user_sockets[j].id;
                                  send(user_sockets[j].in_socket, buf, *sl, 0);
                                } else {
                                  *si = user_sockets[j].id_out;
                                  send(user_sockets[j].out_socket, buf, *sl, 0);
                                }
                              }
                            } else {
                              *si = user_sockets[j].id;
                              send(user_sockets[j].in_socket, buf, *sl, 0);
                            }
                          }
                          if (buf[0] == GG_CMD_USER_REP_CONNECT_TUNNEL_ERR)
                            buf[0] = GG_CMD_USER_REP_CONNECT_TUNNEL_ERR;
                          if (buf[0] != GG_CMD_USER_REP_CONNECT_OK && buf[0] != GG_CMD_USER_DATA)
                            memset(&user_sockets[j], 0, sizeof(gg_struct_user_sockets));
                          if (*sl >= 6 && *sl <= curr_count)
                            curr_count = curr_count - *sl;
                          else {
                            fprintf(stderr, "Error: invalid size\n");
                            curr_count = 0;
                          }
                        break;
                        default:
                          fprintf(stderr, "Warning: command type is invalid on a tunnel proxy! (%d) [BUG!]\n", buf[0]);
                          curr_count = curr_count - 6;
                      }
                  }
                } else {
                  ptr = index(buf+buf[1], ':');
                  if (ptr != NULL)
                    ptr = index(ptr + 1, ':');
                  errno = 0;
                  if (*sl >= 6 && *sl <= curr_count && buf[1] <= curr_count && ptr != NULL) {
                    curr_count = curr_count - *sl;
                    ptr2 = malloc((unsigned int)ptr - ((unsigned int)buf + buf[1]) + 1);
                    memcpy(ptr2, (char *)(buf + buf[1]), (unsigned int)ptr - ((unsigned int)buf + buf[1]));
                    ptr2[(unsigned int)ptr - ((unsigned int)buf + buf[1])] = 0;
#ifdef DEBUG
                    printf("tunnelid: %s\n", ptr2);
#endif
                    l = GG_MAX_ADMIN_SOCKETS;
                    while (l < (GG_MAX_ADMIN_SOCKETS + GG_MAX_TUNNEL_SOCKETS) && (admin_sockets[l].status != GG_STATUS_TUN_OK || ptr2 == NULL || admin_sockets[l].tunnel_id == NULL || strcmp(admin_sockets[l].tunnel_id, ptr2) != 0))
{
                      l++;
}
                    if (admin_sockets[l].status != GG_STATUS_TUN_OK || ptr2 == NULL || admin_sockets[l].tunnel_id == NULL || strcmp(admin_sockets[l].tunnel_id, ptr2) != 0) {
#ifdef DEBUG
                      printf("DEBUG: no tunnel connection yet\n");
#endif
                      l = GG_MAX_ADMIN_SOCKETS;
                      while (l < (GG_MAX_ADMIN_SOCKETS + GG_MAX_TUNNEL_SOCKETS) && admin_sockets[l].status != 0)
                        l++;
                      if (admin_sockets[l].status != 0) {
                        count = 6;
                        buf[0] = GG_CMD_ADMIN_TUNNEL_CONNECT_ERR;
                        buf[1] = 0;
                        *sl = count;
                        send(admin_sockets[i].socket, buf, count, 0);
                        fprintf(stderr, "Error: no free gg socket to connect to tunnel\n");
                      } else {
                        ptr3 = malloc(*sl - buf[1] + 1);
                        memcpy(ptr3, (char *)(buf + buf[1]), *sl - buf[1] + 1);
                        ptr = index(ptr3, ':');
                        *ptr = 0;
                        ptr++;
                        inet_aton(ptr3, &target_addr);
                        ptr1 = index(ptr, ':');
                        *ptr1 = 0;
                        ptr1++;
                        gg_addr.sin_port = htons(atoi(ptr));
                        ptr = index(ptr1, '>');
                        if (ptr != NULL)
                          *ptr = 0;
                        admin_sockets[l].pass = malloc(strlen(ptr1) + 1);
                        strcpy(admin_sockets[l].pass, ptr1);
                        free(ptr3);
                        gg_addr.sin_family = AF_INET;
                        gg_addr.sin_addr.s_addr = target_addr.s_addr;
                        admin_sockets[l].my_id = (time(NULL) + getpid() + getuid()) % 65536;
                        admin_sockets[l].socket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
                        ptr3 = malloc(16);
                        memcpy(ptr3, GG_INIT_TUNNEL_STRING, 4);
                        stmp = (unsigned short int *) ptr3 + 4;
                        *stmp = 8;
                        stmp = (unsigned short int *) ptr3 + 6;
                        *stmp = admin_sockets[l].my_id;
                        admin_sockets[l].my_id++;
                        errno = 0;
                        if (connect(admin_sockets[l].socket, (struct sockaddr *) &gg_addr, sizeof(gg_addr)) < 0) {
                          // XXX some routine to send an error message
                          count = 6;
                          buf[0] = GG_CMD_ADMIN_TUNNEL_CONNECT_ERR;
                          buf[1] = 0;
                          *sl = count;
                          send(admin_sockets[i].socket, buf, count, 0);
                          fprintf(stderr, "Error - connect to next tunnel proxy failed\n");
                        } else {
#ifdef DEBUG
                          fprintf(stderr, "Info: Connected to tunnel, initiating ...\n");
#endif
                          send(admin_sockets[l].socket, ptr3, 8, 0);
                          if (recv(admin_sockets[l].socket, ptr3, 8, 0) < 1) {
                            count = 6;
                            buf[0] = GG_CMD_ADMIN_TUNNEL_CONNECT_ERR;
                            buf[1] = 0;
                            *sl = count;
                            send(admin_sockets[i].socket, buf, count, 0);
                            fprintf(stderr, "Error - recv from next tunnel proxy failed\n");
                          } else {
                            fprintf(stderr, "Info: Init to next tunnel completed\n");
                            gg_init_socket(admin_sockets[l].socket);
                            admin_sockets[l].status = GG_STATUS_TUN_OK;
                            admin_sockets[l].his_id = *stmp;
                            admin_sockets[l].tunnel_id = ptr2;
                          }
                        }
                      }
                    } else {
                      free(ptr2);
#ifdef DEBUG
                        fprintf(stderr, "DEBUG: using existing tunnel connection\n");
#endif
                    }
                    ptr = index(buf+buf[1], '>');
                    if (ptr != NULL) {
                      ptr++;
                      *sl = buf[1] + strlen(ptr) + 1;
                      memcpy(buf + buf[1], ptr, strlen(ptr) + 1);
                      printf("rest of tunnelid: %s (strlen %d) (gesamt len %d start at %d)\n", buf + buf[1], strlen(buf + buf[1]), *sl, buf[1]);
                    } else {
                      *sl = buf[1];
                      buf[1] = 0;
                    }
                    j = 0;
                    while (j < GG_MAX_USER_SOCKETS && user_sockets[j].status != 0)
                      j++;
                    if (user_sockets[j].status != 0) {
                      count = 6;
                      buf[0] = GG_CMD_ADMIN_TUNNEL_CONNECT_ERR;
                      buf[1] = 0;
                      *sl = count;
                      send(admin_sockets[i].socket, buf, count, 0);
                      fprintf(stderr, "Error: No empty gg user socket left\n");
                      errno = 1;
                    } else {
                      user_sockets[j].proto = buf[12]; // might be wrong but we dont care
                      user_sockets[j].id = *si;
                      user_sockets[j].in_socket = admin_sockets[i].socket;
                      user_sockets[j].out_socket = admin_sockets[l].socket;
                      if (i > GG_MAX_ADMIN_SOCKETS || admin_sockets[i].type == GG_TYPE_ADMIN_TUN) {
                        user_sockets[j].status = GG_STATUS_USER_TUNNEL;
                        user_sockets[j].type = GG_TYPE_USER_TUN;
                      } else {
                        user_sockets[j].status = GG_STATUS_USER_WAIT4TUNNEL;
                        user_sockets[j].type = GG_TYPE_USER_IN_WAIT4TUNNEL;
                      }
                      *si = admin_sockets[l].my_id;
                      admin_sockets[l].my_id++;
                      user_sockets[j].id_out = *si;
                      send(user_sockets[j].out_socket, buf, *sl, 0);
                    }
                  } else {
                    fprintf(stderr, "Error: invalid size of tunnel data\n");
                    curr_count = 0;
                  }
                }
              break;
              default:
                fprintf(stderr, "Warning: status of socket invalid! (%d) [BUG!]\n", admin_sockets[i].status);
             }
#ifdef DEBUG
fprintf(stderr, "curr_count at end of while: %d\n", curr_count);
#endif
            }
          }
        }
      }
      for (i = 0; i < GG_MAX_USER_SOCKETS; i++) {
        if (FD_ISSET(user_sockets[i].in_socket, &rfd) && (user_sockets[i].type == GG_TYPE_USER_IN || user_sockets[i].type == GG_TYPE_USER_BOTH)) {
          memset(buf, 0, sizeof(buf));
          errno = 0;
          error = 0;
          if ((count = recv(user_sockets[i].in_socket, buf + 6, sizeof(buf) - 6, 0)) < 1) {
//            if (errno != 0 || count < 0) {
              if (opt.verbose > 1)
                fprintf(stderr, "Info: User connection closed (errorno %d)\n", errno);
              shutdown(user_sockets[i].in_socket, SHUT_RDWR);
              close(user_sockets[i].in_socket);
              if (user_sockets[i].type == GG_TYPE_USER_BOTH) {
                close(user_sockets[i].out_socket);
              } else {
                count = 6;
                buf[0] = GG_CMD_USER_REQ_CLOSE;
                buf[1] = 0;
                *si = user_sockets[i].id_out;
                *sl = count;
                send(user_sockets[i].out_socket, buf, count, 0);
              }
              memset(&user_sockets[i], 0, sizeof(gg_struct_user_sockets));
//            }
          } else {
//            printf("FROM IN DATA: %d - %s\n", count, buf + 6);
            if (user_sockets[i].type == GG_TYPE_USER_BOTH) {
              send(user_sockets[i].out_socket, buf + 6, count, 0);
            } else {
              buf[0] = GG_CMD_USER_DATA;
              buf[1] = 0;
              count = count + 6;
              *si = user_sockets[i].id_out;
              *sl = count;
              send(user_sockets[i].out_socket, buf, count, 0);
            }
          }
        }
        if (FD_ISSET(user_sockets[i].out_socket, &rfd) && (user_sockets[i].type == GG_TYPE_USER_OUT || user_sockets[i].type == GG_TYPE_USER_BOTH)) {
          memset(buf, 0, sizeof(buf));
          errno = 0;
          if ((count = recv(user_sockets[i].out_socket, buf + 6, sizeof(buf) - 6, 0)) < 1) {
//            if (errno != 0 || count < 0) {
              if (opt.verbose > 1)
                fprintf(stderr, "Info: User connection closed\n");
              shutdown(user_sockets[i].out_socket, SHUT_RDWR);
              close(user_sockets[i].out_socket);
              if (user_sockets[i].type == GG_TYPE_USER_BOTH) {
                close(user_sockets[i].in_socket);
              } else {
                count = 6;
                buf[0] = GG_CMD_USER_REQ_CLOSE;
                buf[1] = 0;
                *si = user_sockets[i].id;
                *sl = count;
                send(user_sockets[i].in_socket, buf, count, 0);
              }
              memset(&user_sockets[i], 0, sizeof(gg_struct_user_sockets));
//            }
          } else {
//             printf("FROM OUT DATA: %d - %s\n", count, buf + 6);
            if (user_sockets[i].type == GG_TYPE_USER_BOTH) {
              send(user_sockets[i].in_socket, buf + 6, count, 0);
            } else {
              buf[0] = GG_CMD_USER_DATA;
              buf[1] = 0;
              count = count + 6;
              *sl = count;
              *si = user_sockets[i].id;
              send(user_sockets[i].in_socket, buf, count, 0);
            }
          }
        }
      }
    }
  }

  return 0;
}
