#!/bin/sh
test -z "$DEV" && DEV="$DEVICE"
test -z "$DEV" && DEV=eth0

dsniff=dsniff.$$.sniff
tcpd=tcpdump.$$.sniff

dsniff -i $DEV -n -m -s 2500 > $dsniff &
tcpdump -l -i $DEV -n -s 2500 -w $tcpd ip or arp &
