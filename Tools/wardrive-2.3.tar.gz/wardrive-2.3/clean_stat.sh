test -e "$1" || { echo -e "Syntax: $0 file\nwardrive stat file to clean"; exit 1; }

cat $1 | grep -v ' 00:00:00.0000? 00:00:00.0000? ' | grep -v '[EW?] 0 0 154 '
