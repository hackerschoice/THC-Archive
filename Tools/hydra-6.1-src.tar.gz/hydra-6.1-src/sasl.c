
#include "sasl.h"

void sasl_plain (char *result, char *login, char *pass) {
  if (2*strlen(login) + 3 + strlen(pass) < 250) {
    strcpy(result, login);
    strcpy(result +  strlen(login) + 1, login);
    strcpy(result + 2*strlen(login) + 2, pass);
    hydra_tobase64((unsigned char *) result, strlen(login)*2+strlen(pass)+2, sizeof(result));
  }
}

#ifdef LIBOPENSSLNEW

void sasl_cram_md5 (char *result, char *pass, char *challenge) {
  char ipad[64];
  char opad[64];
  unsigned char md5_raw[MD5_DIGEST_LENGTH];
  MD5_CTX md5c;
  int i;

  memset(ipad, 0, sizeof(ipad));
  memset(opad, 0, sizeof(opad));

  if (strlen(pass) >= 64) {
	 MD5_Init(&md5c);
	 MD5_Update(&md5c, pass, strlen(pass));
	 MD5_Final(md5_raw, &md5c);
	 memcpy(ipad, md5_raw, MD5_DIGEST_LENGTH);
	 memcpy(opad, md5_raw, MD5_DIGEST_LENGTH);
  } else {
	  strcpy(ipad, pass); // safe
	  strcpy(opad, pass); // safe
  }

  for (i = 0; i < 64; i++) {
	  ipad[i] ^= 0x36;
          opad[i] ^= 0x5c;
  }

  MD5_Init(&md5c);
  MD5_Update(&md5c, ipad, 64);
  MD5_Update(&md5c, challenge, strlen(challenge));
  MD5_Final(md5_raw, &md5c);

  MD5_Init(&md5c);
  MD5_Update(&md5c, opad, 64);
  MD5_Update(&md5c, md5_raw, MD5_DIGEST_LENGTH);
  MD5_Final(md5_raw, &md5c);	

  for(i = 0; i < MD5_DIGEST_LENGTH; i++) {
	  sprintf(result, "%02x", md5_raw[i]);
	  result +=2;
  }
}

void sasl_cram_sha1 (char *result, char *pass, char *challenge) {
  char ipad[64];
  char opad[64];
  unsigned char sha1_raw[SHA_DIGEST_LENGTH];
  SHA_CTX shac;
  int i;

  memset(ipad, 0, sizeof(ipad));
  memset(opad, 0, sizeof(opad));

  if (strlen(pass) >= 64) {
	  SHA1_Init(&shac);
	  SHA1_Update(&shac, pass, strlen(pass));
	  SHA1_Final(sha1_raw, &shac);
	  memcpy(ipad, sha1_raw, SHA_DIGEST_LENGTH);
	  memcpy(opad, sha1_raw, SHA_DIGEST_LENGTH);
  } else {
	  strcpy(ipad, pass); // safe
	  strcpy(opad, pass); // safe
  }

  for (i = 0; i < 64; i++) {
	  ipad[i] ^= 0x36;
          opad[i] ^= 0x5c;
  }

  SHA1_Init(&shac);
  SHA1_Update(&shac, ipad, 64);
  SHA1_Update(&shac, challenge, strlen(challenge));
  SHA1_Final(sha1_raw, &shac);

  SHA1_Init(&shac);
  SHA1_Update(&shac, opad, 64);
  SHA1_Update(&shac, sha1_raw, SHA_DIGEST_LENGTH);
  SHA1_Final(sha1_raw, &shac);	

  for(i = 0; i < SHA_DIGEST_LENGTH; i++) {
	  sprintf(result, "%02x", sha1_raw[i]);
	  result +=2;
  }
}

void sasl_cram_sha256 (char *result, char *pass, char *challenge) {
  char ipad[64];
  char opad[64];
  unsigned char sha256_raw[SHA256_DIGEST_LENGTH];
  SHA256_CTX sha256c;
  int i=0;

  memset(ipad, 0, sizeof(ipad));
  memset(opad, 0, sizeof(opad));

  if (strlen(pass) >= 64) {
	  SHA256_Init(&sha256c);
	  SHA256_Update(&sha256c, pass, strlen(pass));
	  SHA256_Final(sha256_raw, &sha256c);
	  memcpy(ipad, sha256_raw, SHA256_DIGEST_LENGTH);
	  memcpy(opad, sha256_raw, SHA256_DIGEST_LENGTH);
  } else {
	  strcpy(ipad, pass); // safe
	  strcpy(opad, pass); // safe
  }

  for (i = 0; i < 64; i++) {
	  ipad[i] ^= 0x36;
          opad[i] ^= 0x5c;
  }

  SHA256_Init(&sha256c);
  SHA256_Update(&sha256c, ipad, 64);
  SHA256_Update(&sha256c, challenge, strlen(challenge));
  SHA256_Final(sha256_raw, &sha256c);

  SHA256_Init(&sha256c);
  SHA256_Update(&sha256c, opad, 64);
  SHA256_Update(&sha256c, sha256_raw, SHA256_DIGEST_LENGTH);
  SHA256_Final(sha256_raw, &sha256c);	

  for(i = 0; i < SHA256_DIGEST_LENGTH; i++) {
	  sprintf(result, "%02x", sha256_raw[i]);
	  result +=2;
  }

}

void sasl_digest_md5 (char *result, char *login, char *pass, char *buffer, char *miscptr, char *type, char *webtarget, int webport, char *header) {
  char *pbuffer;
  int array_size=10;
  unsigned char response[MD5_DIGEST_LENGTH];
  char *array[array_size];
  char buffer2[500], buffer3[500], nonce[200], realm[50], algo[20];
  int i=0, ind=0, lastpos=0, currentpos=0, intq=0;
  MD5_CTX md5c;

  pbuffer=buffer;

  do{
    currentpos++;
    if (pbuffer[0] == '"') {
      if (intq == 0)
	intq=1;
      else {
	intq=0;
      }
    }
    if ((pbuffer[0] == ',') && (intq==0)) {
      array[ind]=malloc(currentpos);
      strncpy(array[ind],buffer+lastpos,currentpos-1);
      array[ind][currentpos-1]='\0';
      ind++;
      lastpos+=currentpos;
      currentpos=0;
    }
    pbuffer++;
  } while ((pbuffer[0] != '\0') && (ind<array_size));


  //save the latest one	
  array[ind]=malloc(currentpos+1);
  strncpy(array[ind],buffer+lastpos,currentpos+1);
  array[ind][currentpos]='\0';
  ind++;

  for(i=0;i<ind;i++) {
    if (strstr(array[i], "nonce=") != NULL) {
      strcpy(nonce, strstr(array[i], "nonce=")+strlen("nonce=")+1);
      nonce[strlen(nonce)-1]='\0';
    }
    if (strstr(array[i], "realm=") != NULL) {
      strcpy(realm, strstr(array[i], "realm=")+strlen("realm=")+1);
      realm[strlen(realm)-1]='\0';
    }
    if (strstr(array[i], "qop=") != NULL) {
      if ((strstr(array[i], "\"auth\"") == NULL) && (strstr(array[i], "\"auth,") == NULL) && (strstr(array[i], ",auth\"") == NULL)) {
	hydra_report(stderr, "Error: DIGEST-MD5 quality of protection is not supported\n");
	result=NULL;
	return;
      }
   }
   if (strstr(array[i], "algorithm=") != NULL) {
      strcpy(algo, strstr(array[i], "algorithm=")+strlen("algorithm="));
      if (algo[strlen(algo)-1]=='"')
	algo[strlen(algo)-1]='\0';
      if ((strstr(algo, "MD5") == NULL)&&(strstr(algo, "md5") == NULL))  {
	hydra_report(stderr, "Error: DIGEST-MD5 algorithm is not supported\n");
	result=NULL;
	return;
      }
   }

   free(array[i]);
  }

  //compute ha1
  //support for algo = MD5
  sprintf(buffer, "%s:%s:%s", login, realm, pass);
  MD5_Init(&md5c);
  MD5_Update(&md5c, buffer, strlen(buffer));
  MD5_Final(response, &md5c);

  //for MD5-sess
  if (strstr(algo, "5-sess")!=NULL) {
    sprintf(buffer, "%s:%s:%s", response ,nonce, "hydra");
    MD5_Init(&md5c);
    MD5_Update(&md5c, buffer, strlen(buffer));
    MD5_Final(response, &md5c);
  }

  pbuffer = buffer3;
  for(i = 0; i < MD5_DIGEST_LENGTH; i++) {
    sprintf(pbuffer, "%02x", response[i]);
    pbuffer +=2;
  }

  //compute ha2
  if (strstr(type, "proxy") != NULL) {
    sprintf(buffer, "%s:%s","HEAD", miscptr);
  } else {
    sprintf(buffer, "%s:%s",type, miscptr);
  }
  MD5_Init(&md5c);
  MD5_Update(&md5c, buffer, strlen(buffer));
  MD5_Final(response, &md5c);

  pbuffer = buffer2;
  for(i = 0; i < MD5_DIGEST_LENGTH; i++) {
    sprintf(pbuffer, "%02x", response[i]);
    pbuffer +=2;
  }

  //compute response
  sprintf(buffer, "%s:%s:%s:%s:%s", nonce,"00000001", "hydra", "auth", buffer2);
  MD5_Init(&md5c);
  MD5_Update(&md5c, buffer3, strlen(buffer3));
  MD5_Update(&md5c, ":", 1);
  MD5_Update(&md5c, buffer, strlen(buffer));
  MD5_Final(response, &md5c);
  pbuffer = buffer;
  for(i = 0; i < MD5_DIGEST_LENGTH; i++) {
    sprintf(pbuffer, "%02x", response[i]);
    pbuffer +=2;
  }

  //create the auth response
  if (strstr(type, "proxy") != NULL) {
  	sprintf(result, "HEAD %s HTTP/1.0\r\n%sProxy-Authorization: Digest username=\"%s\", realm=\"%s\", response=\"%s\", nonce=\"%s\", cnonce=\"hydra\", nc=00000001, algorithm=%s, qop=auth, uri=\"%s\"\r\nUser-Agent: Mozilla/4.0 (Hydra)\r\n%s\r\n", miscptr, webtarget, login, realm, buffer, nonce, algo, miscptr, header);
  } else {
    if ((strstr(miscptr, "imap/") != NULL)||(strstr(miscptr, "pop/") != NULL)||(strstr(miscptr, "smtp/") != NULL)) {
	  sprintf(result, "username=\"%s\",realm=\"%s\",nonce=\"%s\",cnonce=\"hydra\",nc=00000001,algorithm=%s,qop=\"auth\",digest-uri=\"%s\",response=%s", login, realm, nonce, algo, miscptr, buffer);
    } else {
      if (use_proxy == 1 && proxy_authentication != NULL)
	sprintf(result, "%s http://%s:%d%s HTTP/1.0\r\nHost: %s\r\nAuthorization: Digest username=\"%s\", realm=\"%s\", response=\"%s\", nonce=\"%s\", cnonce=\"hydra\", nc=00000001, algorithm=%s, qop=auth, uri=\"%s\"\r\nProxy-Authorization: Basic %s\r\nUser-Agent: Mozilla/4.0 (Hydra)\r\n%s\r\n",
		type, webtarget, webport, miscptr, webtarget, login, realm, buffer, nonce, algo, miscptr, proxy_authentication, header);
      else {
	if (use_proxy == 1)
	  sprintf(result, "%s http://%s:%d%s HTTP/1.0\r\nHost: %s\r\nAuthorization: Digest username=\"%s\", realm=\"%s\", response=\"%s\", nonce=\"%s\", cnonce=\"hydra\", nc=00000001, algorithm=%s, qop=auth, uri=\"%s\"\r\nUser-Agent: Mozilla/4.0 (Hydra)\r\n%s\r\n",
		type, webtarget, webport, miscptr, webtarget, login, realm, buffer, nonce, algo, miscptr, header);
	else
	  sprintf(result, "%s %s HTTP/1.0\r\nHost: %s\r\nAuthorization: Digest username=\"%s\", realm=\"%s\", response=\"%s\", nonce=\"%s\", cnonce=\"hydra\", nc=00000001, algorithm=%s, qop=auth, uri=\"%s\"\r\nUser-Agent: Mozilla/4.0 (Hydra)\r\n%s\r\n",
		type, miscptr, webtarget, login, realm, buffer, nonce, algo, miscptr, header);
      }
    }
  }

}
#endif
