
#include <stdio.h>
#include <string.h>
#include "ntlm.h"
#include "hydra-mod.h"

#define AUTH_CLEAR 0
#define AUTH_APOP 1
#define AUTH_LOGIN 2
#define AUTH_PLAIN 3
#define AUTH_CRAMMD5 4
#define AUTH_CRAMSHA1 5
#define AUTH_CRAMSHA256 6
#define AUTH_DIGESTMD5 7
#define AUTH_NTLM 8
#define AUTH_BASIC 9

void sasl_plain (char *result, char *login, char *pass);

#ifdef LIBOPENSSLNEW
  #include <openssl/md5.h>
  #include <openssl/sha.h>

  void sasl_cram_md5 (char *result, char *pass, char *challenge);
  void sasl_cram_sha1 (char *result, char *pass, char *challenge);
  void sasl_cram_sha256 (char *result, char *pass, char *challenge);
  void sasl_digest_md5 (char *result, char *login, char *pass, char *buffer, char *miscptr, char *type, char *webtarget, int webport, char *header);
#endif
