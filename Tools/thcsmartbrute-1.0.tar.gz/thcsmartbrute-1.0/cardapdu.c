
// thcsmartbrute  <gamma@thc.org>
//
#include "reader.h"
#include "cardapdu.h"
#include "reader.h"

int
gsm_readbinary
(unsigned char *response, unsigned int maxresponselen, unsigned char ofhi,  unsigned char oflo, unsigned char numbytes)
{
        LONG    rv;
        unsigned char    pbSendBuffer[MAXSENDBUFFER];

        pbSendBuffer[0] = 0xA0;
        pbSendBuffer[1] = 0xB0; // GSM 11.11 READ BINARY
        pbSendBuffer[2] = ofhi;
        pbSendBuffer[3] = oflo;
        pbSendBuffer[4] = numbytes;
        dwSendLength = 5;
        dwRecvLength = maxresponselen;

        rv = SCardTransmit(hCard, SCARD_PCI_T0, pbSendBuffer, dwSendLength,
                        &pioRecvPci, response, &dwRecvLength);
        PCSC_ERROR(rv, "SCardTransmit")

        if ( (response[dwRecvLength-2] != 0x90) && (response[dwRecvLength-1]!=0x00) ) {         
                outputresponse(response[dwRecvLength-2], response[dwRecvLength-1]);
                return (-2);
        }
        
        return dwRecvLength-2;
}




	int
gsm_verifypin (char *pin, unsigned char pintype)
// pin: string representation of the smartcards pin
// pintype: 1 for gsm card pin1
// 	    2 for gsm card pin2
// -1 on error
{
        LONG            rv;
        int             i;
        
        if (!pin)       
                return (-1);

        if ( (pintype!=0x01) && (pintype!=0x02)) {
		// wrong pintupe
		return (-1);
	}

        pbSendBuffer[0] = 0xA0;
        pbSendBuffer[1] = 0x20;
        pbSendBuffer[2] = 0x00;
        pbSendBuffer[3] = pintype;
        pbSendBuffer[4] = 0x08;

        for (i=0; i < 8; i++) {
                if (i>=strlen(pin))  {
                        pbSendBuffer[5+i] = 0xff;
                } else {
                        pbSendBuffer[5+i] = *(pin+i);
                }
        }

        dwSendLength = 5 + 8;
        dwRecvLength = sizeof(pbRecvBuffer);

        rv = SCardTransmit(hCard, SCARD_PCI_T0, pbSendBuffer, dwSendLength,
                &pioRecvPci, pbRecvBuffer, &dwRecvLength);
        PCSC_ERROR(rv, "SCardTransmit")

        if ( (pbRecvBuffer[0]!=0x90) && (pbRecvBuffer[1]!=0x00) ) {
                fprintf(stderr, "PIN%d NOT ACCEPTED!\n", pintype);
                outputresponse(pbRecvBuffer[0], pbRecvBuffer[1]);
                return (-1);                                                    
        } else {
                if (verboseflag) {
                        fprintf(stdout, "PIN accepted.\n");
                }
        }

        return 0;
}


int                                                                          
gsm_custom (unsigned char *response, unsigned int maxresponselen, 
BYTE cla, BYTE ins, BYTE p1, BYTE p2, BYTE p3,
unsigned char *payload, unsigned int payloadlen)
{
        LONG    rv;
        char    pbSendBuffer[MAXSENDBUFFER];

        pbSendBuffer[0] = cla;
        pbSendBuffer[1] = ins;
        pbSendBuffer[2] = p1;
        pbSendBuffer[3] = p2;
        pbSendBuffer[4] = p3;

        if (payload)
                memcpy(&pbSendBuffer[5], payload, payloadlen);

        dwSendLength = 5 + payloadlen;
        dwRecvLength = maxresponselen;
        rv = SCardTransmit(hCard, SCARD_PCI_T0, pbSendBuffer, dwSendLength,
                        &pioRecvPci, response, &dwRecvLength);
        if (rv!= SCARD_S_SUCCESS) return -1;
        /*PCSC_ERROR(rv, "SCardTransmit") */

        return dwRecvLength;
}



int
gsm_getresponse
(unsigned char *response, unsigned char numbytes)
{
        LONG    rv;
        unsigned char    pbSendBuffer[MAXSENDBUFFER];

        pbSendBuffer[0] = 0xA0;
        pbSendBuffer[1] = 0xC0; // GSM 11.11  GET RESPONSE
        pbSendBuffer[2] = 0;
        pbSendBuffer[3] = 0;
        pbSendBuffer[4] = numbytes;
        dwSendLength = 5;                                                       

        rv = SCardTransmit(hCard, SCARD_PCI_T0, pbSendBuffer, dwSendLength,
                &pioRecvPci, response, &dwRecvLength);
        PCSC_ERROR((long unsigned int)rv, "SCardTransmit")

        if ( (response[dwRecvLength-2] != 0x90) && (response[dwRecvLength-1]!=0x00) ) {
                outputresponse(response[dwRecvLength-2], response[dwRecvLength-1]);
                return (-1);
        }

         return dwRecvLength;
}


int
iso7816_getresponse
(unsigned char *response, unsigned char numbytes)
{
        LONG    rv;
        unsigned char    pbSendBuffer[MAXSENDBUFFER];

        pbSendBuffer[0] = 0x00;	
        pbSendBuffer[1] = 0xC0; // GSM 11.11  GET RESPONSE
        pbSendBuffer[2] = 0;
        pbSendBuffer[3] = 0;
        pbSendBuffer[4] = numbytes;
        dwSendLength = 5;                                                       

        rv = SCardTransmit(hCard, SCARD_PCI_T0, pbSendBuffer, dwSendLength,
                &pioRecvPci, response, &dwRecvLength);
        PCSC_ERROR(rv, "SCardTransmit")

        if ( (response[dwRecvLength-2] != 0x90) && (response[dwRecvLength-1]!=0x00) ) {
                outputresponse(response[dwRecvLength-2], response[dwRecvLength-1]);
                return (-1);
        }

         return dwRecvLength;
}


