#ifndef __SW_H
#define __SW_H	1

#include <string.h>
#include <stdio.h>
#include <alloca.h>

char *
statusword2string(unsigned char sw1, unsigned char sw2);

int
outputresponse(unsigned char sw1, unsigned char sw2);

#endif



