#ifndef __CARDAPDU_H
#define __CARDAPDU_H 1

#include "config.h"

int
read_file(unsigned char filetype, unsigned char *response, unsigned int maxresponselen, unsigned char reclen, unsigned int *recordcount);

int
gsm_verifypin (char *pin, unsigned char pintype);


int gsm_custom (unsigned char *response, unsigned int maxresponselen, BYTE cla, BYTE ins, BYTE p1, BYTE p2, BYTE p3, unsigned char *payload, unsigned int payloadlen);


int
gsm_getresponse
(unsigned char *response, unsigned char numbytes);


#endif
