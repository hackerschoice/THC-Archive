#include "reader.h"

char            *curreader=NULL;
SCARDCONTEXT    hContext;
DWORD           dwReaders;
char *         mszReaders;
//LPTSTR          mszReaders;
SCARDHANDLE     hCard;
DWORD           dwActiveProtocol, dwReaderLen, dwState, dwProt, dwAtrLen;
BYTE            pbAtr[MAX_ATR_SIZE] = "";
char            pbReader[MAX_READERNAME] = "";
int             reader_nb;
SCARD_IO_REQUEST pioRecvPci;
BYTE            pbRecvBuffer[MAXRECVBUFFER];
BYTE            pbSendBuffer[MAXSENDBUFFER];
DWORD           dwSendLength, dwRecvLength;

extern DWORD		tprot;

int init_reader(void);
int finish_reader(void);

int                                                                
init_reader(void)
// out: 1 on error
{
        int     i;
        char	*ptr, **readers = NULL;
        int	nbReaders,readerindex;
        LONG	rv;

        rv = SCardEstablishContext(SCARD_SCOPE_SYSTEM, NULL, NULL, &hContext);
        if (rv != SCARD_S_SUCCESS)
        {      
 		printf("SCardEstablishContext: Cannot Connect to Resource Manager %lX\n", rv);
		return 1;
        }

        if (rv != SCARD_S_SUCCESS) {
                printf("SCardListReader: %lX\n", rv);
                return 1;
        }


        rv = SCardListReaders(hContext, NULL, NULL, &dwReaders);
        if (rv != SCARD_S_SUCCESS)
        {
                printf("SCardListReader: %lX\n", rv);
                return 1;
        }

        mszReaders = malloc(sizeof(char)*dwReaders);
        if (mszReaders == NULL)
        {
                printf("malloc: not enough memory\n");
                return 1;
        }

        rv = SCardListReaders(hContext, NULL, mszReaders, &dwReaders);
        if (rv != SCARD_S_SUCCESS) {
                printf("SCardListReader: %lX\n", rv);
                return 1;
        }

       /* Extract readers from the null separated string and get the totalx
        * number of readers */

        nbReaders = 0;
        ptr = mszReaders;
        while (*ptr != '\0')
        {
                ptr += strlen(ptr)+1;
                nbReaders++;
        }
        if (nbReaders == 0)
        {
                printf("No reader found\n");
                return 1;
        }

        /* allocate the readers table */
        readers = malloc(nbReaders* sizeof(char *));
        if (NULL == readers)
        {
                printf("Not enough memory for readers[]\n");
                exit (-1);
        }
        /* fill the readers table */
        nbReaders = 0;

        ptr = mszReaders;
        while (*ptr != '\0')
        {
                if (verboseflag)
                         printf("%d: %s\n", nbReaders, ptr);
                readers[nbReaders] = ptr;
                ptr += strlen(ptr)+1;
                nbReaders++;
        }

        if (readerindex != -1) {
                if (verboseflag) 
                        fprintf(stdout, "Using Reader #%d\n",readerindex);
                if (readerindex < 0 || readerindex >= nbReaders) {
                        fprintf(stdout, "Wrong reader index %d\n",readerindex);
                        return (1);
                }
        }

        curreader = readers[reader_nb];
        /* connect to a card */
        dwActiveProtocol = -1;
        rv = SCardConnect(hContext, readers[reader_nb], SCARD_SHARE_EXCLUSIVE,
                tprot, &hCard, &dwActiveProtocol);
        if (verboseflag) 
                fprintf(stdout," Protocol: %ld\n", dwActiveProtocol);
        PCSC_ERROR(rv, "SCardConnect")

        /* get card status */
        dwAtrLen = sizeof(pbAtr);
        dwReaderLen = sizeof(pbReader);
        rv = SCardStatus(hCard, /*NULL*/ pbReader, &dwReaderLen, &dwState, &dwProt,pbAtr, &dwAtrLen);
        if (verboseflag) {
                fprintf(stdout," Reader: %s (length %ld bytes)\n", pbReader, dwReaderLen);
                fprintf(stdout," State: 0x%lX\n", dwState);
                fprintf(stdout," Prot: %ld\n", dwProt);
                fprintf(stdout," ATR (length %ld bytes):", dwAtrLen);
                for (i=0; i<dwAtrLen; i++)
                        fprintf(stdout, " %02X", pbAtr[i]);
                fprintf(stdout, "\n");
        }

        return (0);
}


int
finish_reader(void)
//
// return: 1 on error
// 	   0 no error
{
        int     i;
        LONG    rv;

        rv = SCardDisconnect(hCard, SCARD_LEAVE_CARD);
        PCSC_ERROR(rv, "SCardDisconnect")

        /* We try to leave things as clean as possible */
        rv = SCardReleaseContext(hContext);
        if (rv != SCARD_S_SUCCESS) {                       
                  fprintf(stderr, "SCardReleaseContext: %s (0x%lX)\n", pcsc_stringify_error(rv),rv);
                  return 0;
        }
        
        return 1;
}       








