#ifndef TRUE
#define TRUE 1
#endif

#ifndef FALSE
#define FALSE 0
#endif

#ifndef __MAIN_H
#define __MAIN_H 1

#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>
#include <string.h>
#include <alloca.h>
#include <getopt.h>

#include "config.h"

#include <wintypes.h>


struct ClaIns {
        char            *name;  // pointer to ascii-name of instruction
        unsigned char   cla;    // class
        unsigned char   ins;    // instruction
};

struct _ClaIns {
        char    *name;  // pointer to ascii-name of instruction
        BYTE    cla;    // class
        BYTE    ins;    // instruction
        BYTE    p1,p2,p3; // parameters         
		BYTE 	sw1,sw2; // result after 1st
        char            *payload;
        int             payloadlen;

        BYTE    isFile;
        BYTE    needsPIN;
        BYTE    incorrectTLV;
        unsigned char   *text;  // output text
};

#endif

