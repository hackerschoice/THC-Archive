#ifndef __READER_H
#define __READER_H 1


#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "config.h"
#include <wintypes.h>
#include <PCSC/reader.h>
#include <PCSC/winscard.h>
#include <PCSC/wintypes.h>

extern int		verboseflag;

/* PCSC error message pretty print */


#define PCSC_ERROR(rv, text) \
if (rv != SCARD_S_SUCCESS) \
{ \
        printf(text ": %s (0x%lX)\n", pcsc_stringify_error(rv), rv); \
        return (-1); \
} \
else \
{ \
        if (verboseflag) \
                 printf(text ": OK\n\n"); \
}

//#define PCSC_ERROR(rv, text) { }

#ifndef MAXSENDBUFFER
#define MAXSENDBUFFER   1024
#endif
#ifndef MAXRECVBUFFER
#define MAXRECVBUFFER   1024
#endif


int init_reader(void);
int finish_reader(void);     

//extern int		verboseflag;
extern char            *pin1;
extern char            *pin2;

extern char            *curreader;
extern LONG	    hContext;
extern DWORD           dwReaders; 
extern char *		mszReaders;
//extern LPTSTR          mszReaders;
extern SCARDHANDLE     hCard;
extern DWORD           dwActiveProtocol, dwReaderLen, dwState, dwProt, dwAtrLen;
//extern BYTE            pbAtr[MAX_ATR_SIZE];
//extern char            pbReader[MAX_READERNAME];
extern int             reader_nb;
extern SCARD_IO_REQUEST pioRecvPci;
extern BYTE            pbRecvBuffer[MAXRECVBUFFER];
extern BYTE            pbSendBuffer[MAXSENDBUFFER];
extern DWORD           dwSendLength, dwRecvLength;


#endif	/* ifndef __READER_H */
