#include "sw.h"

char *
statusword2string(unsigned char sw1, unsigned char sw2)
// Input: sw1,sw2	The response of a card APDU execution 
// Output: string describing the Error message of (sw1,sw2)
// returns NULL on unknown sw
{
	char result[1024];
	if ( (sw1==0x90) && (sw2==0x00) )
		return strdup("normal ending of the command.");
	
	switch (sw1) {
		case 0x91:
			snprintf(result, sizeof(result)-1, 
				"normal ending of the command with 0x%.2x extra information", sw2);
			break;
		case 0x9e:
			snprintf(result, sizeof(result)-1,
			"SIM Data Download ERROR but 0x%.2x follow", sw2);
			break;
		case 0x9f:
			snprintf(result, sizeof(result)-1,
			"Response got 0x%.2x bytes...", sw2);
			break;
		case 0x93:
			strcpy(result, "SIM Application Toolkit is busy.");
			break;
		case 0x92:
			if (sw2 < 0x40) {
			snprintf(result, sizeof(result)-1,
			"command successful but after using internal update retry routine using %d times", sw2);
			} else {
			strcpy(result, "Memory problem.");
			}
			break;
		case 0x94:
			switch (sw2) {
				case 0x00:
					strcpy(result,"no EF selected");
					break;
				case 0x02:
					strcpy(result,"out of range");
					break;
				case 0x04:
					strcpy(result,"file ID not found or pattern not found.");
					break;
				case 0x08:
					strcpy(result,"file is inconsistent with the command.");
					break;
				default:
					strcpy(result,"ERROR DECODING: INVALID SW2");
					break;
			}
			break;
		case 0x98:
			switch (sw2) {
				case 0x02:
					strcpy(result, "no CHV initialized");
					break;
				case 0x04:
					strcpy(result, "access condition not fullfilled");
					break;
				case 0x08:
					strcpy(result, "no contradiction with DHV status");
					break;
				case 0x10:
					strcpy(result, "in contradiction with invalidation status");
					break;
				case 0x40:
					strcpy(result, "unsuccessful CHV/UNBLOCK CHV verification and no attemp left or CHV/UNBLOCK CHV blocked");
					break;
				case 0x50:
					strcpy(result, "increase cannot be performed, max value reached");
					break;
				default:
					strcpy(result, "DECODING ERROR: invalid/unknown SW2");
					break;
			}
			break;
		case 0x67:
			if (sw2 == 0) {
				strcpy(result, "incorrect parameter p3");
			} else {
				strcpy(result, "CRC error");
			}
			break;
		case 0x68:
			snprintf(result, sizeof(result)-1, "instruction of classbyte not supported");
			break;
		case 0x69:
			switch (sw2) {
			case 0x00:
				strcpy(result, "Command not allowed");
				break;
			case 0x81:
				strcpy(result, "Command incompatibel to data structure");
				break;
			case 0x82:
				strcpy(result, "Incorrect security level");
				break;
			case 0x83:
				strcpy(result, "Authenticationmethod blocked");
				break;
			case 0x84:
				strcpy(result, "Referecend data is reversable blocked");
				break;
			case 0x85:
				strcpy(result, "User requirement not achieved");
				break;
			case 0x86:
				strcpy(result, "Command not allowed. (no EF selected");
				break;
			case 0x87:
				strcpy(result, "Expected secure messaging objects missing");
				break;
			case 0x88:
				strcpy(result, "secure messaging dataobjects incorrect");
				break;

			default:
				break;
			}
			break;
		case 0x6a:
			switch (sw2) {
			case 0x00:
				strcpy(result, "Incorrect parameter p1/p2");
				break;
			default:
				break;
			}
			break;
		case 0x6b:
			strcpy(result, "incorrect parameter p1 or p2");
			break;
		case 0x6d:
			strcpy(result, "unknown instruction code given in command");
			break;
		case 0x6e:
			strcpy(result, "wrong instruction class in command");
			break;
		case 0x6f:
			strcpy(result, "technical problem with no diagnostic");
			break;
		case 0x62:
			switch (sw2) {
			case 0x81:
				strcpy(result, "Returned data could contain errors");
				break;
			case 0x82:	
				strcpy(result, "Less than Le bytes read cause of unexpected end of file");
				break;
			case 0x83:
				strcpy(result, "Selected file unreversible locked");
				break;
			case 0x84:
				strcpy(result, "File Control Information not structured after iSO 7816-4");
				break;

			default:
				strcpy(result, "Warning: non violent memory got changed.");
				break;
			}
			break;
		
		default:
			return 0;
			break;
	}

	return strdup(result);
}

int
outputresponse(unsigned char sw1, unsigned char sw2)
{
	unsigned short int 	sw;

	fprintf(stdout, "\tResponse: 0x%.2X0x %.2X [%s]\n", sw1,sw2, statusword2string(sw1,sw2));

	return 0;
}

