
// thcsmartbrute  <gamma@thc.org>

#include "main.h"
#include "reader.h"
#include "sw.h"

//#define	VERSION 	"0.2.3"

//#define MAXSENDBUFFER	1024
//#define MAXRECVBUFFER	1024

int	verboseflag=  FALSE;
BOOL	simmode = TRUE;
int	readerindex =-1;
int	readflag = FALSE;
char	*pin1 = NULL;
char	*pin2 = NULL;

int	tmode = 0;	//  indicates which mode of {t0,t1}
DWORD	tprot = SCARD_PROTOCOL_T0;
int	skipcritical = FALSE;	// skip critical instructions ?
BOOL	undoconly = FALSE;
BOOL	fastresults = FALSE;
int	helpflag=0;

char	*bruteclass = NULL;
BOOL	bruteclassset = FALSE;
int	bruteins = 0;
BOOL	bruteinsset = FALSE;
int	p1p2flag = 0;

// bruteforce P3 parameters
BYTE	p3class = 0;
BYTE	p3ins = 0;
int	p3flag = 0;


// p1 and p2 parameter from the command line
BYTE	givenp1 = 0;
BYTE	givenp2 = 0;


struct _ClaIns foundInstructions[0xff * 0xff];
int foundInstructionsPTR = -1;		// index ptr to 'foundInstructions'

// GSM 11.11
struct ClaIns VALID_INSTRUCTION_LIST [] = {
{ "SELECT", 0xa0, 0xa4 },
{ "STATUS", 0xa0, 0xf2 },
{ "READ BINARY", 0xa0, 0xb0 },
{ "UPDATE BINARY", 0xa0, 0xd6 },
{ "READ RECORD", 0xa0, 0xb2 },
{ "UPDATE RECORD", 0xa0, 0xdc },
{ "SEEK", 0xa0, 0xa2},
{ "INCREASE", 0xa0, 0x32 },
{ "VERIFY CHV", 0xa0, 0x20 },
{ "CHANGE CHV", 0xa0, 0x24 },
{ "DISABLE CHV", 0xa0, 0x26 },
{ "ENABLE CHV", 0xa0, 0x28 },
{ "UNBLOCK CHV", 0xa0, 0x2c },
{ "INVALIDE", 0xa0, 0x04 },
{ "REHABILITATE", 0xa0, 0x44 },
{ "RUN GSM ALGORITHM", 0xa0, 0x88 },
{ "SLEEP", 0xa0, 0xfa},
{ "GET RESPONSE", 0xa0, 0xc0},
{ "TERMINAL PROFILE", 0xa0, 0x10},
{ "ENVELOPE", 0xa0, 0xc2},
{ "FETCH", 0xa0, 0x12},
{ "TERMINAL RESPONSE", 0xa0, 0x14},


// GlobalPlatform Card Specification 2.1.1
{ "DELETE", 0x80, 0xe4},
{ "DELETE", 0x84, 0xe4},
{ "GET DATA", 0x00, 0xca},
{ "GET DATA", 0x80, 0xca},
{ "GET DATA", 0x84, 0xca},
{ "GET STATUS", 0x80, 0xf2},
{ "GET STATUS", 0x84, 0xf2},
{ "INSTALL", 0x80, 0xe6},
{ "INSTALL", 0x84, 0xe6},
{ "LOAD", 0x80, 0xe8},
{ "LOAD", 0x84, 0xe8},
{ "MANAGE CHANNEL", 0x00, 0x70},
{ "PUT KEY", 0x80, 0xd8},
{ "PUT KEY", 0x84, 0xd8},
{ "SELECT", 0x00, 0xa4},
{ "SET STATUS", 0x80, 0xf0},
{ "SET STATUS", 0x84, 0xf0},
{ "STORE DATA", 0x80, 0xe2},
{ "STORE DATA", 0x84, 0xe2},

// ISO 7816 part 4
{ "DEACTIVATE FILE", 0x00, 0x04 },
{ "ERASE RECORD/S", 0x00, 0x0c} ,
{ "ERASE BINARY", 0x00, 0x0e},
{ "ERASE BINARY", 0x00, 0x0f},
{ "PERFORM SCQL OPERATION", 0x00, 0x10},
{ "PERFORM TRANSACTION OPERATION", 0x00, 0x12},
{ "PERFORM USER OPERATION", 0x00, 0x14},
{ "VERIFY", 0x00, 0x20 },
{ "VERIFY", 0x00, 0x21 },
{ "MANAGE SECURITY ENVIRONMENT", 0x00, 0x22},
{ "CHANGE REFERENCE DATA", 0x00, 0x24},
{ "DISABLE VERIFICATION REQUIREMENT", 0x00, 0x26},
{ "ENABLE VERIFICATION REQUIREMENT", 0x00, 0x28},
{ "PERFORM SECURITY OPERATION", 0x00, 0x2a},
{ "RESET RETRY COUNTER", 0x00, 0x2c},
{ "ACTIVATE FILE", 0x00, 0x44},
{ "GENERATE ASYMMETRIC KEY PAIR", 0x00, 0x46},
{ "MANAGE CHANNEL", 0x00, 0x70},
{ "EXTERNAL/MUTUAL AUTHENTICATE", 0x00, 0x82},
{ "GET CHALLENGE", 0x00, 0x84},
{ "GENERAL AUTHENTICATE", 0x00, 0x86},
{ "GENERAL AUTHENTICATE", 0x00, 0x87},
{ "INTERNAL AUTHENTICATE", 0x00, 0x88},
{ "SEARCH BINARY", 0x00, 0xa0},
{ "SEARCH BINARY", 0x00, 0xa1},
{ "SEARCH RECORD", 0x00, 0xa2},
{ "ISO7816 SELECT", 0x00, 0xa4},
{ "ISO7816 READ BINARY", 0x00, 0xb0},
{ "ISO7816 READ BINARY", 0x00, 0xb1},
{ "ISO7816 READ RECORD/S", 0x00, 0xb2},
{ "ISO7816 READ RECORD/S", 0x00, 0xb3},
{ "ISO7816 GET RESPONSE", 0x00, 0xc0},
{ "ISO7816 ENVELOPE", 0x00, 0xc2},
{ "ISO7816 ENVELOPE", 0x00, 0xc3},
{ "GET DATA", 0x00, 0xca},
{ "GET DATA", 0x00, 0xcb},
{ "ISO7816 WRITE BINARY", 0x00, 0xd0},
{ "ISO7816 WRITE BINARY", 0x00, 0xd1},
{ "ISO7816 WRITE RECORD", 0x00, 0xd2},
{ "ISO7816 UPDATE BINARY", 0x00, 0xd6},
{ "ISO7816 UPDATE BINARY", 0x00, 0xd7},
{ "PUT DATA", 0x00, 0xda},
{ "PUT DATA", 0x00, 0xdb},
{ "ISO7816 UPDATE RECORD", 0x00, 0xdc},
{ "ISO7816 UPDATE RECORD", 0x00, 0xdd},
{ "CREATE FILE", 0x00, 0xe0},
{ "APPEND RECORD", 0x00, 0xe2},
{ "DELETE FILE", 0x00, 0x0e4},
{ "TERMINATE DF", 0x00, 0xe6},
{ "TERMINATE EF", 0x00, 0xe8},
{ "TERMINATE CARD USAGE", 0x00, 0xfe},
{ NULL, 0x00, 0x00}
};


struct ClaIns CRITICAL_INSTRUCTION_LIST [] = {
{ "DEACTIVATE FILE", 0x00, 0x04 },
{ "DELETE FILE", 0x00, 0x0e4},
{ "TERMINATE DF", 0x00, 0xe6},
{ "TERMINATE EF", 0x00, 0xe8},
{ "TERMINATE CARD USAGE", 0x00, 0xfe},

{ "VERIFY CHV", 0xa0, 0x20 },
{ "CHANGE CHV", 0xa0, 0x24 },
{ "DISABLE CHV", 0xa0, 0x26 },

{ NULL, 0x00, 0x00}
};

struct ClaIns faststart_foundlist [0xff * 0xff]; 	

// ------------------------------------------------------------------

void usage(char **argv);

// --------------------------------------------------------------------------

int xtoi(char* xs, int* result)	{
// convert 8 char hex string to integer
// 
// return
// 1	nothing to convert
// 2	bigger than 32bits
// 4	hex conversion error
//
	size_t szlen = strlen(xs);
	int i, xv, fact;
  
	if (szlen <= 0) {
		// nothing to convert
		return 1;
	}

	// Converting more than 32bit hexadecimal value?
	if (szlen>8) {
		return 2; // exit
        }

	// Begin conversion here
	*result = 0;
	fact = 1;
             
	// Run until no more character to convert
	for(i=szlen-1; i>=0 ;i--)	{
		if (isxdigit(*(xs+i)))	{
			if (*(xs+i)>=97) {
			xv = ( *(xs+i) - 97) + 10;
			}
			else 	if ( *(xs+i) >= 65)	{
				xv = (*(xs+i) - 65) + 10;
				}
				else	{
				xv = *(xs+i) - 48;
				}
				*result += (xv * fact);
				fact *= 16;
				}
			else	{
			// Conversion was abnormally terminated
			// by non hexadecimal digit, hence
			// returning only the converted with
			// an error value 4 (illegal hex character)
			return 4;
			}
		}
	
}

unsigned int
element_of_clainslist (BYTE cla, BYTE ins, struct ClaIns list[], char **name )
{
	int 	iselement = 0;
	int	i=0;

	while ( list[i].name && !iselement) {
		if ( (list[i].cla == cla) && (list[i].ins == ins) ) {
			*name = list[i].name;
			iselement = 1;
		}
		i++;
	}

	return (iselement);
}


int
is_instruction_valid 
(BYTE cla, BYTE ins, BYTE p1, BYTE p2, BYTE p3, BYTE *sw1, BYTE *sw2)
// checks if the gien instruction is a valid one
// returns 1 if valid
{
	LONG	rv;
	BYTE	response[256];
	int	ret;
	BOOL	valid = FALSE;

	rv = SCardDisconnect(hCard, SCARD_LEAVE_CARD);
	PCSC_ERROR(rv, "SCardDisconnect")
	rv = SCardConnect(hContext, curreader, SCARD_SHARE_EXCLUSIVE,
		tprot, &hCard, &dwActiveProtocol);

	ret = gsm_custom (response, sizeof (response),
		cla, ins, p1, p2, p3, NULL, 0);
	*sw1 = response [ret-2];
	*sw2 = response [ret-1];



	if ( (*sw1 != 0x68) && 
             (*sw1 != 0x6D) &&
             (*sw1 != 0x6E) 
                ) {
		// instruction seems to be valid
		valid = TRUE;
	}

	return (valid);
}
	
	
int
getFastResults(void)
// tries to check instructions in VALID_INSTRUCTION_LIST / known instruction list  first 
// this speeds up results
//
// return: always 0
{
	int 	i;
	int	foundindex;
	BYTE	cla, ins, p1, p2 , p3, sw1, sw2;
	char	*instructionname;

	p1 = p2 = p3 = i = foundindex = 0;
	fprintf(stderr, "Trying possible standard instructions first...\n");

	if (simmode) {
		while (VALID_INSTRUCTION_LIST[i].name) { 
			cla = VALID_INSTRUCTION_LIST[i].cla;
			ins = VALID_INSTRUCTION_LIST[i].ins;
			fprintf (stderr, "                                                                 \r");
			fprintf (stderr, "Checking for %.50s...\r",VALID_INSTRUCTION_LIST[i].name);
			if ( skipcritical && element_of_clainslist(cla, ins, CRITICAL_INSTRUCTION_LIST ,&instructionname) ) {
				fprintf(stderr, "skipping potential critical instruction [%s] CLA=0x%.2X INS=0x%.2X\n", instructionname, cla, ins);
				continue;
			}
			if (is_instruction_valid(cla, ins, p1, p2, p3, &sw1, &sw2)) {
				fprintf(stdout, "Found [possible %s] Instruktion:  CLA= 0x%.2X INS=0x%.2X returned sw %.2x %.2x [%s]\n", VALID_INSTRUCTION_LIST[i].name, cla, ins, sw1, sw2, statusword2string(sw1, sw2));
				faststart_foundlist[foundindex].cla = cla;
				faststart_foundlist[foundindex].ins = ins;
				faststart_foundlist[foundindex].name = strdup("unknown");
				foundindex++;
				foundInstructionsPTR ++;
				foundInstructions[foundInstructionsPTR].cla = cla;
				foundInstructions[foundInstructionsPTR].ins = ins;
				foundInstructions[foundInstructionsPTR].p1 = p1;
				foundInstructions[foundInstructionsPTR].p2 = p2;
				foundInstructions[foundInstructionsPTR].p3 = p3;
				

			}
			i++;
		}
	}

	faststart_foundlist[foundindex].name=NULL;

	return 0;
}

int
get_valid_instructions (FILE *fout, FILE *foutb)
//
// return: always 0
{
	unsigned int	cla, ins, p1, p2 , p3;
	BYTE		sw1, sw2;
	int		ret,i,a;
	int		isundocumented;
	char		*undocstring = strdup("UNDOCUMENTED");
	char		*instructionname = NULL;
	int		clalist[257];
	int 		rv;
	char 		delim[] = ",";
	char 		*result = NULL;
		
	p1 = 0x00;
	p2 = 0x00;
	p3 = 0x00;

	// default class list 
	for (i=0 ; i<=0xff; i++)
		clalist[i] = i;
	
	// -1 marks the end of the class list "clalist"
	clalist[256]=-1;

	if (bruteclassset) {
		i=0;
		result = strtok(bruteclass, delim);
		while( result != NULL ) {
			rv=xtoi(result, &clalist[i]);
			if (rv!=0)	{
				fprintf(stderr,"Classlist format error. Exiting...\n");
				exit(-1);
				}
			result = strtok( NULL, delim);
			i++;
			}
		clalist[i] = -1;
	}
	
	if (fastresults) {
		fprintf(stdout, "Start with Classes 0x00, 0x80 and 0xA0 first...\n");
		
		// put 0x00m 0x80 and 0xA0 at the beginning
		clalist[0] = 0x00;
		clalist[1] = 0x80;
		clalist[2] = 0xa0;
		// replace the ones above with the normal 0x01 and 0x02 ones
		clalist[0x80] = 0x01;
		clalist[0xa0] = 0x02;
	}

	fprintf (stderr, "Testing with P1=%.2X P2=%.2X P3=%.2X...\n",p1,p2,p3);
	i=0;	// class iterator
	while ((cla=clalist[i++])!=-1) {	// -1 marks the end
		for (ins=0x00; ins <= 0xff; ins++) {
			if (bruteinsset)	ins=bruteins;				
			if ( fastresults && element_of_clainslist(cla, ins, faststart_foundlist,&instructionname) ) {
				// skipping cla/ins combinations for the results in 
				// fast results
				if (verboseflag)
					fprintf(stderr, "already found [%s] CLA=%.2X INS=%.2X\n",instructionname, cla, ins);
				continue;
				}
			if ( skipcritical && element_of_clainslist(cla, ins, CRITICAL_INSTRUCTION_LIST, &instructionname) ) {
				fprintf(stderr, "skipping potential critical instruction [%s] CLA=0x%.2X INS=0x%.2X\n", instructionname, cla, ins);
				continue;
			}
			fprintf(stderr, "Testing CLA=%.2X INS=%.2X\r", cla, ins);
			
			if (is_instruction_valid (cla,ins,p1,p2,p3,&sw1, &sw2)) {
				instructionname = undocstring;

				// update the list of found instructions
				foundInstructionsPTR ++;
				foundInstructions[foundInstructionsPTR].cla = cla;
				foundInstructions[foundInstructionsPTR].ins = ins;
				foundInstructions[foundInstructionsPTR].p1 = p1;
				foundInstructions[foundInstructionsPTR].p2 = p2;
				foundInstructions[foundInstructionsPTR].p3 = p3;
				

				// instruction is valid
				if ( !element_of_clainslist(cla,ins, VALID_INSTRUCTION_LIST,&instructionname) ) {
					isundocumented = 1;
				} else { isundocumented = 0; }
				
				if (undoconly && isundocumented) { 
					fprintf(fout, "Found undocumented Instruction: CLA= 0x%.2X INS=0x%.2X returned %.2x %.2x [%s] ", cla, ins, sw1, sw2, statusword2string(sw1, sw2));
				} 

				if (!undoconly) {
					fprintf(fout, "Found valid instruction: [possible %s] CLA= 0x%.2X INS=0x%.2X returned %.2x %.2x [%s] ", instructionname, cla, ins, sw1, sw2, statusword2string(sw1, sw2));
				}
				fprintf(fout, "\n");

			}	//TODO maybe add feature to autoprobe p1p2
			if (bruteinsset) break;
		}

		if ( (sw1 == 0x6E) && (sw2 == 0x00) ) {
			fprintf(stderr, "Warning Class %.2X may not be supported! Got SW1=0x6e SW2=0x00 as return value...\n", cla);
			// CLA not supported
		}

		if ( (sw1 == 0x6D) && (sw2 == 0x00) ) {
			// CLA supported but INS not available/valid
		}

		if ( (sw1 == 0x6B) && (sw2 == 0x00) ) {
			// CLA, INS correct but P1 P2 incorrect
		}

		if ( (sw1 == 0x67) && (sw2 == 0x00) ) {
			// CLA INS P1 P2 supported but P3 incorrect
		}

		if ( (sw1 == 0x6E) && (sw2 == 0x00) ) {
			// command not supported, no explicit error
		}

	}
	
	return (0);
}

		
		
int
bruteforceP1P2 (char *bruteclass, BYTE ins)
// brute force for P1,P2-Parameter
{
	unsigned int	p1, p2 , p3;
	BYTE 		sw1, sw2;
	int     	ret,i,cla;
	unsigned char   response[1024];
	LONG    	rv;
	char 		*result=NULL;
	char 		delim[]=",";
	int		clalist[257];

	// default set P3 to 0 
	// TODO: use command line argument
	p3 = 0x00;

	i=0;
	result = strtok(bruteclass, delim);
	while( result != NULL ) {
		rv=xtoi(result, &clalist[i]);
		if (rv!=0)	{
			fprintf(stderr,"Classlist format error. Exiting...\n");
			exit(-1);
			}
		result = strtok( NULL, delim);
		i++;
		}
	clalist[i] = -1;
	
	
	i=0;
	while((cla=clalist[i++])!=-1) {	
		fprintf(stdout, "Probing for valid (P1,P2) combinations for instruction CLA=%.2X INS=%.2X...\n", cla, ins);
		fflush(stdout);
		for (p1= 0x00; p1 <= 0xff; p1++)
		for (p2= 0x00; p2 <= 0xff; p2++)
		{
			fprintf(stderr, "CLA=%.2X INS=%.2X P1=%.2X P2=%.2X P3=%.2X ", cla, ins, p1, p2, p3);
			
			// send instruction to the card reader
			// ret == number of bytes retur
			ret = gsm_custom (response, sizeof (response), 
	                        cla, ins, p1, p2, p3, NULL, 0);
	                       
			// result are the last 2 bytes
			sw1 = response[ret-2];
			sw2 = response[ret-1];

			if (verboseflag) 
				fprintf(stderr, "sw1=%.2X sw2=%.2x [%s]\n",sw1,sw2, statusword2string(sw1,sw2));
			else 	fprintf(stderr, "\r");
			if ( (sw1!=0x6b) && (sw2!=0x00) ) {
				fprintf(stdout, "p1 = 0x%.2X p2 = 0x%.2X valid! returned %.2X %.2X [%s]\n",
					p1,p2, sw1, sw2,
					statusword2string(sw1,sw2));
			}
			
			if ( (sw1==0x68) && (sw2==0x00) ) {
				fprintf(stdout, "p1 = 0x%.2X p2 = 0x%.2X p3!=0x00 valid!\n",p1,p2);
			}	
			if ( (sw1==0x67) && (sw2==0x00) ) {
				 fprintf(stdout, "p1 = 0x%.2X p2 = 0x%.2X valid! p3 should be not 0x00!!\n",p1,p2);
			 }
		}
	}
	return 0;
}

int
bruteforceP3 (BYTE cla, BYTE ins, BYTE p1, BYTE p2)
// brute forces for the P3 parameter of the given instruction cla,ins,p1,p2
//
// return: always 0
{
	unsigned int 	p3;
	int     	ret;
	unsigned char   response[1024];
	BYTE		sw1,sw2;

	for (p3=0x00 ; p3 <= 0xff; p3++) 
	{
		fprintf(stderr, "CLA= %.2X INS=%.2X P1=%.2X P2=%.2X P3=%.2X\r", cla, ins, p1, p2, p3);
                ret = gsm_custom (response, sizeof (response), 
                        cla, ins, p1, p2, p3, NULL, 0);
		sw1 = response[ret-2]; sw2 = response[ret-1];

		if ( (sw1 != 0x67) && (sw2 != 0x00) ) {
			fprintf(stdout, "p3 = %.2X valid!\n", p3);
		}

	}

	return 0;
}



// ===========================================================


int
parseargv(int argc, char **argv)
{
	extern char	*optarg;
	int		option_index;
	int		c;
	char		*ptr; // for conversions

	struct option long_options[] = {
		/* These options set a flag. */
		{"verbose", no_argument,       &verboseflag, 1},
		{"simmode",   no_argument,       &simmode, 1},
		{"skipcritical", no_argument, &skipcritical, 1},
		{"undoconly", no_argument, &undoconly, 1},
		{"fastresults", no_argument, &fastresults, 1},
		{"help", no_argument, &helpflag, 1},	
		{"brutep1p2", no_argument, &p1p2flag, 1},
		{"brutep3", no_argument, &p3flag, 1},

		{"tmode",  required_argument, 0, 't'},
		{"chv1", required_argument, 0, 'p'},
		{"chv2", required_argument, 0, 'c'},
		{"class", required_argument, 0, 'a'},
		{"ins", required_argument, 0, 'b'},
		{"p1", required_argument, 0, 'd'},
		{"p2", required_argument, 0, 'e'},
	
		{"p3", required_argument, 0, 'f'},	// only for fingerprinting
		{"file", required_argument, 0, 'g'},	// only for fingerprinting

		{0, 0, 0, 0}	// end of list
	};

	// default: also criticial instructions
	skipcritical=0;
	// default: no verbose output
	verboseflag=0;

	fprintf(stderr, "%s Version %s gamma@thc.org \n\n",argv[0], VERSION);
	while ((c = getopt_long (argc, argv, "p:c:t:a:b:d:e:f:g:", long_options,& option_index)) != -1) {
		switch (c) {
			case 't': // smartcard transport mode t0 or t1
				tmode = atoi(optarg);
				if ( (tmode !=0) && (tmode!=1) ) {
					fprintf(stderr, "Sorry only T0 and T1 are supported (YET)! :-(\nExiting.\n");
					exit(-2);
				}
				if (tmode != 0)
					tprot = SCARD_PROTOCOL_T1;
					if (tmode > 1) {
						fprintf(stderr, "T2 or higher selected but currently unsupported! Using T1...\n");
					}
				break;
			case 'p': //pin1
				pin1 = strdup(optarg);
				break;
			case 'c': // pin2
				pin2 = strdup(optarg);
				break;
			case 'a': // class 
				bruteclass = strdup(optarg);
				bruteclassset=TRUE;
				break;
			case 'b': // ins instruction
				bruteins = atoi(optarg);
				bruteinsset=TRUE;
				break;
			case 'd': // p1 
				givenp1 = atoi(optarg);
				break;
			case 'e': // p2
				givenp2 = atoi(optarg);
				break;
			default: // error
				usage(argv);
				break;
		}
	}

	if (helpflag) 
		usage(argv);

	
	if (undoconly && fastresults) {
		fprintf(stderr,"'Faststart' does not work in combination with undocumented Instructions only !\nExiting...\n");
		exit(-1);
	}

	if (p1p2flag && fastresults) {
		fprintf(stderr, "Bruteforcing for P1,P2-Parameter does not work with --fastresults!\n");
		exit(-1);
	}

	if (p3flag) {
		p3class = atoi(bruteclass);
		p3ins = bruteins;
	}
	

	return 0;
}


void
usage(char **argv)
{
	fprintf(stderr, "Parameters:\n"
			"--chv1 pin1\tsets the CHV1 to pin1\n"
			"--chv2 pin2\tsets the CHV2 to pin2\n"
			"--simmode\twork in GSM SIM card mode\n"
			"--tmode mode\tsets the transfer mode to T0 or T1\n"
			"--skipcriticalk\tskip potential critical smartcard instructions\n"
			"--undoconly\tjust give out undocumented instructions\n"
			"--fastresults\tfast results, does not work with -u\n"
			"--help\t\tshows this help\n"
			"\nParameter probing functions:\n"
			"--class <CLASS>[,<CLASS>,<CLASS>....]\t\tset the classes to be tested (hex)\n"
			"--ins\t\tset the instruction value of the tested instruction\n"
			"--p1\t\tgives parameter p1\n"
			"--p2\t\tgives parameter p2\n"
			"--p3\t\tgives parameter p3\n"
			"--brutep1p2\tprobes for valid p1/p2 parameters with p3=0\n"
			"--brutep3\tprobes valid p3 with given --p1 and --p2\n"
			"\n"
	);

	exit (-1);
}

void
sanitycheck(void)
// return: Program stops on error
{
	int	ret;

	if ( (!pin1) && (!pin2) && simmode) {
		fprintf(stdout, "!!Warning!!! No CHV supplied. Some tests may fail... !\n");
		return;
	}
	if (pin1) {
		ret = gsm_verifypin(pin1, 1);
		if (ret == -1) {
			fprintf(stdout, "PIN1 not accepted! Exiting...\n");
			exit(-1);
		} else {
			fprintf(stdout, "PIN1 accepted.\n");
		}
	}
	if (pin2) {
		ret = gsm_verifypin(pin2, 2);
		if (ret == -1) {
			fprintf(stdout, "PIN2 not accepted! Exiting...\n");
			exit(-1);
		} else {
			fprintf(stdout, "PIN2 accepted.\n");
		}
	}

	return;
}


/*
 * =========================================================================
 * 				M A I N 
 * =========================================================================
 */

int 
main (int argc, char **argv)
{
	parseargv(argc, argv);

	// initialize smartcard reader
	if (init_reader())
		return (-1);

	// check if parameter combination / enough parameters given
	sanitycheck();

	if (p1p2flag) {
		bruteforceP1P2(bruteclass, bruteins);
		goto finished;
	}

	if (p3flag) {
		bruteforceP3 (p3class, p3ins, givenp1, givenp2);
		goto finished;
	}

	if (fastresults) 
		getFastResults();

	// default 
	get_valid_instructions(stdout,stdout);


finished:
	// deattach the reader
	if (finish_reader() ) {
		fprintf (stdout, "Reader unattached.\n");
	}

	fprintf(stdout, "Job done. Normal exit.\n");
	return 0;
}

