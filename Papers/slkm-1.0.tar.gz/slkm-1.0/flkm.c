/*
 * flkm.c
 * First Loadable Kernel Module for Solaris 2.7 (sparc/x86)
 * (c) 1999 by Plasmoid/THC <plasmoid@pimmel.com>
 * [THC] The Hacker's Choice - http://www.infowar.co.uk/thc  
 *
 * This is an empty module demonstrating the basic structure of loadable
 * kernel modules under Solaris.
 *
 * A documentation of the modules functions can be found in the corresponding
 * THC article at http://www.infowar.co.uk/thc/files/thc/slkm-1.0.html
 *
 *    Solaris Loadable Kernel Modules v1.0
 *    "Attacking Solaris with lodable kernel modules"
 *    by Plasmoid/THC
 *
 */
#include <sys/ddi.h>
#include <sys/sunddi.h>

/*
 * This is the loadable module wrapper.
 */
#include <sys/modctl.h>
extern struct mod_ops mod_miscops;

/*
 * Module linkage information for the kernel.
 */
static struct modlmisc modlmisc =
{
    &mod_miscops,
    "First Loadable Kernel Module",
};

static struct modlinkage modlinkage =
{
    MODREV_1,
    (void *) &modlmisc,
    NULL
};

int _init(void)
{
    int i;

    if ((i = mod_install(&modlinkage)) != 0)
	cmn_err(CE_NOTE, "Could not install module\n");
    else
	cmn_err(CE_NOTE, "flkm: successfully installed");

    return i;
}

int _info(struct modinfo *modinfop)
{
    return (mod_info(&modlinkage, modinfop));
}


int _fini(void)
{
    int i;

    if ((i = mod_remove(&modlinkage)) != 0)
	cmn_err(CE_NOTE, "Could not remove module\n");
    else
	cmn_err(CE_NOTE, "flkm: successfully removed");

    return i;
}
